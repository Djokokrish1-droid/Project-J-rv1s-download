╔══════════════════════════════════════════════════════════╗
║   J@rv1s — your Personal Agent                            ║
╚══════════════════════════════════════════════════════════╝

Thanks for downloading J@rv1s!

TO RUN (macOS):
  1. Unzip this folder (double-click the .zip).
  2. Double-click  "Launch J@rv1s.command"
  3. First launch sets everything up automatically (~1 min), then
     the J@rv1s window opens.
  4. Create an account or sign in to get started.

If macOS says "Apple could not verify ... Not Opened":
  This only means the app isn't code-signed yet — it's safe. Fix it once:

  EASIEST — open Terminal (Cmd-Space, type "Terminal"), paste this, hit Return:

      xattr -dr com.apple.quarantine ~/Downloads/JarvisSetup

  (change the path if you unzipped somewhere else). Then double-click
  "Launch J@rv1s.command" again — it opens normally from now on.

  OR, no Terminal: double-click it, click "Done", then open
  System Settings -> Privacy & Security -> scroll down -> "Open Anyway".
  (On older macOS you could right-click -> Open; Apple removed that in 15+.)

REQUIREMENTS:
  • macOS
  • Python 3 (most Macs have it; if not, the app will tell you —
    install from python.org or run:  xcode-select --install)

Prefer the web version? Visit our website and sign in — no download needed.
(Web automation is desktop-only.)

Questions: support@projectjarvis.app
Developed & Created by Krish Venkatraman and the Project J@rv1s Team.
