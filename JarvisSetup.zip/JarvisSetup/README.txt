J@rv1s — your Personal Agent

MAC:
  Double-click "Launch J@rv1s.command".
  First run sets things up (Python venv + dependencies, ~1 min).
  Sign in or create an account when the window opens.

  If macOS says "Apple could not verify ... Not Opened" (it just means the
  app isn't code-signed yet — it's safe), clear it once: open Terminal and run
      xattr -dr com.apple.quarantine ~/Downloads/JarvisSetup
  (adjust the path if you unzipped elsewhere), then double-click again.
  No-Terminal route: double-click -> Done -> System Settings ->
  Privacy & Security -> "Open Anyway".

WINDOWS:
  Double-click "Launch J@rv1s.bat".
  First run sets things up (Python venv + dependencies, ~1 min).
  Requires Python 3 from python.org (with "Add to PATH" checked).

After installing, click the Connectors page to plug J@rv1s into your
school portal (Google Classroom, Canvas, etc.) and let it pull every
assignment for you. Tasks appear in the Tasks page.

— Krish Venkatraman & the Project J@rv1s Team
   support@projectjarvis.app
