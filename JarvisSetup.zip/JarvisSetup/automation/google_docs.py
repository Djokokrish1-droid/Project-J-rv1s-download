"""Google Docs read + write for Assignment Autopilot.

Most Classroom assignments attach a Google Doc — the prompt usually lives
inside it, and the student is expected to write their answer there. So
Autopilot needs to both READ the attached doc (to understand the task) and
WRITE the answer into it.

READ  — we hit the doc's plain-text export endpoint while logged in:
          https://docs.google.com/document/d/<id>/export?format=txt
        This returns the doc's text with no canvas-scraping needed. Clean.

WRITE — Google Docs renders on a <canvas>, so we can't set innerText. Instead
        we open the editor, focus the editing surface, and drive the keyboard
        the way a human would: Ctrl/Cmd+A to select, then type the answer.
        Google's hidden input target captures the keystrokes and the doc
        autosaves. We verify by re-reading the export afterward.
"""
from __future__ import annotations
import re
import sys
import time
import urllib.parse


DOC_ID_RE = re.compile(r"/document/d/([a-zA-Z0-9_-]{20,})")


def extract_doc_ids(page) -> list[str]:
    """Find every Google Doc attached/linked on the current page, in order.
    Looks at anchor hrefs AND any embedded doc URLs in the DOM."""
    hrefs = page.evaluate(
        """() => Array.from(document.querySelectorAll('a[href]'))
                 .map(a => a.href)
                 .filter(h => h.includes('/document/d/'))"""
    ) or []
    ids: list[str] = []
    for h in hrefs:
        m = DOC_ID_RE.search(h)
        if m and m.group(1) not in ids:
            ids.append(m.group(1))
    return ids


def read_doc_text(page, doc_id: str, *, timeout_ms: int = 15_000) -> str:
    """Return the plain-text contents of a Google Doc via its export endpoint.
    Empty string if it can't be read (no access / not a doc / empty).

    Uses the context's APIRequestContext (shares the logged-in cookies) instead
    of page.goto — so it never triggers a download, never navigates the visible
    page away from the assignment/editor, and gets the raw body directly.
    """
    url = f"https://docs.google.com/document/d/{doc_id}/export?format=txt"
    try:
        resp = page.context.request.get(url, timeout=timeout_ms)
        if not resp.ok:
            print(f"[gdocs] read {doc_id}: HTTP {resp.status}", flush=True)
            return ""
        # If Google bounced us to a login/HTML page, it isn't the doc text.
        if "accounts.google.com" in resp.url:
            return ""
        text = (resp.text() or "").strip()
        if text[:40].lstrip().startswith(("<!DOCTYPE", "<html")):
            return ""
        return text
    except Exception as ex:
        print(f"[gdocs] read failed for {doc_id}: {ex}", flush=True)
        return ""


def write_to_doc(page, doc_id: str, answer: str, *, mode: str = "append",
                 timeout_ms: int = 25_000) -> dict:
    """Type `answer` into the Google Doc editor.

    mode:
      "append"  — go to the end of the doc, add two newlines, then type
      "replace" — select-all + delete, then type (wipes existing content)

    Returns {ok, before_len, after_len, error}. Verifies by re-reading export.
    """
    result = {"ok": False, "before_len": 0, "after_len": 0, "error": ""}
    edit_url = f"https://docs.google.com/document/d/{doc_id}/edit"

    # baseline content length (to confirm the write landed)
    before = read_doc_text(page, doc_id)
    result["before_len"] = len(before)

    try:
        print(f"[gdocs] opening editor for {doc_id}", flush=True)
        page.goto(edit_url, wait_until="domcontentloaded", timeout=timeout_ms)
        # Let the editor fully boot (it's heavy).
        page.wait_for_timeout(4500)

        mod = "Meta" if sys.platform == "darwin" else "Control"

        # Focus the editing surface. Google Docs puts the real input target in a
        # hidden iframe (.docs-texteventtarget-iframe). Clicking the canvas page
        # area places the cursor and routes keystrokes there.
        focused = False
        for sel in [".kix-canvas-tile-content", ".kix-appview-editor",
                    ".kix-page", "div.kix-appview-editor"]:
            try:
                el = page.locator(sel).first
                if el.count():
                    el.click(timeout=2500)  # auto-waits for actionability
                    focused = True
                    break
            except Exception:
                continue
        if not focused:
            # last resort: click roughly in the page body region
            try:
                page.mouse.click(620, 400)
                focused = True
            except Exception:
                pass

        page.wait_for_timeout(600)

        if mode == "replace":
            page.keyboard.press(f"{mod}+a")
            page.wait_for_timeout(200)
            page.keyboard.press("Delete")
            page.wait_for_timeout(300)
        else:  # append → jump to very end of doc
            page.keyboard.press(f"{mod}+End")
            page.wait_for_timeout(200)
            page.keyboard.press("Enter")
            page.keyboard.press("Enter")

        # Type the answer. keyboard.type sends real key events Docs captures.
        # Chunk long text so we don't overwhelm the input target.
        print(f"[gdocs] typing {len(answer)} chars…", flush=True)
        for chunk in _chunks(answer, 800):
            page.keyboard.type(chunk, delay=2)
            page.wait_for_timeout(120)

        # Give Docs a moment to autosave, then verify via a fresh export read.
        page.wait_for_timeout(3500)
        after = read_doc_text(page, doc_id)
        result["after_len"] = len(after)
        # Success = the doc grew (append) or now contains a chunk of our answer.
        probe = answer.strip()[:40]
        result["ok"] = (len(after) > len(before) + 10) or (probe and probe in after)
        if not result["ok"]:
            result["error"] = ("Typed into the doc but couldn't confirm it saved. "
                               "Open the doc to check — Docs may have been slow to autosave.")
    except Exception as ex:
        result["error"] = f"{type(ex).__name__}: {ex}"
    return result


def _chunks(s: str, n: int):
    for i in range(0, len(s), n):
        yield s[i:i + n]
