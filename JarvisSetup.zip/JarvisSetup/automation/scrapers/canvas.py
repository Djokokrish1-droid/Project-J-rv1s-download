"""Canvas LMS assignment scraper.

Canvas exposes a JSON REST API that works via the user's browser cookies
(no OAuth token required) — so we navigate Playwright to those endpoints
and parse the JSON straight out of the page body. Way more reliable than
DOM scraping (which breaks on every Canvas UI tweak).

Endpoints used (all under {base_url}):
  /api/v1/users/self/todo          → ungraded/incomplete items the user owes
  /api/v1/users/self/upcoming_events?type=assignment   → upcoming assignments
  /api/v1/courses?enrollment_state=active              → active course names

Canvas wraps JSON responses with `while(1);` (anti-XSSI). We strip it.

The user must supply their school's Canvas URL (e.g.
`https://canvas.harvard.edu`). Falls back to canvas.instructure.com.
"""
from __future__ import annotations
import json
import re
from pathlib import Path


CANVAS_DEFAULT_URL = "https://canvas.instructure.com"


class CanvasScraper:
    def __init__(
        self,
        profile_dir: Path | str,
        *,
        base_url: str | None = None,
        headless: bool = False,
        timeout_ms: int = 25_000,
    ):
        self.profile_dir = Path(profile_dir)
        self.profile_dir.mkdir(parents=True, exist_ok=True)
        self.base_url = (base_url or CANVAS_DEFAULT_URL).rstrip("/")
        self.headless = headless
        self.timeout_ms = timeout_ms

    def scrape_assignments(self) -> list[dict]:
        from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout

        results: list[dict] = []
        with sync_playwright() as pw:
            launch_kwargs = dict(
                user_data_dir=str(self.profile_dir),
                headless=self.headless,
                viewport={"width": 1280, "height": 900},
                args=["--disable-blink-features=AutomationControlled",
                      "--no-first-run", "--no-default-browser-check"],
            )
            try:
                ctx = pw.chromium.launch_persistent_context(channel="chrome", **launch_kwargs)
            except Exception:
                ctx = pw.chromium.launch_persistent_context(**launch_kwargs)
            ctx.add_init_script(
                "Object.defineProperty(navigator,'webdriver',{get:()=>undefined});"
                "window.chrome = window.chrome || {runtime:{}};"
            )
            page = ctx.pages[0] if ctx.pages else ctx.new_page()
            page.set_default_timeout(self.timeout_ms)

            try:
                # Step 1: open Canvas root so the user can log in (cached profile
                # means subsequent runs skip this).
                print(f"[canvas] Opening {self.base_url} …", flush=True)
                page.goto(self.base_url, wait_until="domcontentloaded")
                # Wait until user is past any login redirects (Canvas, Microsoft,
                # Google SSO, Classlink, etc.) — generous deadline for headed runs.
                if "/login" in page.url or "auth" in page.url or "sso" in page.url.lower():
                    if self.headless:
                        raise RuntimeError(
                            "Not logged in to Canvas. Run a headed sync first."
                        )
                    print("[canvas] Waiting for you to sign in (up to 3 min)…", flush=True)
                    import time as _t
                    deadline = _t.time() + 180
                    while _t.time() < deadline:
                        u = page.url
                        if "/login" not in u and "auth" not in u and "sso" not in u.lower():
                            break
                        _t.sleep(1)

                # Step 2: build course-id → name map.
                print("[canvas] Loading active courses…", flush=True)
                courses = _fetch_json(page, f"{self.base_url}/api/v1/courses"
                                       "?enrollment_state=active&per_page=100")
                course_names = {c["id"]: c.get("name", "") for c in (courses or [])}

                # Step 3: pull upcoming assignments (next 30 days).
                print("[canvas] Loading upcoming assignments…", flush=True)
                upcoming = _fetch_json(page, f"{self.base_url}/api/v1/users/self/"
                                       "upcoming_events?type=assignment&per_page=100") or []

                # Step 4: pull all todo items (pending, missing).
                print("[canvas] Loading to-do list…", flush=True)
                todo = _fetch_json(page, f"{self.base_url}/api/v1/users/self/"
                                   "todo?per_page=100") or []

                seen = set()

                # Parse upcoming events
                for ev in upcoming:
                    a = ev.get("assignment") or ev
                    aid = a.get("id") or ev.get("id")
                    if not aid: continue
                    ext = f"canvas:{aid}"
                    if ext in seen: continue
                    seen.add(ext)
                    course_id = a.get("course_id") or ev.get("course_id")
                    results.append({
                        "title": (a.get("title") or a.get("name") or "Untitled")[:200],
                        "link": a.get("html_url") or ev.get("html_url") or "",
                        "external_id": ext,
                        "subject": course_names.get(course_id, "")[:80],
                        "due": _iso_date(a.get("due_at") or ev.get("end_at") or ""),
                        "description": "",
                        "source": "canvas",
                    })

                # Parse todo (often catches missing/overdue items not in upcoming)
                for item in todo:
                    a = item.get("assignment") or {}
                    aid = a.get("id")
                    if not aid: continue
                    ext = f"canvas:{aid}"
                    if ext in seen: continue
                    seen.add(ext)
                    course_id = a.get("course_id")
                    results.append({
                        "title": (a.get("name") or "Untitled")[:200],
                        "link": a.get("html_url") or item.get("html_url") or "",
                        "external_id": ext,
                        "subject": course_names.get(course_id, "")[:80],
                        "due": _iso_date(a.get("due_at") or ""),
                        "description": "",
                        "source": "canvas",
                    })

                print(f"[canvas] Total assignments: {len(results)}", flush=True)
            finally:
                ctx.close()
        return results


# ── helpers ──────────────────────────────────────────────────────────────
def _fetch_json(page, url: str):
    """Fetch a Canvas JSON endpoint via the context's request (shares the
    logged-in cookies), strip the `while(1);` XSSI prefix, and parse. Returns
    None on any failure (caller defaults gracefully).

    Uses context.request instead of page.goto so we get the raw response body
    — not whatever Chrome's JSON viewer renders into the DOM — and we don't
    navigate the visible page around between endpoint calls.
    """
    try:
        resp = page.context.request.get(url, headers={"Accept": "application/json"})
        if not resp.ok:
            print(f"[canvas]   fetch {url}: HTTP {resp.status}", flush=True)
            return None
        body = resp.text() or ""
        # Strip Canvas's anti-XSSI prefix
        body = re.sub(r"^while\s*\(\s*1\s*\)\s*;\s*", "", body)
        # Find the first { or [ — handles any wrapped HTML/login page too
        m = re.search(r"[\[{]", body)
        if not m:
            return None
        return json.loads(body[m.start():])
    except Exception as ex:
        print(f"[canvas]   fetch failed for {url}: {ex}", flush=True)
        return None


def _iso_date(s: str) -> str:
    """Canvas returns ISO 8601 with time + timezone — keep just YYYY-MM-DD."""
    if not s:
        return ""
    m = re.match(r"(\d{4}-\d{2}-\d{2})", s)
    return m.group(1) if m else ""


def scrape(profile_dir, *, base_url=None, headless=False):
    return CanvasScraper(profile_dir, base_url=base_url, headless=headless).scrape_assignments()
