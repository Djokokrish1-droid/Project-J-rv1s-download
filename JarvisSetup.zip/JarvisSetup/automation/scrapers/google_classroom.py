"""Google Classroom assignment scraper using Playwright.

Strategy
--------
We open the Classroom To-do page (`/a/not-turned-in/all`) which lists every
upcoming assignment across all of a student's classes. Then we extract each
assignment card via DOM evaluation.

Two execution flows
-------------------
1. **Desktop / headed**: launches a real Chromium with a persistent profile
   directory so the user's Google login is cached across runs. First time
   the user sees the login page and signs in normally; subsequent runs
   reuse the cached session.

2. **Cloud / headless**: same code path with `headless=True`. Note: Google
   actively blocks headless Chromium for security ("This browser may not
   be secure"). The cleaner long-term answer is OAuth + Classroom API.
   We keep the option here for users whose schools allow it.

The scraper returns a normalized list of task dicts (title / link /
external_id / etc.) that `core/school.py` then upserts via `add_task()`.
"""
from __future__ import annotations
import re
from pathlib import Path


CLASSROOM_TODO_URL = "https://classroom.google.com/u/0/a/not-turned-in/all"
CLASSROOM_HOME_URL = "https://classroom.google.com/u/0/h"


class NotLoggedInError(RuntimeError):
    """Raised when Classroom redirects to accounts.google.com (no cached session)."""


class GoogleClassroomScraper:
    def __init__(
        self,
        profile_dir: Path | str,
        *,
        headless: bool = False,
        timeout_ms: int = 25_000,
        debug_dir: Path | str | None = None,
        credentials: dict | None = None,
    ):
        self.profile_dir = Path(profile_dir)
        self.profile_dir.mkdir(parents=True, exist_ok=True)
        self.headless = headless
        self.timeout_ms = timeout_ms
        self.credentials = credentials or None  # {'email','password'} or None
        self.debug_dir = Path(debug_dir) if debug_dir else None
        if self.debug_dir:
            self.debug_dir.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------
    def scrape_assignments(self) -> list[dict]:
        """Open Classroom and return a list of assignment dicts.

        Each dict has: title, link, external_id, subject, due, description,
        source. The expectation is the caller dedups on external_id before
        inserting into the user's task list.
        """
        from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout

        results: list[dict] = []
        with sync_playwright() as pw:
            # IMPORTANT: use the user's REAL Chrome (channel="chrome"), not
            # Playwright's bundled Chromium. Google's bot detection fingerprints
            # Chromium and blocks the sign-in. Real Chrome passes those checks.
            launch_kwargs = dict(
                user_data_dir=str(self.profile_dir),
                headless=self.headless,
                viewport={"width": 1280, "height": 900},
                args=[
                    "--disable-blink-features=AutomationControlled",
                    "--no-first-run",
                    "--no-default-browser-check",
                    # Kill Chrome's "Turn on sync / use this account" promo that pops
                    # after a Google web login — it parks the tab off Classroom and
                    # stalls detection. (We also drive straight to Classroom below.)
                    "--disable-sync",
                    "--disable-features=ChromeSigninIntercept,AccountConsistency,SigninInterceptBubble,SyncConsentOptional",
                ],
            )
            try:
                ctx = pw.chromium.launch_persistent_context(
                    channel="chrome", **launch_kwargs
                )
            except Exception:
                # Real Chrome not installed → fall back to bundled Chromium.
                # Google may still block, but at least we tried.
                ctx = pw.chromium.launch_persistent_context(**launch_kwargs)

            # Hide a couple of remaining automation fingerprints. Doesn't fool
            # everything, but kills the obvious `navigator.webdriver` flag.
            ctx.add_init_script(
                """
                Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
                window.chrome = window.chrome || { runtime: {} };
                """
            )

            page = ctx.pages[0] if ctx.pages else ctx.new_page()
            page.set_default_timeout(self.timeout_ms)

            try:
                print("[scraper] Opening Classroom to-do page…", flush=True)
                page.goto(CLASSROOM_TODO_URL, wait_until="domcontentloaded")
                # Let any redirect to the Google sign-in page actually fire.
                try:
                    page.wait_for_load_state("networkidle", timeout=8_000)
                except PWTimeout:
                    pass
                page.wait_for_timeout(2000)
                print(f"[scraper] Landed on: {page.url}", flush=True)

                # Redirected to login? Wait until the user actually LANDS on
                # Classroom (positive signal). Google's sign-in keeps
                # accounts.google.com in the URL through every step (email →
                # password → 2FA), so "left the login page" is the wrong test —
                # we wait for classroom.google.com to appear instead.
                _login = lambda u: any(s in (u or "").lower() for s in
                    ("accounts.google.com", "servicelogin", "/signin", "/oauth"))
                _signed_in = lambda u: ("classroom.google.com" in (u or "").lower()
                                        and not _login(u))
                # Chrome's post-login "Turn on sync / use this account" surface.
                # Distinct from the normal email/password login URLs so we never
                # nudge a tab that's still mid sign-in.
                _sync_prompt = lambda u: any(s in (u or "").lower() for s in (
                    "signin/chrome", "chrome/sync", "sync-confirmation", "syncconfirmation"))

                def _safe_url(p):
                    try: return p.url or ""
                    except Exception: return ""

                def _find_signed_page():
                    # Google's sign-in often lands in a DIFFERENT tab than the one
                    # we opened, so we must scan every page in the context — not
                    # just `page` — or we'd wait forever while the user is already in.
                    for p in list(ctx.pages):
                        if _signed_in(_safe_url(p)):
                            return p
                    return None

                signed = _find_signed_page()
                if signed is None:
                    if self.headless:
                        raise NotLoggedInError(
                            "Not logged in to Google Classroom. Connect the "
                            "connector first (it caches your session)."
                        )
                    # If the user saved credentials, try to auto-fill the sign-in
                    # form. Best-effort: Google may still challenge (2FA / "verify
                    # it's you"), in which case the user finishes in the window and
                    # the arrival wait below catches it.
                    import time as _t
                    if self.credentials and self.credentials.get("email"):
                        print("[scraper] Saved login found — attempting auto sign-in…", flush=True)
                        _try_google_autologin(page,
                                              self.credentials.get("email", ""),
                                              self.credentials.get("password", ""))
                        # After the Google login, Chrome may pop a "Turn on sync /
                        # use this account" prompt that parks the tab off Classroom.
                        # It's a non-blocking bubble — just drive straight to the
                        # to-do page a few times to blow past it (no manual click).
                        for _ in range(8):
                            signed = _find_signed_page()
                            if signed is not None:
                                break
                            try:
                                page.goto(CLASSROOM_TODO_URL, wait_until="domcontentloaded")
                                page.wait_for_timeout(1500)
                            except Exception:
                                pass
                            _t.sleep(1.5)
                    else:
                        print("[scraper] Not signed in — sign in to Google in the Chrome window.", flush=True)

                    if signed is None:
                        print("[scraper] (Waiting up to 4 min — I'll continue the moment you reach Classroom…)", flush=True)
                        deadline = _t.time() + 240
                        last_log = 0.0
                        while _t.time() < deadline:
                            if not ctx.pages:
                                raise NotLoggedInError("The Chrome window was closed before sign-in finished — Sync again and leave it open.")
                            signed = _find_signed_page()
                            if signed is not None:
                                break
                            # If Chrome parked a tab on its post-login sync/sign-in
                            # prompt, push that tab to Classroom — but never touch a
                            # tab that's still mid sign-in (email / password / 2FA).
                            for p in list(ctx.pages):
                                if _sync_prompt(_safe_url(p)):
                                    try: p.goto(CLASSROOM_TODO_URL, wait_until="domcontentloaded")
                                    except Exception: pass
                            if _t.time() - last_log > 12:   # periodic diagnostic
                                print(f"[scraper]   …waiting; open tabs: {[_safe_url(p)[:55] for p in list(ctx.pages)]}", flush=True)
                                last_log = _t.time()
                            _t.sleep(1)
                        if signed is None:
                            raise NotLoggedInError("Didn't reach Classroom in time — Sync again and finish the Google sign-in (it'll continue automatically).")
                # Switch to whichever tab is actually signed in.
                page = signed
                page.set_default_timeout(self.timeout_ms)
                try: page.bring_to_front()
                except Exception: pass
                print(f"[scraper] ✓ Signed in — now on {page.url}", flush=True)
                page.wait_for_timeout(1500)  # let the session settle

                # Make sure we're on the to-do list specifically.
                if "not-turned-in" not in page.url:
                    print("[scraper] Navigating to the to-do page…", flush=True)
                    page.goto(CLASSROOM_TODO_URL, wait_until="domcontentloaded")
                    try:
                        page.wait_for_load_state("networkidle", timeout=8_000)
                    except PWTimeout:
                        pass
                    print(f"[scraper] Now on: {page.url}", flush=True)

                # Let assignment cards hydrate. The to-do page lazy-loads, so if
                # links don't show up we reload a couple of times. We also detect
                # the window being closed and fail loudly instead of returning 0.
                print("[scraper] Waiting for assignments to render…", flush=True)
                def _count_links():
                    try:
                        return page.evaluate("document.querySelectorAll('a[href*=\"/c/\"]').length") or 0
                    except Exception:
                        return -1  # page/context gone (window closed)
                found_links = 0
                for attempt in range(3):
                    try:
                        page.wait_for_load_state("networkidle", timeout=8_000)
                    except PWTimeout:
                        pass
                    try:
                        page.wait_for_selector('a[href*="/c/"][href*="/a/"]', timeout=8_000)
                    except PWTimeout:
                        pass
                    found_links = _count_links()
                    if found_links == -1:
                        raise NotLoggedInError("The Chrome window was closed during sync — keep it open until it finishes, then try again.")
                    if found_links > 0:
                        break
                    print(f"[scraper] No links yet (try {attempt+1}/3) — reloading the to-do page…", flush=True)
                    try:
                        page.reload(wait_until="domcontentloaded")
                        page.wait_for_timeout(2500)
                    except Exception:
                        raise NotLoggedInError("The Chrome window was closed during sync — keep it open until it finishes, then try again.")
                print(f"[scraper] {found_links} course link(s) on the to-do page.", flush=True)

                # ───────────────────────────────────────────────────────
                # Walk every tab + scroll within each to surface every
                # assignment: Assigned (default) → Missing → Done.
                # Within each tab, scroll to bottom to lazy-load sections
                # (This week / Next week / Later / No due date).
                # ───────────────────────────────────────────────────────
                items: list[dict] = []
                seen_external_ids: set[str] = set()

                # Skip "Done" intentionally — it pulls hundreds of completed
                # assignments that aren't actionable.
                tabs_to_visit = ["Assigned", "Missing"]
                for tab_label in tabs_to_visit:
                    print(f"[scraper] Switching to '{tab_label}' tab…", flush=True)
                    tab_clicked = False
                    try:
                        tab = page.get_by_role("tab", name=tab_label).first
                        if tab.is_visible(timeout=2_000):
                            tab.click()
                            page.wait_for_timeout(1_200)
                            tab_clicked = True
                            print(f"[scraper]   ✓ '{tab_label}' tab clicked", flush=True)
                    except Exception as e:
                        if "has been closed" in str(e):
                            raise NotLoggedInError("The Chrome window was closed during sync — keep it open until it finishes, then try again.")
                        print(f"[scraper]   ✗ '{tab_label}' tab not found: {e}", flush=True)

                    if not tab_clicked:
                        # Fallback: try clicking by exact text content
                        try:
                            page.click(f'text="{tab_label}"', timeout=2_000)
                            page.wait_for_timeout(1_000)
                            print(f"[scraper]   ✓ '{tab_label}' clicked via text fallback", flush=True)
                            tab_clicked = True
                        except Exception as e2:
                            if "has been closed" in str(e2):
                                raise NotLoggedInError("The Chrome window was closed during sync — keep it open until it finishes, then try again.")
                            print(f"[scraper]   ✗ '{tab_label}' fallback also failed — skipping", flush=True)
                            continue

                    # ── EXPAND every collapsed section + every "View all" ──
                    # Classroom collapses "No due date", "Next week", "Later",
                    # "Last week", "Earlier" by default. Each row is a
                    # button with aria-expanded="false". We click them all,
                    # repeatedly, until nothing changes.
                    print(f"[scraper]   Expanding collapsed sections + View-all buttons…", flush=True)
                    for round_n in range(6):
                        result = page.evaluate(
                            """
                            () => {
                                let expanded = 0, viewedAll = 0;
                                // Click every collapsed expandable
                                document.querySelectorAll('[aria-expanded="false"]').forEach(el => {
                                    try { el.click(); expanded++; } catch(e) {}
                                });
                                // Click every "View all" / "Show more" button
                                document.querySelectorAll('button, [role="button"], a').forEach(b => {
                                    const t = (b.textContent || '').trim().toLowerCase();
                                    if (t === 'view all' || t === 'show more' || t === 'load more') {
                                        try { b.click(); viewedAll++; } catch(e) {}
                                    }
                                });
                                return {expanded, viewedAll};
                            }
                            """
                        )
                        if result["expanded"] == 0 and result["viewedAll"] == 0:
                            break
                        print(f"[scraper]     round {round_n+1}: expanded {result['expanded']}, "
                              f"clicked {result['viewedAll']} View-all", flush=True)
                        page.wait_for_timeout(900)

                    # Aggressive scroll to trigger lazy-load after expands.
                    print(f"[scraper]   Scrolling to load remaining content…", flush=True)
                    prev_height = 0
                    for _ in range(15):
                        page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
                        page.wait_for_timeout(700)
                        h = page.evaluate("document.body.scrollHeight")
                        if h == prev_height:
                            break
                        prev_height = h
                    page.evaluate("window.scrollTo(0, 0)")
                    page.wait_for_timeout(300)

                    # Snapshot for debug.
                    if self.debug_dir:
                        shot = self.debug_dir / f"{tab_label.lower()}.png"
                        page.screenshot(path=str(shot), full_page=True)
                        print(f"[debug]   📸 Saved screenshot → {shot}", flush=True)

                    tab_items = _extract_cards(page)
                    # DEBUG: dump every raw link we saw on this tab.
                    print(f"[scraper]   Found {len(tab_items)} link(s) in '{tab_label}'", flush=True)
                    for ti in tab_items:
                        first_line = (ti.get("lines") or ["(no text)"])[0]
                        print(f"[scraper]      • {first_line[:60]}  ← {ti.get('link','')[-30:]}", flush=True)

                    for it in tab_items:
                        eid = it.get("external_id", "")
                        if eid and eid in seen_external_ids:
                            continue
                        seen_external_ids.add(eid)
                        # Tag which Classroom tab it came from — this is the
                        # authoritative Missing-vs-Assigned signal (due-date
                        # parsing is unreliable). "Assigned" is walked first, so
                        # a Missing-only item correctly gets tagged 'missing'.
                        it["status"] = tab_label.lower()   # 'assigned' | 'missing'
                        items.append(it)

                # NOTE: We intentionally do NOT do a per-class fallback. The
                # /t/all classwork page on each class shows every assignment
                # ever posted (including completed/turned in / archived) which
                # blows the list up to hundreds. The to-do page Assigned +
                # Missing tabs are the actionable set.

                # `items` was populated by walking each tab via _extract_cards.
                # Convert the raw items into the normalized task shape.
                for it in items:
                    parsed = _parse_card(it.get("lines", []), it.get("aria", ""), it.get("status", ""))
                    results.append({
                        "title": parsed["title"][:200],
                        "link": it.get("link") or "",
                        "external_id": it.get("external_id") or "",
                        "subject": parsed["subject"][:80],
                        "due": parsed["due"],
                        "description": "",
                        "status": it.get("status", ""),   # 'assigned' | 'missing'
                        "source": "google_classroom",
                    })
                print(f"[scraper] Total unique assignments across tabs: {len(results)}", flush=True)
            finally:
                ctx.close()

        return results


# ── best-effort auto sign-in ─────────────────────────────────────────
def _try_google_autologin(page, email: str, password: str) -> bool:
    """Fill Google's email → password sign-in. Best-effort only: returns True
    if it submitted both fields. Google often challenges automated logins (2FA,
    "this browser may not be secure"); the caller still waits for the user to
    finish in the window, so a partial/failed attempt is harmless."""
    if not email or not password:
        return False
    try:
        # Email step
        try:
            page.wait_for_selector("input[type=email]", timeout=8_000)
            page.fill("input[type=email]", email)
            page.wait_for_timeout(300)
            for sel in ["#identifierNext button", "#identifierNext",
                        "button:has-text('Next')"]:
                try:
                    loc = page.locator(sel).first
                    if loc.count():
                        loc.click(timeout=3_000); break
                except Exception:
                    continue
        except Exception:
            pass  # maybe already past the email step
        # Password step
        page.wait_for_selector("input[type=password]", timeout=12_000)
        page.fill("input[type=password]", password)
        page.wait_for_timeout(300)
        for sel in ["#passwordNext button", "#passwordNext",
                    "button:has-text('Next')"]:
            try:
                loc = page.locator(sel).first
                if loc.count():
                    loc.click(timeout=3_000); break
            except Exception:
                continue
        print("[scraper] auto-login: submitted credentials.", flush=True)
        return True
    except Exception as ex:
        print(f"[scraper] auto-login best-effort failed ({ex}) — finish in the window.", flush=True)
        return False


# ── card extraction (used per-tab inside scrape_assignments) ─────────
def _extract_cards(page) -> list[dict]:
    """Pull every visible assignment / question / material card on this page.
    Catches BOTH /a/ (assignments) AND /sa/ (questions / short assignments)."""
    return page.evaluate(
        """
        () => {
            const out = [];
            const seen = new Set();
            // Broader selector: any course link, filter to a|sa via regex.
            document.querySelectorAll('a[href*="/c/"]').forEach(a => {
                const href = a.href;
                if (seen.has(href)) return;
                const m = href.match(/\\/c\\/([^/]+)\\/(?:a|sa|m)\\/([^/?]+)/);
                if (!m) return;          // skip course tiles, classwork tab, etc.
                seen.add(href);
                // Walk leaf text nodes inside the card.
                const lines = [];
                const seenText = new Set();
                function walk(el) {
                    if (!el) return;
                    if (el.children && el.children.length > 0) {
                        for (const c of el.children) walk(c);
                    } else {
                        const t = (el.textContent || '').trim();
                        if (t && !seenText.has(t)) { seenText.add(t); lines.push(t); }
                    }
                }
                walk(a);
                const aria = (a.getAttribute('aria-label')
                              || a.closest('[aria-label]')?.getAttribute('aria-label')
                              || '').trim();
                out.push({
                    lines,
                    aria,
                    link: href,
                    external_id: 'classroom:' + m[1] + ':' + m[2],
                });
            });
            return out;
        }
        """
    )


# ── helpers ──────────────────────────────────────────────────────────
_MONTHS = {"jan":1,"feb":2,"mar":3,"apr":4,"may":5,"jun":6,
           "jul":7,"aug":8,"sep":9,"sept":9,"oct":10,"nov":11,"dec":12}
_TYPE_PREFIXES = ("assignment", "material", "quiz", "question", "announcement")
_DAY_NAMES = ("monday","tuesday","wednesday","thursday","friday","saturday","sunday",
              "mon","tue","wed","thu","fri","sat","sun")


def _parse_card(lines: list[str], aria: str, status: str = "") -> dict:
    """Split a Classroom card's leaf text nodes into title / subject / due.

    Classroom's DOM glues the type-icon text ('assignment'), title, course
    name, and date all together. We dedup + label each chunk.
    """
    # Strip the type-prefix line if present.
    cleaned = []
    for ln in lines:
        low = ln.lower().strip()
        if low in _TYPE_PREFIXES:
            continue
        if not ln:
            continue
        cleaned.append(ln)

    # Aria-label sometimes has the cleanest title — try it first.
    title = ""
    if aria:
        # aria like: "Assignment, Lab Report on Momentum, AP Physics, due Friday May 30"
        parts = [p.strip() for p in aria.split(",") if p.strip()]
        # Skip the first if it's just the type
        if parts and parts[0].lower() in _TYPE_PREFIXES:
            parts = parts[1:]
        if parts:
            title = parts[0]

    # Walk the cleaned lines to detect title / course / date.
    due = ""
    subject = ""
    for ln in cleaned:
        low = ln.lower()
        # "Posted [date]" = when teacher posted it, NOT a due date — skip entirely.
        if low.startswith("posted"):
            continue
        # Detect date lines: "Monday, Jun 1" or "Mon Jun 1"
        d = _parse_due_date(ln, status)
        if d and not due:
            due = d
            continue
        # Day-only ("Monday", "Mon") — Classroom sometimes splits the date
        if low in _DAY_NAMES:
            continue
        # Month-day ("Jun 1") — partial date, ignore
        if re.match(r"^(jan|feb|mar|apr|may|jun|jul|aug|sept?|oct|nov|dec)\s+\d{1,2}$", low):
            continue
        # First useful non-date line = title (if we didn't get one from aria)
        if not title:
            title = ln
            continue
        # Next useful non-date line = subject/course
        if not subject and ln != title:
            subject = ln

    return {
        "title": title or (cleaned[0] if cleaned else "Untitled"),
        "subject": subject,
        "due": due,
    }


def _parse_due_date(raw: str, status: str = "") -> str:
    """Best-effort Date → 'YYYY-MM-DD'. Returns '' if unparseable.

    Classroom shows a bare "Apr 8" with no year, so we infer it. The catch:
    a 'missing' (overdue) assignment's due date is in the PAST, while an
    'assigned' (upcoming) one is in the FUTURE. Inferring the wrong direction
    is what made overdue work look due in 2027 and broke the Missing filters.
    """
    if not raw:
        return ""
    import datetime as _dt
    s = raw.lower().strip()
    # Patterns: "due may 30", "due fri, may 30", "due tomorrow", "due today"
    today = _dt.date.today()
    if "today" in s:
        return today.isoformat()
    if "tomorrow" in s:
        return (today + _dt.timedelta(days=1)).isoformat()
    m = re.search(r"(jan|feb|mar|apr|may|jun|jul|aug|sept?|oct|nov|dec)[a-z]*\s+(\d{1,2})", s)
    if m:
        month = _MONTHS.get(m.group(1)[:3] if m.group(1)[:4] != "sept" else "sept", 0)
        if not month:
            return ""
        day = int(m.group(2))
        year = today.year
        overdue = (status or "").lower() == "missing"
        if overdue:
            # Due date is in the past: if it still reads as future, it was last year.
            if (month, day) > (today.month, today.day):
                year -= 1
        else:
            # Upcoming: if the date already passed this year, it's next year.
            if (month, day) < (today.month, today.day):
                year += 1
        try:
            return _dt.date(year, month, day).isoformat()
        except ValueError:
            return ""
    return ""


# ── convenience ──────────────────────────────────────────────────────
def scrape(profile_dir: Path | str, *, headless: bool = False,
           credentials: dict | None = None) -> list[dict]:
    """One-shot entry point used by core/school.py."""
    return GoogleClassroomScraper(profile_dir, headless=headless,
                                  credentials=credentials).scrape_assignments()
