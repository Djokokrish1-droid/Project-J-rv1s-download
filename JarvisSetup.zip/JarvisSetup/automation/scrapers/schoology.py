"""Schoology assignment scraper.

Schoology's REST API requires OAuth keys most students can't get, so we
scrape the upcoming-assignments page in the logged-in browser session.

Entry point: /home/upcoming  (or the home/dashboard for some installs)
Each item is an `<a>` link inside an `.upcoming-assignment-item` (or
`.upcoming-item`) container. We grab title + course + due in one pass.

The user supplies their school's Schoology URL when connecting (e.g.
https://yourschool.schoology.com) — defaults to app.schoology.com.
"""
from __future__ import annotations
import re
from pathlib import Path


SCHOOLOGY_DEFAULT_URL = "https://app.schoology.com"


class SchoologyScraper:
    def __init__(
        self,
        profile_dir: Path | str,
        *,
        base_url: str | None = None,
        headless: bool = False,
        timeout_ms: int = 25_000,
    ):
        self.profile_dir = Path(profile_dir)
        self.profile_dir.mkdir(parents=True, exist_ok=True)
        self.base_url = (base_url or SCHOOLOGY_DEFAULT_URL).rstrip("/")
        self.headless = headless
        self.timeout_ms = timeout_ms

    def scrape_assignments(self) -> list[dict]:
        from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout

        results: list[dict] = []
        with sync_playwright() as pw:
            launch_kwargs = dict(
                user_data_dir=str(self.profile_dir),
                headless=self.headless,
                viewport={"width": 1280, "height": 900},
                args=["--disable-blink-features=AutomationControlled",
                      "--no-first-run", "--no-default-browser-check"],
            )
            try:
                ctx = pw.chromium.launch_persistent_context(channel="chrome", **launch_kwargs)
            except Exception:
                ctx = pw.chromium.launch_persistent_context(**launch_kwargs)
            ctx.add_init_script(
                "Object.defineProperty(navigator,'webdriver',{get:()=>undefined});"
                "window.chrome = window.chrome || {runtime:{}};"
            )
            page = ctx.pages[0] if ctx.pages else ctx.new_page()
            page.set_default_timeout(self.timeout_ms)

            try:
                upcoming_url = f"{self.base_url}/home/upcoming"
                print(f"[schoology] Opening {upcoming_url} …", flush=True)
                page.goto(upcoming_url, wait_until="domcontentloaded")

                # If we hit a login/SSO page, wait for the user to finish.
                if any(s in page.url for s in ("/login", "/sso", "/auth", "saml")):
                    if self.headless:
                        raise RuntimeError("Not logged in to Schoology — run a headed sync first.")
                    print("[schoology] Waiting for sign-in (up to 3 min)…", flush=True)
                    import time as _t
                    deadline = _t.time() + 180
                    while _t.time() < deadline:
                        u = page.url
                        if not any(s in u for s in ("/login", "/sso", "/auth", "saml")):
                            break
                        _t.sleep(1)
                    page.goto(upcoming_url, wait_until="domcontentloaded")

                # Schoology lazy-loads. Scroll to flush every item.
                try:
                    page.wait_for_load_state("networkidle", timeout=8_000)
                except PWTimeout:
                    pass
                prev_h = 0
                for _ in range(10):
                    page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
                    page.wait_for_timeout(500)
                    h = page.evaluate("document.body.scrollHeight")
                    if h == prev_h: break
                    prev_h = h
                page.evaluate("window.scrollTo(0, 0)")

                # Extract: each upcoming item is a link to /assignment/{id} or
                # /event/{id}; the page wraps each in an "upcoming" row.
                items = page.evaluate(
                    """
                    () => {
                        const out = [];
                        const seen = new Set();
                        document.querySelectorAll(
                            'a[href*="/assignment/"], a[href*="/event/"], a[href*="/discussion/"]'
                        ).forEach(a => {
                            const href = a.href;
                            if (seen.has(href)) return;
                            const m = href.match(/\\/(?:assignment|event|discussion)\\/(\\d+)/);
                            if (!m) return;
                            seen.add(href);
                            // Walk leaf text nodes to capture title/course/date separately
                            const lines = [];
                            const seenText = new Set();
                            function walk(el) {
                                if (!el) return;
                                if (el.children && el.children.length > 0) {
                                    for (const c of el.children) walk(c);
                                } else {
                                    const t = (el.textContent || '').trim();
                                    if (t && !seenText.has(t)) { seenText.add(t); lines.push(t); }
                                }
                            }
                            // Use the closest list-item container to capture sibling course/date
                            const card = a.closest('li, .upcoming-item, .upcoming-assignment-item, .upcoming') || a;
                            walk(card);
                            out.push({
                                lines,
                                link: href,
                                external_id: 'schoology:' + m[1],
                            });
                        });
                        return out;
                    }
                    """
                )

                for it in items:
                    p = _parse_schoology_card(it.get("lines", []))
                    results.append({
                        "title": p["title"][:200],
                        "link": it.get("link") or "",
                        "external_id": it.get("external_id") or "",
                        "subject": p["subject"][:80],
                        "due": p["due"],
                        "description": "",
                        "source": "schoology",
                    })
                print(f"[schoology] Total assignments: {len(results)}", flush=True)
            finally:
                ctx.close()
        return results


# ── helpers ──────────────────────────────────────────────────────────────
_MONTHS = {"jan":1,"feb":2,"mar":3,"apr":4,"may":5,"jun":6,
           "jul":7,"aug":8,"sep":9,"sept":9,"oct":10,"nov":11,"dec":12}


def _parse_schoology_card(lines: list[str]) -> dict:
    """Pull title / course / due from the card's leaf text."""
    import datetime as _dt
    title = subject = ""
    due = ""
    today = _dt.date.today()
    for ln in lines:
        low = ln.lower().strip()
        if not low:
            continue
        # Skip noisy chrome
        if low in ("assignment", "event", "discussion", "due", "more"):
            continue
        # Due date detection
        m = re.search(r"(jan|feb|mar|apr|may|jun|jul|aug|sept?|oct|nov|dec)[a-z]*\s+(\d{1,2})", low)
        if m and not due:
            month = _MONTHS.get(m.group(1)[:4] if m.group(1)[:4] == "sept" else m.group(1)[:3], 0)
            if month:
                day = int(m.group(2))
                year = today.year + (1 if (month, day) < (today.month, today.day) else 0)
                try:
                    due = _dt.date(year, month, day).isoformat()
                except ValueError:
                    pass
            continue
        # Title first, then course/subject
        if not title:
            title = ln
        elif not subject and ln != title:
            subject = ln
    return {"title": title or "Untitled", "subject": subject, "due": due}


def scrape(profile_dir, *, base_url=None, headless=False):
    return SchoologyScraper(profile_dir, base_url=base_url, headless=headless).scrape_assignments()
