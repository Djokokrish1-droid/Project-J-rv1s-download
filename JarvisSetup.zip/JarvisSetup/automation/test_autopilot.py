"""End-to-end local test of Assignment Autopilot (read → write into Google Doc).

Opens a REAL Google Classroom assignment with the cached login at
~/.jarvis-test-profile/google_classroom, reads the attached Google Doc,
writes the answer with Claude, and types it INTO the Doc.

Usage:
    python -m automation.test_autopilot                      # default assignment, write into doc
    python -m automation.test_autopilot "<assignment_url>"
    python -m automation.test_autopilot "<url>" --no-write   # generate only, don't touch the doc
"""
from __future__ import annotations
import sys
from pathlib import Path

from core.assignment_runner import do_assignment
from integrations.anthropic import ClaudeClient

DEFAULT_URL = "https://classroom.google.com/u/0/c/ODAwMTIwMDUyODA0/a/ODE5NzQ0NjQ3OTI5/details"
PROFILE = Path.home() / ".jarvis-test-profile" / "google_classroom"
MODEL = "claude-opus-4-8"


def main() -> int:
    args = [a for a in sys.argv[1:]]
    write_doc = "--no-write" not in args
    urls = [a for a in args if not a.startswith("--")]
    url = urls[0] if urls else DEFAULT_URL

    claude = ClaudeClient()
    try: claude.model = MODEL
    except Exception: pass

    print(f"[test] assignment: {url}")
    print(f"[test] write into doc: {write_doc}")
    print(f"[test] a real Chrome window will open — watch it.\n")

    task = {"title": "(autopilot test)", "subject": "", "due": "", "link": url,
            "source": "google_classroom"}
    r = do_assignment(task, profile_dir=PROFILE, user_context="", claude=claude,
                      headless=False, write_doc=write_doc, doc_mode="append")

    print("\n" + "=" * 72)
    print(f"ok={r['ok']}  wrote_to_doc={r['wrote_to_doc']}  docs={len(r['doc_ids'])}")
    print(f"page chars={r['instructions_chars']}  doc chars={r['doc_chars']}")
    if r.get("doc_url"): print(f"doc: {r['doc_url']}")
    if r.get("error"): print(f"error: {r['error']}")
    print("=" * 72)
    print("ANSWER:\n")
    print(r.get("answer", "(none)"))
    print("=" * 72)
    return 0 if r["ok"] else 1


if __name__ == "__main__":
    sys.exit(main())
