"""Central configuration for Jarvis."""
import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

ROOT_DIR = Path(__file__).parent.resolve()
DATA_DIR = ROOT_DIR / "data"
PROJECTS_DIR = DATA_DIR / "projects"
MEMORY_FILE = DATA_DIR / "memory.json"
SESSION_FILE = DATA_DIR / "session.json"
SETTINGS_FILE = DATA_DIR / "settings.json"

for p in (DATA_DIR, PROJECTS_DIR):
    p.mkdir(parents=True, exist_ok=True)

# Anthropic
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")
# Default to a low-cost model (Haiku 4.5 = "Mini J@r"). Switch to Opus/Sonnet in
# the model picker when you need more horsepower. Override via env if desired.
CLAUDE_MODEL = os.getenv("CLAUDE_MODEL", "claude-haiku-4-5-20251001")
MAX_TOKENS = int(os.getenv("CLAUDE_MAX_TOKENS", "1600"))
# Cap how many prior messages we send to the API (cost control on long chats).
HISTORY_LIMIT = int(os.getenv("JARVIS_HISTORY_LIMIT", "24"))

# ── Public-launch guardrails ────────────────────────────────────────────────
# Hosted mode = multi-user accounts + paywall (both the web deploy and desktop app).
HOSTED_MODE = os.getenv("JARVIS_HOSTED", "false").lower() == "true"
# Machine control (browser automation, mic/voice) only makes sense on the user's
# own machine — i.e. the desktop app. The cloud web deploy leaves this OFF, so
# web automation is unavailable on the web. The desktop launcher turns it on.
ALLOW_MACHINE_CONTROL = os.getenv("JARVIS_ALLOW_AUTOMATION", "false").lower() == "true"
USAGE_FILE = DATA_DIR / "usage.json"
# Per-user daily message cap.
DAILY_USER_MESSAGE_CAP = int(os.getenv("JARVIS_USER_DAILY_CAP", "40"))
# Global daily spend ceiling in USD — when exceeded, serving stops (kill-switch).
DAILY_GLOBAL_COST_CEILING = float(os.getenv("JARVIS_DAILY_COST_CEILING", "5.0"))
# Minimum seconds between messages from one user (basic rate limit).
MIN_SECONDS_BETWEEN_MESSAGES = float(os.getenv("JARVIS_MIN_GAP", "1.5"))
# In hosted mode, lock everyone to the cheapest model regardless of picker.
HOSTED_FORCED_MODEL = os.getenv("JARVIS_HOSTED_MODEL", "claude-haiku-4-5-20251001")

# ── Billing (Stripe) ────────────────────────────────────────────────────────
STRIPE_SECRET_KEY = os.getenv("STRIPE_SECRET_KEY", "")           # sk_test_… / sk_live_…
STRIPE_WEBHOOK_SECRET = os.getenv("STRIPE_WEBHOOK_SECRET", "")   # whsec_…
# Four subscription tiers × two intervals (monthly / annual) = eight Payment
# Links. These public URLs are baked in as defaults so the desktop builds work
# without a .env. Override via env on the server (e.g. to swap test → live).
# Monthly
STRIPE_PAYMENT_LINK_STARTER = os.getenv("STRIPE_PAYMENT_LINK_STARTER",
    "https://buy.stripe.com/test_5kQ9AT8Uh8Rs6mF3BvdEs00")
STRIPE_PAYMENT_LINK_PRO = os.getenv("STRIPE_PAYMENT_LINK_PRO",
    "https://buy.stripe.com/test_bJecN51rP6JkfXf2xrdEs03")          # 7-day trial
STRIPE_PAYMENT_LINK_MAX = os.getenv("STRIPE_PAYMENT_LINK_MAX",
    "https://buy.stripe.com/test_aFaaEX6M91p0h1jb3XdEs04")          # 7-day trial
STRIPE_PAYMENT_LINK_ULTRA = os.getenv("STRIPE_PAYMENT_LINK_ULTRA",
    "https://buy.stripe.com/test_aFacN5gmJffQ5iBb3XdEs05")          # $99/mo, 7-day trial
STRIPE_PAYMENT_LINK_APEX = os.getenv("STRIPE_PAYMENT_LINK_APEX",
    "https://buy.stripe.com/test_fZu5kD4E18Rs7qJ8VPdEs0c")           # $199/mo, 7-day trial
# Annual (no trial — discount is the value prop, paid upfront)
STRIPE_PAYMENT_LINK_STARTER_ANNUAL = os.getenv("STRIPE_PAYMENT_LINK_STARTER_ANNUAL",
    "https://buy.stripe.com/test_00w9AT5I5ebMh1jb3XdEs06")
STRIPE_PAYMENT_LINK_PRO_ANNUAL = os.getenv("STRIPE_PAYMENT_LINK_PRO_ANNUAL",
    "https://buy.stripe.com/test_3cIdR97Qdc3Eh1j7RLdEs07")
STRIPE_PAYMENT_LINK_MAX_ANNUAL = os.getenv("STRIPE_PAYMENT_LINK_MAX_ANNUAL",
    "https://buy.stripe.com/test_00w3cv9Yl7NodP7b3XdEs08")
STRIPE_PAYMENT_LINK_ULTRA_ANNUAL = os.getenv("STRIPE_PAYMENT_LINK_ULTRA_ANNUAL",
    "https://buy.stripe.com/test_28E7sLc6t4BccL3fkddEs09")          # $594/yr, 50% off
STRIPE_PAYMENT_LINK_APEX_ANNUAL = os.getenv("STRIPE_PAYMENT_LINK_APEX_ANNUAL",
    "https://buy.stripe.com/test_8x2aEXdax6Jkh1j0pjdEs0d")           # $835.80/yr, 65% off

STARTER_DAILY_CAP = int(os.getenv("JARVIS_STARTER_CAP", "20"))
PRO_DAILY_CAP = int(os.getenv("JARVIS_PRO_CAP", "100"))
MAX_DAILY_CAP = int(os.getenv("JARVIS_MAX_CAP", "400"))
ULTRA_DAILY_CAP = int(os.getenv("JARVIS_ULTRA_CAP", "1000"))
APEX_DAILY_CAP = int(os.getenv("JARVIS_APEX_CAP", "2000"))
STARTER_PRICE = os.getenv("JARVIS_STARTER_PRICE", "$10/mo")
PRO_PRICE = os.getenv("JARVIS_PRO_PRICE", "$22.99/mo")
MAX_PRICE = os.getenv("JARVIS_MAX_PRICE", "$49.99/mo")
ULTRA_PRICE = os.getenv("JARVIS_ULTRA_PRICE", "$99/mo")
APEX_PRICE = os.getenv("JARVIS_APEX_PRICE", "$199/mo")
# Hard paywall: in hosted mode, require an active subscription to use J@rv1s.
REQUIRE_SUBSCRIPTION = os.getenv("JARVIS_REQUIRE_SUB", "true").lower() == "true"
BILLING_ENABLED = bool(STRIPE_PAYMENT_LINK_STARTER or STRIPE_PAYMENT_LINK_PRO
                       or STRIPE_PAYMENT_LINK_MAX or STRIPE_PAYMENT_LINK_ULTRA
                       or STRIPE_PAYMENT_LINK_APEX)

# Which Claude model each tier runs on (Max / Ultra / Apex get full Opus = "J@rv1s 1.0").
PLAN_MODELS = {
    "starter": HOSTED_FORCED_MODEL,             # Haiku
    "professional": HOSTED_FORCED_MODEL,        # Haiku
    "max": os.getenv("JARVIS_MAX_MODEL", "claude-opus-4-7"),    # Opus
    "ultra": os.getenv("JARVIS_ULTRA_MODEL", "claude-opus-4-7"),# Opus
    "apex": os.getenv("JARVIS_APEX_MODEL", "claude-opus-4-7"),  # Opus
}

# Auto-trial on signup is DISABLED by default. The only trial path is via
# Stripe checkout (Pro/Max/Ultra/Apex payment links have trial_period_days=7
# baked in, card required). Set JARVIS_TRIAL_DAYS=7 to re-enable a no-card
# trial — but keep it 0 in production so new accounts must enter card to trial.
TRIAL_DAYS = int(os.getenv("JARVIS_TRIAL_DAYS", "0"))
TRIAL_TIER = os.getenv("JARVIS_TRIAL_TIER", "professional")

# Numeric prices (for MRR math on the admin dashboard).
STARTER_PRICE_USD = float(os.getenv("JARVIS_STARTER_USD", "10"))
PRO_PRICE_USD = float(os.getenv("JARVIS_PRO_USD", "22.99"))
MAX_PRICE_USD = float(os.getenv("JARVIS_MAX_USD", "49.99"))
ULTRA_PRICE_USD = float(os.getenv("JARVIS_ULTRA_USD", "99"))
APEX_PRICE_USD = float(os.getenv("JARVIS_APEX_USD", "199"))
# Annual discounted prices (full-year totals).
STARTER_ANNUAL_USD = float(os.getenv("JARVIS_STARTER_ANNUAL_USD", "90"))      # 25% off $120
PRO_ANNUAL_USD = float(os.getenv("JARVIS_PRO_ANNUAL_USD", "179.32"))          # 35% off $275.88
MAX_ANNUAL_USD = float(os.getenv("JARVIS_MAX_ANNUAL_USD", "359.93"))          # 40% off $599.88
ULTRA_ANNUAL_USD = float(os.getenv("JARVIS_ULTRA_ANNUAL_USD", "594"))         # 50% off $1188
APEX_ANNUAL_USD = float(os.getenv("JARVIS_APEX_ANNUAL_USD", "835.80"))         # 65% off $2388

# Admin: usernames in this list see the admin dashboard + bypass the paywall.
ADMIN_USERS = [u.strip().lower() for u in os.getenv("JARVIS_ADMIN_USERS", "admin").split(",") if u.strip()]
# If set, an admin account is auto-created on boot with this password.
ADMIN_PASSWORD = os.getenv("JARVIS_ADMIN_PASSWORD", "")

# ── Email (transactional, via Resend) ───────────────────────────────────────
RESEND_API_KEY = os.getenv("RESEND_API_KEY", "")           # re_… from resend.com
# FROM defaults to no-reply on the production domain so it works out of the box
# once the domain is verified in Resend. Override via env to change display name.
MAIL_FROM = os.getenv("JARVIS_MAIL_FROM",
                      "J@rv1s <noreply@projectjarvis.app>")
# Optional Reply-To — if unset, replies go back to MAIL_FROM. Use a friendly
# inbox like support@projectjarvis.app so subscribers can actually reach you.
MAIL_REPLY_TO = os.getenv("JARVIS_MAIL_REPLY_TO", "support@projectjarvis.app")
# Public support address shown in the email footer.
SUPPORT_EMAIL = os.getenv("JARVIS_SUPPORT_EMAIL", "support@projectjarvis.app")
APP_NAME = os.getenv("JARVIS_APP_NAME", "J@rv1s")
APP_VERSION = os.getenv("JARVIS_APP_VERSION", "1.2.11")  # single source of truth
# Public base URL used to build links in emails (password reset, etc.).
APP_BASE_URL = os.getenv("JARVIS_BASE_URL",
                         "https://web.projectjarvis.app")
EMAIL_ENABLED = bool(RESEND_API_KEY and MAIL_FROM)

# Plan catalog (drives the paywall UI + caps + feature gates).
# Each plan carries monthly + annual pricing; the frontend toggles between them.
# `trial_days` only fires on the *monthly* purchase (annual is paid upfront).
PLANS = [
    {"id": "starter", "name": "Starter",
     "price": STARTER_PRICE, "price_usd": STARTER_PRICE_USD,
     "price_annual": f"${STARTER_ANNUAL_USD:g}/yr", "price_annual_usd": STARTER_ANNUAL_USD,
     "annual_discount_pct": 25, "trial_days": 0,
     "cap": STARTER_DAILY_CAP, "web_automation": False,
     "features": [f"{STARTER_DAILY_CAP} messages / day", "All subjects & skills",
                  "Full academic package", "Mini J@r"]},
    {"id": "professional", "name": "Professional",
     "price": PRO_PRICE, "price_usd": PRO_PRICE_USD,
     "price_annual": f"${PRO_ANNUAL_USD:.2f}/yr", "price_annual_usd": PRO_ANNUAL_USD,
     "annual_discount_pct": 35, "trial_days": 7,
     "cap": PRO_DAILY_CAP, "web_automation": True,
     "features": [f"{PRO_DAILY_CAP} messages / day (5×)", "Everything in Starter",
                  "Web automation (desktop app)", "7-day free trial (card required)"]},
    {"id": "max", "name": "Max",
     "price": MAX_PRICE, "price_usd": MAX_PRICE_USD,
     "price_annual": f"${MAX_ANNUAL_USD:.2f}/yr", "price_annual_usd": MAX_ANNUAL_USD,
     "annual_discount_pct": 40, "trial_days": 7,
     "cap": MAX_DAILY_CAP, "web_automation": True,
     "features": [f"{MAX_DAILY_CAP} messages / day (20×)", "Everything in Professional",
                  "Runs on J@rv1s 1.0 (max power)", "Web automation (desktop app)",
                  "7-day free trial (card required)"]},
    {"id": "ultra", "name": "Ultra",
     "price": ULTRA_PRICE, "price_usd": ULTRA_PRICE_USD,
     "price_annual": f"${ULTRA_ANNUAL_USD:g}/yr", "price_annual_usd": ULTRA_ANNUAL_USD,
     "annual_discount_pct": 50, "trial_days": 7,
     "cap": ULTRA_DAILY_CAP, "web_automation": True,
     "features": [f"{ULTRA_DAILY_CAP} messages / day (50×)", "Everything in Max",
                  "Priority support", "Early access to new features",
                  "7-day free trial (card required)"]},
    {"id": "apex", "name": "Apex",
     "price": APEX_PRICE, "price_usd": APEX_PRICE_USD,
     "price_annual": f"${APEX_ANNUAL_USD:.2f}/yr", "price_annual_usd": APEX_ANNUAL_USD,
     "annual_discount_pct": 65, "trial_days": 7,
     "cap": APEX_DAILY_CAP, "web_automation": True,
     "features": [f"{APEX_DAILY_CAP} messages / day (100×)", "Everything in Ultra",
                  "Dedicated priority support", "Custom AI personality",
                  "Earliest access to new features",
                  "7-day free trial (card required)"]},
]
PLAN_CAPS = {p["id"]: p["cap"] for p in PLANS}
PLAN_PRICE_USD = {p["id"]: p["price_usd"] for p in PLANS}
PLAN_TRIAL_DAYS = {p["id"]: p["trial_days"] for p in PLANS}

# Cluely (documentation-only integration, no key required)
CLUELY_ENABLED = os.getenv("CLUELY_ENABLED", "false").lower() == "true"
CLUELY_ENDPOINT = os.getenv("CLUELY_ENDPOINT", "https://cluely.example/api")

# Flask API
API_HOST = os.getenv("JARVIS_API_HOST", "127.0.0.1")
API_PORT = int(os.getenv("JARVIS_API_PORT", "5005"))

# Voice
VOICE_RATE = int(os.getenv("VOICE_RATE", "180"))

# Prompt the user pastes into another AI (ChatGPT, Gemini, etc.) to dump
# everything that model remembers about them — for "Import memory" in Settings.
MEMORY_IMPORT_PROMPT = """Export all of my stored memories and any context you've learned about me from past conversations. Preserve my words verbatim where possible, especially for instructions and preferences.

## Categories (output in this order):

1. **Instructions**: Rules I've explicitly asked you to follow going forward — tone, format, style, "always do X", "never do Y", and corrections to your behavior. Only include rules from stored memories, not from conversations.

2. **Identity**: Name, age, location, education, family, relationships, languages, and personal interests.

3. **Career**: Current and past roles, companies, and general skill areas.

4. **Projects**: Projects I meaningfully built or committed to. Ideally ONE entry per project. Include what it does, current status, and any key decisions. Use the project name or a short descriptor as the first words of the entry.

5. **Preferences**: Opinions, tastes, and working-style preferences that apply broadly.

## Format:

Use section headers for each category. Within each category, list one entry per line, sorted by oldest date first. Format each line as:

[YYYY-MM-DD] - Entry content here.

If no date is known, use [unknown] instead.

## Output:
- Wrap the entire export in a single code block for easy copying.
- After the code block, state whether this is the complete set or if more remain."""


SYSTEM_PROMPT = """You are Jarvis, a personal AI assistant.
You help the user manage projects, files, assignments, and deadlines, automate
their browser and desktop, and learn their preferences over time. Be concise,
direct, and proactive. When the user references a project by name, use the
project context provided in the conversation."""
