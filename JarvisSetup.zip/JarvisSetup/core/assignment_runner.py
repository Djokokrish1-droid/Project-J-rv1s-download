"""Assignment Autopilot — read a Classroom assignment (incl. its attached
Google Doc), write the answer with Claude, and type it into the Doc.

Flow (one shared browser context):
  1. Launch real Chrome with the user's cached Google session
  2. Open the assignment page → extract title + inline instructions + attached
     Google Doc ids  (the prompt usually lives INSIDE the doc, not on the page)
  3. Read the attached Doc's text via its export endpoint
  4. Ask Claude to write a complete answer using page + doc context
  5. If the assignment has an attached Doc and write_doc=True → type the answer
     INTO that Doc (the student's submission doc)
  6. Return everything to the caller (the chat shows what happened)

Submission ("Turn in") is a separate later step — this module gets the answer
written into the doc. The student (or a future submit step) turns it in.
"""
from __future__ import annotations
import re
from pathlib import Path

from automation.google_docs import extract_doc_ids, read_doc_text, write_to_doc

_SKIP_URL_HINTS = ("accounts.google.com", "ServiceLogin", "/login", "/sso", "/saml")


# ── browser ──────────────────────────────────────────────────────────────
def _launch(pw, profile_dir: Path, headless: bool):
    kwargs = dict(
        user_data_dir=str(profile_dir),
        headless=headless,
        viewport={"width": 1280, "height": 950},
        args=["--disable-blink-features=AutomationControlled",
              "--no-first-run", "--no-default-browser-check"],
    )
    try:
        ctx = pw.chromium.launch_persistent_context(channel="chrome", **kwargs)
    except Exception:
        ctx = pw.chromium.launch_persistent_context(**kwargs)
    ctx.add_init_script(
        "Object.defineProperty(navigator,'webdriver',{get:()=>undefined});"
        "window.chrome = window.chrome || {runtime:{}};"
    )
    page = ctx.pages[0] if ctx.pages else ctx.new_page()
    page.set_default_timeout(20_000)
    return ctx, page


# ── extraction ─────────────────────────────────────────────────────────────
def _extract_assignment(page, url: str) -> dict:
    """Open the assignment page; return {ok, title, instructions, doc_ids, error}."""
    from playwright.sync_api import TimeoutError as PWTimeout
    out = {"ok": False, "title": "", "instructions": "", "doc_ids": [], "error": ""}

    print(f"[runner] Opening assignment: {url}", flush=True)
    page.goto(url, wait_until="domcontentloaded")
    try:
        page.wait_for_load_state("networkidle", timeout=10_000)
    except PWTimeout:
        pass
    page.wait_for_timeout(2500)  # let Classroom hydrate

    if any(s in page.url for s in _SKIP_URL_HINTS):
        out["error"] = ("Not signed in to Google. Open Connectors → Connect "
                        "Google Classroom first, then try Autopilot again.")
        return out

    out["title"] = (page.title() or "").replace(" - Classroom", "").strip()

    # The assignment region is [role='main'] (the bare <main> tag often times out).
    instr = ""
    for sel in ["[role='main']", "div[role='main']", "main", "body"]:
        try:
            t = page.inner_text(sel, timeout=2500)
            if t and len(t.strip()) > len(instr):
                instr = t.strip()
            if instr and len(instr) > 60:
                break
        except Exception:
            continue
    out["instructions"] = _clean(instr)

    # Attached Google Docs (the real prompt + the doc we'll write into).
    out["doc_ids"] = extract_doc_ids(page)
    print(f"[runner] title={out['title']!r}  docs={len(out['doc_ids'])}  "
          f"instr={len(out['instructions'])} chars", flush=True)
    out["ok"] = True
    return out


def _clean(raw: str) -> str:
    """Strip Classroom's left-nav chrome + dedupe lines so the LLM sees signal."""
    if not raw:
        return ""
    # Everything before the assignment header is sidebar nav — cut it.
    NAV_END = ("Archived classes", "Settings")
    lines = [ln.strip() for ln in raw.split("\n")]
    # find last nav marker and drop everything up to it
    cut = 0
    for i, ln in enumerate(lines):
        if ln in NAV_END:
            cut = i + 1
    lines = lines[cut:] if cut else lines
    # dedupe + drop tiny cruft
    out, prev = [], ""
    for ln in lines:
        if not ln or (len(ln) < 3 and ln in ("·", "•", "›")):
            continue
        if ln != prev:
            out.append(ln); prev = ln
    text = "\n".join(out)
    return text[:8000] + ("\n…[truncated]" if len(text) > 8000 else "")


# ── answer generation ──────────────────────────────────────────────────────
def generate_answer(*, title: str, subject: str, due: str, instructions: str,
                    doc_text: str, user_context: str, claude, style: str = "default",
                    extra_instructions: str = "") -> str:
    """Write the assignment answer with Claude using page + doc context.

    extra_instructions: free-text the student typed into Autopilot (e.g.
    "write in first person, ~300 words, cite two sources"). These take priority
    over inferred formatting — they're the student's explicit ask."""
    have_doc = bool(doc_text.strip())
    context_block = ""
    if instructions.strip():
        context_block += f"--- CLASSROOM PAGE ---\n{instructions.strip()}\n"
    if have_doc:
        context_block += f"--- ATTACHED GOOGLE DOC (the prompt + your workspace) ---\n{doc_text.strip()}\n"
    if not context_block.strip():
        return ("⚠️ Couldn't find any assignment text — the Classroom page and the "
                "attached doc were both empty. Open it manually and paste the prompt into chat.")

    system = (
        "You are J@rv1s, the user's personal AI agent, completing a school "
        "assignment FOR them. Write a complete, submission-ready answer in the "
        "user's natural student voice. No disclaimers, no 'as an AI', no "
        "refusals — just the answer.\n"
        "Rules:\n"
        "- Match the requested format exactly (essay, problem set, short answer, etc.)\n"
        "- Hit any specified word/length count within ~10%\n"
        "- Show brief work for math/science\n"
        "- Label multi-part answers clearly\n"
        "- If the doc already contains the prompt/question, DON'T repeat it — write only the answer/response\n"
        "- Make a reasonable choice on anything ambiguous and continue\n"
        "- The student's own instructions (if any) OVERRIDE inferred formatting — follow them exactly\n"
        "- Output ONLY the answer text — no preamble, no closing remarks"
    )
    prompt = (
        f"Subject: {subject or 'Unknown'}\nTitle: {title}\n"
        f"{('Due: ' + due) if due else ''}\nStyle: {style}\n\n"
        f"{context_block}\n--- END ---\n\nWrite the complete answer now."
    )
    if extra_instructions.strip():
        prompt = (f"⚡ THE STUDENT'S INSTRUCTIONS (follow these exactly, they take "
                  f"priority):\n{extra_instructions.strip()}\n\n") + prompt
    if user_context.strip():
        prompt = f"About the user (match their voice):\n{user_context}\n\n" + prompt
    try:
        return claude.chat([{"role": "user", "content": prompt}], extra_system=system)
    except Exception as ex:
        return f"⚠️ Couldn't generate the answer ({type(ex).__name__}: {ex})."


# ── orchestration ────────────────────────────────────────────────────────
def do_assignment(task: dict, *, profile_dir: Path, user_context: str, claude,
                  style: str = "default", headless: bool = False,
                  write_doc: bool = True, doc_mode: str = "append",
                  submit: bool = False, extra_instructions: str = "",
                  should_cancel=None) -> dict:
    """Full Autopilot run. Returns:
        {ok, page_title, answer, doc_ids, wrote_to_doc, doc_url, error,
         instructions_chars, doc_chars, turned_in, submit_state}

    submit=True also clicks Turn in / Mark as done after writing the answer.
    extra_instructions: the student's free-text guidance for the answer.
    """
    from playwright.sync_api import sync_playwright

    res = {"ok": False, "page_title": "", "answer": "", "doc_ids": [],
           "wrote_to_doc": False, "doc_url": "", "error": "",
           "instructions_chars": 0, "doc_chars": 0,
           "turned_in": False, "submit_state": ""}

    if not task.get("link"):
        res["error"] = "This task has no link to open."
        return res

    _cancelled = lambda: bool(should_cancel and should_cancel())

    profile_dir = Path(profile_dir); profile_dir.mkdir(parents=True, exist_ok=True)
    with sync_playwright() as pw:
        ctx, page = _launch(pw, profile_dir, headless)
        try:
            if _cancelled():
                res["error"] = "Stopped before it started — nothing was written or turned in."
                res["submit_state"] = "cancelled"
                return res
            ex = _extract_assignment(page, task["link"])
            res["page_title"] = ex.get("title", "")
            if not ex.get("ok"):
                res["error"] = ex.get("error") or "Couldn't read the assignment."
                return res
            res["doc_ids"] = ex["doc_ids"]
            res["instructions_chars"] = len(ex["instructions"])

            # Read the first attached doc (the prompt usually lives there).
            doc_text = ""
            if ex["doc_ids"]:
                doc_text = read_doc_text(page, ex["doc_ids"][0])
                res["doc_chars"] = len(doc_text)
                print(f"[runner] read {len(doc_text)} chars from attached doc", flush=True)

            # Generate the answer.
            if _cancelled():
                res["error"] = "Stopped by you — nothing was written or turned in."
                res["submit_state"] = "cancelled"
                return res
            answer = generate_answer(
                title=ex["title"], subject=task.get("subject", ""),
                due=task.get("due", ""), instructions=ex["instructions"],
                doc_text=doc_text, user_context=user_context, claude=claude,
                style=style, extra_instructions=extra_instructions)
            res["answer"] = answer

            if answer.startswith("⚠️"):
                res["ok"] = False
                res["error"] = answer
                return res

            # Write into the attached doc — SKIPPED if STOP was pressed, so a stop
            # halts the whole run (and so it can never reach the turn-in).
            if write_doc and ex["doc_ids"] and not _cancelled():
                doc_id = ex["doc_ids"][0]
                res["doc_url"] = f"https://docs.google.com/document/d/{doc_id}/edit"
                w = write_to_doc(page, doc_id, answer, mode=doc_mode)
                res["wrote_to_doc"] = bool(w.get("ok"))
                if not w.get("ok") and w.get("error"):
                    res["error"] = w["error"]  # non-fatal; answer still returned

            # Hard stop: if cancelled, bail before turn-in with the answer intact.
            if _cancelled():
                res["submit_state"] = "cancelled"
                res["ok"] = True              # answer is in res["answer"] to review
                return res

            # Turn it in (separate, explicit step). Only if asked — and NEVER if
            # STOP was pressed. This is the accidental-submit guard.
            if submit and _cancelled():
                res["submit_state"] = "cancelled"
            elif submit:
                ti = _turn_in(page, task["link"])
                res["turned_in"] = bool(ti.get("ok") and ti.get("state") in
                                        ("turned_in", "already_turned_in"))
                res["submit_state"] = ti.get("state", "")
                if ti.get("error") and not res["error"]:
                    res["error"] = ti["error"]

            res["ok"] = True
            return res
        except Exception as ex:
            res["error"] = f"{type(ex).__name__}: {ex}"
            return res
        finally:
            ctx.close()


# ── turn-in ────────────────────────────────────────────────────────────────
def _turn_in(page, url: str) -> dict:
    """Click Turn in / Hand in / Mark as done on the assignment page and confirm.
    Returns {ok, state, error}. state ∈ {turned_in, already_turned_in,
    submitted_unverified, ""}."""
    import re as _re
    from playwright.sync_api import TimeoutError as PWTimeout
    out = {"ok": False, "state": "", "error": ""}
    try:
        # Writing the doc navigated away — get back to the assignment page.
        if "classroom.google.com" not in (page.url or ""):
            page.goto(url, wait_until="domcontentloaded")
            try:
                page.wait_for_load_state("networkidle", timeout=8_000)
            except PWTimeout:
                pass
            page.wait_for_timeout(1800)

        # Already submitted? Don't double-submit.
        try:
            body = (page.inner_text("body", timeout=4000) or "").lower()
        except Exception:
            body = ""
        if "turned in" in body or "unsubmit" in body:
            out["ok"] = True; out["state"] = "already_turned_in"
            print("[runner] already turned in", flush=True)
            return out

        # Find the submit button: "Turn in" / "Hand in" / "Mark as done".
        clicked = False
        for name in ("Turn in", "Hand in", "Mark as done"):
            loc = page.get_by_role("button", name=_re.compile(name, _re.I))
            n = loc.count()
            for i in range(n):
                b = loc.nth(i)
                try:
                    if b.is_visible() and b.is_enabled():
                        b.click(timeout=4000)
                        clicked = True
                        print(f"[runner] clicked '{name}'", flush=True)
                        break
                except Exception:
                    continue
            if clicked:
                break
        if not clicked:
            out["error"] = ("Couldn't find a Turn in / Mark as done button — the "
                            "assignment may not accept submissions, or its layout changed.")
            return out

        page.wait_for_timeout(1300)

        # A confirmation dialog usually appears ("Turn in your work?") with a
        # final Turn in button. Click the visible one if present.
        for name in ("Turn in", "Hand in", "Submit"):
            try:
                dlg = page.get_by_role("button", name=_re.compile(rf"^{name}$", _re.I))
                if dlg.count() and dlg.last.is_visible():
                    dlg.last.click(timeout=3000)
                    print(f"[runner] confirmed '{name}'", flush=True)
                    break
            except Exception:
                continue
        page.wait_for_timeout(2800)

        # Verify the state flipped.
        try:
            body2 = (page.inner_text("body", timeout=4000) or "").lower()
        except Exception:
            body2 = ""
        if "turned in" in body2 or "unsubmit" in body2:
            out["ok"] = True; out["state"] = "turned_in"
        else:
            out["ok"] = True; out["state"] = "submitted_unverified"
        return out
    except Exception as ex:
        out["error"] = f"{type(ex).__name__}: {ex}"
        return out
