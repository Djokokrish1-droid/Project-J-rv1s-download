"""The Jarvis conversation engine — wires Claude + memory + projects + skills."""
from __future__ import annotations
from datetime import datetime
from integrations.anthropic import ClaudeClient
from core.memory import Memory, Session
from core.project_manager import ProjectManager
from core.skills import SkillsManager
from core.voice import VoiceManager
from core.settings import Settings
from core.usage import UsageGuard, estimate_cost
from integrations.anthropic import APIUnavailable
from urllib.parse import urlparse
from config import (DATA_DIR, MAX_TOKENS, HISTORY_LIMIT, HOSTED_MODE,
                    HOSTED_FORCED_MODEL)

# Default safe sites the armed browser may visit (education/research-focused).
DEFAULT_ALLOWLIST = [
    "google.com", "duckduckgo.com", "bing.com", "wikipedia.org",
    "khanacademy.org", "youtube.com", "wolframalpha.com", "desmos.com",
    "quizlet.com", "britannica.com", "archive.org", "github.com",
    "docs.google.com", "classroom.google.com", "drive.google.com",
    "scholar.google.com", "jstor.org", "sparknotes.com", "coursera.org",
]


# Browser tools exposed to Claude when browser automation is armed.
BROWSER_TOOLS = [
    {
        "name": "browser_open",
        "description": "Navigate the browser to a URL. Returns the page title.",
        "input_schema": {
            "type": "object",
            "properties": {"url": {"type": "string", "description": "Full URL, including https://"}},
            "required": ["url"],
        },
    },
    {
        "name": "browser_extract",
        "description": "Read visible text from the current page. Optionally pass a CSS selector to scope it. Use this to understand the page before clicking or typing.",
        "input_schema": {
            "type": "object",
            "properties": {"selector": {"type": "string", "description": "Optional CSS selector"}},
        },
    },
    {
        "name": "browser_click",
        "description": "Click an element. Accepts a CSS selector or a Playwright text selector like text=Sign in.",
        "input_schema": {
            "type": "object",
            "properties": {"selector": {"type": "string"}},
            "required": ["selector"],
        },
    },
    {
        "name": "browser_type",
        "description": "Type text into an input/textarea identified by a CSS selector.",
        "input_schema": {
            "type": "object",
            "properties": {"selector": {"type": "string"}, "text": {"type": "string"}},
            "required": ["selector", "text"],
        },
    },
    {
        "name": "browser_press",
        "description": "Press a keyboard key (e.g. Enter, Tab, ArrowDown).",
        "input_schema": {
            "type": "object",
            "properties": {"key": {"type": "string", "default": "Enter"}},
        },
    },
    {
        "name": "browser_screenshot",
        "description": "Capture a screenshot of the current page. Returns the saved file path.",
        "input_schema": {"type": "object", "properties": {}},
    },
]


class JarvisEngine:
    def __init__(self, data_dir=None, usage: "UsageGuard | None" = None):
        """data_dir scopes all this user's storage. usage (the spend guard) is
        shared across users so the global ceiling tracks total spend."""
        from pathlib import Path
        from config import DATA_DIR
        data_dir = Path(data_dir) if data_dir else DATA_DIR
        data_dir.mkdir(parents=True, exist_ok=True)
        (data_dir / "projects").mkdir(parents=True, exist_ok=True)
        self.data_dir = data_dir

        self.claude = ClaudeClient()
        self.memory = Memory(data_dir / "memory.json")
        self.session = Session(data_dir / "session.json")
        self.projects = ProjectManager(data_dir / "projects")
        self.skills = SkillsManager(data_dir / "skills.json")
        self.voice = VoiceManager(data_dir / "voice.json", self.claude, self.skills)
        self.settings = Settings(data_dir / "settings.json")
        self.usage = usage or UsageGuard()
        # apply persisted model choice. In hosted mode, fall back to the cheap
        # model for new users (admin gets bumped to Opus by api_server at engine creation).
        self.claude.model = self.settings.get("model") or (HOSTED_FORCED_MODEL if HOSTED_MODE else None)
        self.active_project: str | None = None
        self.active_conversation_id: str | None = None
        self.browser_armed: bool = False   # toggle state; browser launches lazily
        self._browser = None               # live BrowserController, created on first use
        self.browser_restricted: bool = bool(self.settings.get("browser_restricted", True))
        self.browser_allowlist: list[str] = list(DEFAULT_ALLOWLIST)

    def set_model(self, model: str) -> None:
        # Always allowed at the engine level; the API endpoint gates non-admins
        # in hosted mode so regular users can't bypass plan-tier locking.
        self.claude.model = model
        self.settings.set("model", model)

    def set_project(self, name: str) -> bool:
        meta = self.projects.get(name)
        if not meta:
            return False
        self.active_project = name
        # restore that project's most-recent conversation, if any
        self.active_conversation_id = meta.get("current_conversation_id")
        return True

    def clear_project(self) -> None:
        self.active_project = None
        self.active_conversation_id = None

    def open_conversation(self, project: str, cid: str) -> bool:
        if not self.projects.get_conversation(project, cid):
            return False
        self.active_project = project
        self.active_conversation_id = cid
        self.projects.set_current_conversation(project, cid)
        return True

    def start_new_conversation(self, project: str, title: str = "") -> dict:
        conv = self.projects.new_conversation(project, title)
        self.active_project = project
        self.active_conversation_id = conv["id"]
        return conv

    def current_history(self) -> list[dict]:
        """Messages to render in the chat panel."""
        if self.active_project and self.active_conversation_id:
            conv = self.projects.get_conversation(self.active_project, self.active_conversation_id)
            if conv:
                return [{"role": m["role"], "content": m["content"]} for m in conv.get("messages", [])]
        return self.session.history()

    def _extra_system(self) -> str:
        parts = [f"Today's date is {datetime.now().strftime('%Y-%m-%d (%A)')}.",
                 self.memory.context_block(),
                 self.skills.context_block()]
        # Per-user "Custom Instructions" from Settings → General (if set).
        ci = getattr(self, "custom_instructions", "") or ""
        nick = getattr(self, "nickname", "") or ""
        if nick:
            parts.append(f"The user prefers to be called: {nick}.")
        if ci.strip():
            parts.append("Custom instructions from the user (follow these throughout):\n" + ci.strip())
        if self.active_project:
            parts.append(self.projects.context_for(self.active_project))
        if self.browser_armed:
            parts.append(
                "Browser automation is ARMED. You control a real Chromium browser via the "
                "browser_* tools. Use them only when the task genuinely needs the web "
                "(e.g. 'open YouTube and…', 'look up…', 'fill this form'). For normal "
                "questions, just answer — don't open the browser. When you do use it: open a "
                "URL, extract the page to find selectors, then click/type/press. Narrate "
                "briefly what you're doing."
            )
        return "\n\n".join(p for p in parts if p)

    def _build_history(self, user_text: str) -> list[dict]:
        if self.active_project and self.active_conversation_id:
            conv = self.projects.get_conversation(self.active_project, self.active_conversation_id)
            history = [{"role": m["role"], "content": m["content"]} for m in (conv["messages"] if conv else [])]
        else:
            history = list(self.session.history())
        # Cost control: only send the most recent turns to the API. Keep an even
        # count so we start on a user message and don't orphan a tool exchange.
        if len(history) > HISTORY_LIMIT:
            history = history[-HISTORY_LIMIT:]
        history.append({"role": "user", "content": user_text})
        return history

    def _persist_turn(self, user_text: str, reply: str) -> None:
        if self.active_project and self.active_conversation_id:
            self.projects.append_to_conversation(
                self.active_project,
                self.active_conversation_id,
                {"role": "user", "content": user_text},
                {"role": "assistant", "content": reply},
            )
        else:
            self.session.add("user", user_text)
            self.session.add("assistant", reply)
        # Auto-memory: quietly extract personal facts when the user says
        # something self-disclosing. Cheap (Haiku) + throttled.
        try:
            if getattr(self, "auto_memory", True):
                self._maybe_extract_memory(user_text)
        except Exception:
            pass  # never break a chat on memory extraction

    # ────────────────────────────────────────────────────────────────────
    # Auto-memory extraction — quietly pulls atomic facts from user msgs
    # ────────────────────────────────────────────────────────────────────
    _MEM_PRONOUNS = ("i ", "i'", "im ", "i’", "my ", "me ", "mine ")
    _last_mem_ts: float = 0.0

    def _maybe_extract_memory(self, text: str) -> None:
        import time as _t
        t = (text or "").strip().lower()
        if len(t) < 30:
            return
        if not any(p in t for p in self._MEM_PRONOUNS):
            return
        now = _t.time()
        if now - self._last_mem_ts < 45:        # at most once per 45 s
            return
        self._last_mem_ts = now
        self._extract_facts_into_memory(text)

    def _extract_facts_into_memory(self, text: str) -> None:
        """Call Haiku to pull 0-3 atomic facts about the user from `text`."""
        import json, re
        from integrations.anthropic import APIUnavailable
        prior_model = self.claude.model
        try:
            self.claude.model = "claude-haiku-4-5-20251001"      # cheap extractor
            prompt = (
                "From the user message below, extract 0-3 atomic, durable facts "
                "about the user that are worth remembering long-term. Each fact "
                "should be one short sentence in third person ('User is …', "
                "'User prefers …', 'User's goal is …'). Skip transient things "
                "(weather, mood) and questions. Respond with a JSON array of "
                "strings only — no prose. Empty array if nothing memorable.\n\n"
                f"User message:\n\"\"\"{text}\"\"\""
            )
            out = self.claude.chat([{"role": "user", "content": prompt}],
                                   extra_system="You extract memory atoms. Output JSON only.")
            m = re.search(r"\[.*\]", out, re.DOTALL)
            if not m:
                return
            facts = json.loads(m.group(0))
            for f in facts:
                if isinstance(f, str) and 4 < len(f) < 240:
                    self.memory.remember(f.strip(), tag="auto")
        except (APIUnavailable, json.JSONDecodeError, Exception):
            return
        finally:
            self.claude.model = prior_model

    def ask(self, user_text: str, user_id: str = "local") -> str:
        return "".join(self.ask_stream(user_text, user_id))

    def _account(self, user_id: str) -> None:
        """Record estimated cost of the most recent API call against this user."""
        try:
            self.usage.record_cost(user_id, estimate_cost(self.claude.model, self.claude.last_usage))
        except Exception:
            pass

    def _user_cap(self, user_id: str) -> int | None:
        """Daily message cap for this user by plan tier (None = module default)."""
        if not HOSTED_MODE:
            return None  # local/desktop: no plan throttling
        from core import auth
        from config import PLAN_CAPS, STARTER_DAILY_CAP
        return PLAN_CAPS.get(auth.get_plan(user_id), STARTER_DAILY_CAP)

    def _subscription_block(self, user_id: str) -> str | None:
        """Return a paywall message if this user may not use J@rv1s, else None."""
        if not HOSTED_MODE:
            return None
        from config import REQUIRE_SUBSCRIPTION
        if not REQUIRE_SUBSCRIPTION:
            return None
        from core import auth
        if auth.is_subscribed(user_id):
            return None
        return ("🔒 J@rv1s requires an active subscription. Tap **Subscribe** to "
                "unlock your Personal Agent.")

    def _apply_plan_model(self, user_id: str) -> None:
        """In hosted mode, the model is set by the user's tier (Max → Opus).
        Admins are exempt — their manual model choice (via the picker) sticks."""
        if not HOSTED_MODE:
            return
        from core import auth
        if auth.is_admin(user_id):
            return  # admin keeps whatever they picked
        from config import PLAN_MODELS, HOSTED_FORCED_MODEL
        self.claude.model = PLAN_MODELS.get(auth.get_plan(user_id), HOSTED_FORCED_MODEL)

    def ask_stream(self, user_text: str, user_id: str = "local"):
        """Stream the reply, enforcing the paywall + usage guardrails. If the
        browser is armed, run an agentic tool loop; otherwise stream normally."""
        self._apply_plan_model(user_id)
        from core import auth
        if not auth.is_admin(user_id):   # admins: full access, no paywall/cap/rate limit
            wall = self._subscription_block(user_id)
            if wall:
                yield wall
                return  # no API call for non-subscribers
            ok, refusal = self.usage.check(user_id, cap=self._user_cap(user_id))
            if not ok:
                yield f"⏳ {refusal}"
                return  # blocked before any API call — costs nothing, not persisted
            self.usage.touch(user_id)

        if self.browser_armed:
            yield from self._agentic_turn(user_text, user_id)
            return

        history = self._build_history(user_text)
        chunks: list[str] = []
        try:
            for chunk in self.claude.chat_stream(history, extra_system=self._extra_system()):
                chunks.append(chunk)
                yield chunk
        except APIUnavailable as ex:
            msg = f"\n\n⚠️ {ex}"
            yield msg
            chunks.append(msg)
        finally:
            self._account(user_id)
        self._persist_turn(user_text, "".join(chunks))

    # -------- agentic browser turn (tool use) -------------------------------
    def _agentic_turn(self, user_text: str, user_id: str = "local"):
        system = self.claude._system_blocks(self._extra_system())
        messages = self._build_history(user_text)
        shown = []  # everything we yield, persisted as the assistant message

        for _ in range(10):  # cap tool-use iterations
            try:
                resp = self.claude.create(
                    model=self.claude.model,
                    max_tokens=MAX_TOKENS,
                    system=system,
                    messages=messages,
                    tools=BROWSER_TOOLS,
                )
            except APIUnavailable as ex:
                note = f"\n\n⚠️ {ex}"
                shown.append(note)
                yield note
                break
            self._account(user_id)  # bill each tool-loop API call
            # surface any text the model produced this step
            for block in resp.content:
                if getattr(block, "type", "") == "text" and block.text:
                    shown.append(block.text)
                    yield block.text

            if resp.stop_reason != "tool_use":
                break

            # record the assistant turn, run each tool, return results
            messages.append({"role": "assistant", "content": resp.content})
            results = []
            for block in resp.content:
                if getattr(block, "type", "") != "tool_use":
                    continue
                note = f"\n\n_🌐 {self._describe_tool(block.name, block.input)}_\n"
                shown.append(note)
                yield note
                output = self._exec_browser_tool(block.name, block.input)
                results.append({
                    "type": "tool_result",
                    "tool_use_id": block.id,
                    "content": output[:4000],
                })
            messages.append({"role": "user", "content": results})

        self._persist_turn(user_text, "".join(shown))

    @staticmethod
    def _describe_tool(name: str, inp: dict) -> str:
        return {
            "browser_open": f"Opening {inp.get('url', '')}",
            "browser_extract": "Reading the page",
            "browser_click": f"Clicking {inp.get('selector', '')}",
            "browser_type": f"Typing into {inp.get('selector', '')}",
            "browser_press": f"Pressing {inp.get('key', 'Enter')}",
            "browser_screenshot": "Taking a screenshot",
        }.get(name, name)

    def _exec_browser_tool(self, name: str, inp: dict) -> str:
        try:
            self._ensure_browser()
            b = self._browser
            if name == "browser_open":
                blocked = self._check_allowed(inp["url"])
                if blocked:
                    return blocked
                b.open(inp["url"])
                return f"Opened {b.current_url()} — title: {b.title()}"
            if name == "browser_extract":
                return b.extract_text(inp.get("selector")) or "(no text found)"
            if name == "browser_click":
                b.click(inp["selector"])
                return f"Clicked {inp['selector']}. Now at {b.current_url()}"
            if name == "browser_type":
                b.fill(inp["selector"], inp["text"])
                return f"Typed into {inp['selector']}"
            if name == "browser_press":
                b.press(inp.get("key", "Enter"))
                return f"Pressed {inp.get('key', 'Enter')}. Now at {b.current_url()}"
            if name == "browser_screenshot":
                return f"Saved: {b.screenshot(str(DATA_DIR / 'browser_shot.png'))}"
            return f"Unknown tool: {name}"
        except Exception as ex:
            return f"Error in {name}: {ex}"

    def feedback(self, text: str, rating: int | None = None) -> None:
        self.memory.record_feedback(text, rating)

    def reset_conversation(self) -> None:
        if self.active_project and self.active_conversation_id:
            self.projects.delete_conversation(self.active_project, self.active_conversation_id)
            self.active_conversation_id = None
        else:
            self.session.clear()

    # -------- browser automation (armed flag + lazy launch) -----------------
    def browser_status(self) -> dict:
        return {
            "armed": self.browser_armed,
            "running": self._browser is not None,
            "restricted": self.browser_restricted,
            "allowlist": self.browser_allowlist,
        }

    def _check_allowed(self, url: str) -> str | None:
        """Return a refusal string if the URL is blocked, else None."""
        if not self.browser_restricted:
            return None
        host = (urlparse(url).netloc or "").lower().split(":")[0]
        ok = any(host == d or host.endswith("." + d) for d in self.browser_allowlist)
        if ok:
            return None
        return (f"BLOCKED: '{host or url}' is not on the safe-sites allowlist. "
                "Tell the user it's blocked and that they can add it in the sidebar "
                "or turn off 'Safe Sites Only'. Do not try other URLs to get around this.")

    def set_browser_restricted(self, restricted: bool) -> None:
        self.browser_restricted = bool(restricted)
        self.settings.set("browser_restricted", self.browser_restricted)

    def add_allowed_site(self, domain: str) -> None:
        d = domain.strip().lower().replace("https://", "").replace("http://", "").split("/")[0]
        if d and d not in self.browser_allowlist:
            self.browser_allowlist.append(d)

    def remove_allowed_site(self, domain: str) -> None:
        self.browser_allowlist = [d for d in self.browser_allowlist if d != domain.strip().lower()]

    def arm_browser(self) -> bool:
        """Enable browser mode. Does NOT launch a browser — that happens lazily
        the first time a task actually needs it."""
        self.browser_armed = True
        return True

    def disarm_browser(self) -> bool:
        self.browser_armed = False
        if self._browser is not None:
            try:
                self._browser.stop()
            finally:
                self._browser = None
        return True

    def _ensure_browser(self):
        if self._browser is None:
            from automation.browser import BrowserController
            ctrl = BrowserController(engine="playwright", headless=False)
            ctrl.start()
            self._browser = ctrl
        return self._browser
