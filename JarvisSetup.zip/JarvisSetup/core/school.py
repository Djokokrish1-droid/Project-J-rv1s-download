"""School-platform Tasks: storage + (stubbed) automation hooks.

Each user gets a per-user data directory holding:
  data/users/<uid>/school.json   — connected platform + automation mode
  data/users/<uid>/tasks.json    — list of assignment tasks

Automation modes:
  "desktop"  → Playwright runs on the user's Mac via the desktop app
  "cloud"    → Playwright runs on the server (uses extra credits)
  "manual"   → user enters tasks by hand; no automation

The actual Playwright drivers live in `core/automation/` (TODO) — this module
just persists state and exposes the surface the Flask routes call.
"""
from __future__ import annotations
import base64
import json
import os
import secrets
import threading
import time
from pathlib import Path

from config import DATA_DIR


# ── storage helpers ─────────────────────────────────────────────────────────
def _user_dir(uid: str) -> Path:
    d = DATA_DIR / "users" / uid
    d.mkdir(parents=True, exist_ok=True)
    return d


def _load_json(p: Path, default):
    if not p.exists():
        return default
    try:
        return json.loads(p.read_text())
    except Exception:
        return default


def _save_json(p: Path, data) -> None:
    p.write_text(json.dumps(data, indent=2))


# ── credentials (encrypted at rest) ─────────────────────────────────────────
# Lightweight XOR-with-rolling-key obfuscation backed by a server secret.
# Good enough to keep creds out of plaintext on disk; not a substitute for
# Fernet/KMS if you ever take this to production scale.
def _server_key() -> bytes:
    """Per-deployment key. Stable across restarts because it's derived from
    the env's SECRET_KEY, plus a per-install salt persisted to disk."""
    base = os.getenv("JARVIS_SCHOOL_KEY") or os.getenv("FLASK_SECRET_KEY") or "jarvis"
    salt_path = DATA_DIR / ".school_salt"
    if salt_path.exists():
        salt = salt_path.read_text().strip()
    else:
        salt = secrets.token_hex(16)
        salt_path.write_text(salt)
    return (base + salt).encode()


def _crypt(b: bytes) -> bytes:
    k = _server_key()
    return bytes(c ^ k[i % len(k)] for i, c in enumerate(b))


def encrypt(s: str) -> str:
    return base64.b64encode(_crypt(s.encode())).decode()


def decrypt(s: str) -> str:
    try:
        return _crypt(base64.b64decode(s.encode())).decode()
    except Exception:
        return ""


# ── platform connection ────────────────────────────────────────────────────
SUPPORTED_PLATFORMS = {
    "google_classroom": "Google Classroom",
    "canvas": "Canvas",
    "schoology": "Schoology",
    "powerschool": "PowerSchool",
    "blackboard": "Blackboard",
    "custom": "Other",
}
# Per-platform metadata for the Connectors UI: icon, login URL, scraper-capable
PLATFORM_META = {
    "google_classroom": {
        "name": "Google Classroom",
        "icon": "🎓",
        "login_url": "https://classroom.google.com/u/0/h",
        "ready": True,
        "warnings": "Uses your real Chrome. Sign in once — J@rv1s caches the session locally.",
    },
    "canvas": {
        "name": "Canvas",
        "icon": "🎨",
        "login_url": "https://canvas.instructure.com",
        "ready": True,
        "warnings": "Enter your school's Canvas URL when connecting (e.g. https://canvas.harvard.edu).",
    },
    "schoology": {
        "name": "Schoology", "icon": "📘",
        "login_url": "https://app.schoology.com",
        "ready": True,
        "warnings": "Enter your district's Schoology URL when connecting (or use app.schoology.com).",
    },
    "powerschool": {
        "name": "PowerSchool", "icon": "🏫",
        "login_url": "https://powerschool.com",
        "ready": False, "warnings": "Scraper not yet built — coming soon.",
    },
    "blackboard": {
        "name": "Blackboard", "icon": "⬛",
        "login_url": "https://blackboard.com",
        "ready": False, "warnings": "Scraper not yet built — coming soon.",
    },
}
VALID_MODES = ("desktop", "cloud", "manual")


def get_platform(uid: str) -> dict | None:
    """Returns the user's connected platform config (without password)."""
    rec = _load_json(_user_dir(uid) / "school.json", None)
    if not rec:
        return None
    return {
        "platform": rec.get("platform"),
        "platform_name": SUPPORTED_PLATFORMS.get(rec.get("platform", ""), "School"),
        "mode": rec.get("mode"),
        "url": rec.get("url"),
        "username": rec.get("username"),
        "has_password": bool(rec.get("password_enc")),
        "connected_at": rec.get("connected_at"),
        "last_synced_at": rec.get("last_synced_at"),
        "last_sync_count": rec.get("last_sync_count"),
    }


def set_platform(uid: str, platform: str, mode: str, *,
                 url: str = "", username: str = "", password: str = "") -> dict:
    """Save the user's school connection. Password is encrypted at rest."""
    if platform not in SUPPORTED_PLATFORMS:
        platform = "custom"
    if mode not in VALID_MODES:
        mode = "manual"
    rec = {
        "platform": platform,
        "mode": mode,
        "url": (url or "").strip(),
        "username": (username or "").strip(),
        "connected_at": time.time(),
    }
    if password:
        rec["password_enc"] = encrypt(password)
    _save_json(_user_dir(uid) / "school.json", rec)
    return get_platform(uid)


def disconnect(uid: str) -> None:
    p = _user_dir(uid) / "school.json"
    if p.exists():
        p.unlink()


# ── multi-connector model (new) ────────────────────────────────────────────
# Stored at data/users/<uid>/connectors.json as a list of dicts:
#   {platform, mode, connected_at, last_synced_at, last_sync_count, last_error,
#    status: "idle" | "syncing" | "error" | "needs_login"}
def _connectors_path(uid: str) -> Path:
    return _user_dir(uid) / "connectors.json"


def list_connectors(uid: str) -> list[dict]:
    """Return all connectors for this user, enriched with platform metadata."""
    conns = _load_json(_connectors_path(uid), [])
    out = []
    for c in conns:
        meta = PLATFORM_META.get(c.get("platform"), {})
        out.append({
            **c,
            "name": meta.get("name", c.get("platform", "Unknown")),
            "icon": meta.get("icon", "🔗"),
            "ready": meta.get("ready", False),
        })
    return out


def get_connector(uid: str, platform: str) -> dict | None:
    for c in list_connectors(uid):
        if c.get("platform") == platform:
            return c
    return None


def upsert_connector(uid: str, platform: str, **fields) -> dict:
    """Create or update a connector entry."""
    conns = _load_json(_connectors_path(uid), [])
    rec = next((c for c in conns if c.get("platform") == platform), None)
    if not rec:
        rec = {"platform": platform, "mode": fields.get("mode", "desktop"),
               "status": "idle", "connected_at": time.time()}
        conns.append(rec)
    for k, v in fields.items():
        if v is not None:
            rec[k] = v
    _save_json(_connectors_path(uid), conns)
    return rec


def remove_connector(uid: str, platform: str) -> bool:
    """Disconnect a platform: wipe its login profile so a reconnect needs a
    fresh sign-in, but KEEP a lightweight record marked 'disconnected' so the
    UI can tell "you disconnected this" apart from "never connected" (and keep
    the user's synced tasks, which live separately)."""
    conns = _load_json(_connectors_path(uid), [])
    rec = next((c for c in conns if c.get("platform") == platform), None)
    if not rec:
        return False
    rec["status"] = "disconnected"
    rec["logged_in"] = False
    rec["disconnected_at"] = time.time()
    _save_json(_connectors_path(uid), conns)
    # Clear the Playwright profile (logged-out state).
    import shutil as _sh
    pd = _user_dir(uid) / "playwright" / platform
    if pd.exists():
        _sh.rmtree(pd, ignore_errors=True)
    return True


# ── stored sign-in credentials (optional auto-login) ─────────────────────
# Encrypted at rest with the same key as the rest of school.py. Only ever used
# to auto-fill the platform's OWN sign-in form. Note: Google frequently blocks
# automated sign-in (2FA / "this browser may not be secure"), so auto-login is
# best-effort and always falls back to the user finishing in the window.
def _creds_path(uid: str) -> Path:
    return _user_dir(uid) / "credentials.json"


def save_credentials(uid: str, platform: str, email: str, password: str) -> bool:
    if not email or not password:
        return False
    data = _load_json(_creds_path(uid), {}) or {}
    data[platform] = {"email": encrypt(email.strip()), "password": encrypt(password)}
    _save_json(_creds_path(uid), data)
    try:  # best-effort tighten perms on the secrets file
        os.chmod(_creds_path(uid), 0o600)
    except Exception:
        pass
    return True


def get_credentials(uid: str, platform: str) -> dict | None:
    rec = (_load_json(_creds_path(uid), {}) or {}).get(platform)
    if not rec:
        return None
    try:
        return {"email": decrypt(rec.get("email", "")),
                "password": decrypt(rec.get("password", ""))}
    except Exception:
        return None


def has_credentials(uid: str, platform: str) -> bool:
    return bool((_load_json(_creds_path(uid), {}) or {}).get(platform))


def delete_credentials(uid: str, platform: str) -> bool:
    data = _load_json(_creds_path(uid), {}) or {}
    if platform in data:
        del data[platform]
        _save_json(_creds_path(uid), data)
        return True
    return False


def is_logged_in(uid: str, platform: str) -> bool:
    """Best-effort check: does a cached Playwright profile exist for this
    platform? Doesn't actually validate the session — sync will surface that."""
    pd = _user_dir(uid) / "playwright" / platform
    return pd.exists() and any(pd.iterdir())


# ── browser-launch safety ────────────────────────────────────────────────
# Only one browser may use a given profile dir at a time. Two concurrent
# launches (e.g. an impatient double-click) make Chromium fail with the cryptic
# "profile is already in use" error. We guard every launch behind an in-flight
# set so the 2nd request gets a friendly message instead of crashing the 1st.
_INFLIGHT: set[tuple[str, str]] = set()
_INFLIGHT_LOCK = threading.Lock()

# URL fragments that mean "still on a sign-in / SSO page, not signed in yet".
_LOGIN_MARKERS = ("accounts.google.com", "servicelogin", "/login", "/signin",
                  "/sso", "saml", "/oauth", "clever.com", "classlink",
                  "myschoolapp", "/auth")


def _try_acquire(uid: str, platform: str) -> bool:
    """Reserve (uid, platform) for a browser op. False if one's already running."""
    key = (uid, platform)
    with _INFLIGHT_LOCK:
        if key in _INFLIGHT:
            return False
        _INFLIGHT.add(key)
        return True


def _release(uid: str, platform: str) -> None:
    with _INFLIGHT_LOCK:
        _INFLIGHT.discard((uid, platform))


# ── Autopilot emergency stop ─────────────────────────────────────────
# A cooperative cancel flag per user. The runner checks it at checkpoints
# (most importantly right before the Turn-in step), so STOP never submits.
_CANCEL: set[str] = set()

def request_cancel(uid: str) -> None:
    with _INFLIGHT_LOCK:
        _CANCEL.add(uid)

def clear_cancel(uid: str) -> None:
    with _INFLIGHT_LOCK:
        _CANCEL.discard(uid)

def is_cancelled(uid: str) -> bool:
    with _INFLIGHT_LOCK:
        return uid in _CANCEL


# ── Autopilot run history (the Dashboard) ────────────────────────────
def _ap_history_path(uid: str) -> Path:
    return _user_dir(uid) / "autopilot_history.json"

def list_autopilot_runs(uid: str) -> list[dict]:
    runs = _load_json(_ap_history_path(uid), []) or []
    runs.sort(key=lambda r: -(r.get("ts") or 0))   # newest first
    return runs

def get_autopilot_run(uid: str, run_id: str) -> dict | None:
    for r in list_autopilot_runs(uid):
        if r.get("id") == run_id:
            return r
    return None

def add_autopilot_run(uid: str, record: dict) -> dict:
    runs = _load_json(_ap_history_path(uid), []) or []
    record = dict(record)
    record.setdefault("id", "ap_" + secrets.token_hex(6))
    record.setdefault("ts", time.time())
    if record.get("answer"):                        # keep the file small
        record["answer"] = str(record["answer"])[:8000]
    runs.insert(0, record)
    _save_json(_ap_history_path(uid), runs[:100])   # keep the last 100 runs
    return record


def _friendly_browser_error(msg: str) -> str:
    """Turn raw Playwright/Chromium errors into something a student can act on."""
    low = (msg or "").lower()
    if "has been closed" in low or "target page" in low:
        return ("The Chrome window closed before sync finished. Click Sync and "
                "let the window run — it closes itself when it's done.")
    if "already in use" in low or "singletonlock" in low:
        return ("A Chrome window is still open from a previous try. Close any "
                "leftover J@rv1s Chrome windows, then Sync again.")
    if "executable doesn't exist" in low or "channel" in low:
        return ("Couldn't launch Chrome. Make sure Google Chrome is installed, "
                "then try again.")
    return msg


def _clear_singleton_locks(profile_dir: Path) -> None:
    """Remove stale Chromium singleton locks from a profile dir.

    Chromium drops SingletonLock / SingletonSocket / SingletonCookie into the
    user-data-dir while a browser is open and removes them on a clean exit. A
    crash (or a force-killed run) leaves them behind, which blocks the NEXT
    launch with "profile already in use". Clearing them before we launch makes
    sync self-heal. Safe because this is a dedicated profile dir — never the
    user's real Chrome profile."""
    for name in ("SingletonLock", "SingletonSocket", "SingletonCookie"):
        try:
            (profile_dir / name).unlink(missing_ok=True)
        except Exception:
            pass


def connect_via_browser(uid: str, platform: str, *, headless: bool = False,
                        wait_seconds: int = 240) -> dict:
    """Launch a real Chrome window for the user to sign into `platform`.
    Blocks until the user lands on a non-login URL OR `wait_seconds` elapses.
    Caches the session in the per-platform Playwright profile dir.
    Returns {ok, logged_in, message}.
    """
    meta = PLATFORM_META.get(platform)
    if not meta:
        return {"ok": False, "error": f"Unknown platform: {platform}"}
    if not meta.get("ready"):
        return {"ok": False, "error": meta.get("warnings", "Not yet supported.")}

    if not _try_acquire(uid, platform):
        return {"ok": False, "busy": True,
                "error": "A sign-in window is already open for this platform — "
                         "finish there (or close it), then try again."}

    pd = _user_dir(uid) / "playwright" / platform
    pd.mkdir(parents=True, exist_ok=True)
    _clear_singleton_locks(pd)
    login_url = meta["login_url"]
    upsert_connector(uid, platform, status="connecting", last_error=None)

    try:
        from playwright.sync_api import sync_playwright
        import time as _t
        with sync_playwright() as pw:
            launch_kwargs = dict(
                user_data_dir=str(pd),
                headless=headless,
                viewport={"width": 1280, "height": 900},
                args=["--disable-blink-features=AutomationControlled",
                      "--no-first-run", "--no-default-browser-check"],
            )
            try:
                ctx = pw.chromium.launch_persistent_context(channel="chrome", **launch_kwargs)
            except Exception:
                ctx = pw.chromium.launch_persistent_context(**launch_kwargs)
            ctx.add_init_script(
                "Object.defineProperty(navigator,'webdriver',{get:()=>undefined});"
                "window.chrome = window.chrome || {runtime:{}};"
            )
            from urllib.parse import urlparse as _urlparse
            target_host = (_urlparse(login_url).netloc or "").lower()
            page = ctx.pages[0] if ctx.pages else ctx.new_page()
            page.goto(login_url, wait_until="domcontentloaded")
            try:
                page.wait_for_load_state("networkidle", timeout=8_000)
            except Exception:
                pass
            page.wait_for_timeout(1200)

            # "Signed in" = landed back on the platform's OWN domain and not on a
            # sign-in / SSO page. Google keeps accounts.google.com in the URL
            # through the entire multi-step sign-in, so we must wait for the
            # POSITIVE arrival on the platform — not merely "left the login page".
            def _signed_in(u):
                u = (u or "").lower()
                if not u or u.startswith("about:"):
                    return False
                if any(s in u for s in _LOGIN_MARKERS):
                    return False
                return bool(target_host) and target_host in u

            def _safe_url(p):
                try: return p.url or ""
                except Exception: return ""

            deadline = _t.time() + wait_seconds
            logged_in = False
            landed_url = ""
            while _t.time() < deadline:
                if not ctx.pages:
                    break  # the user closed the window
                # Sign-in can land in a different tab — scan them all.
                hit = next((p for p in list(ctx.pages) if _signed_in(_safe_url(p))), None)
                if hit is not None:
                    logged_in = True
                    landed_url = _safe_url(hit)
                    hit.wait_for_timeout(1500)  # let the session cookie flush
                    break
                _t.sleep(1)
            try:
                ctx.close()
            except Exception:
                pass
    except Exception as ex:
        msg = _friendly_browser_error(str(ex))
        upsert_connector(uid, platform, status="error", last_error=msg)
        return {"ok": False, "error": msg}
    finally:
        _release(uid, platform)

    status = "idle" if logged_in else "needs_login"
    base = None
    if landed_url:
        try:
            from urllib.parse import urlparse
            p = urlparse(landed_url)
            base = f"{p.scheme}://{p.netloc}"
        except Exception:
            base = None
    upsert_connector(uid, platform, status=status,
                     connected_at=time.time() if logged_in else None,
                     url=base, last_error=None)
    return {"ok": True, "logged_in": logged_in,
            "message": "Signed in ✓" if logged_in else "Login window timed out — try again."}


def sync_connector(uid: str, platform: str, *, headless: bool = False) -> dict:
    """Run the platform scraper and add/dedup tasks. Marks status throughout."""
    meta = PLATFORM_META.get(platform)
    if not meta:
        return {"ok": False, "error": f"Unknown platform: {platform}"}
    if not meta.get("ready"):
        return {"ok": False, "error": meta.get("warnings", "Not yet supported.")}

    if not _try_acquire(uid, platform):
        return {"ok": False, "busy": True,
                "error": "Already syncing this one — give it a few seconds."}

    upsert_connector(uid, platform, status="syncing", last_error=None)
    pd = _user_dir(uid) / "playwright" / platform
    _clear_singleton_locks(pd)
    # Canvas / Schoology need the user's school-specific base URL.
    base_url = (get_connector(uid, platform) or {}).get("url") or None
    # Optional saved credentials → best-effort auto sign-in.
    creds = get_credentials(uid, platform)
    try:
        items = _run_scraper(platform, pd, headless=headless, base_url=base_url,
                             credentials=creds)
    except Exception as ex:
        friendly = _friendly_browser_error(str(ex))
        upsert_connector(uid, platform, status="error", last_error=friendly)
        return {"ok": False, "error": friendly}
    finally:
        _release(uid, platform)

    added = 0
    for it in items:
        before = len(_load_json(_user_dir(uid) / "tasks.json", []))
        add_task(uid, title=it.get("title", ""), subject=it.get("subject", ""),
                 due=it.get("due", ""), link=it.get("link", ""),
                 description=it.get("description", ""),
                 source=it.get("source", platform),
                 external_id=it.get("external_id", ""),
                 status=it.get("status", ""))
        after = len(_load_json(_user_dir(uid) / "tasks.json", []))
        if after > before:
            added += 1

    upsert_connector(uid, platform, status="idle",
                     last_synced_at=time.time(),
                     last_sync_count=len(items),
                     last_added_count=added)
    return {"ok": True, "added": added, "found": len(items),
            "tasks": list_tasks(uid),
            "message": f"Synced {len(items)} ({added} new)."}


# ── tasks ──────────────────────────────────────────────────────────────────
def list_tasks(uid: str) -> list[dict]:
    tasks = _load_json(_user_dir(uid) / "tasks.json", [])
    # newest-first by due (urgent first) then by created
    tasks.sort(key=lambda t: (t.get("due") or "9999", -(t.get("created") or 0)))
    return tasks


def get_task(uid: str, task_id: str) -> dict | None:
    for t in list_tasks(uid):
        if t.get("id") == task_id:
            return t
    return None


def add_task(uid: str, *, title: str, subject: str = "", due: str = "",
             link: str = "", description: str = "", source: str = "manual",
             external_id: str = "", status: str = "") -> dict:
    """Add a task. If `external_id` is supplied and already present, the
    existing task is updated (title/due/link/status refreshed) rather than
    duplicated. `status` is the platform tab origin ('assigned'|'missing') —
    the authoritative Missing-vs-Assigned signal. Returns the task."""
    tasks = _load_json(_user_dir(uid) / "tasks.json", [])
    # Dedup by external_id when present (e.g. classroom:c123:a456)
    if external_id:
        for t in tasks:
            if t.get("external_id") == external_id:
                t["title"] = (title or t.get("title", "")).strip() or t["title"]
                if subject: t["subject"] = subject.strip()
                if due:     t["due"] = due.strip()
                if link:    t["link"] = link.strip()
                if description: t["description"] = description.strip()
                if status:  t["status"] = status.strip()
                t["last_synced"] = time.time()
                _save_json(_user_dir(uid) / "tasks.json", tasks)
                return t
    task = {
        "id": "t_" + secrets.token_hex(6),
        "external_id": external_id,
        "title": (title or "").strip() or "Untitled task",
        "subject": (subject or "").strip(),
        "due": (due or "").strip(),
        "link": (link or "").strip(),
        "description": (description or "").strip(),
        "source": source,       # "manual" | "google_classroom" | "canvas" | …
        "status": (status or "").strip(),   # 'assigned' | 'missing' | ''
        "done": False,
        "created": time.time(),
    }
    tasks.append(task)
    _save_json(_user_dir(uid) / "tasks.json", tasks)
    return task


def update_task(uid: str, task_id: str, **fields) -> dict | None:
    tasks = _load_json(_user_dir(uid) / "tasks.json", [])
    for t in tasks:
        if t.get("id") == task_id:
            for k, v in fields.items():
                if v is not None:
                    t[k] = v
            _save_json(_user_dir(uid) / "tasks.json", tasks)
            return t
    return None


def delete_task(uid: str, task_id: str) -> bool:
    tasks = _load_json(_user_dir(uid) / "tasks.json", [])
    new = [t for t in tasks if t.get("id") != task_id]
    if len(new) == len(tasks):
        return False
    _save_json(_user_dir(uid) / "tasks.json", new)
    return True


# ── bulk task ops (multi-select) ─────────────────────────────────────────
def bulk_delete(uid: str, ids: list[str]) -> int:
    """Delete many tasks by id. Returns how many were removed."""
    idset = set(ids or [])
    tasks = _load_json(_user_dir(uid) / "tasks.json", [])
    kept = [t for t in tasks if t.get("id") not in idset]
    removed = len(tasks) - len(kept)
    if removed:
        _save_json(_user_dir(uid) / "tasks.json", kept)
    return removed


def delete_all_tasks(uid: str) -> int:
    """Delete every task. Returns how many were removed."""
    tasks = _load_json(_user_dir(uid) / "tasks.json", [])
    n = len(tasks)
    if n:
        _save_json(_user_dir(uid) / "tasks.json", [])
    return n


def bulk_set_done(uid: str, ids: list[str], done: bool = True) -> int:
    """Mark many tasks done/undone. Returns how many changed."""
    idset = set(ids or [])
    tasks = _load_json(_user_dir(uid) / "tasks.json", [])
    n = 0
    for t in tasks:
        if t.get("id") in idset and bool(t.get("done")) != bool(done):
            t["done"] = bool(done); n += 1
    if n:
        _save_json(_user_dir(uid) / "tasks.json", tasks)
    return n


## (kept-in-file shim — actual Playwright sync lives in sync_tasks below)
def _profile_dir(uid: str, platform: str) -> Path:
    p = _user_dir(uid) / "playwright" / platform
    p.mkdir(parents=True, exist_ok=True)
    return p


# ── sync + automation ─────────────────────────────────────────────────────
def sync_tasks(uid: str, *, force_local: bool = False) -> dict:
    """Pull current assignments from the connected platform.

    `force_local=True` means we're inside the desktop app — run Playwright
    in-process, with a headed browser. Otherwise on the cloud server:
      - mode=desktop → tell the web client to open the desktop app
      - mode=cloud   → run Playwright headlessly on the server
      - mode=manual  → no-op
    """
    cfg = get_platform(uid)
    if not cfg:
        return {"ok": False, "error": "no_platform"}
    platform = cfg.get("platform")
    mode = cfg.get("mode")

    # Manual mode never syncs.
    if mode == "manual":
        return {"ok": True, "queued": False, "added": 0,
                "message": "Manual mode — add tasks by hand."}

    # Desktop mode on the cloud server → tell the client to open the app.
    if mode == "desktop" and not force_local:
        return {"ok": True, "queued": False, "added": 0,
                "message": "Open the J@rv1s desktop app to run sync locally.",
                "action": "open_desktop_app"}

    # Cloud mode (or desktop running locally) → actually scrape.
    headless = (mode == "cloud") and not force_local
    try:
        items = _run_scraper(platform, _profile_dir(uid, platform), headless=headless)
    except Exception as ex:
        return {"ok": False, "error": str(ex),
                "message": f"Sync failed: {ex}"}

    added = 0
    for it in items:
        before = len(_load_json(_user_dir(uid) / "tasks.json", []))
        add_task(uid,
                 title=it.get("title", ""),
                 subject=it.get("subject", ""),
                 due=it.get("due", ""),
                 link=it.get("link", ""),
                 description=it.get("description", ""),
                 source=it.get("source", platform),
                 external_id=it.get("external_id", ""))
        after = len(_load_json(_user_dir(uid) / "tasks.json", []))
        if after > before:
            added += 1

    # Update last-synced timestamp on the platform config.
    rec = _load_json(_user_dir(uid) / "school.json", {}) or {}
    rec["last_synced_at"] = time.time()
    rec["last_sync_count"] = len(items)
    _save_json(_user_dir(uid) / "school.json", rec)

    return {"ok": True, "added": added, "found": len(items),
            "message": (f"Synced {len(items)} assignment{'s' if len(items)!=1 else ''} "
                        f"({added} new)."),
            "tasks": list_tasks(uid)}


def _run_scraper(platform: str, profile_dir: Path, *, headless: bool,
                 base_url: str | None = None, credentials: dict | None = None) -> list[dict]:
    """Dispatch to the correct scraper module."""
    if platform == "google_classroom":
        from automation.scrapers import google_classroom
        return google_classroom.scrape(profile_dir, headless=headless,
                                       credentials=credentials)
    if platform == "canvas":
        from automation.scrapers import canvas
        return canvas.scrape(profile_dir, base_url=base_url, headless=headless)
    if platform == "schoology":
        from automation.scrapers import schoology
        return schoology.scrape(profile_dir, base_url=base_url, headless=headless)
    raise NotImplementedError(
        f"Scraper for '{platform}' isn't built yet. "
        f"Currently supported: google_classroom, canvas, schoology."
    )


def run_task(uid: str, task_id: str, mode_choice: str = "answers",
             *, claude=None, user_context: str = "", instructions: str = "") -> dict:
    """Have J@rv1s work the assignment via Autopilot.

    mode_choice:
      "answers"  → read assignment (+ attached Google Doc) → write the answer →
                   type it INTO the attached Doc. Returns the answer + doc link.
      "submit"   → everything above PLUS click Turn in / Mark as done.
    instructions: optional free-text guidance the student typed for Autopilot.
    """
    task = get_task(uid, task_id)
    if not task:
        return {"ok": False, "error": "no_such_task"}

    if claude is None:
        return {"ok": False, "error": "Engine not available."}

    do_submit = (mode_choice == "submit")
    platform = task.get("source") or "google_classroom"
    profile = _profile_dir(uid, platform)

    # Same profile dir as connect/sync — serialize so a double-click (or a sync
    # running at the same time) can't launch two browsers on it.
    if not _try_acquire(uid, platform):
        return {"ok": False, "busy": True,
                "error": "A browser is already open for this account — let it "
                         "finish (or close it), then run Autopilot again."}
    _clear_singleton_locks(profile)
    clear_cancel(uid)                       # fresh run — drop any stale stop request
    from core.assignment_runner import do_assignment
    try:
        result = do_assignment(task, profile_dir=profile,
                               user_context=user_context, claude=claude,
                               headless=False, write_doc=True, doc_mode="append",
                               submit=do_submit, extra_instructions=instructions,
                               should_cancel=lambda: is_cancelled(uid))
    finally:
        _release(uid, platform)
        clear_cancel(uid)

    try:                                    # log the run for the Autopilot Dashboard
        add_autopilot_run(uid, {
            "task_id": task_id, "title": task.get("title", ""),
            "subject": task.get("subject", ""), "link": task.get("link", ""),
            "mode": mode_choice, "instructions": instructions,
            "ok": result.get("ok", False), "answer": result.get("answer", ""),
            "wrote_to_doc": result.get("wrote_to_doc", False),
            "doc_url": result.get("doc_url", ""),
            "turned_in": result.get("turned_in", False),
            "submit_state": result.get("submit_state", ""),
            "error": result.get("error", ""),
        })
    except Exception:
        pass

    return {
        "ok": result["ok"],
        "task": task,
        "answer": result.get("answer", ""),
        "page_title": result.get("page_title", ""),
        "wrote_to_doc": result.get("wrote_to_doc", False),
        "doc_url": result.get("doc_url", ""),
        "doc_ids": result.get("doc_ids", []),
        "instructions_chars": result.get("instructions_chars", 0),
        "doc_chars": result.get("doc_chars", 0),
        "turned_in": result.get("turned_in", False),
        "submit_state": result.get("submit_state", ""),
        "error": result.get("error", ""),
    }
