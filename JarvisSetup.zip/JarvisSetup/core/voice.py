"""Your Voice — learn the user's authentic writing style from their own work.

Ingest writing samples the student *actually wrote*, analyze them into a style
profile + a plain-English report, then register a custom skill ("<Name>'s
Voice") that makes Jarvis write and rewrite in *their* voice.

This is voice-matching from the user's real samples — it reproduces how THEY
write because it's modeled on their own writing. It is not a detector-evasion
tool: there's no third-party "undetectable" service and no claim of beating
plagiarism checkers. The output sounds like the student because it's built from
the student's own words.
"""
from __future__ import annotations
import io
import json
import re
import time
import zipfile
from pathlib import Path

MAX_SAMPLES = 12
MAX_SAMPLE_CHARS = 14000        # per sample
MIN_WORDS = 120                 # need at least this much total to analyze
ANALYZE_MODEL = "claude-sonnet-4-6"   # one-time, quality matters more than cost


def _words(t: str) -> int:
    return len(re.findall(r"\S+", t or ""))


def _slug(name: str) -> str:
    # mirror SkillsManager.create's id derivation so get/update line up
    return "-".join("".join(c if c.isalnum() else " " for c in (name or "").lower()).split())


def _parse_json(raw: str):
    if not raw:
        return None
    raw = raw.strip()
    if raw.startswith("```"):
        raw = re.sub(r"^```[a-zA-Z]*\n?", "", raw)
        raw = re.sub(r"\n?```$", "", raw).strip()
    try:
        return json.loads(raw)
    except Exception:
        pass
    i, j = raw.find("{"), raw.rfind("}")
    if i != -1 and j != -1 and j > i:
        try:
            return json.loads(raw[i:j + 1])
        except Exception:
            return None
    return None


# ── file text extraction (dependency-free) ──────────────────────────────────
def extract_text(filename: str, raw: bytes) -> str:
    """Pull plain text out of an uploaded file. Supports .docx (zip+xml) and any
    text-decodable file (.txt/.md/etc). PDFs aren't supported here — paste instead."""
    name = (filename or "").lower()
    if name.endswith(".docx"):
        return _docx_text(raw)
    if name.endswith(".pdf"):
        return ""   # no PDF lib; caller tells the user to paste
    for enc in ("utf-8", "utf-16", "latin-1"):
        try:
            return raw.decode(enc)
        except Exception:
            continue
    return ""


def _docx_text(raw: bytes) -> str:
    try:
        zf = zipfile.ZipFile(io.BytesIO(raw))
        xml = zf.read("word/document.xml").decode("utf-8", "ignore")
    except Exception:
        return ""
    xml = re.sub(r"</w:p>", "\n", xml)       # paragraph breaks
    xml = re.sub(r"<[^>]+>", "", xml)         # strip tags
    for a, b in (("&amp;", "&"), ("&lt;", "<"), ("&gt;", ">"),
                 ("&quot;", '"'), ("&apos;", "'")):
        xml = xml.replace(a, b)
    return re.sub(r"\n{3,}", "\n\n", xml).strip()


class VoiceManager:
    """Per-user store + analysis. Lives at data_dir/voice.json."""

    def __init__(self, path, claude, skills, owner_name: str = ""):
        self.path = Path(path)
        self.claude = claude          # ClaudeClient
        self.skills = skills          # SkillsManager (to register the voice skill)
        self.owner_name = owner_name or "My"
        self.data = {"samples": [], "profile": None, "report": "",
                     "voice_name": "", "skill_id": "", "updated": 0, "seq": 0}
        self._load()

    # ----- persistence ---------------------------------------------------
    def _load(self) -> None:
        if not self.path.exists():
            return
        try:
            self.data.update(json.loads(self.path.read_text()))
        except Exception:
            pass

    def _save(self) -> None:
        try:
            self.path.write_text(json.dumps(self.data, indent=2))
        except Exception:
            pass

    # ----- samples -------------------------------------------------------
    def add_sample(self, text: str, title: str = "") -> dict:
        text = (text or "").strip()[:MAX_SAMPLE_CHARS]
        if _words(text) < 5:
            raise ValueError("That sample is too short to learn anything from.")
        self.data["seq"] = self.data.get("seq", 0) + 1
        sid = f"s{self.data['seq']}"
        title = (title or "").strip() or self._auto_title(text)
        self.data["samples"].append({
            "id": sid, "title": title[:60], "text": text,
            "words": _words(text), "added": time.time(),
        })
        # keep the most recent MAX_SAMPLES
        self.data["samples"] = self.data["samples"][-MAX_SAMPLES:]
        self._save()
        return self._sample_meta(self.data["samples"][-1])

    def remove_sample(self, sid: str) -> bool:
        n = len(self.data["samples"])
        self.data["samples"] = [s for s in self.data["samples"] if s["id"] != sid]
        if len(self.data["samples"]) < n:
            self._save()
            return True
        return False

    @staticmethod
    def _auto_title(text: str) -> str:
        first = (text.strip().splitlines() or ["Sample"])[0].strip()
        return (first[:48] or "Sample")

    @staticmethod
    def _sample_meta(s: dict) -> dict:
        return {"id": s["id"], "title": s["title"], "words": s.get("words", 0),
                "preview": s["text"][:140]}

    def total_words(self) -> int:
        return sum(s.get("words", 0) for s in self.data["samples"])

    def state(self) -> dict:
        tw = self.total_words()
        return {
            "samples": [self._sample_meta(s) for s in self.data["samples"]],
            "total_words": tw,
            "min_words": MIN_WORDS,
            "max_samples": MAX_SAMPLES,
            "ready_to_analyze": tw >= MIN_WORDS,
            "has_profile": bool(self.data.get("profile")),
            "report": self.data.get("report", ""),
            "voice_name": self.data.get("voice_name", ""),
            "skill_id": self.data.get("skill_id", ""),
            "updated": self.data.get("updated", 0),
        }

    # ----- LLM helper ----------------------------------------------------
    def _complete(self, system: str, user: str, model=None, max_tokens=2000) -> str:
        resp = self.claude.create(
            model=model or self.claude.model,
            max_tokens=max_tokens,
            system=[{"type": "text", "text": system}],
            messages=[{"role": "user", "content": user}],
        )
        return "".join(b.text for b in resp.content
                       if getattr(b, "type", "") == "text").strip()

    # ----- analysis ------------------------------------------------------
    def analyze(self) -> dict:
        tw = self.total_words()
        if tw < MIN_WORDS:
            raise ValueError(f"Add at least {MIN_WORDS} words of your own writing first "
                             f"(you have {tw}).")
        samples = self.data["samples"]
        joined = "\n\n".join(
            f"--- SAMPLE {i + 1}: {s['title']} ---\n{s['text']}"
            for i, s in enumerate(samples)
        )[:40000]

        system = (
            "You are a writing-style analyst. You are given several writing "
            "samples ALL WRITTEN BY THE SAME PERSON (a student). Reverse-engineer "
            "their authentic voice so it can be reproduced faithfully. Be specific "
            "and evidence-based — point to real patterns in these samples, not "
            "generic writing advice. Output STRICT JSON only, no prose around it."
        )
        schema = (
            '{\n'
            '  "voice_name": "<FirstName>\'s Voice, or \\"My Voice\\" if no name is clear",\n'
            '  "summary": "one sentence on how this person writes",\n'
            '  "report_md": "markdown report, 4-7 short ## sections: Tone, Sentence rhythm, '
            'Vocabulary, Structure, Punctuation & formatting habits, Signature moves, Tics to watch. '
            'Quote 2-3 short real phrases from the samples as evidence.",\n'
            '  "style_rules": ["8-14 concrete imperative rules that reproduce this exact voice"],\n'
            '  "signature_phrases": ["short verbatim words/phrases they actually use"],\n'
            '  "avoid": ["patterns this writer never uses that would break the illusion"]\n'
            '}'
        )
        user = f"WRITING SAMPLES:\n{joined}\n\nReturn JSON exactly in this shape:\n{schema}"
        raw = self._complete(system, user, model=ANALYZE_MODEL, max_tokens=2600)
        prof = _parse_json(raw)
        if not prof:
            prof = {"voice_name": f"{self.owner_name} Voice", "summary": "",
                    "report_md": raw[:4000], "style_rules": [],
                    "signature_phrases": [], "avoid": []}

        voice_name = (prof.get("voice_name") or f"{self.owner_name} Voice").strip()[:40]
        report = prof.get("report_md") or ""
        skill_prompt = self._build_skill_prompt(prof, samples)
        skill_id = self._register_skill(voice_name, prof.get("summary", ""), skill_prompt)

        self.data.update({"profile": prof, "report": report, "voice_name": voice_name,
                          "skill_id": skill_id, "updated": time.time()})
        self._save()
        st = self.state()
        st["skill"] = self.skills.get(skill_id)
        return st

    def _build_skill_prompt(self, prof: dict, samples: list) -> str:
        rules = prof.get("style_rules") or []
        sigs = prof.get("signature_phrases") or []
        avoid = prof.get("avoid") or []
        anchors = []
        for s in samples:
            snip = " ".join(s["text"].split())[:280]
            if snip:
                anchors.append(snip)
            if len(anchors) >= 3:
                break

        parts = [
            "Write in the user's OWN authentic voice, learned from their real "
            "writing. Reproduce how THEY write — this is their personal style, not "
            "a generic one. Keep their wording, rhythm, and tone sounding like them.",
            "",
            "Voice rules:",
        ]
        parts += [f"- {r}" for r in rules[:14]]
        if sigs:
            parts.append("Words/phrases they actually use (work them in naturally, "
                         "don't force): " + ", ".join(sigs[:12]) + ".")
        if avoid:
            parts.append("Never do these — it breaks their voice:")
            parts += [f"- {a}" for a in avoid[:8]]
        if anchors:
            parts.append("\nReal excerpts of their writing — match this exact feel:")
            for a in anchors:
                parts.append(f"> {a}")
        return "\n".join(parts)

    def _register_skill(self, voice_name: str, summary: str, prompt: str) -> str:
        sid = _slug(voice_name)
        desc = summary or "Writes and rewrites in your own voice."
        if self.skills.get(sid):
            self.skills.update(sid, name=voice_name, description=desc, prompt=prompt)
        else:
            sk = self.skills.create(name=voice_name, description=desc,
                                    prompt=prompt, icon="🖋️")
            sid = sk["id"]
        return sid

    # ----- generation ----------------------------------------------------
    def write(self, text: str, mode: str = "rewrite", instructions: str = "") -> str:
        prof = self.data.get("profile")
        if not prof:
            raise ValueError("Learn your voice first — add a few writing samples and analyze them.")
        text = (text or "").strip()
        if not text:
            raise ValueError("Give me something to work with — paste text to rewrite, "
                             "or describe what to write.")

        rules = "\n".join(f"- {r}" for r in (prof.get("style_rules") or [])[:14])
        sigs = ", ".join((prof.get("signature_phrases") or [])[:12])
        anchors = []
        for s in self.data["samples"]:
            snip = " ".join(s["text"].split())[:300]
            if snip:
                anchors.append(snip)
            if len(anchors) >= 3:
                break
        anchor_block = "\n".join(f"> {a}" for a in anchors)

        system = (
            "You reproduce a specific person's authentic writing voice, learned "
            "from their own real writing. Make the output genuinely sound like "
            "them. Output ONLY the finished text — no preamble, no notes, no "
            "explanation.\n\n"
            f"THEIR VOICE RULES:\n{rules}\n"
            + (f"\nWORDS THEY USE: {sigs}\n" if sigs else "")
            + (f"\nREAL EXCERPTS (match this feel):\n{anchor_block}\n" if anchor_block else "")
        )
        if mode == "write":
            user = ("Write the following in their voice"
                    + (f", following these instructions: {instructions}" if instructions else "")
                    + f":\n\n{text}")
        else:
            user = ("Rewrite the text below so it reads as if THEY wrote it from "
                    "scratch. Keep the meaning and any facts intact, but make the "
                    "wording, rhythm, and tone fully theirs."
                    + (f" Also: {instructions}" if instructions else "")
                    + f"\n\nTEXT:\n{text}")
        return self._complete(system, user, model=None, max_tokens=2000)
