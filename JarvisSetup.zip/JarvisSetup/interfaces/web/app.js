// =====================================================
// JARVIS — frontend logic
// =====================================================
const API = (path, opts) => fetch(path, opts).then(async r => {
  const text = await r.text();
  const data = text ? JSON.parse(text) : {};
  return r.ok ? data : Promise.reject(data);
});

// State
let state = {
  active_project: null,
  active_conversation_id: null,
  model: 'claude-opus-4-7',
  projects: [],
  upcoming: [],
  history: [],
  skills: [],
  browser: { running: false },
};
let currentProjectPage = null;  // name of project currently shown in project view
let models = [];
let speakResponses = false;
let skillFilter = 'all';
let skillSearch = '';

// DOM helpers
const $ = (id) => document.getElementById(id);
const $$ = (sel) => document.querySelectorAll(sel);

// Elements
const chat = $('chat');
const input = $('input');
const sendBtn = $('send-btn');
const voiceBtn = $('voice-btn');
const projectList = $('project-list');
const upcomingList = $('upcoming-list');
const activeProjectDisplay = $('active-project-display');
const modelBadge = $('model-badge');
const modelBadgeName = $('model-badge-name');
const modelDropdown = $('model-dropdown');
const statusDot = $('status-dot');
const statusText = $('status-text');
const projectModal = $('modal-backdrop');
const skillModal = $('skill-modal-backdrop');
const browserToggle = $('browser-toggle');
const voiceOutToggle = $('voice-out-toggle');

marked.setOptions({
  breaks: true,
  gfm: true,
  highlight: (code, lang) => {
    if (lang && hljs.getLanguage(lang)) {
      try { return hljs.highlight(code, { language: lang }).value; } catch {}
    }
    return hljs.highlightAuto(code).value;
  },
});

function escape(s) {
  return String(s).replace(/[&<>"']/g, c => ({
    '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
  }[c]));
}

// =====================================================
// Dynamic welcome screen (randomized every load)
// =====================================================
const USER = 'Krish';

// Honor the OS "reduce motion" setting for JS-driven animation (the CSS @media
// block can't stop requestAnimationFrame loops or setTimeout-staggered reveals).
const REDUCED_MOTION = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);

const GREETINGS = [
  'How can I help, {n}?',
  'What are we tackling, {n}?',
  'Systems online. Your move, {n}.',
  'Ready when you are, {n}.',
  "Let's get to work, {n}.",
  "What's the mission, {n}?",
  '{day}, {n}.',
  'Back at it, {n}?',
  'All systems nominal, {n}.',
  'Standing by, {n}.',
  "Let's make today count, {n}.",
  'Online and ready, {n}.',
  'At your service, {n}.',
];

const TAGLINES = [
  'Manage projects, draft work, automate tasks.',
  'Homework, deadlines, and everything in between.',
  'Your second brain for school.',
  'Think faster. Submit smarter.',
  'Four subjects, one assistant.',
  'Less busywork. More learning.',
  'Built to make school effortless.',
  'Your unfair advantage, quietly.',
  'Point me at the hard part.',
];

const SUGGESTION_POOL = [
  { icon: '🎯', title: 'Focus Today', desc: "What's most important right now", prompt: 'What should I focus on today?' },
  { icon: '📅', title: "This Week's Deadlines", desc: 'Surface upcoming work', prompt: 'Show me everything due in the next week.' },
  { icon: '📚', title: 'Plan a Study Block', desc: 'Structure focused time', prompt: 'Help me plan my study session.' },
  { icon: '💡', title: 'Quiz Me', desc: 'Active recall on a topic', prompt: "Quiz me on what I'm currently studying." },
  { icon: '✍️', title: 'Write an Essay', desc: 'Outline then draft', prompt: 'Help me outline and draft an essay. Ask me the topic first.' },
  { icon: '🧮', title: 'Solve a Problem', desc: 'Step-by-step walkthrough', prompt: "I have a homework problem I'm stuck on. Walk me through it." },
  { icon: '📖', title: 'Explain a Concept', desc: 'Simply, then test me', prompt: 'Explain a concept I am struggling with, simply, then test me on it.' },
  { icon: '🗂️', title: 'Summarize Notes', desc: 'Key points to review', prompt: 'Summarize my notes into key points I can review.' },
  { icon: '⚡', title: 'Beat Procrastination', desc: 'A 10-minute starter task', prompt: "I'm procrastinating. Give me a 10-minute task to start right now." },
  { icon: '🔬', title: 'Lab Report Help', desc: 'Structure the writeup', prompt: 'Help me structure a lab report for my science class.' },
  { icon: '🌐', title: 'Research a Topic', desc: 'Find solid sources', prompt: 'Help me research a topic and find credible sources.' },
  { icon: '📝', title: 'Check My Work', desc: 'Point out what to fix', prompt: 'Review what I wrote and point out what to improve.' },
];

function pick(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
function sample(arr, n) {
  const copy = [...arr];
  const out = [];
  while (out.length < n && copy.length) out.push(copy.splice(Math.floor(Math.random() * copy.length), 1)[0]);
  return out;
}
function dayPart() {
  const h = new Date().getHours();
  if (h < 12) return 'Good morning';
  if (h < 18) return 'Good afternoon';
  return 'Good evening';
}

function renderWelcome() {
  const titleEl = $('welcome-title');
  const subEl = $('welcome-sub');
  const sugEl = $('welcome-suggestions');
  if (!titleEl) return;

  // greeting
  const g = pick(GREETINGS).replace('{day}', dayPart()).replace('{n}', `<span class="grad">${USER}</span>`);
  titleEl.innerHTML = g;
  subEl.textContent = pick(TAGLINES);

  // clean, calm reveal — no glitch, no boot sequence
  titleEl.style.animation = REDUCED_MOTION ? 'none' : 'fadeUp 0.55s var(--ease-out) 0.05s both';
  subEl.style.animation   = REDUCED_MOTION ? 'none' : 'fadeUp 0.55s var(--ease-out) 0.16s both';

  // suggestions: 4 random
  sugEl.innerHTML = '';
  sample(SUGGESTION_POOL, 4).forEach((s, i) => {
    const b = document.createElement('button');
    b.className = 'suggestion';
    b.style.animationDelay = REDUCED_MOTION ? '0s' : `${(0.28 + i * 0.07).toFixed(2)}s`;
    b.innerHTML = `<div class="suggestion-icon">${s.icon}</div>
      <div><div class="suggestion-title">${escape(s.title)}</div>
      <div class="suggestion-desc">${escape(s.desc)}</div></div>`;
    b.addEventListener('click', () => { input.value = s.prompt; autosize(); send(); });
    sugEl.appendChild(b);
  });
}

// Cursor-reactive magnetism for the welcome screen
function wireWelcomeFX() {
  const welcome = $('welcome');
  const reactor = welcome && welcome.querySelector('.reactor');
  const title = $('welcome-title');
  const sub = $('welcome-sub');
  if (!welcome || !reactor || welcome.dataset.fxWired) return;
  welcome.dataset.fxWired = '1';

  // Reduced-motion: leave the orb static (CSS pulses are already disabled by the
  // @media block) and skip the perpetual rAF spin, cursor tilt, and card-tilt loops.
  if (REDUCED_MOTION) return;

  welcome.addEventListener('mousemove', (e) => {
    const r = reactor.getBoundingClientRect();
    const cx = r.left + r.width / 2;
    const cy = r.top + r.height / 2;
    const dx = (e.clientX - cx) / 22;   // tilt strength
    const dy = (e.clientY - cy) / 22;
    reactor.style.transform = `rotateY(${Math.max(-22, Math.min(22, dx))}deg) rotateX(${Math.max(-22, Math.min(22, -dy))}deg)`;
    // subtle parallax on text
    if (title) title.style.transform = `translate(${dx * 0.25}px, ${dy * 0.25}px)`;
    if (sub) sub.style.transform = `translate(${dx * 0.4}px, ${dy * 0.4}px)`;
  });
  welcome.addEventListener('mouseleave', () => {
    reactor.style.transform = '';
    if (title) title.style.transform = '';
    if (sub) sub.style.transform = '';
  });
  // ---- Proximity-driven spin: slow when far, light-speed at the core ----
  const rings = [
    { el: reactor.querySelector('.ring-1'),       base: 48,  dir: 1,  a: 0 },
    { el: reactor.querySelector('.ring-2'),       base: 70,  dir: -1, a: 0 },
    { el: reactor.querySelector('.ring-3'),       base: 104, dir: 1,  a: 0 },
    { el: reactor.querySelector('.reactor-ticks'),base: 14,  dir: 1,  a: 0 },
  ];
  const glow = reactor.querySelector('.reactor-glow');
  const core = reactor.querySelector('.reactor-core');
  if (glow) glow.style.animation = 'none';  // JS drives glow now (avoid CSS conflict)
  let speed = 1;          // eased current multiplier
  let target = 1;         // proximity-derived multiplier
  let lastT = performance.now();

  window.addEventListener('mousemove', (e) => {
    const r = reactor.getBoundingClientRect();
    if (!r.width) return;
    const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
    const d = Math.hypot(e.clientX - cx, e.clientY - cy);
    const maxDist = 480;
    const prox = Math.max(0, 1 - d / maxDist);   // 0 (far) … 1 (centered)
    // steep curve so it really winds up near the core
    target = 1 + Math.pow(prox, 2.4) * 42;       // up to ~43× near the core
  });
  window.addEventListener('mouseout', (e) => { if (!e.relatedTarget) target = 1; });

  function spinFrame(t) {
    if (!reactor.isConnected) return;            // welcome removed → stop loop
    const dt = Math.min(0.05, (t - lastT) / 1000);
    lastT = t;
    speed += (target - speed) * Math.min(1, dt * 3.5);   // smooth ease
    rings.forEach(ring => {
      if (!ring.el) return;
      ring.a += ring.dir * ring.base * speed * dt;
      ring.el.style.transform = `rotate(${ring.a.toFixed(2)}deg)`;
    });
    // glow + core intensify with speed
    const intensity = Math.min(1, (speed - 1) / 42);
    if (glow) {
      glow.style.opacity = (0.5 + intensity * 0.5).toFixed(3);
      glow.style.transform = `scale(${(0.95 + intensity * 0.5).toFixed(3)})`;
    }
    if (core) core.style.filter = `brightness(${(1 + intensity * 0.8).toFixed(2)})`;
    requestAnimationFrame(spinFrame);
  }
  requestAnimationFrame(spinFrame);

  // 3D tilt on each suggestion card
  welcome.querySelectorAll('.suggestion').forEach(card => {
    card.addEventListener('mousemove', (e) => {
      const r = card.getBoundingClientRect();
      const px = (e.clientX - r.left) / r.width - 0.5;
      const py = (e.clientY - r.top) / r.height - 0.5;
      card.style.transform =
        `perspective(600px) rotateX(${(-py * 12).toFixed(2)}deg) rotateY(${(px * 12).toFixed(2)}deg) translateY(-3px) scale(1.03)`;
    });
    card.addEventListener('mouseleave', () => { card.style.transform = ''; });
  });
}

// =====================================================
// Auth (hosted mode)
// =====================================================
let authMode = 'login';
const authOverlay = $('auth-overlay');

function showAuth() { authOverlay.classList.remove('hidden'); $('auth-username').focus(); }
function hideAuth() { authOverlay.classList.add('hidden'); }

function setAuthMode(mode) {
  authMode = mode;
  const signup = mode === 'signup';
  $('auth-username').placeholder = 'Email';
  $('auth-username').setAttribute('autocomplete', signup ? 'email' : 'username');
  $('auth-sub').textContent = signup ? 'Create your Personal Agent account' : 'Sign in to your Personal Agent';
  $('auth-submit').textContent = signup ? 'Create Account' : 'Sign In';
  $('auth-switch-text').textContent = signup ? 'Already have an account?' : 'New here?';
  $('auth-switch-link').textContent = signup ? 'Sign in' : 'Create an account';
  $('auth-password').setAttribute('autocomplete', signup ? 'new-password' : 'current-password');
  $('auth-confirm-wrap').style.display = signup ? 'block' : 'none';  // confirm only on signup
  $('auth-confirm').value = '';
  const fr = $('auth-forgot-row'); if (fr) fr.style.display = signup ? 'none' : 'block';
  $('auth-error').textContent = '';
}

// show / hide password (controls both password + confirm)
let pwVisible = false;
const pwToggle = $('auth-pw-toggle');
if (pwToggle) pwToggle.addEventListener('click', () => {
  pwVisible = !pwVisible;
  const t = pwVisible ? 'text' : 'password';
  $('auth-password').type = t;
  $('auth-confirm').type = t;
  pwToggle.querySelector('.eye').style.display = pwVisible ? 'none' : 'block';
  pwToggle.querySelector('.eye-off').style.display = pwVisible ? 'block' : 'none';
});

async function submitAuth() {
  const username = $('auth-username').value.trim();
  const password = $('auth-password').value;
  if (!username || !password) { $('auth-error').textContent = 'Enter a username and password.'; return; }
  const isSignup = authMode === 'signup';
  if (isSignup && password !== $('auth-confirm').value) {
    $('auth-error').textContent = 'Passwords don’t match.';
    return;
  }
  try {
    await API(`/api/auth/${isSignup ? 'signup' : 'login'}`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password }),
    });
    hideAuth();
    $('auth-password').value = '';
    if (isSignup) {
      // New users: show the tutorial first, then boot into app, then paywall.
      tutIndex = 0;
      showTutorial();
    } else {
      // Returning users: standard boot (paywall pops immediately if gated).
      boot();
    }
  } catch (e) {
    const errEl = $('auth-error');
    errEl.innerHTML = '';
    const msg = e && (e.error || e.message) || 'Something went wrong.';
    errEl.appendChild(document.createTextNode(msg));
    // If this email already has an account, offer to switch to sign-in mode.
    if (e && e.code === 'email_exists' && e.email) {
      errEl.appendChild(document.createElement('br'));
      const link = document.createElement('button');
      link.type = 'button';
      link.className = 'auth-inline-link';
      link.textContent = `Sign in as ${e.email} →`;
      link.addEventListener('click', () => {
        setAuthMode('login');
        $('auth-username').value = e.email;
        $('auth-password').focus();
      });
      errEl.appendChild(link);
    } else if (e && e.code === 'no_user') {
      // Wrong email at login → offer to create account
      errEl.appendChild(document.createElement('br'));
      const link = document.createElement('button');
      link.type = 'button';
      link.className = 'auth-inline-link';
      link.textContent = 'Create an account instead →';
      link.addEventListener('click', () => setAuthMode('signup'));
      errEl.appendChild(link);
    }
  }
}

if (authOverlay) {
  $('auth-submit').addEventListener('click', submitAuth);
  $('auth-password').addEventListener('keydown', (e) => {
    if (e.key !== 'Enter') return;
    if (authMode === 'signup') $('auth-confirm').focus(); else submitAuth();
  });
  $('auth-confirm').addEventListener('keydown', (e) => { if (e.key === 'Enter') submitAuth(); });
  $('auth-username').addEventListener('keydown', (e) => { if (e.key === 'Enter') $('auth-password').focus(); });
  $('auth-switch-link').addEventListener('click', () => setAuthMode(authMode === 'login' ? 'signup' : 'login'));
  const forgot = $('auth-forgot-link');
  if (forgot) forgot.addEventListener('click', async () => {
    const email = ($('auth-username').value || '').trim();
    if (!email) { $('auth-error').textContent = 'Enter your email above, then tap “Forgot password?”'; return; }
    $('auth-error').textContent = '';
    try {
      await API('/api/auth/forgot', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });
    } catch { /* never reveal errors */ }
    $('auth-sub').textContent = 'If an account exists for that email, a reset link is on its way. Check your inbox.';
  });
}

// =====================================================
// Boot
// =====================================================
// opts.delayPaywall — show the app first, pop pricing after a few seconds
// (used right after signup so new users see the product before the gate).
async function boot(opts = {}) {
  try {
    state = await API('/api/state');
    models = await API('/api/models');
    statusDot.classList.add('ok');
    statusText.textContent = 'connected';
    applyTheme(state.theme || 'dark');
    renderSidebar();
    renderActiveProject();
    renderModel();
    renderBrowserToggle();
    renderSkillsPage();
    renderAllProjects();
    const isGated = await loadBilling();   // sets module-level `gated`
    renderTrialAndAdmin();
    refreshAccountCard();
    if (state.hosted) applyHostedMode(billingInfo);
    if (state.history && state.history.length > 0) {
      clearChat();
      state.history.forEach(m => appendMessage(m.role, m.content));
    } else {
      renderWelcome();
    }
    // App is browsable; paywall sits on top (dismissible) until they subscribe.
    if (isGated) {
      if (opts.deferPaywall) {
        // New-account flow: the interactive walkthrough runs first; the paywall
        // is shown when the tour ends (see finishTutorial → endTour).
      } else if (opts.delayPaywall) {
        // Let new users watch the welcome screen animation play out.
        setTimeout(() => { if (gated) showPaywall(); }, 4200);
      } else showPaywall();
    } else hidePaywall();
  } catch (e) {
    if (e && e.auth) { showAuth(); return; }   // hosted mode, not logged in
    statusDot.classList.add('bad');
    statusText.textContent = 'offline';
    console.error('boot failed', e);
  }
}

// Hosted build: hide machine-control by plan. Admins keep everything.
function applyHostedMode(info) {
  const admin = !!(info && info.is_admin);
  const plan = info && info.plan;
  const automation = !!state.automation;   // only the desktop app allows machine control
  const canBrowse = automation && (admin || plan === 'professional' || plan === 'max' || plan === 'ultra' || plan === 'apex');
  const showVoice = automation && admin;   // voice uses the local mic (desktop only)
  const hide = (id, cond) => { const el = $(id); if (el) el.style.display = cond ? 'none' : ''; };
  hide('browser-toggle', !canBrowse);
  hide('safesites-toggle', !canBrowse);
  hide('voice-out-toggle', !showVoice);
  hide('voice-btn', !showVoice);
  hide('project-voice-btn', !showVoice);
  // Already running in the desktop app → the "Get the Desktop App" prompts
  // are pointless. Hide every download-link when automation is available.
  document.querySelectorAll('.download-link').forEach(el => {
    el.style.display = automation ? 'none' : '';
  });
  // model picker: admins can switch freely; regular users are locked to their plan.
  const mp = $('model-picker');
  if (mp) mp.style.pointerEvents = admin ? '' : 'none';
  const chev = modelBadge && modelBadge.querySelector('svg');
  if (chev) chev.style.display = admin ? '' : 'none';
}

// =====================================================
// Billing / subscription paywall
// =====================================================
const paywall = $('paywall-overlay');
let billingInfo = null;
let gated = false;   // true = logged in but no plan → can browse, can't message

// Returns true if messaging is gated (must subscribe). Also sets `gated`.
async function loadBilling() {
  try {
    billingInfo = await API('/api/billing/status');
  } catch { billingInfo = null; gated = false; return false; }
  renderPlans();
  gated = !!(billingInfo.require_subscription && !billingInfo.subscribed);
  updateComposerLock();
  return gated;
}

// Reflect the locked state in the composer (hint + placeholder + lock styling).
function updateComposerLock() {
  const composer = document.querySelector('.composer');
  const hint = document.querySelector('.composer-hint span');
  const inputEl = document.getElementById('input');
  if (composer) composer.classList.toggle('gated', gated);
  if (inputEl) inputEl.setAttribute('placeholder', gated
    ? 'Subscribe to start chatting…'
    : 'Ask J@rv1s anything…  (Shift+Enter for newline)');
  if (!hint) return;
  if (gated) {
    hint.innerHTML = '<button class="composer-unlock" type="button">🔒 Subscribe to start chatting →</button>';
    const btn = hint.querySelector('.composer-unlock');
    if (btn) btn.addEventListener('click', () => { if (typeof showPaywall === 'function') showPaywall(); });
  } else {
    hint.innerHTML = '<kbd>Enter</kbd> send · <kbd>Shift</kbd>+<kbd>Enter</kbd> newline · <kbd>🎙</kbd> voice → speak';
  }
}

let billingInterval = 'monthly';   // 'monthly' | 'annual'

function renderPlans() {
  const wrap = $('paywall-plans');
  if (!wrap || !billingInfo) return;
  const plans = billingInfo.plans || [];
  wrap.innerHTML = '';

  // ── Interval toggle pill ─────────────────────────────────────────
  const toggle = document.createElement('div');
  toggle.className = 'billing-toggle';
  toggle.innerHTML = `
    <button data-i="monthly" class="${billingInterval === 'monthly' ? 'on' : ''}">Monthly</button>
    <button data-i="annual" class="${billingInterval === 'annual' ? 'on' : ''}">Annual <span class="bt-save">up to 65% off</span></button>`;
  toggle.querySelectorAll('button').forEach(b =>
    b.addEventListener('click', () => { billingInterval = b.dataset.i; renderPlans(); }));
  wrap.appendChild(toggle);

  // ── Plan cards grid ──────────────────────────────────────────────
  const grid = document.createElement('div');
  grid.className = 'pw-grid';
  const isAnnual = billingInterval === 'annual';

  plans.forEach(p => {
    const isCurrent = billingInfo.plan === p.id;
    const hasTrial = (p.trial_days || 0) > 0 && !isAnnual;   // trial only on monthly
    const featured = p.id === 'professional';
    const accent = featured || p.id === 'max' || p.id === 'ultra' || p.id === 'apex';
    const priceStr = isAnnual ? p.price_annual : p.price;
    const [amt, per] = (priceStr || '').split('/');
    const discount = p.annual_discount_pct || 0;

    let tag = '';
    if (hasTrial) tag = '<span class="pw-tag">★ 7-DAY FREE TRIAL</span>';
    else if (isAnnual && discount) tag = `<span class="pw-tag">SAVE ${discount}%</span>`;
    else if (p.id === 'max') tag = '<span class="pw-tag">Max power</span>';
    else if (p.id === 'ultra') tag = '<span class="pw-tag">Ultra</span>';
    else if (p.id === 'apex') tag = '<span class="pw-tag">★ APEX</span>';

    let cta = 'Subscribe';
    if (isCurrent) cta = 'Current plan';
    else if (hasTrial) cta = 'Start 7-Day Free Trial';
    else if (isAnnual) cta = 'Subscribe (annual)';

    const sub = isAnnual ? `<div class="pw-sub">${escape(p.price)} when billed monthly</div>` : '';

    const card = document.createElement('div');
    card.className = 'pw-card' + (featured ? ' pro featured' : '') + (accent && !featured ? ' pro' : '') + (isCurrent ? ' current' : '');
    card.innerHTML = `
      ${tag}
      <div class="pw-name">${escape(p.name)}</div>
      <div class="pw-price">${escape(amt)}${per ? `<span>/${escape(per)}</span>` : ''}</div>
      ${sub}
      <ul>${(p.features || []).map(f => `<li>${escape(f)}</li>`).join('')}</ul>
      <button class="primary-btn">${cta}</button>`;
    const btn = card.querySelector('button');
    if (isCurrent) { btn.disabled = true; btn.style.opacity = '0.6'; }
    else btn.addEventListener('click', () => startCheckout(p.id, billingInterval));
    grid.appendChild(card);
  });
  wrap.appendChild(grid);
}

function showPaywall() { paywall.classList.remove('hidden'); }
function hidePaywall() { paywall.classList.add('hidden'); }

// ---- Onboarding tutorial ----
const tutorial = $('tutorial-overlay');
const TUT_SLIDES = [
  { icon: '🤖', title: 'Welcome to <span class="grad">J@rv1s</span>', text: 'Your personal AI agent for school. Here’s a 30-second tour of what you can do.' },
  { icon: '📚', title: 'Subject Projects', text: 'Math, English, History & Science come built in. Each keeps its own chats, deadlines, uploaded worksheets, and instructions.' },
  { icon: '✨', title: 'Skills', text: 'Toggle behaviors like Undetectable (natural student writing), Humanizer, Concise, and Tutor mode — or build your own.' },
  { icon: '🎙️', title: 'Voice & Web Automation', text: 'Talk to J@rv1s hands-free, and on higher plans let it drive a real browser to do tasks for you.' },
  { icon: '⌘', title: 'Fast Everywhere', text: 'Hit ⌘K for the command palette to jump anywhere. Upload files, set deadlines, switch subjects in a keystroke.' },
  { icon: '📌', title: 'Make It Yours', text: 'Pin the items you use most — Tasks, Connectors, History — to your sidebar, collapse it to a slim icon rail for focus, and replay this tour anytime from ⌘K → “Take a tour”.' },
  { icon: '🚀', title: 'Pick Your Plan', text: 'One last step — choose a plan to unlock J@rv1s. Professional starts with a 7-day free trial.' },
];
let tutIndex = 0;
function renderTutorial() {
  const s = TUT_SLIDES[tutIndex];
  $('tut-body').innerHTML = `<div class="tut-icon">${s.icon}</div>
    <div class="tut-title">${s.title}</div><div class="tut-text">${s.text}</div>`;
  $('tut-dots').innerHTML = TUT_SLIDES.map((_, i) => `<span class="dot ${i === tutIndex ? 'on' : ''}"></span>`).join('');
  $('tut-back').style.visibility = tutIndex === 0 ? 'hidden' : 'visible';
  $('tut-next').textContent = tutIndex === TUT_SLIDES.length - 1 ? 'See plans →' : 'Next';
}
function showTutorial() { tutorial.classList.remove('hidden'); renderTutorial(); }
function hideTutorial() { tutorial.classList.add('hidden'); }
// After the tutorial: load the app, then pop the paywall after a short delay
// so the user sees the welcome screen / animation before being asked to pay.
function finishTutorial() {
  // Runs once, only for a brand-new account (right after the signup flashcards):
  // boot into the real interface, run the interactive walkthrough on it, then
  // show the paywall when the tour ends. It never appears again after this.
  hideTutorial();
  boot({ deferPaywall: true }).then(() => {
    setTimeout(startWalkthrough, 700);   // let the interface settle, then tour it
  });
}
if (tutorial) {
  $('tut-next').addEventListener('click', () => {
    if (tutIndex < TUT_SLIDES.length - 1) { tutIndex++; renderTutorial(); }
    else finishTutorial();
  });
  $('tut-back').addEventListener('click', () => { if (tutIndex > 0) { tutIndex--; renderTutorial(); } });
}

async function refreshAccountCard() {
  try {
    const a = await API('/api/account');
    renderAccountCard(a);
  } catch { /* ignore */ }
}

function renderTrialAndAdmin() {
  // trial banner
  const banner = $('trial-banner');
  if (banner && billingInfo && billingInfo.trial && billingInfo.trial.trialing) {
    const d = billingInfo.trial.days_left;
    banner.textContent = `★ ${d} day${d === 1 ? '' : 's'} left in your Pro trial — Subscribe`;
    banner.style.display = 'block';
    banner.onclick = showPaywall;
  } else if (banner) {
    banner.style.display = 'none';
  }
  // admin nav
  const navAdmin = $('nav-admin');
  if (navAdmin) navAdmin.style.display = (billingInfo && billingInfo.is_admin) ? 'flex' : 'none';
}

// admin dashboard
async function loadAdmin() {
  const grid = $('admin-stats');
  if (!grid) return;
  grid.innerHTML = '<div class="stat-card"><div class="stat-label">Loading…</div></div>';
  try {
    const s = await API('/api/admin/stats');
    const u = s.usage || {};
    const cards = [
      ['Total users', s.total_users, ''],
      ['Paying', s.paying, `${s.paid_starter} starter · ${s.paid_professional} pro · ${s.paid_max} max · ${s.paid_ultra ?? 0} ultra · ${s.paid_apex ?? 0} apex`],
      ['On trial', s.trialing, 'free Pro trials'],
      ['MRR', `$${s.mrr}`, 'monthly recurring', true],
      ["Today's spend (est)", `$${(u.global_cost_est ?? 0)}`, `ceiling $${u.ceiling ?? '—'}`],
      ['Active today', u.active_users ?? 0, 'users who messaged'],
    ];
    grid.innerHTML = cards.map(([label, val, sub, money]) => `
      <div class="stat-card">
        <div class="stat-label">${escape(label)}</div>
        <div class="stat-value ${money ? 'money' : ''}">${escape(String(val))}</div>
        ${sub ? `<div class="stat-sub">${escape(sub)}</div>` : ''}
      </div>`).join('');
    $('admin-note').textContent = `Estimated daily margin: $${(s.mrr / 30 - (u.global_cost_est || 0)).toFixed(2)} (MRR/30 − today's spend). Spend is an estimate; trust the Anthropic Console for exact billing.`;
  } catch (e) {
    grid.innerHTML = `<div class="stat-card"><div class="stat-label">Error</div><div class="stat-sub">${escape(e.error || 'failed')}</div></div>`;
  }
}
const adminRefresh = $('admin-refresh');
if (adminRefresh) adminRefresh.addEventListener('click', loadAdmin);

// =====================================================
// Settings
// =====================================================
async function loadSettings() {
  try {
    const a = await API('/api/account');
    settingsAccount = a;
    $('set-username').textContent = a.email || a.username || '—';
    if ($('set-uid')) $('set-uid').textContent = a.uid || '—';
    // Fmt account dates
    const fmtDate = (t) => t ? new Date(t * 1000).toLocaleString() : '—';
    if ($('set-created')) $('set-created').textContent = fmtDate(a.created);
    if ($('set-last-login')) $('set-last-login').textContent = fmtDate(a.last_login);
    const planName = ({ none: 'No active plan', starter: 'Starter', professional: 'Professional', max: 'Max', ultra: 'Ultra', apex: 'Apex' })[a.plan] || a.plan;
    const trial = a.trial && a.trial.trialing ? ` · ${a.trial.days_left}d trial left` : '';
    // Billing hero
    if ($('plan-hero-title')) {
      $('plan-hero-title').textContent = `${planName} plan`;
      $('plan-hero-sub').textContent = trial || (a.plan === 'none' ? 'No active plan — pick one to unlock messaging' :
        ({starter:'20 messages / day · Mini J@r', professional:'100 messages / day (5×) · Web automation',
          max:'400 messages / day (20×) · J@rv1s 1.0', ultra:'1,000 messages / day (50×) · Priority support',
          apex:'2,000 messages / day (100×) · Dedicated priority support'})[a.plan] || '');
    }
    // hide account-only controls in local (non-hosted) mode
    const local = !state.hosted;
    ['set-change-pw', 'set-logout', 'set-delete', 'set-manage'].forEach(id => {
      const el = $(id); if (el) el.style.display = local ? 'none' : '';
    });
    // Load + apply prefs
    if (a.prefs) {
      settingsPrefs = a.prefs;
      applyPrefsToUI(a.prefs);
    }
  } catch (e) { /* ignore */ }
  loadMemoryStatus();
}

let settingsPrefs = {};
let settingsAccount = null;

function applyPrefsToUI(p) {
  const set = (id, v) => { const el = $(id); if (el && v != null) el.value = v; };
  set('pref-full-name', p.full_name);
  set('pref-nickname', p.nickname);
  set('pref-work-type', p.work_type);
  set('pref-instructions', p.custom_instructions);
  set('pref-voice', p.voice);
  set('pref-tool-access', p.tool_access_mode);
  set('pref-timezone', p.timezone);
  set('pref-language', p.language);
  // segmented buttons
  const segActivate = (groupId, val) => {
    const g = $(groupId); if (!g) return;
    g.querySelectorAll('.seg-btn').forEach(b => b.classList.toggle('active', b.dataset.val === val));
  };
  segActivate('pref-appearance', p.appearance);
  segActivate('pref-voice-speed', p.voice_speed);
  // toggles
  document.querySelectorAll('[data-pref]').forEach(el => {
    if (el.classList.contains('set-toggle')) {
      el.classList.toggle('on', !!p[el.dataset.pref]);
    }
  });
}

// Debounced save for text fields
let _prefSaveTimer = null;
function queuePrefSave(partial) {
  Object.assign(settingsPrefs, partial);
  clearTimeout(_prefSaveTimer);
  _prefSaveTimer = setTimeout(async () => {
    try {
      const r = await API('/api/account/prefs', {
        method: 'PUT', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(partial),
      });
      settingsPrefs = r.prefs;
    } catch (e) { console.warn('pref save', e); }
  }, 450);
}

// Wire prefs once on load (idempotent)
let _prefsWired = false;
function wireSettings() {
  if (_prefsWired) return; _prefsWired = true;

  // Tab switching
  document.querySelectorAll('.settings-tab').forEach(btn => {
    btn.addEventListener('click', () => {
      const tab = btn.dataset.tab;
      document.querySelectorAll('.settings-tab').forEach(b => b.classList.toggle('active', b === btn));
      document.querySelectorAll('.settings-tab-content').forEach(c =>
        c.classList.toggle('active', c.dataset.tabContent === tab));
      if (tab === 'usage') loadUsage();
    });
  });

  // Text inputs / textareas / selects → debounced save
  const wireField = (id, key) => {
    const el = $(id);
    if (!el) return;
    el.addEventListener('input', () => queuePrefSave({ [key]: el.value }));
    el.addEventListener('change', () => queuePrefSave({ [key]: el.value }));
  };
  wireField('pref-full-name', 'full_name');
  wireField('pref-nickname', 'nickname');
  wireField('pref-work-type', 'work_type');
  wireField('pref-instructions', 'custom_instructions');
  wireField('pref-voice', 'voice');
  wireField('pref-tool-access', 'tool_access_mode');
  wireField('pref-timezone', 'timezone');
  wireField('pref-language', 'language');

  // Segmented controls
  const wireSeg = (groupId, key) => {
    const g = $(groupId); if (!g) return;
    g.querySelectorAll('.seg-btn').forEach(b => b.addEventListener('click', () => {
      g.querySelectorAll('.seg-btn').forEach(x => x.classList.remove('active'));
      b.classList.add('active');
      queuePrefSave({ [key]: b.dataset.val });
      if (key === 'appearance') {
        if (b.dataset.val === 'light' || b.dataset.val === 'dark') applyTheme(b.dataset.val);
      }
    }));
  };
  wireSeg('pref-appearance', 'appearance');
  wireSeg('pref-voice-speed', 'voice_speed');

  // Toggles
  document.querySelectorAll('.set-toggle[data-pref]').forEach(el => {
    el.addEventListener('click', () => {
      if (el.disabled) return;
      const key = el.dataset.pref;
      const next = !el.classList.contains('on');
      el.classList.toggle('on', next);
      queuePrefSave({ [key]: next });
    });
  });

  // Billing buttons
  $('set-adjust-plan') && $('set-adjust-plan').addEventListener('click', showPaywall);

  // Usage refresh
  $('usage-refresh') && $('usage-refresh').addEventListener('click', loadUsage);
}

async function loadUsage() {
  try {
    const u = await API('/api/usage/me');
    const planLabel = ({starter:'Starter (1×)', professional:'Professional (5×)', max:'Max (20×)',
                       ultra:'Ultra (50×)', apex:'Apex (100×)', none:'No plan'})[u.plan] || u.plan;
    $('usage-plan-name') && ($('usage-plan-name').textContent = planLabel);
    $('usage-used') && ($('usage-used').textContent = u.used_today || 0);
    $('usage-cap') && ($('usage-cap').textContent = u.daily_cap || '—');
    const pct = u.percent_used || 0;
    if ($('usage-fill-today')) $('usage-fill-today').style.width = pct + '%';
    if ($('usage-pct-today')) $('usage-pct-today').textContent = pct + '% used';
    // Admin sees server cost
    if (settingsAccount && settingsAccount.is_admin && $('usage-cost-row')) {
      $('usage-cost-row').style.display = '';
      const cost = u.global_cost_est || 0;
      const ceil = u.ceiling || 5;
      const cpct = Math.min(100, Math.round(100 * cost / ceil));
      $('usage-fill-cost').style.width = cpct + '%';
      $('usage-pct-cost').textContent = '$' + cost.toFixed(2);
      $('usage-ceiling').textContent = `Resets at midnight · ceiling $${ceil}`;
    }
    $('usage-pct-auto') && ($('usage-pct-auto').textContent = '0 / 15');
    $('usage-fill-auto') && ($('usage-fill-auto').style.width = '0%');
  } catch (e) { /* ignore */ }
}

wireSettings();

// =====================================================
// MEMORIES VIEW — top-level atomic-memory CRUD
// =====================================================
let memFeed = { atoms: [] };
let memFilter = 'all';
let memSearch = '';

async function loadMemories() {
  try {
    memFeed = await API('/api/memory/atoms');
  } catch { memFeed = { atoms: [] }; }
  renderMemFeed();
  // sidebar count badge
  const nav = $('nav-mem-count');
  const n = (memFeed.atoms || []).length;
  if (nav) {
    nav.textContent = n;
    nav.style.display = n ? '' : 'none';
  }
}

function renderMemFeed() {
  const feed = $('mem-feed');
  const stat = $('mem-feed-stat');
  if (!feed) return;
  const all = memFeed.atoms || [];
  const filtered = all.filter(a => {
    if (memFilter === 'auto') return a.tag === 'auto';
    if (memFilter !== 'all' && a.kind !== memFilter) return false;
    if (memSearch && !((a.text || '') + ' ' + (a.tag || ''))
        .toLowerCase().includes(memSearch.toLowerCase())) return false;
    return true;
  });
  if (stat) stat.textContent = `${filtered.length} of ${all.length}`;
  feed.innerHTML = '';
  if (!filtered.length) {
    feed.innerHTML = `
      <div class="mem-empty">
        <div class="empty-icon">🧠</div>
        <h3>${all.length ? 'Nothing matches that filter' : 'No memories yet'}</h3>
        <p>${all.length
            ? 'Try a different filter, or clear the search box.'
            : 'Add a memory manually, import from another AI, or just chat — J@rv1s extracts atomic facts automatically when "Generate memory from chat" is on.'}</p>
      </div>`;
    return;
  }
  filtered.forEach(a => feed.appendChild(renderMemAtom(a)));
}

function renderMemAtom(a) {
  const card = document.createElement('div');
  card.className = 'mem-atom';
  const ico = ({fact:'•', preference:'⚙', imported:'↳', auto:'✨'})[a.tag === 'auto' ? 'auto' : a.kind] || '•';
  const kindCls = a.tag === 'auto' ? 'auto' : a.kind;
  const time = a.ts ? new Date(a.ts * 1000).toLocaleDateString() : '';
  card.innerHTML = `
    <div class="mem-atom-kind ${kindCls}">${ico}</div>
    <div class="mem-atom-body">
      <div class="mem-atom-text">${escape(a.text || '')}</div>
      <div class="mem-atom-meta">
        ${a.tag ? `<span class="mem-atom-tag">${escape(a.tag)}</span>` : ''}
        ${time ? `<span>${escape(time)}</span>` : ''}
      </div>
    </div>
    <div class="mem-atom-actions">
      ${a.kind === 'fact' ? '<button data-act="edit" title="Edit">✎</button>' : ''}
      <button data-act="del" title="Delete">🗑</button>
    </div>`;
  const editBtn = card.querySelector('[data-act="edit"]');
  if (editBtn) editBtn.addEventListener('click', () => openMemAtomModal(a));
  card.querySelector('[data-act="del"]').addEventListener('click', () => deleteAtom(a));
  return card;
}

async function deleteAtom(a) {
  if (!confirm(`Delete this memory?\n\n"${(a.text || '').slice(0, 80)}…"`)) return;
  try {
    if (a.kind === 'fact') {
      await API(`/api/memory/facts/${a.id}`, { method: 'DELETE' });
    } else if (a.kind === 'imported') {
      const idx = parseInt((a.id || '').split(':')[1] || '-1', 10);
      if (idx >= 0) await API(`/api/memory/import/${idx}`, { method: 'DELETE' });
    } else {
      alert('Preferences are managed in Settings → General.');
      return;
    }
    loadMemories();
  } catch (e) { alert(e.error || 'Delete failed.'); }
}

// Memory-atom add/edit modal
const memAtomBackdrop = $('mem-atom-backdrop');
let memEditTarget = null;
function openMemAtomModal(atom) {
  memEditTarget = atom;
  $('mem-atom-title').textContent = atom ? 'Edit memory' : 'Add memory';
  $('mem-atom-text').value = atom ? (atom.text || '') : '';
  $('mem-atom-tag').value = atom && atom.tag !== 'auto' && atom.tag !== 'general' ? atom.tag : '';
  $('mem-atom-delete').style.display = atom ? '' : 'none';
  memAtomBackdrop.classList.remove('hidden');
  $('mem-atom-text').focus();
}
$('mem-add-open') && $('mem-add-open').addEventListener('click', () => openMemAtomModal(null));
$('mem-atom-cancel') && $('mem-atom-cancel').addEventListener('click', () => memAtomBackdrop.classList.add('hidden'));
memAtomBackdrop && memAtomBackdrop.addEventListener('click', (e) => {
  if (e.target === memAtomBackdrop) memAtomBackdrop.classList.add('hidden');
});
$('mem-atom-save') && $('mem-atom-save').addEventListener('click', async () => {
  const text = $('mem-atom-text').value.trim();
  const tag = $('mem-atom-tag').value.trim() || 'manual';
  if (!text) { alert('Memory text required.'); return; }
  try {
    if (memEditTarget && memEditTarget.kind === 'fact') {
      await API(`/api/memory/facts/${memEditTarget.id}`, {
        method: 'PUT', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text, tag }),
      });
    } else {
      await API('/api/memory/facts', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text, tag }),
      });
    }
    memAtomBackdrop.classList.add('hidden');
    loadMemories();
  } catch (e) { alert(e.error || 'Save failed.'); }
});
$('mem-atom-delete') && $('mem-atom-delete').addEventListener('click', async () => {
  if (!memEditTarget || memEditTarget.kind !== 'fact') return;
  if (!confirm('Delete this memory?')) return;
  await API(`/api/memory/facts/${memEditTarget.id}`, { method: 'DELETE' });
  memAtomBackdrop.classList.add('hidden');
  loadMemories();
});

// Feed filter + search + bulk actions
document.querySelectorAll('[data-mem-filter]').forEach(b =>
  b.addEventListener('click', () => {
    document.querySelectorAll('[data-mem-filter]').forEach(x => x.classList.remove('active'));
    b.classList.add('active');
    memFilter = b.dataset.memFilter;
    renderMemFeed();
  }));
$('mem-feed-search') && $('mem-feed-search').addEventListener('input', (e) => {
  memSearch = e.target.value;
  renderMemFeed();
});
$('mem-import-open') && $('mem-import-open').addEventListener('click', async () => {
  if (!memoryInfo) await loadMemoryStatus();
  $('mem-prompt-pre').textContent = (memoryInfo && memoryInfo.import_prompt) || '';
  $('mem-paste').value = '';
  $('mem-import-backdrop').classList.remove('hidden');
});
$('mem-clear-auto') && $('mem-clear-auto').addEventListener('click', async () => {
  if (!confirm('Delete every auto-saved memory? (Manual & imported memories stay.)')) return;
  await API('/api/memory/facts?tag=auto', { method: 'DELETE' });
  loadMemories();
});

// =====================================================
// CONNECTORS VIEW — top-level page with platform cards
// =====================================================
let connectorsState = { connectors: [] };

async function loadConnectors() {
  // Cloud web users see a "desktop-only" pitch instead of the full UI.
  if (state.hosted && !state.automation) {
    renderDesktopExclusive('connectors');
    const nav = $('nav-conn-count');
    if (nav) { nav.textContent = '↓'; nav.style.display = ''; nav.classList.add('nav-pulse'); }
    return;
  }
  try {
    connectorsState = await API('/api/connectors');
  } catch (e) {
    if (e && e.auth) { showAuth(); return; }
    connectorsState = { connectors: [] };
  }
  renderConnectors();
  // sidebar badge: count of connected platforms
  const nav = $('nav-conn-count');
  const connected = (connectorsState.connectors || []).filter(c => c.logged_in).length;
  if (nav) {
    if (connected > 0) {
      nav.textContent = connected;
      nav.style.display = '';
      nav.classList.remove('nav-pulse');
    } else {
      nav.textContent = '!';
      nav.style.display = '';
      nav.classList.add('nav-pulse');
    }
  }
}

function renderDesktopExclusive(which) {
  // `which` is "connectors" or "tasks" — slight copy difference.
  const isConnectors = which === 'connectors';
  const target = isConnectors ? $('conn-school-grid')?.parentElement : $('tasks-body');
  if (!target) return;
  // Wipe everything inside the view, replace with the pitch.
  if (isConnectors) {
    // Clear the connectors-view body but keep the topbar
    const view = document.querySelector('.view-connectors');
    if (view) {
      // Keep topbar only
      Array.from(view.children).forEach(child => {
        if (!child.classList.contains('topbar')) child.remove();
      });
      const cta = document.createElement('div');
      cta.innerHTML = desktopExclusiveHTML(isConnectors);
      view.appendChild(cta.firstElementChild);
      wireDesktopExclusiveButtons();
    }
  } else {
    target.innerHTML = desktopExclusiveHTML(false);
    wireDesktopExclusiveButtons();
  }
}

function desktopExclusiveHTML(isConnectors) {
  const title = isConnectors
    ? `<span class="grad">School connectors</span><br>only run on your computer.`
    : `<span class="grad">Tasks</span> only work in the desktop app.`;
  const sub = isConnectors
    ? `Most school Google accounts block third-party logins (OAuth), and Google flags cloud-based browsers as bots. So J@rv1s connects to Classroom, Canvas, Schoology and more <strong>on your actual computer</strong> — using your real Chrome, your real session. Nothing is sent to our servers. Ever.`
    : `Your assignments come from your school portal — and your school's Google account doesn't let outside apps log in from the cloud. So J@rv1s does the pulling locally on your Mac. Install the desktop app once, sign in, and your tasks appear here.`;

  return `
    <div class="desktop-exclusive">
      <div class="desktop-exclusive-badge"><span class="dot"></span>Desktop-only feature · by design</div>
      <div class="desktop-exclusive-orb"></div>
      <h1>${title}</h1>
      <p>${sub}</p>
      <div class="desktop-exclusive-actions">
        <a class="primary" href="https://projectjarvis.app/download" target="_blank" rel="noopener">
          ↓ Download for Mac · Free
        </a>
        <a class="secondary" href="https://projectjarvis.app/download" target="_blank" rel="noopener">
          Windows version
        </a>
      </div>
      <div class="desktop-exclusive-features">
        <div class="desktop-exclusive-feature">
          <div class="ico">🔒</div>
          <div class="lbl">Your session stays local</div>
          <div class="desc">School login never touches our servers</div>
        </div>
        <div class="desktop-exclusive-feature">
          <div class="ico">⚡</div>
          <div class="lbl">Works with strict schools</div>
          <div class="desc">No OAuth needed — uses your real Chrome</div>
        </div>
        <div class="desktop-exclusive-feature">
          <div class="ico">🤖</div>
          <div class="lbl">Pulls every assignment</div>
          <div class="desc">Across every class, every tab, automatically</div>
        </div>
      </div>
    </div>
  `;
}

function wireDesktopExclusiveButtons() {
  // Hook is here in case we want to track download clicks later.
}

// School platforms ⇆ "other" productivity stubs
const _SCHOOL_PLATFORMS = ['google_classroom','canvas','schoology','powerschool','blackboard'];

function renderConnectors() {
  const schoolGrid = $('conn-school-grid');
  const otherGrid = $('conn-other-grid');
  if (!schoolGrid || !otherGrid) return;
  schoolGrid.innerHTML = '';
  otherGrid.innerHTML = '';

  // School cards from API
  (connectorsState.connectors || []).forEach(c => {
    schoolGrid.appendChild(renderConnectorCard(c));
  });
  // Hard-coded productivity stubs (until we wire OAuth)
  const stubs = [
    { platform: 'gmail',    name: 'Gmail',           icon: '📧', desc: 'Read recent threads, draft replies, summarize inbox.' },
    { platform: 'calendar', name: 'Google Calendar', icon: '📅', desc: "See today's schedule, find free time, propose meetings." },
    { platform: 'drive',    name: 'Google Drive',    icon: '📂', desc: 'Pull context from docs you share with J@rv1s.' },
    { platform: 'slack',    name: 'Slack',           icon: '💬', desc: 'Read recent channels, draft messages, summarize threads.' },
    { platform: 'notion',   name: 'Notion',          icon: '📓', desc: 'Pull pages, search workspace, append updates.' },
    { platform: 'github',   name: 'GitHub',          icon: '🐙', desc: 'Browse repos, read issues / PRs, draft code reviews.' },
  ];
  stubs.forEach(s => {
    otherGrid.appendChild(renderConnectorCard({
      platform: s.platform, name: s.name, icon: s.icon, ready: false,
      status: 'disconnected', logged_in: false,
      _desc: s.desc,
    }));
  });
}

function renderConnectorCard(c) {
  const card = document.createElement('div');
  card.className = 'conn-tile' + (c.ready === false ? ' coming-soon' : '');
  card.dataset.platform = c.platform;

  // mouse-tracking glow
  card.addEventListener('mousemove', (e) => {
    const r = card.getBoundingClientRect();
    card.style.setProperty('--mx', ((e.clientX - r.left) / r.width * 100) + '%');
    card.style.setProperty('--my', ((e.clientY - r.top) / r.height * 100) + '%');
  });

  const statusKey = c.logged_in ? 'connected'
                  : (c.status === 'syncing' ? 'syncing'
                  : (c.status === 'error' ? 'error'
                  : (c.ready === false ? 'coming-soon' : 'disconnected')));
  const statusLabel = ({
    connected: 'Connected',
    syncing: 'Syncing…',
    error: 'Error',
    'coming-soon': 'Coming soon',
    disconnected: 'Not connected',
  })[statusKey];

  const longDesc = LONG_DESCRIPTIONS[c.platform] || c._desc || DESCRIPTIONS[c.platform] || 'Pull tasks and context from this platform.';

  const lastSync = c.last_synced_at
    ? `Last synced ${timeAgo(c.last_synced_at)} · ${c.last_sync_count || 0} found`
    : (c.connected_at ? `Connected ${timeAgo(c.connected_at)}` : '');

  card.innerHTML = `
    <div class="conn-tile-head">
      <div class="conn-tile-icon">${c.icon || '🔗'}</div>
      <div class="conn-tile-info">
        <div class="conn-tile-name">${escape(c.name || c.platform)}</div>
        <div class="conn-tile-status ${statusKey}"><span class="dot"></span>${statusLabel}</div>
      </div>
      <svg class="conn-tile-chev" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
    </div>
    ${lastSync ? `<div class="conn-tile-meta"><span>${escape(lastSync)}</span>${c.last_error ? `<span title="${escape(c.last_error)}" style="color:var(--danger)">!</span>` : ''}</div>` : ''}
    <div class="conn-tile-about">${longDesc}</div>
    <div class="conn-tile-actions">
      ${c.ready === false
        ? `<button disabled>Coming soon</button>`
        : (c.logged_in
            ? `<button data-act="sync" class="primary">↻ Sync now</button>
               <button data-act="tasks">Go to Tasks →</button>
               <button data-act="disconnect" class="danger">Disconnect</button>`
            : `<button data-act="connect" class="primary">Connect →</button>`)}
    </div>
  `;

  const conBtn  = card.querySelector('[data-act="connect"]');
  const syncBtn = card.querySelector('[data-act="sync"]');
  const disBtn  = card.querySelector('[data-act="disconnect"]');
  const tasksBtn = card.querySelector('[data-act="tasks"]');
  if (conBtn)  conBtn.addEventListener('click', () => connectPlatform(c.platform));
  if (syncBtn) syncBtn.addEventListener('click', () => syncPlatform(c.platform));
  if (disBtn)  disBtn.addEventListener('click', () => disconnectPlatform(c.platform));
  if (tasksBtn) tasksBtn.addEventListener('click', () => {
    // Jump to Tasks, focused on this platform's assignments.
    taskSel.primary = 'all'; taskSel.deep = 'all';
    switchView('tasks');
  });

  // Click the card body (anywhere but a button) to reveal the write-up.
  card.addEventListener('click', (e) => {
    if (e.target.closest('button') || e.target.closest('a')) return;
    card.classList.toggle('expanded');
  });

  return card;
}

const DESCRIPTIONS = {
  google_classroom: 'Pull every assignment from Google Classroom — Assigned, Missing, and No Due Date sections, across all your classes.',
  canvas: 'Sync your Canvas course assignments and due dates straight into Tasks.',
  schoology: 'Pull assignments + announcements from your Schoology portal.',
  powerschool: 'See your PowerSchool tasks alongside everything else.',
  blackboard: 'Sync from your Blackboard Learn courses.',
};

// Long write-ups shown when a connector card is expanded (click the card body).
const LONG_DESCRIPTIONS = {
  google_classroom: `Google Classroom is where most of your assignments actually live, so J@rv1s treats it as the source of truth. When you connect, it opens your real Chrome, signs into your school Google account, and walks your to-do list the same way you would — every class, every section. It reads the Assigned tab for what's coming up and the Missing tab for what's overdue, expanding the collapsed "No due date", "This week", "Next week" and "Later" groups so nothing hides. Each assignment comes back with its title, class, due date and a direct link, then lands on your Tasks page split into Missing and Assigned. From there you can hand any of them to Autopilot, which reopens the assignment, reads the instructions and any attached Google Doc, writes your answer straight into the Doc, and — if you ask — turns it in for you. Your login stays on your own Mac: J@rv1s never stores your Google password on a server, and the session lives in a local browser profile you control. Re-sync anytime to pull new work, and disconnect in one click to wipe the cached session while keeping the tasks you've already pulled. It's the closest thing to an assistant that runs your homework portal for you.`,
  canvas: `Canvas is the LMS most colleges and a lot of high schools run on, and it scatters assignments, quizzes and due dates across course pages that are easy to lose track of. Connecting Canvas lets J@rv1s log into your institution's Canvas, walk each active course, and pull every assignment and deadline into one unified Tasks list — no more clicking through six course cards to find what's due Friday. It reads the same dashboard and calendar you see, normalizes every item to a title, course and due date, and tags whether it's upcoming or already past due. Because Canvas due dates are structured, they come through cleanly and feed the Missing/Assigned split and the time filters on your Tasks page. From there, Autopilot can open an assignment, read the prompt and any linked instructions, and draft your response. Your Canvas credentials stay on your machine inside a local browser session — J@rv1s doesn't ship your password anywhere. Sync whenever you want a fresh pull, and disconnect to clear the cached login while keeping the assignments already imported. If your school runs on Canvas, this turns it from a portal you dread into a feed that quietly keeps your whole workload in one place.`,
  schoology: `Schoology is the platform a huge number of middle and high schools use to post assignments, materials and grades, and its interface buries due dates inside course folders and the Upcoming widget. Connecting Schoology lets J@rv1s sign into your district's Schoology, read your courses and the Upcoming and Overdue lists, and pull every graded item into your Tasks page with its title, course and deadline attached. Instead of checking each class's materials folder, you get one clean list that separates what's coming up from what you've missed, with the same time filters and bulk actions as the rest of J@rv1s. The connector mirrors what you'd see logged in yourself, so nothing private leaves your Mac — your Schoology login lives in a local browser profile, never on a server. Once your assignments are in, hand any of them to Autopilot to read the instructions and draft an answer, or just use the list to stay ahead of deadlines. Re-sync to catch newly posted work, and disconnect in a click to wipe the cached session while keeping the tasks already imported. For a lot of students Schoology is the daily homepage of school — this makes it actually work for you instead of against you.`,
  powerschool: `PowerSchool is where grades and assignments live for thousands of districts, and its student portal is famously clunky — work is scattered across class pages and the score views. Connecting PowerSchool lets J@rv1s log into your district's portal, read each course, and surface assignments and their due dates into a single Tasks list alongside everything from your other platforms. Rather than hunting through PowerSchool's frames and tabs, you get one normalized feed split into Missing and Assigned, with the same filters, color-coded subjects and bulk actions as the rest of the app. The connector reads exactly what you'd see signed in, so your data stays yours: your PowerSchool credentials are kept in a local browser session on your own machine, never uploaded. Pull a fresh sync whenever grades or assignments update, and disconnect at any time to clear the saved login while keeping the tasks already imported. PowerSchool coverage is still being hardened across districts — every district themes it differently — so if a sync misses something, a re-sync usually catches it. The goal is simple: take the portal you only open when you're worried about a grade and turn it into a quiet, always-current view of what you actually owe.`,
  blackboard: `Blackboard Learn is the LMS many universities and some high schools still run, and its content areas and "Due Dates" tool spread your work across a maze of menus. Connecting Blackboard lets J@rv1s sign into your institution's Blackboard, walk your active courses, and pull assignments and deadlines into one unified Tasks list with the rest of your school. Instead of drilling into each course's content area to find what's due, you get a single normalized feed separated into Missing and Assigned, with time filters, color-coded subjects and bulk actions built in. The connector only reads what you'd see logged in yourself; your Blackboard login is stored in a local browser profile on your Mac and never sent to a server. Sync whenever you want to refresh, and disconnect in one click to clear the cached session while keeping the assignments already imported. Once your work is in, Autopilot can open an assignment, read the prompt, and draft a response for you to review. Blackboard's layout varies a lot between schools, so coverage is still being broadened — if something doesn't come through, a re-sync or a quick note helps us tune it. The point is to make a dated, heavy LMS feel light and current.`,
  gmail: `Gmail support is on the way. Once it lands, connecting Gmail will let J@rv1s read your recent threads, summarize a noisy inbox down to what actually needs a reply, and draft responses in your voice that you approve before anything sends. Think of it as triage: it surfaces the few emails that matter, pulls the context you need from the thread, and writes a first draft so you're not staring at a blank reply box. For students that means catching the teacher's note about a moved deadline, the club announcement you'd have missed, and the college-rep follow-up — without scrolling past fifty promotions. Nothing is ever sent on your behalf without your explicit say-so, and J@rv1s won't dig through your whole mailbox or harvest contacts; it reads what you point it at, when you ask. Authentication uses Google's standard secure sign-in, so your password never touches our servers, and you can revoke access at any time. When Gmail is live you'll connect it right here, and your inbox becomes one more thing J@rv1s quietly keeps under control instead of another tab you're afraid to open. Until then, this card is a placeholder for what's coming.`,
  calendar: `Google Calendar support is coming. When it's ready, connecting your calendar will let J@rv1s see today's schedule at a glance, find the gaps where you actually have time to work, and slot your assignments and study blocks around the commitments you already have. Tell it you have three things due this week and it can propose when to do each one based on your real free time, then drop those blocks onto your calendar once you approve. It'll also pull events into context, so when you ask what your day looks like you get a clean rundown instead of a wall of overlapping invites. Combined with your synced assignments, that turns a list of deadlines into an actual plan — what to do, and when. J@rv1s won't create, move or delete events without your explicit confirmation, and it only reads the calendars you connect. Sign-in uses Google's secure OAuth, so no password is ever stored on our servers, and access is revocable whenever you want. When it's live you'll connect it from this card and your week stops being a guessing game. For now, this is a preview of what's on the roadmap.`,
  drive: `Google Drive support is on the roadmap. Once it's live, connecting Drive will let J@rv1s pull context from the documents you choose to share with it — a worksheet, an essay draft, a study guide — so it can answer questions grounded in your actual materials instead of guessing. Point it at a folder or a file and it can read the contents, summarize them, find the section you need, or use them as source material when it writes. For a research paper that means drawing from the PDFs you've collected; for a class it means knowing the rubric you uploaded. You stay in control of what it sees: J@rv1s only reads the specific files or folders you grant, never your whole Drive, and it won't move, rename or delete anything without your say-so. Authentication uses Google's secure sign-in, so your password is never stored on our servers and access can be revoked at any time. When Drive is connected, every Doc you share becomes part of J@rv1s's working memory for the task at hand — and Autopilot can write answers straight back into the right Doc. Until it ships, this card marks where Drive will plug in.`,
  slack: `Slack support is coming. When it lands, connecting Slack will let J@rv1s catch you up on the channels that matter — reading recent messages, summarizing a thread that blew up while you were in class, and drafting replies you approve before they post. Instead of scrolling through a dozen busy channels, you ask what you missed and get the gist plus anything that needs a response. It can help you write a clear message, find the link someone dropped last week, or pull the decision out of a long back-and-forth. Nothing posts on your behalf without your explicit confirmation, and J@rv1s only reads the workspaces and channels you connect — it won't trawl DMs or harvest data. Sign-in uses Slack's standard secure OAuth, so credentials never touch our servers and you can revoke access whenever you like. For students in club, team or project Slacks, that means staying on top of group work without living in the app. When it's ready you'll connect it from this card; until then, this is a preview of what's planned.`,
  notion: `Notion support is on the way. Once it's live, connecting Notion will let J@rv1s pull pages from your workspace, search across your notes and databases, and append updates where you want them. Keep your assignments, project plans or class notes in Notion and J@rv1s can read them for context, answer questions grounded in what you've written, and add new entries — a logged assignment, a summary, a meeting note — to the right page or database. It works the way you organize: point it at the pages or databases you connect and it stays out of everything else. Nothing is changed or deleted without your explicit confirmation, and J@rv1s won't crawl your entire workspace, only what you grant. Authentication uses Notion's secure integration flow, so no password is stored on our servers, and you can revoke access at any time. For students who run their lives in Notion, this closes the loop: your synced assignments and your Notion system finally talk to each other, and J@rv1s keeps both current. When it ships you'll connect it from this card. For now, it's a placeholder for what's coming next.`,
  github: `GitHub support is coming. When it's ready, connecting GitHub will let J@rv1s browse your repositories, read issues and pull requests, and help you draft code reviews and responses. Working on a CS assignment or a side project? It can read the relevant files for context, explain what a PR changes, summarize an issue thread, or draft review comments you approve before posting. It's built to assist, not act on its own — nothing is pushed, merged or commented without your explicit go-ahead, and it only reads the repos you connect, public or private as you choose. Authentication uses GitHub's standard secure OAuth, so your credentials never touch our servers and access is revocable at any time. For students learning to code, that means a reviewer who can walk through your project, point out what's off, and help you write clearer commits and responses — without doing the thinking for you. When it lands you'll connect it from this card, and your projects become one more place J@rv1s can lend a hand. Until then, this card marks where GitHub will plug in.`,
};

// ── Non-blocking toast notifications (replaces blocking alert()) ─────────
function toast(msg, type = 'info', ms = 4500) {
  let wrap = $('toast-wrap');
  if (!wrap) { wrap = document.createElement('div'); wrap.id = 'toast-wrap'; document.body.appendChild(wrap); }
  const ico = { success: '✓', error: '⚠', sync: '↻', info: '✦' }[type] || '✦';
  const el = document.createElement('div');
  el.className = `toast toast-${type}`;
  el.innerHTML = `<span class="toast-ico">${ico}</span><span class="toast-msg"></span><span class="toast-x">×</span>`;
  el.querySelector('.toast-msg').textContent = msg;
  wrap.appendChild(el);
  requestAnimationFrame(() => el.classList.add('show'));
  const kill = () => { el.classList.remove('show'); setTimeout(() => el.remove(), 280); };
  if (ms) el._timer = setTimeout(kill, ms);
  el.addEventListener('click', () => { clearTimeout(el._timer); kill(); });
  return el;
}

// Connectors currently running a browser op — blocks impatient double-clicks
// that would launch a 2nd Chrome on the same profile (the "profile in use" bug).
const busyConnectors = new Set();

function setConnectorBusy(platform, busy, label) {
  busyConnectors[busy ? 'add' : 'delete'](platform);
  const card = document.querySelector(`.conn-tile[data-platform="${platform}"]`);
  if (!card) return;
  card.classList.toggle('busy', busy);
  const st = card.querySelector('.conn-tile-status');
  if (st && busy) { st.className = 'conn-tile-status syncing'; st.innerHTML = `<span class="dot"></span>${label || 'Working…'}`; }
  card.querySelectorAll('.conn-tile-actions button').forEach(b => { b.disabled = busy; });
  const primary = card.querySelector('.conn-tile-actions button.primary');
  if (primary) {
    if (busy) { primary.dataset._label = primary.innerHTML; primary.innerHTML = `<span class="btn-spin"></span>${label || 'Working…'}`; }
    else if (primary.dataset._label) { primary.innerHTML = primary.dataset._label; delete primary.dataset._label; }
  }
}

// "How would you like to sign in?" — manual (open Chrome) vs save-login (auto).
function showLoginChoiceModal(platform) {
  const old = $('login-choice-backdrop'); if (old) old.remove();
  const back = document.createElement('div');
  back.id = 'login-choice-backdrop';
  back.className = 'modal-backdrop';
  back.innerHTML = `
    <div class="modal login-choice">
      <div class="modal-title">Sign in to Google Classroom</div>
      <p class="modal-sub">How would you like J@rv1s to sign in?</p>
      <div class="login-choice-opts">
        <button class="login-opt" data-lc="manual">
          <span class="lc-ico">🔐</span>
          <span class="lc-text"><strong>Sign in myself</strong>
          <span>Chrome opens — you sign in once, then leave the window open. Most reliable (works with 2-step &amp; school SSO).</span></span>
        </button>
        <button class="login-opt" data-lc="save">
          <span class="lc-ico">⚡</span>
          <span class="lc-text"><strong>Save my login &amp; do it for me</strong>
          <span>Store your email + password (encrypted, on this Mac) so J@rv1s fills the sign-in. Best-effort — Google may still ask for a code.</span></span>
        </button>
      </div>
      <div class="login-creds hidden" id="login-creds">
        <input type="email" id="lc-email" placeholder="School email" autocomplete="off" spellcheck="false">
        <input type="password" id="lc-pass" placeholder="Password" autocomplete="off">
        <p class="lc-note">🔒 Encrypted and stored only on this computer — used solely to fill the Google sign-in form.</p>
        <button class="primary-btn" id="lc-save-go">Save &amp; Sync →</button>
      </div>
      <div class="modal-actions"><button class="ghost-btn" id="lc-cancel">Cancel</button></div>
    </div>`;
  document.body.appendChild(back);
  const close = () => back.remove();
  back.addEventListener('click', (e) => { if (e.target === back) close(); });
  $('lc-cancel').addEventListener('click', close);
  back.querySelector('[data-lc="manual"]').addEventListener('click', () => { close(); syncPlatform(platform); });
  back.querySelector('[data-lc="save"]').addEventListener('click', () => {
    $('login-creds').classList.remove('hidden');
    $('lc-email').focus();
  });
  $('lc-save-go').addEventListener('click', async () => {
    const email = $('lc-email').value.trim();
    const password = $('lc-pass').value;
    if (!email || !password) { toast('Enter your email and password.', 'info'); return; }
    try {
      const r = await API('/api/connectors/' + platform + '/credentials', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      if (r.ok) { toast('Login saved 🔒 — signing in for you…', 'success'); close(); syncPlatform(platform); }
      else { toast(r.error || "Couldn't save login.", 'error'); }
    } catch (e) { toast((e && e.error) || "Couldn't save login.", 'error'); }
  });
}

async function connectPlatform(platform) {
  if (busyConnectors.has(platform)) { toast('A sign-in window is already opening — check for it.', 'info'); return; }
  // Google Classroom needs no school-specific URL, so "connecting" is just
  // signing in — and the sync flow already does that inline in ONE Chrome
  // window (sign in → it scrapes). Routing Connect → sync avoids opening two
  // separate browser windows (which was causing the confusion + closed-window
  // errors). Canvas/Schoology still use the dedicated connect flow to capture
  // their school URL first.
  if (platform === 'google_classroom') {
    return showLoginChoiceModal(platform);
  }
  setConnectorBusy(platform, true, 'Connecting…');
  toast('Opening a Chrome window — sign in there, then come back.', 'sync', 6500);
  try {
    const r = await API('/api/connectors/' + platform + '/connect', { method: 'POST' });
    if (r.action === 'open_desktop_app') { toast('Sign-in runs in the desktop app. Get it at projectjarvis.app/download.', 'error', 7000); return; }
    if (r.busy) { toast(r.error || 'A sign-in window is already open.', 'info'); return; }
    if (r.ok && r.logged_in) { toast('Signed in ✓ — now hit “Sync now” to pull your assignments.', 'success'); }
    else if (r.error) { toast('Connection failed: ' + r.error, 'error', 7000); }
    else { toast(r.message || 'Login window timed out — try again.', 'info'); }
  } catch (e) {
    toast((e && e.error) || 'Couldn’t start the connect flow.', 'error');
  } finally {
    setConnectorBusy(platform, false);
    loadConnectors();
  }
}

async function syncPlatform(platform) {
  if (busyConnectors.has(platform)) { toast('Already syncing this one — give it a few seconds.', 'info'); return; }
  setConnectorBusy(platform, true, 'Syncing…');
  toast('Opening Chrome — sign in if it asks, then leave the window open. It closes itself when done.', 'sync', 11000);
  try {
    const r = await API('/api/connectors/' + platform + '/sync', { method: 'POST' });
    if (r.action === 'open_desktop_app') { toast('Sync runs in the desktop app — open it on your Mac.', 'error', 7000); return; }
    if (r.busy) { toast(r.error || 'Already syncing.', 'info'); return; }
    if (r.ok) {
      const found = r.found || 0, added = r.added || 0;
      toast(`Synced ✓  ${found} found · ${added} new`, 'success');
    } else if (r.error) {
      toast('Sync failed: ' + r.error, 'error', 8000);
    }
  } catch (e) {
    toast((e && e.error) || 'Sync failed.', 'error');
  } finally {
    setConnectorBusy(platform, false);
    loadConnectors();
  }
}

async function disconnectPlatform(platform) {
  if (!confirm(`Disconnect from this platform? Your existing tasks stay.`)) return;
  await API('/api/connectors/' + platform, { method: 'DELETE' });
  toast('Disconnected. Your tasks are still here.', 'info');
  loadConnectors();
}

$('conn-refresh') && $('conn-refresh').addEventListener('click', loadConnectors);

// "Join the waitlist" on the J@rv1s Cloud tease — saves an interest signal
// (currently just shows a fun confirmation; later wire to an email capture).
$('cloud-tease-waitlist') && $('cloud-tease-waitlist').addEventListener('click', (e) => {
  const btn = e.currentTarget;
  btn.textContent = '✓ You\'re on the list';
  btn.disabled = true;
  btn.style.opacity = '0.7';
  btn.style.cursor = 'default';
});

// On every boot, prime the Connectors count badge.
const _origBoot = boot;
boot = async function(opts) {
  await _origBoot.call(this, opts);
  loadConnectors();
};

// =====================================================
// HISTORY VIEW — every chat across every project
// =====================================================
let historyAll = [];        // flat list of {project, id, title, updated, files, preview}
let historyFilter = { q: '', project: '', sort: 'newest' };

async function loadHistory() {
  // Build from state.all_projects which we already have. Refresh first.
  try {
    state = await API('/api/state');
  } catch (e) {
    if (e && e.auth) { showAuth(); return; }
  }
  historyAll = [];
  (state.all_projects || []).forEach(p => {
    (p.conversations || []).forEach(c => {
      historyAll.push({
        project: p.name,
        id: c.id,
        title: c.title || '(Untitled)',
        preview: c.preview || '',
        updated: c.updated || 0,
        files: c.files || [],     // attached files if any
      });
    });
  });
  // Populate project filter dropdown
  const sel = $('hist-project');
  if (sel) {
    const projects = Array.from(new Set(historyAll.map(h => h.project))).sort();
    sel.innerHTML = '<option value="">All projects</option>' +
      projects.map(p => `<option value="${escape(p)}">${escape(p)}</option>`).join('');
  }
  renderHistory();
}

function renderHistory() {
  const list = $('hist-list');
  const count = $('hist-count');
  if (!list) return;
  const q = historyFilter.q.toLowerCase();
  let rows = historyAll.filter(h => {
    if (historyFilter.project && h.project !== historyFilter.project) return false;
    if (q && !((h.title || '') + ' ' + (h.project || '') + ' ' + (h.preview || ''))
        .toLowerCase().includes(q)) return false;
    return true;
  });
  // Sort
  if (historyFilter.sort === 'oldest') rows.sort((a, b) => (a.updated || 0) - (b.updated || 0));
  else if (historyFilter.sort === 'project') rows.sort((a, b) => (a.project || '').localeCompare(b.project || '') || ((b.updated || 0) - (a.updated || 0)));
  else rows.sort((a, b) => (b.updated || 0) - (a.updated || 0));

  if (count) count.textContent = `${rows.length} chat${rows.length === 1 ? '' : 's'}`;
  list.innerHTML = '';
  if (!rows.length) {
    list.innerHTML = `
      <div class="hist-empty">
        <div class="ico">💬</div>
        <h3>${historyAll.length ? 'Nothing matches that filter' : 'No chats yet'}</h3>
        <p>${historyAll.length ? 'Try a different search or filter.' : 'Start chatting and your history will appear here.'}</p>
      </div>`;
    return;
  }
  rows.forEach(h => list.appendChild(renderHistRow(h)));
}

function renderHistRow(h) {
  const row = document.createElement('div');
  row.className = 'hist-row';
  // Build file tag string
  const fileChips = (h.files || []).slice(0, 2).map(f =>
    `<span class="file-tag">📎 ${escape(f.name || f)}</span>`).join('');
  const moreFiles = (h.files || []).length > 2
    ? `<span class="file-tag">+${(h.files || []).length - 2}</span>` : '';
  row.innerHTML = `
    <span class="ico">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
      </svg>
    </span>
    <div class="title">${escape(h.title)}</div>
    <div class="meta">
      ${fileChips}${moreFiles}
      <span class="project-tag">${escape(h.project)}</span>
    </div>
    <div class="when">${escape(timeAgo(h.updated) || '—')}</div>
  `;
  row.addEventListener('click', () => openConversation(h.project, h.id));
  return row;
}

// Bar wiring
$('hist-search') && $('hist-search').addEventListener('input', (e) => {
  historyFilter.q = e.target.value; renderHistory();
});
$('hist-project') && $('hist-project').addEventListener('change', (e) => {
  historyFilter.project = e.target.value; renderHistory();
});
$('hist-sort') && $('hist-sort').addEventListener('change', (e) => {
  historyFilter.sort = e.target.value; renderHistory();
});
$('hist-new') && $('hist-new').addEventListener('click', newChat);

// ─── Memory import flow ────────────────────────────────────────────────────
let memoryInfo = null;
async function loadMemoryStatus() {
  try {
    memoryInfo = await API('/api/memory');
  } catch { memoryInfo = null; return; }
  const n = (memoryInfo.imported || []).length;
  const row = $('mem-status-row'), clear = $('mem-clear-row');
  if (n > 0) {
    row.style.display = ''; clear.style.display = '';
    const chars = (memoryInfo.imported_text || '').length;
    $('mem-status').textContent = `${n} import${n === 1 ? '' : 's'} · ${chars.toLocaleString()} characters stored`;
  } else {
    row.style.display = 'none'; clear.style.display = 'none';
  }
}

// open import modal: paint the prompt + clear paste box
$('set-mem-import') && $('set-mem-import').addEventListener('click', async () => {
  if (!memoryInfo) await loadMemoryStatus();
  $('mem-prompt-pre').textContent = (memoryInfo && memoryInfo.import_prompt) || '';
  $('mem-paste').value = '';
  $('mem-copy').textContent = '📋 Copy';
  $('mem-copy').classList.remove('copied');
  $('mem-import-backdrop').classList.remove('hidden');
});

// copy prompt
$('mem-copy') && $('mem-copy').addEventListener('click', async () => {
  try {
    await navigator.clipboard.writeText($('mem-prompt-pre').textContent);
    $('mem-copy').textContent = '✓ Copied';
    $('mem-copy').classList.add('copied');
    setTimeout(() => {
      $('mem-copy').textContent = '📋 Copy';
      $('mem-copy').classList.remove('copied');
    }, 1800);
  } catch { alert('Copy failed — select and copy manually.'); }
});

// save imported memory
$('mem-import-save') && $('mem-import-save').addEventListener('click', async () => {
  const text = $('mem-paste').value.trim();
  if (!text) { alert('Paste your memory export first.'); return; }
  try {
    await API('/api/memory/import', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text, source: $('mem-source').value }),
    });
    $('mem-import-backdrop').classList.add('hidden');
    $('mem-paste').value = '';
    await loadMemoryStatus();
    alert(`Memory imported. J@rv1s will use this context from now on.`);
  } catch (e) { alert(e.error || 'Import failed.'); }
});

$('mem-import-cancel') && $('mem-import-cancel').addEventListener('click', () =>
  $('mem-import-backdrop').classList.add('hidden'));
$('mem-import-backdrop') && $('mem-import-backdrop').addEventListener('click', (e) => {
  if (e.target.id === 'mem-import-backdrop') e.currentTarget.classList.add('hidden');
});

// view / edit existing imported memory
$('set-mem-view') && $('set-mem-view').addEventListener('click', async () => {
  if (!memoryInfo) await loadMemoryStatus();
  $('mem-view-text').value = (memoryInfo && memoryInfo.imported_text) || '';
  $('mem-view-backdrop').classList.remove('hidden');
});

$('mem-view-save') && $('mem-view-save').addEventListener('click', async () => {
  const text = $('mem-view-text').value.trim();
  // Save = wipe imports + replace with the edited text as one entry
  await API('/api/memory/import', { method: 'DELETE' });
  if (text) {
    await API('/api/memory/import', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text, source: 'edited' }),
    });
  }
  $('mem-view-backdrop').classList.add('hidden');
  await loadMemoryStatus();
});

$('mem-view-cancel') && $('mem-view-cancel').addEventListener('click', () =>
  $('mem-view-backdrop').classList.add('hidden'));
$('mem-view-backdrop') && $('mem-view-backdrop').addEventListener('click', (e) => {
  if (e.target.id === 'mem-view-backdrop') e.currentTarget.classList.add('hidden');
});

// clear all imported memory
$('set-mem-clear') && $('set-mem-clear').addEventListener('click', async () => {
  if (!confirm('Clear ALL imported memory? This wipes everything you brought in from other AIs.')) return;
  await API('/api/memory/import', { method: 'DELETE' });
  await loadMemoryStatus();
});

const pwModal = $('password-modal-backdrop');
function bindSettings() {
  $('set-theme') && $('set-theme').addEventListener('click', () => themeToggle && themeToggle.click());
  $('set-logout') && $('set-logout').addEventListener('click', async () => {
    if (!confirm('Sign out?')) return;
    await API('/api/auth/logout', { method: 'POST' }); location.reload();
  });
  $('set-manage') && $('set-manage').addEventListener('click', () => {
    if (billingInfo && billingInfo.subscribed) openPortal(); else showPaywall();
  });
  $('set-export') && $('set-export').addEventListener('click', () => { window.location.href = '/api/account/export'; });
  $('set-clear') && $('set-clear').addEventListener('click', resetConversation);
  $('set-delete') && $('set-delete').addEventListener('click', async () => {
    if (!confirm('Delete your account and ALL data? This cannot be undone.')) return;
    if (!confirm('Really delete everything permanently? Conversations, projects, memory — all gone.')) return;
    try {
      const r = await API('/api/account/delete', { method: 'POST' });
      if (r.ok) {
        alert('Account deleted. Goodbye 👋');
        // Send to auth screen, not a refresh — refresh might 401-loop on a deleted session.
        window.location.href = '/?deleted=1';
      } else {
        alert(r.error || 'Delete failed.');
      }
    } catch (e) {
      alert((e && e.error) || 'Delete failed. If you have an active subscription, cancel it first via Stripe portal.');
    }
  });
  $('set-change-pw') && $('set-change-pw').addEventListener('click', () => {
    pwModal.classList.remove('hidden'); $('pw-old').focus();
  });
  $('pw-cancel') && $('pw-cancel').addEventListener('click', () => {
    pwModal.classList.add('hidden'); $('pw-old').value = ''; $('pw-new').value = ''; $('pw-error').textContent = '';
  });
  $('pw-save') && $('pw-save').addEventListener('click', async () => {
    try {
      await API('/api/account/password', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ old: $('pw-old').value, new: $('pw-new').value }),
      });
      pwModal.classList.add('hidden'); $('pw-old').value = ''; $('pw-new').value = '';
      $('pw-error').textContent = '';
      alert('Password updated.');
    } catch (e) { $('pw-error').textContent = e.error || 'Could not update password.'; }
  });
  pwModal && pwModal.addEventListener('click', (e) => { if (e.target === pwModal) pwModal.classList.add('hidden'); });
}
bindSettings();

async function startCheckout(tier, interval = 'monthly') {
  const note = $('paywall-note');
  if (!billingInfo || !billingInfo.enabled) {
    note.textContent = 'Payments aren’t switched on yet (Stripe link not set).';
    return;
  }
  note.textContent = 'Opening secure checkout…';
  try {
    const r = await API('/api/billing/checkout', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ tier, interval }),
    });
    if (r.url) window.location.href = r.url;
  } catch (e) { note.textContent = e.error || 'Could not start checkout.'; }
}

async function refreshSubscription() {
  const note = $('paywall-note');
  note.textContent = 'Checking…';
  await loadBilling();
  if (!gated) { hidePaywall(); boot(); }
  else note.textContent = "No active subscription found yet. If you just paid, give it a few seconds.";
}

if (paywall) {
  $('paywall-refresh').addEventListener('click', refreshSubscription);
  // "Explore first" — dismiss the paywall and browse the app (messaging still locked).
  $('paywall-back').addEventListener('click', hidePaywall);
  $('paywall-signout').addEventListener('click', async () => {
    await API('/api/auth/logout', { method: 'POST' }); location.reload();
  });
}

// returning from Stripe: poll a few times for the webhook to land
if (location.search.includes('upgraded=1')) {
  let tries = 0;
  const poll = setInterval(async () => {
    tries++;
    await loadBilling();
    if (!gated || tries > 6) { clearInterval(poll); if (!gated) hidePaywall(); }
  }, 2000);
}

// =====================================================
// View switching
// =====================================================
function switchView(view) {
  document.body.dataset.view = view;
  $$('.nav-item').forEach(el => {
    // highlight the matching view item; highlight New chat when on chat view
    const isActive = el.dataset.view === view ||
                     (view === 'chat' && el.dataset.action === 'new-chat');
    el.classList.toggle('active', isActive);
  });
  if (view === 'admin') loadAdmin();
  if (view === 'settings') loadSettings();
  if (view === 'tasks') loadTasks();
  if (view === 'autopilot') loadAutopilotDashboard();
  if (view === 'memories') loadMemories();
  if (view === 'connectors') loadConnectors();
  if (view === 'history') loadHistory();
  if (view === 'voice') { wireVoice(); loadVoice(); }
}

async function newChat() {
  // leave any project context and start a clean global conversation
  await API('/api/projects/clear', { method: 'POST' });
  await API('/api/reset', { method: 'POST' });
  state.active_project = null;
  state.active_conversation_id = null;
  currentProjectPage = null;
  switchView('chat');
  clearChat();
  location.reload();
}

$$('.nav-item').forEach(el => {
  el.addEventListener('click', () => {
    if (el.dataset.action === 'new-chat') newChat();
    else if (el.dataset.action === 'search') openPalette();
    else if (el.dataset.view) switchView(el.dataset.view);
  });
});

/* ── Customize sidebar ───────────────────────────────────────────────
   Resting state shows only New Chat + the user's pinned essentials +
   a "Customize sidebar" button. Clicking it expands every item and
   reveals a pin star on each so the user can choose what stays. The
   pinned set persists; the currently-active view is always shown. */
(function setupSidebarCustomize() {
  const nav = document.querySelector('.nav-section');
  const btn = $('sidebar-customize-btn');
  if (!nav || !btn) return;

  const PIN_KEY = 'jarvis_sidebar_pins';
  const DEFAULT_PINS = ['search', 'projects', 'tasks', 'autopilot', 'connectors', 'history'];
  const items = Array.from(nav.querySelectorAll('.nav-item[data-nav-key]'));

  let pins;
  try {
    const raw = JSON.parse(localStorage.getItem(PIN_KEY));
    pins = new Set(Array.isArray(raw) ? raw : DEFAULT_PINS);
  } catch (_) { pins = new Set(DEFAULT_PINS); }
  // one-time: surface Connectors for users who pinned before it became a default
  try {
    if (!localStorage.getItem('jarvis_pins_v3')) {
      pins.add('connectors'); pins.add('autopilot');
      localStorage.setItem('jarvis_pins_v3', '1');
      localStorage.setItem(PIN_KEY, JSON.stringify([...pins]));
    }
  } catch (_) {}
  const savePins = () => {
    try { localStorage.setItem(PIN_KEY, JSON.stringify([...pins])); } catch (_) {}
  };

  function applyPins() {
    items.forEach(el => {
      const on = pins.has(el.dataset.navKey);
      el.classList.toggle('pinned', on);
      const star = el.querySelector('.nav-pin');
      if (star) {
        star.classList.toggle('on', on);
        star.title = on ? 'Remove from collapsed sidebar' : 'Keep in collapsed sidebar';
      }
    });
  }

  // inject a pin star into each pinnable item (visible only while customizing)
  items.forEach(el => {
    const key = el.dataset.navKey;
    const star = document.createElement('span');
    star.className = 'nav-pin';
    star.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2l2.9 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14l-5-4.87 7.1-1.01z"/></svg>';
    star.addEventListener('click', (e) => {
      e.stopPropagation();
      if (pins.has(key)) pins.delete(key); else pins.add(key);
      savePins();
      applyPins();
    });
    el.appendChild(star);
  });

  function setMode(customizing) {
    nav.classList.toggle('customizing', customizing);
    btn.classList.toggle('active', customizing);
    btn.setAttribute('aria-expanded', customizing ? 'true' : 'false');
    const label = btn.querySelector('.sc-label');
    if (label) label.textContent = customizing ? 'Done' : 'Customize sidebar';
  }

  btn.addEventListener('click', () => setMode(!nav.classList.contains('customizing')));

  applyPins();
  setMode(false);   // always boot to the clean, collapsed view
  nav.classList.add('pins-ready');   // arms the collapse rule (graceful if JS never ran)
})();

/* ── Rail toggle: collapse the whole sidebar to an icon-only rail ───── */
(function setupRailToggle() {
  const btn = $('rail-toggle');
  if (!btn) return;
  const KEY = 'jarvis_sidebar_rail';
  function setRail(on) {
    document.body.classList.toggle('rail', on);
    btn.setAttribute('aria-pressed', on ? 'true' : 'false');
    btn.title = on ? 'Expand sidebar' : 'Collapse sidebar';
  }
  btn.addEventListener('click', () => {
    const on = !document.body.classList.contains('rail');
    setRail(on);
    try { localStorage.setItem(KEY, on ? '1' : '0'); } catch (_) {}
  });
  setRail(localStorage.getItem(KEY) === '1');   // restore last layout
})();

/* ── Guided walkthrough: spotlight real parts of the interface ───────── */
const TOUR_STEPS = [
  { sel: '.brand', title: 'Welcome to <span class="grad">J@rv1s</span> 👋', text: 'A 20-second tour of your workspace. Use Next, or hit Skip anytime.', place: 'right' },
  { sel: '#sidebar-customize-btn', title: 'Customize your sidebar', text: 'Click here to pick which items stay pinned. Star the ones you want, hit Done, and the rest tuck away.', place: 'right' },
  { sel: '#rail-toggle', title: 'Collapse to icons', text: 'Tap this to shrink the whole sidebar into a slim icon rail when you want maximum focus.', place: 'bottom' },
  { sel: '[data-nav-key="connectors"]', title: 'Connect your school', text: 'Link Google Classroom, Canvas or Schoology so J@rv1s can pull in your real assignments.', place: 'right' },
  { sel: '[data-nav-key="tasks"]', title: 'Your assignments', text: 'Everything due lands here — split into Missing and Assigned, with filters and bulk actions.', place: 'right' },
  { sel: '#input', title: 'Ask or assign', text: 'Type a question, paste a problem, or hand J@rv1s a whole task to do for you.', place: 'top' },
  { sel: '#account-card', title: 'Account & settings', text: 'Your plan, preferences and settings live here. That’s the tour — you’re all set!', place: 'top' },
];

let tourIdx = 0;
let tourEls = null;

function buildTourEls() {
  if (tourEls) return tourEls;
  const overlay = document.createElement('div');
  overlay.className = 'tour-overlay hidden';
  overlay.innerHTML =
    '<div class="tour-spot"></div>' +
    '<div class="tour-pop">' +
      '<div class="tour-step"></div>' +
      '<div class="tour-title"></div>' +
      '<div class="tour-text"></div>' +
      '<div class="tour-nav">' +
        '<button class="tour-skip" type="button">Skip</button>' +
        '<span class="tour-dots"></span>' +
        '<button class="ghost-btn tour-prev" type="button">Back</button>' +
        '<button class="primary-btn tour-next" type="button">Next</button>' +
      '</div>' +
    '</div>';
  document.body.appendChild(overlay);
  tourEls = {
    overlay,
    spot: overlay.querySelector('.tour-spot'),
    pop: overlay.querySelector('.tour-pop'),
    step: overlay.querySelector('.tour-step'),
    title: overlay.querySelector('.tour-title'),
    text: overlay.querySelector('.tour-text'),
    dots: overlay.querySelector('.tour-dots'),
    prev: overlay.querySelector('.tour-prev'),
    next: overlay.querySelector('.tour-next'),
    skip: overlay.querySelector('.tour-skip'),
  };
  tourEls.next.addEventListener('click', () => tourGoto(tourIdx + 1));
  tourEls.prev.addEventListener('click', () => tourGoto(tourIdx - 1));
  tourEls.skip.addEventListener('click', () => endTour());
  window.addEventListener('keydown', (e) => {
    if (!tourEls || tourEls.overlay.classList.contains('hidden')) return;
    if (e.key === 'Escape') endTour();
    else if (e.key === 'ArrowRight' || e.key === 'Enter') tourGoto(tourIdx + 1);
    else if (e.key === 'ArrowLeft') tourGoto(tourIdx - 1);
  });
  window.addEventListener('resize', () => {
    if (tourEls && !tourEls.overlay.classList.contains('hidden')) positionTour();
  });
  return tourEls;
}

function tourTarget(sel) {
  const el = document.querySelector(sel);
  if (!el) return null;
  const r = el.getBoundingClientRect();
  return (r.width > 0 && r.height > 0) ? el : null;
}

function tourGoto(i) {
  const dir = i >= tourIdx ? 1 : -1;
  let n = i;
  while (n >= 0 && n < TOUR_STEPS.length && !tourTarget(TOUR_STEPS[n].sel)) n += dir;
  if (n < 0) return;                                  // backed past the first visible step
  if (n >= TOUR_STEPS.length) { endTour(); return; }  // ran off the end → finished
  tourIdx = n;
  renderTourStep();
}

function renderTourStep() {
  const s = TOUR_STEPS[tourIdx];
  tourEls.title.innerHTML = s.title;
  tourEls.text.textContent = s.text;
  tourEls.step.textContent = `Step ${tourIdx + 1} of ${TOUR_STEPS.length}`;
  tourEls.dots.innerHTML = TOUR_STEPS.map((_, i) => `<span class="dot ${i === tourIdx ? 'on' : ''}"></span>`).join('');
  tourEls.prev.style.visibility = tourIdx === 0 ? 'hidden' : 'visible';
  tourEls.next.textContent = tourIdx === TOUR_STEPS.length - 1 ? 'Done' : 'Next';
  positionTour();
}

function positionTour() {
  const s = TOUR_STEPS[tourIdx];
  const el = tourTarget(s.sel);
  if (!el) { tourGoto(tourIdx + 1); return; }
  const r = el.getBoundingClientRect();
  const pad = 6;
  const spot = tourEls.spot;
  spot.style.top = (r.top - pad) + 'px';
  spot.style.left = (r.left - pad) + 'px';
  spot.style.width = (r.width + pad * 2) + 'px';
  spot.style.height = (r.height + pad * 2) + 'px';

  const pop = tourEls.pop;
  pop.style.visibility = 'hidden';
  const pw = pop.offsetWidth, ph = pop.offsetHeight, gap = 14;
  let top, left;
  const place = s.place || 'right';
  if (place === 'right')       { left = r.right + gap;                 top = r.top + r.height / 2 - ph / 2; }
  else if (place === 'left')   { left = r.left - pw - gap;             top = r.top + r.height / 2 - ph / 2; }
  else if (place === 'top')    { left = r.left + r.width / 2 - pw / 2; top = r.top - ph - gap; }
  else                         { left = r.left + r.width / 2 - pw / 2; top = r.bottom + gap; }
  const vw = window.innerWidth, vh = window.innerHeight;
  left = Math.max(12, Math.min(left, vw - pw - 12));
  top  = Math.max(12, Math.min(top,  vh - ph - 12));
  pop.style.left = left + 'px';
  pop.style.top = top + 'px';
  pop.style.visibility = 'visible';
}

function startWalkthrough() {
  buildTourEls();
  tourIdx = 0;
  tourEls.overlay.classList.remove('hidden');
  if (tourTarget(TOUR_STEPS[0].sel)) renderTourStep();
  else tourGoto(0);
}

function endTour() {
  if (tourEls) tourEls.overlay.classList.add('hidden');
  try { localStorage.setItem('jarvis_tour_done', '1'); } catch (_) {}
  // New users tour the app before paying — pop the deferred paywall on finish.
  if (typeof gated !== 'undefined' && gated && typeof showPaywall === 'function') showPaywall();
}

// Account card (sidebar bottom-left) → opens settings.
const accountCard = $('account-card');
if (accountCard) accountCard.addEventListener('click', () => switchView('settings'));

function renderAccountCard(info) {
  if (!accountCard || !info) return;
  const name = info.email || info.username || 'Account';
  const plan = info.plan === 'none' ? 'No plan' :
               ({starter:'Starter', professional:'Professional', max:'Max', ultra:'Ultra', apex:'Apex'})[info.plan] || info.plan;
  $('ac-name').textContent = name;
  $('ac-plan').textContent = info.is_admin ? 'Admin' : `${plan} plan`;
  $('ac-avatar').textContent = (name[0] || 'J').toUpperCase();
}

// Aggregate conversations across pinned projects → "Recent chats" sidebar list
function renderRecentChats() {
  const wrap = $('recent-chats');
  if (!wrap) return;
  const all = [];
  (state.all_projects || []).forEach(p => {
    (p.conversations || []).forEach(c => {
      all.push({ project: p.name, id: c.id, title: c.title || 'Untitled', updated: c.updated || 0 });
    });
  });
  all.sort((a, b) => (b.updated || 0) - (a.updated || 0));
  const top = all.slice(0, 10);
  wrap.innerHTML = '';
  if (!top.length) {
    wrap.innerHTML = '<div class="sidebar-empty"><span class="se-ico">💬</span> No chats yet</div>';
    return;
  }
  top.forEach(c => {
    const el = document.createElement('div');
    el.className = 'recent-chat-item';
    el.textContent = c.title;
    el.title = `${c.title} · ${c.project}`;
    el.addEventListener('click', () => openConversation(c.project, c.id));
    wrap.appendChild(el);
  });
}

// =====================================================
// Chat rendering
// =====================================================
function clearChat() { chat.innerHTML = ''; }

function appendMessage(role, content) {
  const welcome = chat.querySelector('.welcome');
  if (welcome) welcome.remove();

  const wrap = document.createElement('div');
  wrap.className = `msg ${role}`;

  const avatar = document.createElement('div');
  avatar.className = 'msg-avatar';
  avatar.textContent = role === 'user' ? 'K' : 'J';

  const body = document.createElement('div');
  body.className = 'msg-body';

  const roleEl = document.createElement('div');
  roleEl.className = 'msg-role';
  roleEl.textContent = role === 'user' ? 'You' : 'J@rv1s';

  const contentEl = document.createElement('div');
  contentEl.className = 'msg-content';
  if (role === 'assistant') {
    contentEl.innerHTML = marked.parse(content);
    contentEl.querySelectorAll('pre code').forEach(b => hljs.highlightElement(b));
  } else {
    contentEl.textContent = content;
  }

  body.appendChild(roleEl);
  body.appendChild(contentEl);
  wrap.appendChild(avatar);
  wrap.appendChild(body);
  chat.appendChild(wrap);
  chat.scrollTop = chat.scrollHeight;
  return contentEl;
}

function appendTyping() {
  const welcome = chat.querySelector('.welcome');
  if (welcome) welcome.remove();
  const wrap = document.createElement('div');
  wrap.className = 'msg assistant';
  wrap.id = 'typing-msg';
  wrap.innerHTML = `
    <div class="msg-avatar">J</div>
    <div class="msg-body">
      <div class="msg-role">J@rv1s</div>
      <div class="msg-content"><div class="typing"><span></span><span></span><span></span></div></div>
    </div>`;
  chat.appendChild(wrap);
  chat.scrollTop = chat.scrollHeight;
}
function removeTyping() { const t = $('typing-msg'); if (t) t.remove(); }

// =====================================================
// Sidebar
// =====================================================
function renderSidebar() {
  // Projects
  projectList.innerHTML = '';
  if (state.projects.length === 0) {
    projectList.innerHTML = '<div class="sidebar-empty"><span class="se-ico">📁</span> No pinned projects</div>';
  } else {
    state.projects.forEach(p => {
      const el = document.createElement('div');
      el.className = 'project-item' + (p.name === state.active_project ? ' active' : '');
      const open = p.assignments.filter(a => !a.done).length;
      el.innerHTML = `
        <span class="name">${escape(p.name)}</span>
        ${open > 0 ? `<span class="count">${open}</span>` : ''}
        <button class="pi-unpin" title="Unpin from sidebar" aria-label="Unpin ${escape(p.name)}">📌</button>
      `;
      el.addEventListener('click', (e) => {
        if (e.target.closest('.pi-unpin')) return;   // don't open on unpin
        useProject(p.name);
      });
      el.querySelector('.pi-unpin').addEventListener('click', async (e) => {
        e.stopPropagation();
        await API(`/api/projects/${encodeURIComponent(p.name)}/pin`, {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ pinned: false }),
        });
        await refreshState();
      });
      projectList.appendChild(el);
    });
  }

  // Upcoming
  upcomingList.innerHTML = '';
  if (state.upcoming.length === 0) {
    upcomingList.innerHTML = '<div class="sidebar-empty"><span class="se-ico">📅</span> Nothing due soon</div>';
  } else {
    state.upcoming.slice(0, 6).forEach(a => {
      const cls = a.days_until <= 1 ? 'urgent' : a.days_until <= 3 ? 'soon' : 'fine';
      const el = document.createElement('div');
      el.className = 'upcoming-item';
      el.innerHTML = `
        <div class="title">${escape(a.title)}</div>
        <div class="meta">
          <span>${escape(a.project)}</span>
          <span class="days ${cls}">${a.days_until}d</span>
        </div>`;
      upcomingList.appendChild(el);
    });
  }

  // Skill count badge in nav
  const enabledCount = (state.skills || []).filter(s => s.enabled).length;
  const navCount = $('nav-skill-count');
  navCount.textContent = enabledCount;
  navCount.classList.toggle('show', enabledCount > 0);

  renderRecentChats();
}

function renderActiveProject() {
  if (state.active_project) {
    activeProjectDisplay.innerHTML = `<span class="muted">In</span> <strong class="ap-label">${escape(state.active_project)}</strong>`;
  } else {
    activeProjectDisplay.innerHTML = `<strong class="ap-label">General Chat</strong>`;
  }
}

// =====================================================
// Model picker
// =====================================================
function modelClass(id) {
  if (id === 'claude-opus-4-7') return 'm-opus';
  if (id === 'claude-haiku-4-5-20251001') return 'm-haiku';
  if (id === 'claude-sonnet-4-6') return 'm-sonnet';
  return '';
}

function renderModel() {
  const current = models.find(m => m.id === state.model);
  modelBadgeName.textContent = current ? current.name : state.model;
  modelBadgeName.className = 'm-name ' + modelClass(state.model);
  modelDropdown.innerHTML = '';
  models.forEach(m => {
    const opt = document.createElement('div');
    opt.className = 'model-option' + (m.id === state.model ? ' active' : '');
    opt.innerHTML = `
      <div class="top">
        <span class="name m-name ${modelClass(m.id)}">${escape(m.name)}</span>
        <span class="check">✓</span>
      </div>
      <span class="desc">${escape(m.desc)}</span>`;
    opt.onclick = async () => {
      try {
        await API('/api/model', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ model: m.id }),
        });
        state.model = m.id;
        modelDropdown.classList.add('hidden');
        renderModel();
      } catch (e) { alert(e.error || 'Failed to switch model'); }
    };
    modelDropdown.appendChild(opt);
  });
}

modelBadge.addEventListener('click', (e) => {
  e.stopPropagation();
  modelDropdown.classList.toggle('hidden');
});
document.addEventListener('click', (e) => {
  if (!e.target.closest('#model-picker')) modelDropdown.classList.add('hidden');
});

// =====================================================
// Browser automation toggle
// =====================================================
function renderBrowserToggle() {
  const on = !!(state.browser && state.browser.armed);
  browserToggle.classList.toggle('on', on);
  const safe = $('safesites-toggle');
  if (safe) {
    safe.classList.toggle('on', !!(state.browser && state.browser.restricted));
    safe.style.display = on ? 'flex' : 'none';   // only show when armed
  }
}

browserToggle.addEventListener('click', async () => {
  const on = browserToggle.classList.contains('on');
  browserToggle.classList.add('loading');
  try {
    const res = await API(`/api/browser/${on ? 'disable' : 'enable'}`, { method: 'POST' });
    state.browser = res;
    renderBrowserToggle();
  } catch (e) {
    // arming never launches a browser, so this should basically never fail
    console.warn('browser toggle', e);
  } finally {
    browserToggle.classList.remove('loading');
  }
});

// theme toggle
function applyTheme(theme) {
  document.body.dataset.theme = theme;
  const t = $('theme-toggle');
  if (t) t.classList.toggle('on', theme === 'light');
}
const themeToggle = $('theme-toggle');
if (themeToggle) themeToggle.addEventListener('click', async () => {
  const next = (document.body.dataset.theme === 'light') ? 'dark' : 'light';
  applyTheme(next);
  state.theme = next;
  await API('/api/theme', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ theme: next }),
  });
});

const safeToggle = $('safesites-toggle');
if (safeToggle) safeToggle.addEventListener('click', async () => {
  const on = safeToggle.classList.contains('on');
  const res = await API('/api/browser/restrict', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ restricted: !on }),
  });
  state.browser = res;
  renderBrowserToggle();
});

// =====================================================
// Voice-out toggle (speak responses)
// =====================================================
voiceOutToggle.addEventListener('click', () => {
  speakResponses = !speakResponses;
  voiceOutToggle.classList.toggle('on', speakResponses);
});

async function speak(text) {
  try {
    await API('/api/voice/speak', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text }),
    });
  } catch (e) { console.warn('TTS failed', e); }
}

// =====================================================
// Send / chat
// =====================================================
async function send(opts = {}) {
  const text = (opts.text ?? input.value).trim();
  if (!text) return;
  if (gated) { showPaywall(); return; }   // no messaging without a plan
  if (!opts.text) {
    input.value = '';
    input.style.height = 'auto';
  }
  sendBtn.disabled = true;
  sendBtn.classList.add('loading');

  appendMessage('user', text);
  appendTyping();

  try {
    await streamReply(text, !!(speakResponses || opts.alwaysSpeak));
  } catch (e) {
    removeTyping();
    appendMessage('assistant', `**Error:** ${e.error || e.message || JSON.stringify(e)}`);
  } finally {
    sendBtn.disabled = false;
    sendBtn.classList.remove('loading');
    input.focus();
  }
}

// Stream the assistant reply token-by-token via SSE; render markdown live.
async function streamReply(message, doSpeak) {
  const resp = await fetch('/api/chat/stream', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ message }),
  });
  if (!resp.ok || !resp.body) {
    // fall back to non-streaming
    removeTyping();
    const res = await API('/api/chat', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message }),
    });
    appendMessage('assistant', res.reply);
    if (doSpeak) speak(res.reply);
    return;
  }

  removeTyping();
  const contentEl = appendMessage('assistant', '');
  contentEl.classList.add('streaming');

  const reader = resp.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';
  let full = '';

  // throttle markdown re-render for smoothness
  let pending = false;
  const renderNow = () => {
    contentEl.innerHTML = marked.parse(full);
    contentEl.querySelectorAll('pre code').forEach(b => hljs.highlightElement(b));
    contentEl.classList.add('streaming');
    chat.scrollTop = chat.scrollHeight;
    pending = false;
  };

  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split('\n\n');
    buffer = lines.pop();
    for (const line of lines) {
      const m = line.match(/^data: (.*)$/s);
      if (!m) continue;
      let payload;
      try { payload = JSON.parse(m[1]); } catch { continue; }
      if (payload.t) {
        full += payload.t;
        if (!pending) { pending = true; requestAnimationFrame(renderNow); }
      } else if (payload.error) {
        full += `\n\n**Error:** ${payload.error}`;
      }
    }
  }
  full = full || '…';
  contentEl.innerHTML = marked.parse(full);
  contentEl.querySelectorAll('pre code').forEach(b => hljs.highlightElement(b));
  contentEl.classList.remove('streaming');
  chat.scrollTop = chat.scrollHeight;
  if (doSpeak) speak(full);
}

// =====================================================
// Projects
// =====================================================
async function useProject(name) {
  // Activate the project on the backend, then open the project view.
  const r = await API(`/api/projects/${encodeURIComponent(name)}/use`, { method: 'POST' });
  state.active_project = name;
  state.active_conversation_id = r.conversation_id || null;
  renderSidebar();
  renderActiveProject();
  await openProjectPage(name);
}

async function openProjectPage(name) {
  currentProjectPage = name;
  switchView('project');
  // skeleton while loading
  $('project-title-display').textContent = name;
  $('project-suggestions').innerHTML =
    Array(6).fill('<div class="skeleton skel-card"></div>').join('');
  $('project-recents').innerHTML =
    Array(3).fill('<div class="skeleton skel-card"></div>').join('');
  // load detail + conversations + suggestions + files in parallel
  const [meta, convs, sugg, files] = await Promise.all([
    API(`/api/projects/${encodeURIComponent(name)}`),
    API(`/api/projects/${encodeURIComponent(name)}/conversations`),
    API(`/api/projects/${encodeURIComponent(name)}/suggestions`),
    API(`/api/projects/${encodeURIComponent(name)}/files`),
  ]);
  renderProjectPage(meta, convs, sugg, files);
}

function fmtBytes(n) {
  if (n < 1024) return n + ' B';
  if (n < 1048576) return (n / 1024).toFixed(0) + ' KB';
  return (n / 1048576).toFixed(1) + ' MB';
}

async function uploadFiles(fileList) {
  if (!currentProjectPage || !fileList.length) return;
  const fd = new FormData();
  for (const f of fileList) fd.append('file', f);
  await fetch(`/api/projects/${encodeURIComponent(currentProjectPage)}/files`, {
    method: 'POST', body: fd,
  });
  openProjectPage(currentProjectPage);  // refresh
}

async function deleteFile(fname) {
  if (!currentProjectPage) return;
  await API(`/api/projects/${encodeURIComponent(currentProjectPage)}/files/${encodeURIComponent(fname)}`, { method: 'DELETE' });
  openProjectPage(currentProjectPage);
}

function renderProjectPage(meta, convs, suggestions, files = []) {
  $('project-title-display').textContent = meta.name;
  $('project-conv-count').textContent = `${convs.length} chat${convs.length === 1 ? '' : 's'}`;

  // instructions card
  const ib = $('instructions-body');
  ib.textContent = meta.instructions || meta.description || 'No instructions yet. Click the pencil to add some.';
  ib.dataset.value = meta.instructions || '';

  // assignments card
  const ab = $('assignments-body');
  ab.innerHTML = '';
  const assigns = meta.assignments || [];
  if (!assigns.length) {
    ab.innerHTML = '<div class="muted-body" style="padding:0">No deadlines yet.</div>';
  } else {
    assigns.forEach(a => {
      const row = document.createElement('div');
      row.className = 'assign-row' + (a.done ? ' done' : '');
      row.innerHTML = `
        <button class="assign-check" title="Toggle complete">${a.done ? '✓' : ''}</button>
        <div class="assign-info">
          <div class="assign-title">${escape(a.title)}</div>
          <div class="assign-due">due ${escape(fmtMonthDay(a.due))}${a.notes ? ' · ' + escape(a.notes) : ''}</div>
        </div>`;
      row.querySelector('.assign-check').addEventListener('click', async () => {
        await API(`/api/projects/${encodeURIComponent(meta.name)}/assignments/complete`, {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ title: a.title }),
        });
        openProjectPage(meta.name); refreshState();
      });
      ab.appendChild(row);
    });
  }

  // scheduled card
  const scb = $('scheduled-body');
  scb.innerHTML = '';
  const sched = meta.scheduled || [];
  if (!sched.length) {
    scb.innerHTML = '<div class="muted-body" style="padding:0">No recurring tasks.</div>';
  } else {
    sched.forEach((s, i) => {
      const row = document.createElement('div');
      row.className = 'assign-row';
      row.innerHTML = `<div class="assign-info">
          <div class="assign-title">${escape(s.title)}</div>
          <div class="assign-due">${escape(s.cadence)}</div>
        </div>
        <button class="fi-del" title="Remove">×</button>`;
      row.querySelector('.fi-del').addEventListener('click', async () => {
        await API(`/api/projects/${encodeURIComponent(meta.name)}/scheduled/${i}`, { method: 'DELETE' });
        openProjectPage(meta.name);
      });
      scb.appendChild(row);
    });
  }

  // context card: files + drop zone
  const cb = $('context-body');
  cb.innerHTML = '';
  cb.insertAdjacentHTML('beforeend', `<div class="label">Files (${files.length})</div>`);
  if (files.length) {
    files.forEach(f => {
      const row = document.createElement('div');
      row.className = 'context-item file-item';
      row.innerHTML = `<span class="fi-name">📄 ${escape(f.name)}</span>
        <span class="fi-meta">${fmtBytes(f.size)}</span>
        <button class="fi-del" title="Remove">×</button>`;
      row.querySelector('.fi-del').addEventListener('click', () => deleteFile(f.name));
      cb.appendChild(row);
    });
  }
  const drop = document.createElement('label');
  drop.className = 'dropzone';
  drop.innerHTML = `<input type="file" multiple hidden>
    <span>＋ Drop files or click to upload</span>`;
  const fileInput = drop.querySelector('input');
  fileInput.addEventListener('change', () => uploadFiles(fileInput.files));
  ['dragenter', 'dragover'].forEach(ev => drop.addEventListener(ev, (e) => {
    e.preventDefault(); drop.classList.add('drag');
  }));
  ['dragleave', 'drop'].forEach(ev => drop.addEventListener(ev, (e) => {
    e.preventDefault(); drop.classList.remove('drag');
  }));
  drop.addEventListener('drop', (e) => uploadFiles(e.dataTransfer.files));
  cb.appendChild(drop);
  cb.insertAdjacentHTML('beforeend', '<div class="label" style="margin-top:10px">Memory</div>');
  cb.insertAdjacentHTML('beforeend', `<div class="context-item">🧠 Personal memory + preferences</div>`);

  // suggestions
  const sg = $('project-suggestions');
  sg.innerHTML = '';
  suggestions.forEach((s, i) => {
    const b = document.createElement('button');
    b.className = 'suggestion-chip';
    b.style.animationDelay = `${i * 0.05}s`;
    b.innerHTML = `<span class="chip-icon">${s.icon}</span><span>${escape(s.title)}</span>`;
    b.addEventListener('click', () => startConversationWith(s.prompt));
    sg.appendChild(b);
  });

  // recents
  const rl = $('project-recents');
  rl.innerHTML = '';
  if (convs.length === 0) {
    rl.innerHTML = '<div class="recents-empty">No conversations yet. Start one above ↑</div>';
  } else {
    convs.forEach((c, i) => {
      const card = document.createElement('div');
      card.className = 'recent-card';
      card.style.animationDelay = `${i * 0.04}s`;
      card.innerHTML = `
        <div class="recent-icon">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
          </svg>
        </div>
        <div class="recent-info">
          <div class="recent-title">${escape(c.title)}</div>
          ${c.preview ? `<div class="recent-preview">${escape(c.preview)}</div>` : ''}
        </div>
        <div class="recent-time">${timeAgo(c.updated)}</div>`;
      card.addEventListener('click', () => openConversation(meta.name, c.id));
      rl.appendChild(card);
    });
  }
}

function timeAgo(ts) {
  if (!ts) return '';
  const s = Date.now() / 1000 - ts;
  if (s < 60) return 'just now';
  if (s < 3600) return Math.floor(s / 60) + ' min ago';
  if (s < 86400) return Math.floor(s / 3600) + ' hr ago';
  if (s < 604800) return Math.floor(s / 86400) + ' days ago';
  return new Date(ts * 1000).toLocaleDateString();
}

async function startConversationWith(text) {
  if (!currentProjectPage) return;
  // create a new conversation and send the seed message
  await API(`/api/projects/${encodeURIComponent(currentProjectPage)}/conversations`, { method: 'POST' });
  // refresh state so active_conversation_id is set
  state = await API('/api/state');
  switchView('chat');
  clearChat();
  await send({ text });
  renderChatBreadcrumb();
}

async function startNewConversation() {
  if (!currentProjectPage) return;
  await API(`/api/projects/${encodeURIComponent(currentProjectPage)}/conversations`, { method: 'POST' });
  state = await API('/api/state');
  switchView('chat');
  clearChat();
  renderChatBreadcrumb();
  input.focus();
}

async function openConversation(project, cid) {
  await API(`/api/projects/${encodeURIComponent(project)}/conversations/${cid}/open`, { method: 'POST' });
  state = await API('/api/state');
  switchView('chat');
  clearChat();
  if (state.history && state.history.length) {
    state.history.forEach(m => appendMessage(m.role, m.content));
  }
  renderChatBreadcrumb();
}

function renderChatBreadcrumb() {
  const back = $('chat-back-btn');
  const disp = $('active-project-display');
  if (state.active_project) {
    back.classList.remove('hidden');
    back.textContent = `← ${state.active_project}`;
    disp.innerHTML = `<span class="muted">In</span> <strong class="ap-label">${escape(state.active_project)}</strong>`;
  } else {
    back.classList.add('hidden');
    disp.innerHTML = `<strong class="ap-label">General Chat</strong>`;
  }
}

async function newProject(name, description) {
  await API('/api/projects', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, description }),
  });
  await refreshState();
}

async function refreshState() {
  state = await API('/api/state');
  renderSidebar();
  renderActiveProject();
  renderBrowserToggle();
  renderSkillsPage();
  renderAllProjects();
}

function renderAllProjects() {
  const grid = $('all-projects-grid');
  if (!grid) return;
  grid.innerHTML = '';
  (state.all_projects || []).forEach((p, i) => {
    const open = p.assignments.filter(a => !a.done).length;
    const convs = (p.conversations || []).length;
    const pinned = p.pinned !== false;
    const card = document.createElement('div');
    card.className = 'project-card';
    card.style.animationDelay = `${i * 0.05}s`;
    card.innerHTML = `
      <div class="pc-actions">
        <button class="pc-action pin ${pinned ? 'pinned' : ''}" data-action="pin" title="${pinned ? 'Unpin' : 'Pin'}">📌</button>
        <button class="pc-action delete" data-action="delete" title="Delete">🗑</button>
      </div>
      <div class="pc-name">${escape(p.name)}</div>
      <div class="pc-desc">${escape(p.description || '')}</div>
      <div class="pc-stats">
        <span><strong>${convs}</strong> chats</span>
        <span><strong>${open}</strong> open</span>
        <span><strong>${p.assignments.length}</strong> total</span>
      </div>`;
    card.addEventListener('click', (e) => {
      if (e.target.closest('.pc-action')) return;
      useProject(p.name);
    });
    card.querySelector('[data-action="pin"]').addEventListener('click', async (e) => {
      e.stopPropagation();
      await API(`/api/projects/${encodeURIComponent(p.name)}/pin`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pinned: !pinned }),
      });
      await refreshState();
    });
    card.querySelector('[data-action="delete"]').addEventListener('click', async (e) => {
      e.stopPropagation();
      if (!confirm(`Delete "${p.name}" and all its conversations?`)) return;
      await API(`/api/projects/${encodeURIComponent(p.name)}`, { method: 'DELETE' });
      await refreshState();
    });
    grid.appendChild(card);
  });
  if ((state.all_projects || []).length === 0) {
    grid.innerHTML = '<div class="recents-empty">No projects yet. Create one.</div>';
  }
}

async function resetConversation() {
  await API('/api/reset', { method: 'POST' });
  clearChat();
  location.reload();
}

// =====================================================
// Voice (round-trip: listen → chat → speak)
// =====================================================
async function voiceTurn() {
  voiceBtn.classList.add('active');
  try {
    const res = await API('/api/voice/listen', { method: 'POST' });
    if (res.text) {
      await send({ text: res.text, alwaysSpeak: true });
    }
  } catch (e) {
    appendMessage('assistant', `**Voice error:** ${e.error || JSON.stringify(e)}`);
  } finally {
    voiceBtn.classList.remove('active');
  }
}

// =====================================================
// Skills page
// =====================================================
function renderSkillsPage() {
  const skills = (state.skills || []).filter(s => {
    if (skillFilter !== 'all' && s.category !== skillFilter) return false;
    if (skillSearch && !(`${s.name} ${s.description}`.toLowerCase().includes(skillSearch.toLowerCase()))) return false;
    return true;
  });
  const sections = { personal: $('grid-personal'), system: $('grid-system'), custom: $('grid-custom') };
  Object.values(sections).forEach(g => g.innerHTML = '');

  skills.forEach(s => {
    const card = document.createElement('div');
    card.className = 'skill-card' + (s.enabled ? ' enabled' : '') + (s.category === 'custom' ? ' custom' : '');
    card.innerHTML = `
      <div class="skill-icon" style="background: ${s.gradient || 'linear-gradient(135deg,#00d9ff,#b794f6)'}">${s.icon || '✨'}</div>
      <div class="skill-info">
        <div class="skill-name">${escape(s.name)}</div>
        <div class="skill-desc">${escape(s.description)}</div>
      </div>
      ${s.category === 'custom' ? '<button class="skill-delete" title="Delete skill">×</button>' : ''}
      <div class="skill-check">✓</div>`;
    card.addEventListener('click', async (e) => {
      if (e.target.classList.contains('skill-delete')) return;
      const r = await API(`/api/skills/${encodeURIComponent(s.id)}/toggle`, { method: 'POST' });
      const idx = state.skills.findIndex(x => x.id === s.id);
      if (idx >= 0) state.skills[idx].enabled = r.enabled;
      renderSkillsPage();
      renderSidebar();
    });
    const del = card.querySelector('.skill-delete');
    if (del) {
      del.addEventListener('click', async (e) => {
        e.stopPropagation();
        if (!confirm(`Delete "${s.name}"?`)) return;
        await API(`/api/skills/${encodeURIComponent(s.id)}`, { method: 'DELETE' });
        await refreshState();
      });
    }
    sections[s.category]?.appendChild(card);
  });

  // hide empty sections
  $$('.skills-section').forEach(sec => {
    const grid = sec.querySelector('.skills-grid');
    sec.classList.toggle('hidden', grid.children.length === 0);
  });

  // active note in top bar
  const active = (state.skills || []).filter(s => s.enabled);
  const note = $('skills-active-note');
  if (active.length > 0) {
    note.textContent = `${active.length} active`;
  } else {
    note.textContent = '';
  }
}

$('skill-search').addEventListener('input', (e) => {
  skillSearch = e.target.value;
  renderSkillsPage();
});
$$('.pill').forEach(p => {
  p.addEventListener('click', () => {
    $$('.pill').forEach(x => x.classList.remove('active'));
    p.classList.add('active');
    skillFilter = p.dataset.filter;
    renderSkillsPage();
  });
});

// =====================================================
// Modals
// =====================================================
function openNewProjectModal() {
  projectModal.classList.remove('hidden');
  $('np-name').focus();
}
$('new-project-btn').addEventListener('click', openNewProjectModal);
const allNewBtn = $('all-new-project-btn');
if (allNewBtn) allNewBtn.addEventListener('click', openNewProjectModal);
$('np-cancel').addEventListener('click', () => {
  projectModal.classList.add('hidden');
  $('np-name').value = ''; $('np-desc').value = '';
});
$('np-create').addEventListener('click', async () => {
  const name = $('np-name').value.trim();
  if (!name) return;
  try {
    await newProject(name, $('np-desc').value.trim());
    projectModal.classList.add('hidden');
    $('np-name').value = ''; $('np-desc').value = '';
  } catch (e) { alert(e.error || 'Failed to create project'); }
});
projectModal.addEventListener('click', (e) => {
  if (e.target === projectModal) projectModal.classList.add('hidden');
});

$('new-skill-btn').addEventListener('click', () => {
  skillModal.classList.remove('hidden');
  $('ns-name').focus();
});
$('ns-cancel').addEventListener('click', () => {
  skillModal.classList.add('hidden');
  ['ns-name','ns-icon','ns-desc','ns-prompt'].forEach(id => $(id).value = '');
});
$('ns-create').addEventListener('click', async () => {
  const name = $('ns-name').value.trim();
  const prompt = $('ns-prompt').value.trim();
  if (!name || !prompt) { alert('Name and instructions are required.'); return; }
  try {
    await API('/api/skills', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name,
        description: $('ns-desc').value.trim(),
        icon: $('ns-icon').value.trim() || '✨',
        prompt,
      }),
    });
    skillModal.classList.add('hidden');
    ['ns-name','ns-icon','ns-desc','ns-prompt'].forEach(id => $(id).value = '');
    await refreshState();
  } catch (e) { alert(e.error || 'Failed to create skill'); }
});
skillModal.addEventListener('click', (e) => {
  if (e.target === skillModal) skillModal.classList.add('hidden');
});

// =====================================================
// Composer
// =====================================================
function autosize() {
  input.style.height = 'auto';
  input.style.height = Math.min(input.scrollHeight, 220) + 'px';
}
input.addEventListener('input', autosize);
input.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    send();
  }
});
sendBtn.addEventListener('click', () => send());
voiceBtn.addEventListener('click', voiceTurn);
$('reset-btn').addEventListener('click', resetConversation);

// (welcome suggestions are wired dynamically in renderWelcome)

// project-view interactions
$('project-back').addEventListener('click', () => {
  switchView('chat');
});
$('chat-back-btn').addEventListener('click', () => {
  if (currentProjectPage) openProjectPage(currentProjectPage);
  else switchView('chat');
});
$('project-new-conv').addEventListener('click', startNewConversation);

$('project-send-btn').addEventListener('click', () => {
  const t = $('project-input').value.trim();
  if (!t) return;
  $('project-input').value = '';
  startConversationWith(t);
});
$('project-input').addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    $('project-send-btn').click();
  }
});
$('project-voice-btn').addEventListener('click', async () => {
  const btn = $('project-voice-btn');
  btn.classList.add('active');
  try {
    const r = await API('/api/voice/listen', { method: 'POST' });
    if (r.text) {
      $('project-input').value = r.text;
      $('project-send-btn').click();
    }
  } catch (e) { alert('Voice error: ' + (e.error || JSON.stringify(e))); }
  finally { btn.classList.remove('active'); }
});

// assignment modal
const asModal = $('assignment-modal-backdrop');
$('add-assignment-btn').addEventListener('click', () => {
  asModal.classList.remove('hidden'); $('as-title').focus();
});
$('as-cancel').addEventListener('click', () => {
  asModal.classList.add('hidden');
  ['as-title','as-due','as-notes'].forEach(id => $(id).value = '');
});
$('as-create').addEventListener('click', async () => {
  const title = $('as-title').value.trim();
  const due = $('as-due').value;
  if (!title || !due || !currentProjectPage) { alert('Title and due date required.'); return; }
  await API(`/api/projects/${encodeURIComponent(currentProjectPage)}/assignments`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ title, due, notes: $('as-notes').value.trim() }),
  });
  asModal.classList.add('hidden');
  ['as-title','as-due','as-notes'].forEach(id => $(id).value = '');
  openProjectPage(currentProjectPage); refreshState();
});
asModal.addEventListener('click', (e) => { if (e.target === asModal) asModal.classList.add('hidden'); });

// scheduled modal
const scModal = $('scheduled-modal-backdrop');
$('add-scheduled-btn').addEventListener('click', () => {
  scModal.classList.remove('hidden'); $('sc-title').focus();
});
$('sc-cancel').addEventListener('click', () => { scModal.classList.add('hidden'); $('sc-title').value = ''; });
$('sc-create').addEventListener('click', async () => {
  const title = $('sc-title').value.trim();
  if (!title || !currentProjectPage) { alert('Describe the task.'); return; }
  await API(`/api/projects/${encodeURIComponent(currentProjectPage)}/scheduled`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ title, cadence: $('sc-cadence').value }),
  });
  scModal.classList.add('hidden'); $('sc-title').value = '';
  openProjectPage(currentProjectPage);
});
scModal.addEventListener('click', (e) => { if (e.target === scModal) scModal.classList.add('hidden'); });

// instructions modal
const instrModal = $('instructions-modal-backdrop');
$('edit-instructions-btn').addEventListener('click', () => {
  $('instr-text').value = $('instructions-body').dataset.value || '';
  instrModal.classList.remove('hidden');
  $('instr-text').focus();
});
$('instr-cancel').addEventListener('click', () => instrModal.classList.add('hidden'));
$('instr-save').addEventListener('click', async () => {
  const text = $('instr-text').value;
  if (!currentProjectPage) return;
  await fetch(`/api/projects/${encodeURIComponent(currentProjectPage)}/instructions`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ instructions: text }),
  });
  instrModal.classList.add('hidden');
  await openProjectPage(currentProjectPage);  // refresh
});
instrModal.addEventListener('click', (e) => { if (e.target === instrModal) instrModal.classList.add('hidden'); });

// =====================================================
// ⌘K Command palette
// =====================================================
const palette = $('palette-backdrop');
const paletteInput = $('palette-input');
const paletteList = $('palette-list');
let paletteCmds = [];
let paletteSel = 0;

function buildPaletteCommands() {
  const c = [];
  c.push({ label: 'New Chat', hint: 'chat', run: newChat });
  c.push({ label: 'Go to Projects', hint: 'view', run: () => switchView('projects') });
  c.push({ label: 'Go to Skills', hint: 'view', run: () => switchView('skills') });
  c.push({ label: 'Back to Chat', hint: 'view', run: () => switchView('chat') });
  c.push({ label: 'Take a tour', hint: 'help', run: () => startWalkthrough() });
  (state.all_projects || state.projects || []).forEach(p =>
    c.push({ label: `Open ${p.name}`, hint: 'project', run: () => useProject(p.name) }));
  models.forEach(m =>
    c.push({ label: `Model → ${m.name}`, hint: 'model', run: async () => {
      await API('/api/model', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ model: m.id }) });
      state.model = m.id; renderModel();
    }}));
  (state.skills || []).forEach(s =>
    c.push({ label: `${s.enabled ? 'Disable' : 'Enable'} skill: ${s.name}`, hint: 'skill', run: async () => {
      const r = await API(`/api/skills/${encodeURIComponent(s.id)}/toggle`, { method: 'POST' });
      const i = state.skills.findIndex(x => x.id === s.id); if (i >= 0) state.skills[i].enabled = r.enabled;
      renderSkillsPage(); renderSidebar();
    }}));
  c.push({ label: 'Open Settings', hint: 'view', run: () => switchView('settings') });
  c.push({ label: 'Toggle Appearance (Light / Dark)', hint: 'theme', run: () => themeToggle && themeToggle.click() });
  c.push({ label: 'Toggle Browser Automation', hint: 'browser', run: () => browserToggle.click() });
  c.push({ label: 'New Project', hint: 'create', run: openNewProjectModal });
  c.push({ label: 'Reset Conversation', hint: 'danger', run: resetConversation });
  if (state.hosted) c.push({ label: 'Sign Out', hint: 'account', run: async () => {
    await API('/api/auth/logout', { method: 'POST' }); location.reload();
  }});
  return c;
}

function renderPalette(filter = '') {
  const f = filter.toLowerCase();
  const items = paletteCmds.filter(c => c.label.toLowerCase().includes(f));
  paletteSel = Math.min(paletteSel, Math.max(0, items.length - 1));
  paletteList.innerHTML = '';
  if (!items.length) {
    paletteList.innerHTML = '<div class="palette-empty">No matching commands</div>';
    paletteList._items = [];
    return;
  }
  items.forEach((c, i) => {
    const el = document.createElement('div');
    el.className = 'palette-item' + (i === paletteSel ? ' sel' : '');
    el.innerHTML = `<span>${escape(c.label)}</span><span class="pi-hint">${escape(c.hint)}</span>`;
    el.addEventListener('click', () => { closePalette(); c.run(); });
    el.addEventListener('mousemove', () => { paletteSel = i; [...paletteList.children].forEach((x, j) => x.classList.toggle('sel', j === i)); });
    paletteList.appendChild(el);
  });
  paletteList._items = items;
}

function openPalette() {
  paletteCmds = buildPaletteCommands();
  paletteSel = 0;
  palette.classList.remove('hidden');
  paletteInput.value = '';
  renderPalette('');
  paletteInput.focus();
}
function closePalette() { palette.classList.add('hidden'); }

paletteInput.addEventListener('input', () => { paletteSel = 0; renderPalette(paletteInput.value); });
paletteInput.addEventListener('keydown', (e) => {
  const items = paletteList._items || [];
  if (e.key === 'ArrowDown') { e.preventDefault(); paletteSel = Math.min(paletteSel + 1, items.length - 1); renderPalette(paletteInput.value); }
  else if (e.key === 'ArrowUp') { e.preventDefault(); paletteSel = Math.max(paletteSel - 1, 0); renderPalette(paletteInput.value); }
  else if (e.key === 'Enter') { e.preventDefault(); if (items[paletteSel]) { closePalette(); items[paletteSel].run(); } }
  else if (e.key === 'Escape') { closePalette(); }
});
palette.addEventListener('click', (e) => { if (e.target === palette) closePalette(); });
document.addEventListener('keydown', (e) => {
  if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
    e.preventDefault();
    palette.classList.contains('hidden') ? openPalette() : closePalette();
  }
});

// =====================================================
// TASKS — school-platform assignments + automation
// =====================================================
let tasksState = { tasks: [], platform: null };
// Multi-select + filter state for the Tasks page.
//   primary: 'all' | 'assigned' | 'missing' | 'done'
//   deep:    sub-filter within Assigned/Missing (time buckets), 'all' = no sub-filter
//   group:   'due' | 'class' — only used in the 'all' sectioned view
let taskSel = { mode: false, ids: new Set(), group: 'due', primary: 'all', deep: 'all' };

async function loadTasks() {
  // Cloud web users see desktop-exclusive pitch on Tasks too
  if (state.hosted && !state.automation) {
    renderDesktopExclusive('tasks');
    return;
  }
  try {
    // Pull tasks + connector state together so the "connected" badge and the
    // empty-state CTA always reflect reality.
    const [t, c] = await Promise.all([
      API('/api/tasks'),
      API('/api/connectors').catch(() => null),
    ]);
    tasksState = t;
    if (c) connectorsState = c;
  } catch (e) {
    if (e && e.auth) { showAuth(); return; }
    tasksState = { tasks: [], platform: null };
  }
  renderTasksView();
}

function renderTasksView() {
  const body = $('tasks-body');
  const label = $('tasks-platform-label');
  const sync = $('tasks-sync');
  const disc = $('tasks-disconnect');
  const navCount = $('nav-task-count');
  if (!body) return;

  const open = tasksState.tasks.filter(t => !t.done);
  if (navCount) {
    navCount.textContent = open.length;
    navCount.style.display = open.length ? '' : 'none';
  }

  // The connector model is the source of truth — show whether a school account
  // is connected, was disconnected, or was never set up.
  const SCHOOL_SOURCES = ['google_classroom', 'canvas', 'schoology', 'powerschool', 'blackboard'];
  const conns = connectorsState.connectors || [];
  const connected = conns.filter(c => c.logged_in);
  const hasSchoolTasks = tasksState.tasks.some(t => SCHOOL_SOURCES.includes(t.source));
  // "Was disconnected" = not connected now, but there's a record that was once
  // connected (or school-synced tasks are still hanging around).
  const wasDisconnected = !connected.length &&
    (conns.some(c => !c.logged_in && (c.connected_at || c.disconnected_at)) || hasSchoolTasks);
  const discBanner = $('tasks-disc-banner');
  const hideBanner = () => { if (discBanner) discBanner.classList.add('hidden'); };

  if (connected.length) {
    label.innerHTML = connected.map(c =>
      `<span class="conn-pill"><span class="dot"></span>${escape(c.icon || '🔗')} ${escape(c.name || c.platform)}</span>`
    ).join('');
    sync.style.display = '';
    disc.style.display = 'none';   // disconnect is per-connector in Connectors
    hideBanner();
  } else if (wasDisconnected) {
    label.innerHTML = `<span class="conn-pill warn"><span class="dot"></span>School disconnected</span>`;
    sync.style.display = 'none';
    disc.style.display = 'none';
    if (discBanner) {
      discBanner.classList.remove('hidden');
      discBanner.innerHTML =
        `<span class="tdb-ico">🔌</span>` +
        `<span class="tdb-text"><strong>Your school system was disconnected.</strong> Your synced tasks are still here — reconnect to pull new assignments.</span>` +
        `<button class="tdb-btn" id="tdb-reconnect">Reconnect →</button>`;
      const rb = $('tdb-reconnect'); if (rb) rb.addEventListener('click', () => switchView('connectors'));
    }
  } else if (tasksState.platform) {
    const p = tasksState.platform;
    label.textContent = `${p.platform_name} · ${p.mode === 'desktop' ? 'desktop' : p.mode === 'cloud' ? 'cloud' : 'manual'}`;
    sync.style.display = p.mode !== 'manual' ? '' : 'none';
    disc.style.display = '';
    hideBanner();
  } else {
    label.innerHTML = `<span class="conn-pill muted"><span class="dot"></span>Not connected</span>`;
    sync.style.display = 'none';
    disc.style.display = 'none';
    hideBanner();
  }

  // ── Tasks-page controls: Select button + group selector visibility ──
  const hasTasks = tasksState.tasks.length > 0;
  const selToggle = $('tasks-select-toggle');
  const groupSel = $('tasks-group');
  const filtersEl = $('tasks-filters');
  if (selToggle) selToggle.style.display = hasTasks ? '' : 'none';
  if (groupSel) {  // group selector only matters in the "All" sectioned view
    groupSel.style.display = (hasTasks && taskSel.primary === 'all') ? '' : 'none';
    groupSel.value = taskSel.group;
  }
  if (!hasTasks && taskSel.mode) { taskSel.mode = false; taskSel.ids.clear(); }

  if (!tasksState.tasks.length) {
    if (filtersEl) { filtersEl.innerHTML = ''; filtersEl.style.display = 'none'; }
    body.classList.remove('select-mode');
    if (selToggle) selToggle.textContent = '☑ Select';
    // Tailor the empty state to the connection state (connected / disconnected
    // / never set up). `connected` and `wasDisconnected` are computed above.
    let title, sub;
    if (connected.length) {
      title = 'No assignments synced yet';
      sub = `You're connected — hit <strong>Sync now</strong> to pull your assignments in. You can also add a task by hand.`;
    } else if (wasDisconnected) {
      title = 'No tasks right now';
      sub = `Your school system is disconnected, so there's nothing new to show. <strong>Reconnect</strong> in Connectors to pull your assignments back.`;
    } else {
      title = 'Connect a school platform to get started';
      sub = `J@rv1s pulls every assignment from <strong>Google Classroom, Canvas, Schoology, PowerSchool</strong> &amp; more — so you stop checking six places a day.`;
    }
    body.innerHTML = `
      <div class="tasks-cta-card">
        <div class="tasks-cta-orb"></div>
        <h3 class="tasks-cta-title">${title}</h3>
        <p class="tasks-cta-sub">${sub}</p>
        <div class="tasks-cta-actions">
          <button class="tasks-cta-btn" id="empty-sync">↻ Sync now</button>
          <button class="tasks-cta-btn ghost" id="empty-connect-cta">Go to Connectors →</button>
        </div>
      </div>`;
    const es = $('empty-sync'); if (es) es.addEventListener('click', syncAllConnectors);
    const gc = $('empty-connect-cta'); if (gc) gc.addEventListener('click', () => switchView('connectors'));
    updateBulkBar();
    return;
  }

  // Prune selections that no longer exist (after a bulk op or re-sync).
  const liveIds = new Set(tasksState.tasks.map(t => t.id));
  [...taskSel.ids].forEach(id => { if (!liveIds.has(id)) taskSel.ids.delete(id); });

  body.classList.toggle('select-mode', taskSel.mode);
  if (selToggle) selToggle.textContent = taskSel.mode ? '✕ Cancel' : '☑ Select';
  if (filtersEl) { filtersEl.style.display = ''; renderTaskFilters(filtersEl); }

  body.innerHTML = '';
  if (taskSel.primary === 'all') {
    const sections = taskSel.group === 'class'
      ? groupTasksByClass(tasksState.tasks)
      : groupTasksByDue(tasksState.tasks);
    sections.forEach(sec => appendTaskSection(body, sec.label, sec.tasks, sec.key));
  } else if (taskSel.primary === 'missing' && taskSel.deep === 'all') {
    // Missing pile → grouped into subcategories by class.
    const missing = tasksState.tasks.filter(_isMissing);
    if (!missing.length) {
      body.innerHTML = `<div class="tasks-empty"><div class="empty-icon">🎉</div><h3>Nothing here</h3><p>No missing tasks.</p></div>`;
    } else {
      groupTasksByClass(missing).forEach(sec => appendTaskSection(body, sec.label, sec.tasks, sec.key));
    }
  } else {
    const list = filterTasks(taskSel.primary, taskSel.deep);
    if (!list.length) {
      body.innerHTML = `<div class="tasks-empty"><div class="empty-icon">🎉</div><h3>Nothing here</h3><p>No tasks match this filter.</p></div>`;
    } else {
      appendTaskSection(body, null, list, taskSel.primary);
    }
  }
  updateBulkBar();
}

// ── grouping / filtering helpers ──────────────────────────────────────
function _sortByDue(arr) {
  return arr.slice().sort((a, b) => {
    const x = a.due || '9999', y = b.due || '9999';
    return x < y ? -1 : x > y ? 1 : 0;
  });
}
function appendTaskSection(body, label, tasks, key) {
  if (!tasks.length) return;
  const wrap = document.createElement('div');
  wrap.className = 'task-section' + (key === 'missing' ? ' overdue' : '');
  if (label) {
    const head = document.createElement('div');
    head.className = 'task-section-head';
    head.innerHTML = `<span class="ts-label">${escape(label)}</span><span class="ts-count">${tasks.length}</span>`;
    wrap.appendChild(head);
  }
  const grid = document.createElement('div'); grid.className = 'task-grid';
  tasks.forEach(t => grid.appendChild(renderTaskCard(t)));
  wrap.appendChild(grid);
  body.appendChild(wrap);
}
// Missing vs Assigned: trust the platform tab origin (t.status) when present —
// it's authoritative. Fall back to due-date derivation for manual/legacy tasks.
function _isMissing(t) {
  if (t.done) return false;
  if (t.status === 'missing') return true;
  if (t.status === 'assigned') return false;
  return !!t.due && daysUntil(t.due) < 0;
}
function _isAssigned(t) { return !t.done && !_isMissing(t); }
function filterTasks(primary, deep) {
  let list = tasksState.tasks;
  if (primary === 'done') return _sortByDue(list.filter(t => t.done));
  if (primary === 'assigned') {
    list = list.filter(_isAssigned);
    if (deep !== 'all') list = list.filter(t => _matchAssignedDeep(t, deep));
  } else if (primary === 'missing') {
    list = list.filter(_isMissing);
    if (deep && deep.indexOf('class:') === 0) {
      const subj = deep.slice(6);
      list = list.filter(t => (t.subject || 'No class') === subj);
    }
  }
  return _sortByDue(list);
}
function _matchAssignedDeep(t, deep) {
  if (deep === 'nodue') return !t.due;
  if (!t.due) return false;
  const d = daysUntil(t.due);
  return ({ today: d === 0, tomorrow: d === 1, week: d >= 0 && d <= 7,
            nextweek: d >= 8 && d <= 14, later: d > 14 })[deep] || false;
}
function _matchMissingDeep(t, deep) {
  const d = t.due ? daysUntil(t.due) : null;   // negative = days overdue
  if (d !== null && d < 0) {
    return ({ yesterday: d === -1, last3: d >= -3, last7: d >= -7,
              '3to7': d >= -7 && d <= -3, older: d < -7 })[deep] || false;
  }
  // Undated, or a due date that isn't actually overdue (e.g. a stale bad year
  // before re-sync) — never drop it; bucket under "Older" so it stays findable.
  return deep === 'older';
}
function groupTasksByDue(tasks) {
  const b = { missing: [], today: [], tomorrow: [], week: [], nextweek: [], later: [], nodue: [], done: [] };
  tasks.forEach(t => {
    if (t.done) return b.done.push(t);
    if (_isMissing(t)) return b.missing.push(t);   // tab-tagged or overdue
    if (!t.due) return b.nodue.push(t);
    const d = daysUntil(t.due);
    if (d < 0) b.missing.push(t);
    else if (d === 0) b.today.push(t);
    else if (d === 1) b.tomorrow.push(t);
    else if (d <= 7) b.week.push(t);
    else if (d <= 14) b.nextweek.push(t);
    else b.later.push(t);
  });
  return [
    { key: 'missing',  label: '🔴 Missing',     tasks: _sortByDue(b.missing) },
    { key: 'today',    label: '📅 Today',        tasks: _sortByDue(b.today) },
    { key: 'tomorrow', label: '⏭️ Tomorrow',     tasks: _sortByDue(b.tomorrow) },
    { key: 'week',     label: '🗓️ This Week',    tasks: _sortByDue(b.week) },
    { key: 'nextweek', label: '📆 Next Week',    tasks: _sortByDue(b.nextweek) },
    { key: 'later',    label: '🕓 Later',        tasks: _sortByDue(b.later) },
    { key: 'nodue',    label: '♾️ No due date',  tasks: _sortByDue(b.nodue) },
    { key: 'done',     label: '✅ Completed',     tasks: _sortByDue(b.done) },
  ];
}
function groupTasksByClass(tasks) {
  const map = {};
  tasks.forEach(t => { const k = t.subject || 'No class'; (map[k] = map[k] || []).push(t); });
  return Object.keys(map).sort((a, b) => a.localeCompare(b)).map(k => ({
    key: 'class:' + k, label: '📚 ' + k, tasks: _sortByDue(map[k]),
  }));
}

// ── filter pills: primary (Assigned/Missing/Done) + deep time buckets ───
function renderTaskFilters(el) {
  const tasks = tasksState.tasks;
  const primaries = [
    { key: 'all',      label: 'All',          count: tasks.length },
    { key: 'assigned', label: '📘 Assigned',  count: tasks.filter(_isAssigned).length },
    { key: 'missing',  label: '🔴 Missing',   count: tasks.filter(_isMissing).length },
    { key: 'done',     label: '✅ Completed', count: tasks.filter(t => t.done).length },
  ];
  let html = `<div class="filter-row">` + primaries.map(p =>
    `<button class="filter-pill ${taskSel.primary === p.key ? 'active' : ''}" data-pf="${p.key}">${p.label}<span class="fp-count">${p.count}</span></button>`
  ).join('') + `</div>`;

  let deeps = null;
  if (taskSel.primary === 'assigned') {
    deeps = [['all','All'],['today','Today'],['tomorrow','Tomorrow'],['week','This week'],['nextweek','Next week'],['later','Later'],['nodue','No date']];
  } else if (taskSel.primary === 'missing') {
    // Subcategories by class — date buckets didn't fit missing work, which is mostly old.
    const missing = tasks.filter(_isMissing);
    const subs = [...new Set(missing.map(t => t.subject || 'No class'))].sort((a, b) => a.localeCompare(b));
    deeps = [['all', 'All'], ...subs.map(s => ['class:' + s, s])];
  }
  if (deeps) {
    html += `<div class="filter-row deep">` + deeps.map(([k, l]) => {
      const cnt = k === 'all' ? null : filterTasks(taskSel.primary, k).length;
      return `<button class="filter-pill sub ${taskSel.deep === k ? 'active' : ''}" data-df="${k}">${l}${cnt !== null ? `<span class="fp-count">${cnt}</span>` : ''}</button>`;
    }).join('') + `</div>`;
  }
  el.innerHTML = html;
  el.querySelectorAll('[data-pf]').forEach(b => b.addEventListener('click', () => { taskSel.primary = b.dataset.pf; taskSel.deep = 'all'; renderTasksView(); }));
  el.querySelectorAll('[data-df]').forEach(b => b.addEventListener('click', () => { taskSel.deep = b.dataset.df; renderTasksView(); }));
}

// ── select mode + bulk actions ─────────────────────────────────────────
function updateBulkBar() {
  const bar = $('tasks-bulkbar'); if (!bar) return;
  bar.classList.toggle('hidden', !taskSel.mode);
  const n = taskSel.ids.size;
  const cnt = $('bulk-count'); if (cnt) cnt.textContent = `${n} selected`;
  ['bulk-complete', 'bulk-delete'].forEach(id => { const b = $(id); if (b) b.disabled = !n; });
}
function toggleSelectMode() { taskSel.mode = !taskSel.mode; taskSel.ids.clear(); renderTasksView(); }
async function bulkTaskAction(action) {
  const ids = [...taskSel.ids];
  if ((action === 'delete' || action === 'complete') && !ids.length) { toast('Select some tasks first.', 'info'); return; }
  if (action === 'delete' && !confirm(`Delete ${ids.length} selected task${ids.length > 1 ? 's' : ''}?`)) return;
  if (action === 'delete_all' && !confirm('Delete ALL tasks? This cannot be undone.')) return;
  try {
    const r = await API('/api/tasks/bulk', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action, ids }),
    });
    if (r.ok) {
      if (r.tasks) tasksState.tasks = r.tasks;
      taskSel.ids.clear();
      const verb = action === 'complete' ? 'Completed' : 'Deleted';
      toast(`${verb} ${r.count} task${r.count !== 1 ? 's' : ''}.`, 'success');
      renderTasksView();
    } else { toast(r.error || 'Bulk action failed.', 'error'); }
  } catch (e) { toast((e && e.error) || 'Bulk action failed.', 'error'); }
}

// Subject → color chip. Languages are matched first (more specific than core).
function subjectColorClass(subject) {
  const s = (subject || '').toLowerCase();
  if (!s) return 'subj-gray';
  if (/spanish|españ|espan/.test(s)) return 'subj-purple';
  if (/chinese|mandarin/.test(s)) return 'subj-red';
  if (/french|frança|franca/.test(s)) return 'subj-blue';
  if (/latin/.test(s)) return 'subj-orange';
  if (/math|algebra|geometry|calc|precalc|trig|statistic/.test(s)) return 'subj-blue';
  if (/scien|physic|chem|biolog|\bbio\b|anatomy|environ/.test(s)) return 'subj-green';
  if (/histor|social studies|civic|government|\bgov\b|econ/.test(s)) return 'subj-orange';
  if (/english|literatur|\blit\b|writing|language arts|\bela\b|humanities|composition/.test(s)) return 'subj-yellow';
  return 'subj-gray';
}

function renderTaskCard(t) {
  const card = document.createElement('div');
  card.className = 'task-card' + (t.done ? ' done' : '') + (taskSel.ids.has(t.id) ? ' selected' : '');
  card.dataset.id = t.id;
  const du = t.due ? daysUntil(t.due) : null;
  const dueCls = du === null ? '' : (du < 0 ? 'overdue' : du <= 1 ? 'urgent' : du <= 3 ? 'soon' : '');
  const dueLabel = t.due ? (du < 0 ? `${-du}d overdue` : du === 0 ? 'Due today' : du === 1 ? 'Due tomorrow' : `Due ${fmtMonthDay(t.due)}`) : '';
  card.innerHTML = `
    <div class="task-check"><input type="checkbox" tabindex="-1" ${taskSel.ids.has(t.id) ? 'checked' : ''}></div>
    <div class="task-head">
      ${t.subject ? `<span class="task-subject ${subjectColorClass(t.subject)}">${escape(t.subject)}</span>` : ''}
      ${dueLabel ? `<span class="task-due ${dueCls}">${escape(dueLabel)}</span>` : ''}
    </div>
    <div class="task-title">${escape(t.title)}</div>
    ${t.description ? `<div class="task-desc">${escape(t.description.slice(0, 180))}${t.description.length > 180 ? '…' : ''}</div>` : ''}
    <div class="task-actions">
      ${t.link ? `<a href="${escape(t.link)}" target="_blank" rel="noopener">Open ↗</a>` : ''}
      <button data-act="help">💬 Help me</button>
      <button class="do-it" data-act="run">⚡ Autopilot</button>
      <button data-act="toggle" class="task-done-check">${t.done ? '↺' : '✓'}</button>
      <button data-act="del" title="Delete">🗑</button>
    </div>`;

  // selection — only meaningful in select mode (checkbox shown via CSS)
  const cb = card.querySelector('.task-check input');
  const toggleSel = () => {
    if (taskSel.ids.has(t.id)) taskSel.ids.delete(t.id); else taskSel.ids.add(t.id);
    const on = taskSel.ids.has(t.id);
    card.classList.toggle('selected', on);
    if (cb) cb.checked = on;
    updateBulkBar();
  };
  if (cb) cb.addEventListener('click', (e) => { e.stopPropagation(); toggleSel(); });
  card.addEventListener('click', (e) => {
    if (!taskSel.mode) return;
    if (e.target.closest('a, button')) return;
    toggleSel();
  });

  card.querySelector('[data-act="help"]').addEventListener('click', () => helpWithTask(t));
  card.querySelector('[data-act="run"]').addEventListener('click', () => showRunTaskModal(t));
  card.querySelector('[data-act="toggle"]').addEventListener('click', async () => {
    await API(`/api/tasks/${t.id}`, {
      method: 'PUT', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ done: !t.done }),
    });
    loadTasks();
  });
  card.querySelector('[data-act="del"]').addEventListener('click', async () => {
    if (!confirm(`Delete "${t.title}"?`)) return;
    await API(`/api/tasks/${t.id}`, { method: 'DELETE' });
    toast('Task deleted.', 'info');
    loadTasks();
  });
  return card;
}

function daysUntil(yyyymmdd) {
  try {
    // Compare local calendar days (strip time) so "today"/"tomorrow" are exact.
    const parts = String(yyyymmdd).split('-').map(Number);
    const due = new Date(parts[0], (parts[1] || 1) - 1, parts[2] || 1);
    const now = new Date(); now.setHours(0, 0, 0, 0);
    return Math.round((due - now) / 86400000);
  } catch { return 999; }
}

// Short, friendly due date — month + day only, no year. "2027-04-08" → "Apr 8"
function fmtMonthDay(yyyymmdd) {
  try {
    const parts = String(yyyymmdd).split('-').map(Number);
    if (!parts[0]) return String(yyyymmdd || '');
    const d = new Date(parts[0], (parts[1] || 1) - 1, parts[2] || 1);
    if (isNaN(d)) return String(yyyymmdd);
    return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
  } catch { return String(yyyymmdd || ''); }
}

function helpWithTask(t) {
  const seed = `Help me with this assignment:\n\n**${t.title}**${t.subject ? ` (${t.subject})` : ''}${t.due ? `\nDue: ${t.due}` : ''}${t.description ? `\n\n${t.description}` : ''}${t.link ? `\n\nLink: ${t.link}` : ''}`;
  switchView('chat');
  setTimeout(() => { input.value = seed; autosize(); send(); }, 100);
}

async function triggerSync() {
  const r = await API('/api/tasks/sync', { method: 'POST' });
  if (r.action === 'open_desktop_app') {
    toast('Open the J@rv1s desktop app to sync — your school session lives on your Mac.', 'error', 7000);
  } else if (r.queued) {
    toast('Cloud sync started — check back in a minute for new tasks.', 'sync');
  } else if (r.message) {
    toast(r.message, 'info');
  }
  loadTasks();
}

// Sync every connected school connector (the connector model is the source of
// truth; the legacy single-platform sync above is kept for old accounts).
async function syncAllConnectors() {
  let conns = (connectorsState.connectors || []).filter(c => c.logged_in);
  if (!conns.length) {
    try { connectorsState = await API('/api/connectors'); } catch (e) {}
    conns = (connectorsState.connectors || []).filter(c => c.logged_in);
  }
  if (!conns.length) {
    toast('No school account connected yet — connect one first.', 'info');
    switchView('connectors');
    return;
  }
  toast(`Syncing ${conns.length} connector${conns.length > 1 ? 's' : ''}… a Chrome window will open.`, 'sync', 9000);
  let found = 0, added = 0, failed = 0;
  for (const c of conns) {
    if (busyConnectors.has(c.platform)) continue;
    busyConnectors.add(c.platform);
    try {
      const r = await API('/api/connectors/' + c.platform + '/sync', { method: 'POST' });
      if (r.ok) { found += r.found || 0; added += r.added || 0; }
      else { failed++; if (r.error) toast(`${c.name || c.platform}: ${r.error}`, 'error', 7000); }
    } catch (e) { failed++; }
    finally { busyConnectors.delete(c.platform); }
  }
  if (found || !failed) toast(`Synced ✓  ${found} found · ${added} new`, 'success');
  loadTasks();
}

$('tasks-sync') && $('tasks-sync').addEventListener('click', syncAllConnectors);
$('tasks-disconnect') && $('tasks-disconnect').addEventListener('click', async () => {
  if (!confirm('Disconnect from your school platform? Your tasks stay.')) return;
  await API('/api/school/platform', { method: 'DELETE' });
  loadTasks();
});

// Select mode + grouping + bulk actions (one-time listeners)
$('tasks-select-toggle') && $('tasks-select-toggle').addEventListener('click', toggleSelectMode);
$('tasks-group') && $('tasks-group').addEventListener('change', (e) => { taskSel.group = e.target.value; renderTasksView(); });
$('bulk-selectall') && $('bulk-selectall').addEventListener('click', () => {
  // Select everything currently visible under the active filter.
  const visible = taskSel.primary === 'all' ? tasksState.tasks : filterTasks(taskSel.primary, taskSel.deep);
  const allSel = visible.length && visible.every(t => taskSel.ids.has(t.id));
  if (allSel) visible.forEach(t => taskSel.ids.delete(t.id));   // toggle: deselect all
  else visible.forEach(t => taskSel.ids.add(t.id));
  renderTasksView();
});
$('bulk-complete') && $('bulk-complete').addEventListener('click', () => bulkTaskAction('complete'));
$('bulk-delete') && $('bulk-delete').addEventListener('click', () => bulkTaskAction('delete'));
$('bulk-deleteall') && $('bulk-deleteall').addEventListener('click', () => bulkTaskAction('delete_all'));
$('bulk-cancel') && $('bulk-cancel').addEventListener('click', toggleSelectMode);

// ── Add task modal ─────────────────────────────────────────────────────────
const taskModal = $('task-modal-backdrop');
$('tasks-add') && $('tasks-add').addEventListener('click', () => {
  taskModal.classList.remove('hidden');
  $('task-title').focus();
});
$('task-cancel') && $('task-cancel').addEventListener('click', closeAddTask);
function closeAddTask() {
  taskModal.classList.add('hidden');
  ['task-title','task-subject','task-due','task-link','task-desc'].forEach(id => $(id).value = '');
}
$('task-create') && $('task-create').addEventListener('click', async () => {
  const body = {
    title: $('task-title').value.trim(),
    subject: $('task-subject').value.trim(),
    due: $('task-due').value,
    link: $('task-link').value.trim(),
    description: $('task-desc').value.trim(),
  };
  if (!body.title) { alert('Title is required.'); return; }
  await API('/api/tasks', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  closeAddTask();
  loadTasks();
});
taskModal && taskModal.addEventListener('click', (e) => { if (e.target === taskModal) closeAddTask(); });

// ── "Do it for me" run modal ───────────────────────────────────────────────
const taskRunModal = $('task-run-backdrop');
let runningTask = null;
function showRunTaskModal(t) {
  runningTask = t;
  $('task-run-desc').textContent = `Autopilot will read + write: ${t.title}`;
  const instr = $('task-run-instructions'); if (instr) instr.value = '';
  _setRunMode('answers');                 // default to the safe option every time
  taskRunModal.classList.remove('hidden');
}
$('task-run-cancel') && $('task-run-cancel').addEventListener('click', () => taskRunModal.classList.add('hidden'));
// The two mode cards are a SELECTION now — nothing runs until "Engage".
let runMode = 'answers';
function _setRunMode(m) {
  runMode = m;
  if (!taskRunModal) return;
  taskRunModal.querySelectorAll('.run-mode-btn').forEach(b => b.classList.toggle('selected', b.dataset.mode === m));
  const cb = $('task-run-confirm');
  if (cb) {
    cb.textContent = m === 'submit' ? '📤 Engage & Turn in' : '⚡ Engage';
    cb.classList.toggle('warn', m === 'submit');
  }
}
taskRunModal && taskRunModal.querySelectorAll('.run-mode-btn').forEach(b =>
  b.addEventListener('click', () => _setRunMode(b.dataset.mode)));
$('task-run-confirm') && $('task-run-confirm').addEventListener('click', () => {
  const task = runningTask;
  if (!task) return;
  const instructions = ($('task-run-instructions')?.value || '').trim();
  // Turn-in submits for real — deliberate confirm, with the beta warning.
  if (runMode === 'submit' &&
      !confirm(`⚠️ Autopilot is in BETA and makes mistakes — turning work in without reviewing it is risky and NOT recommended.\n\nThis will write AND turn in this assignment to your teacher, for real. Continue anyway?`)) return;
  taskRunModal.classList.add('hidden');
  runAutopilotBatch([task], runMode, instructions);   // unified runner (live status + Stop bar)
});
taskRunModal && taskRunModal.addEventListener('click', (e) => { if (e.target === taskRunModal) taskRunModal.classList.add('hidden'); });

/* ════════════════════════════════════════════════════════════════════
   /autopilot — slash command → pick one or many tasks → run them
   ════════════════════════════════════════════════════════════════════ */

// Shared result formatter (used by the single-run modal flow + batch runner).
function formatAutopilotResult(r, task, submitting) {
  if (r.ok && r.answer) {
    let submitLine = '';
    if (submitting) {
      if (r.turned_in) submitLine = `\n\n## ✅ Turned in.\n`;
      else if (r.submit_state === 'cancelled') submitLine = `\n\n## ⏹ Stopped — **NOT submitted to your teacher**. Review the draft below.\n`;
      else if (r.submit_state === 'submitted_unverified') submitLine = `\n\n## 📤 Clicked Turn in — couldn't 100% confirm. Open Classroom to double-check.\n`;
      else submitLine = `\n\n## ⚠️ Couldn't turn it in${r.error ? ': ' + escape(r.error) : ''}.\nThe answer is in your Doc — turn it in manually.\n`;
    }
    let header;
    if (r.wrote_to_doc) {
      const cta = r.turned_in ? '' : (submitting ? ' — review it' : ' — review it, then click **Turn in** in Classroom');
      header = `### ✅ Autopilot wrote your answer into the Doc${submitLine}\n\n` +
        (r.doc_url ? `**[Open your Doc →](${r.doc_url})**${cta}.\n\n---\n\n` : '') +
        `Here's what it wrote:\n\n`;
    } else if ((r.doc_ids || []).length) {
      header = `### ✍️ Autopilot — answer ready${submitLine}\n\n_(Couldn't confirm the Doc save${r.error ? ': ' + escape(r.error) : ''} — paste it in yourself if needed.)_\n\n`;
    } else {
      header = `### ✍️ Autopilot — answer ready${submitLine}\n\n_No attached Doc on this one — copy the answer into your portal._\n\n`;
    }
    const stats = `\n\n---\n_Read ${r.instructions_chars || 0} chars from the page` +
      ((r.doc_chars || 0) ? ` + ${r.doc_chars} from the attached Doc` : '') + `._`;
    return header + r.answer + stats;
  }
  return `### ⚠️ Autopilot couldn't finish\n\n${r.error || 'Unknown error.'}\n\n` +
    `Try opening the assignment manually and pasting the instructions into chat instead.`;
}

// Floating emergency-stop bar, shown only while Autopilot is running.
let autopilotStop = false;
let apStopBar = null;
function showAutopilotStop() {
  if (!apStopBar) {
    apStopBar = document.createElement('div');
    apStopBar.className = 'ap-stopbar';
    apStopBar.innerHTML =
      '<span class="ap-stop-dot"></span>' +
      '<span class="ap-stop-label">Autopilot running…</span>' +
      '<button class="ap-stop-btn" type="button">⏹ Stop</button>';
    document.body.appendChild(apStopBar);
    apStopBar.querySelector('.ap-stop-btn').addEventListener('click', async () => {
      autopilotStop = true;                        // halt the queue (between tasks)
      const btn = apStopBar.querySelector('.ap-stop-btn');
      btn.disabled = true; btn.textContent = 'Stopping…';
      apStopBar.querySelector('.ap-stop-label').textContent = 'Stopping — it won’t turn in';
      try { await API('/api/autopilot/stop', { method: 'POST' }); } catch (_) {}   // halt the in-flight run (skips write + turn-in)
      toast('🛑 Stop registered — Autopilot will NOT turn in.', 'success', 6000);
      // The current step (e.g. the answer call) can't be killed mid-flight, so
      // don't let the bar look frozen — it has already stopped writing/turning in.
      setTimeout(() => { if (autopilotStop) hideAutopilotStop(); }, 6000);
    });
  }
  autopilotStop = false;
  const btn = apStopBar.querySelector('.ap-stop-btn');
  btn.disabled = false; btn.textContent = '⏹ Stop';
  apStopBar.querySelector('.ap-stop-label').textContent = 'Autopilot running…';
  apStopBar.classList.add('show');
}
function hideAutopilotStop() { if (apStopBar) apStopBar.classList.remove('show'); }

// Run a list of tasks through Autopilot, one after another (they share one
// browser profile, so they must be serial). Live status streams into chat.
async function runAutopilotBatch(tasks, choice, instructions) {
  const submitting = choice === 'submit';
  switchView('chat');
  clearChat();
  appendMessage('user',
    `⚡ Autopilot${submitting ? ' + Turn in' : ''} — ${tasks.length} task${tasks.length > 1 ? 's' : ''}` +
    (instructions ? `\n\n_Instructions: ${instructions}_` : '') + '\n\n' +
    tasks.map((t, i) => `${i + 1}. **${escape(t.title || 'Untitled')}**${t.subject ? ' — ' + escape(t.subject) : ''}`).join('\n'));

  showAutopilotStop();
  let done = 0, stoppedAt = -1;
  try {
    for (let i = 0; i < tasks.length; i++) {
      if (autopilotStop) { stoppedAt = i; break; }     // user hit Stop — halt the queue
      const task = tasks[i];
      const statusEl = appendMessage('assistant',
        `🛸 **Autopilot ${i + 1}/${tasks.length} — ${escape(task.title || 'task')}**\n\n` +
        `🌐 Opening Chrome · 📄 Reading · ✍️ Writing${submitting ? ' · 📤 Turning in' : ''}…\n\n_(30–90 sec — ⏹ Stop is bottom-right)_`);
      try {
        const r = await API(`/api/tasks/${task.id}/run`, {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ choice, instructions }),
        });
        if (r.action === 'open_desktop_app') {
          statusEl.innerHTML = marked.parse(
            `### ⚡ Autopilot is desktop-only\n\n${r.error || 'Autopilot needs your real Chrome locally.'}` +
            `\n\n**[Download the desktop app →](https://projectjarvis.app/download)**`);
          break;   // cloud mode — no point continuing
        }
        statusEl.innerHTML = marked.parse(formatAutopilotResult(r, task, submitting));
        statusEl.querySelectorAll('pre code').forEach(b => hljs.highlightElement(b));
        if (r.ok && r.answer) done++;
        if (r.turned_in) { try { loadTasks(); } catch (e) {} }
      } catch (e) {
        statusEl.innerHTML = marked.parse(
          `❌ **${escape(task.title || 'task')}** — Autopilot failed: ${(e && e.error) || e.message || JSON.stringify(e)}`);
      }
    }
    if (stoppedAt >= 0)
      appendMessage('assistant', `### ⏹ Autopilot stopped — ${done} done, ${tasks.length - stoppedAt} skipped. Nothing was turned in after Stop.`);
    else
      appendMessage('assistant', `### 🏁 Autopilot batch done — ${done}/${tasks.length} completed.`);
  } finally {
    hideAutopilotStop();
  }
}

// ── Autopilot Dashboard ─────────────────────────────────────────────────
let apRuns = [];
async function loadAutopilotDashboard() {
  const dash = $('ap-dash');
  if (!dash) return;
  dash.innerHTML = '<div class="ap-dash-empty"><p>Loading…</p></div>';
  try { apRuns = (await API('/api/autopilot/history')).runs || []; }
  catch (e) { apRuns = []; }
  renderApDashboard();
}
function _apOutcome(run) {
  if (run.submit_state === 'cancelled') return { cls: 'stopped', label: '⏹ Stopped' };
  if (!run.ok) return { cls: 'failed', label: '⚠️ Failed' };
  if (run.turned_in) return { cls: 'turnedin', label: '✅ Turned in' };
  if (run.wrote_to_doc) return { cls: 'wrote', label: '✍️ Written' };
  return { cls: 'done', label: '✓ Done' };
}
function _apWhen(ts) {
  if (!ts) return '';
  try { return new Date(ts * 1000).toLocaleString(undefined, { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }); }
  catch (_) { return ''; }
}
function renderApDashboard() {
  const dash = $('ap-dash');
  if (!dash) return;
  if (!apRuns.length) {
    dash.innerHTML = `<div class="ap-dash-empty"><div class="ap-empty-ico">🛸</div>
      <h3>No Autopilot runs yet</h3>
      <p>Run Autopilot on an assignment (try <strong>/autopilot</strong> in chat) — every run is logged here with a full report.</p></div>`;
    return;
  }
  dash.innerHTML = `<div class="ap-grid">` + apRuns.map(run => {
    const o = _apOutcome(run);
    return `<button class="ap-card" data-id="${run.id}">
      <div class="ap-card-top">
        <span class="task-subject ${subjectColorClass(run.subject)}">${escape(run.subject || 'No class')}</span>
        <span class="ap-badge ${o.cls}">${o.label}</span>
      </div>
      <div class="ap-card-title">${escape(run.title || 'Untitled assignment')}</div>
      <div class="ap-card-meta">${run.mode === 'submit' ? '📤 Write & turn in' : '✍️ Write'} · ${_apWhen(run.ts)}</div>
    </button>`;
  }).join('') + `</div>`;
  dash.querySelectorAll('.ap-card').forEach(c => c.addEventListener('click', () => {
    const run = apRuns.find(r => r.id === c.dataset.id);
    if (run) renderApDetail(run);
  }));
}
function renderApDetail(run) {
  const dash = $('ap-dash');
  if (!dash) return;
  const o = _apOutcome(run);
  dash.innerHTML = `
    <button class="ap-back" id="ap-back">← All Autopilot runs</button>
    <div class="ap-report">
      <div class="ap-report-head">
        <span class="task-subject ${subjectColorClass(run.subject)}">${escape(run.subject || 'No class')}</span>
        <span class="ap-badge ${o.cls}">${o.label}</span>
      </div>
      <h2 class="ap-report-title">${escape(run.title || 'Untitled assignment')}</h2>
      <div class="ap-report-meta">${run.mode === 'submit' ? '📤 Write &amp; turn in' : '✍️ Write the answer'} · ${_apWhen(run.ts)}${run.instructions ? ` · “${escape(run.instructions)}”` : ''}</div>
      <div class="ap-report-actions">
        <button class="primary-btn" id="ap-explain">🎓 Explain in Tutor Mode</button>
        <button class="ghost-btn" id="ap-ask">💬 Ask about this</button>
        ${run.doc_url ? `<a class="ghost-btn" href="${run.doc_url}" target="_blank" rel="noopener">📄 Open Doc</a>` : ''}
        <button class="ghost-btn" id="ap-rerun">↻ Re-run</button>
      </div>
      ${run.error ? `<div class="ap-report-err">⚠️ ${escape(run.error)}</div>` : ''}
      <div class="ap-report-label">What Autopilot wrote</div>
      <div class="ap-report-answer markdown" id="ap-answer"></div>
    </div>`;
  const ansEl = $('ap-answer');
  if (ansEl) {
    ansEl.innerHTML = run.answer ? marked.parse(run.answer) : '<em class="ap-noans">No answer was captured for this run.</em>';
    ansEl.querySelectorAll('pre code').forEach(b => hljs.highlightElement(b));
  }
  $('ap-back').addEventListener('click', renderApDashboard);
  $('ap-explain') && $('ap-explain').addEventListener('click', () => _apExplain(run, true));
  $('ap-ask') && $('ap-ask').addEventListener('click', () => _apExplain(run, false));
  $('ap-rerun') && $('ap-rerun').addEventListener('click', () => {
    const task = (tasksState.tasks || []).find(t => t.id === run.task_id) ||
      { id: run.task_id, title: run.title, subject: run.subject, link: run.link };
    runAutopilotBatch([task], 'answers', run.instructions || '');
  });
}
function _apExplain(run, tutor) {
  switchView('chat');
  const a = run.answer || '(no answer was captured)';
  const seed = tutor
    ? `Tutor mode: teach me the assignment "${run.title}"${run.subject ? ` (${run.subject})` : ''} that Autopilot did for me. Walk me through how it was approached, the key concepts behind it, and WHY the answer is built this way — so I actually understand it and could do it myself. Don't just restate it; quiz me a little.\n\nHere's what Autopilot wrote:\n\n${a}`
    : `This is the assignment "${run.title}"${run.subject ? ` (${run.subject})` : ''} that Autopilot did. Here's what it wrote:\n\n${a}\n\nI want to ask you about it.`;
  setTimeout(() => { input.value = seed; autosize(); send(); }, 120);
}
$('ap-dash-refresh') && $('ap-dash-refresh').addEventListener('click', loadAutopilotDashboard);

// ── The task picker (the "database of tasks" with multi-select) ──────────
let apPickerEl = null;
let apSel = new Set();
function buildAutopilotPicker(tasks) {
  apSel = new Set();
  if (!apPickerEl) {
    apPickerEl = document.createElement('div');
    apPickerEl.className = 'ap-backdrop hidden';
    document.body.appendChild(apPickerEl);
    apPickerEl.addEventListener('click', (e) => { if (e.target === apPickerEl) apPickerEl.classList.add('hidden'); });
  }
  const rows = tasks.map(t => {
    const due = t.due ? `Due ${fmtMonthDay(t.due)}` : 'No due date';
    const src = (t.source || '').replace(/_/g, ' ');
    return `<label class="ap-row" data-id="${t.id}">
        <input type="checkbox" class="ap-cb" data-id="${t.id}">
        <span class="ap-row-main">
          <span class="ap-row-title">${escape(t.title || 'Untitled')}</span>
          <span class="ap-row-meta">${t.subject ? escape(t.subject) + ' · ' : ''}${escape(due)}${src ? ' · ' + escape(src) : ''}</span>
        </span>
      </label>`;
  }).join('');
  apPickerEl.innerHTML = `
    <div class="ap-modal">
      <div class="ap-head">
        <div>
          <div class="ap-title">⚡ Autopilot</div>
          <div class="ap-sub">Pick one or more tasks — J@rv1s reads &amp; writes each one for you.</div>
        </div>
        <button class="ap-x" title="Close">✕</button>
      </div>
      <div class="ap-warn">
        <span class="ap-warn-ico">⚠️</span>
        <span><strong>Autopilot is in beta and can be risky.</strong> It makes mistakes — we don't recommend the “Write &amp; turn in” option, and you should <strong>always look over the work yourself</strong> before it's used or submitted.</span>
      </div>
      ${tasks.length ? `
      <div class="ap-tools">
        <button class="ap-selall ghost-btn">Select all</button>
        <span class="ap-count">0 selected</span>
      </div>
      <div class="ap-list">${rows}</div>
      <div class="ap-mode">
        <button class="ap-mode-btn active" data-mode="answers">✍️ Just write</button>
        <button class="ap-mode-btn" data-mode="submit">📤 Write &amp; turn in</button>
      </div>
      <textarea class="ap-instr" rows="2" placeholder="Optional instructions for all selected (e.g. keep it concise, show your work)…"></textarea>
      <div class="ap-actions">
        <button class="primary-btn ap-submit" disabled>⚡ Run Autopilot</button>
      </div>` : `
      <div class="ap-empty">
        <div class="ap-empty-ico">📭</div>
        <p>No open tasks yet. Connect a school system and sync to pull in your assignments.</p>
        <button class="primary-btn ap-goconn">Go to Connectors</button>
      </div>`}
    </div>`;

  apPickerEl.querySelector('.ap-x').addEventListener('click', () => apPickerEl.classList.add('hidden'));
  const goconn = apPickerEl.querySelector('.ap-goconn');
  if (goconn) goconn.addEventListener('click', () => { apPickerEl.classList.add('hidden'); switchView('connectors'); });

  const countEl = apPickerEl.querySelector('.ap-count');
  const submitBtn = apPickerEl.querySelector('.ap-submit');
  const modeBtns = [...apPickerEl.querySelectorAll('.ap-mode-btn')];
  const selall = apPickerEl.querySelector('.ap-selall');
  let apMode = 'answers';                       // 'answers' = just write (default, safe)

  const syncSubmit = () => {
    if (!submitBtn) return;
    submitBtn.disabled = apSel.size === 0;
    const turnin = apMode === 'submit';
    const n = apSel.size ? ` (${apSel.size})` : '';
    submitBtn.textContent = turnin ? `📤 Run & Turn in${n}` : `⚡ Run Autopilot${n}`;
    submitBtn.classList.toggle('warn', turnin);
  };
  const refresh = () => {
    if (countEl) countEl.textContent = `${apSel.size} selected`;
    apPickerEl.querySelectorAll('.ap-row').forEach(r => r.classList.toggle('on', apSel.has(r.dataset.id)));
    if (selall) selall.textContent = (apSel.size === tasks.length && tasks.length) ? 'Clear all' : 'Select all';
    syncSubmit();
  };
  modeBtns.forEach(b => b.addEventListener('click', () => {
    apMode = b.dataset.mode;
    modeBtns.forEach(x => x.classList.toggle('active', x === b));
    syncSubmit();
  }));
  apPickerEl.querySelectorAll('.ap-cb').forEach(cb => {
    cb.addEventListener('change', () => {
      if (cb.checked) apSel.add(cb.dataset.id); else apSel.delete(cb.dataset.id);
      refresh();
    });
  });
  if (selall) selall.addEventListener('click', () => {
    const allOn = apSel.size === tasks.length;
    apSel = new Set(allOn ? [] : tasks.map(t => String(t.id)));
    apPickerEl.querySelectorAll('.ap-cb').forEach(cb => { cb.checked = !allOn; });
    refresh();
  });
  if (submitBtn) submitBtn.addEventListener('click', () => {
    const chosen = tasks.filter(t => apSel.has(String(t.id)));
    if (!chosen.length) return;
    const instructions = (apPickerEl.querySelector('.ap-instr')?.value || '').trim();
    // Turn-in actually submits to the teacher — make it a deliberate confirm.
    if (apMode === 'submit' &&
        !confirm(`⚠️ Autopilot is in BETA and makes mistakes — turning work in without reviewing it is risky and NOT recommended.\n\nThis will write AND turn in ${chosen.length} assignment${chosen.length > 1 ? 's' : ''} to your teacher, for real. Continue anyway?`)) return;
    apPickerEl.classList.add('hidden');
    runAutopilotBatch(chosen, apMode, instructions);
  });
  syncSubmit();
  apPickerEl.classList.remove('hidden');
}

async function openAutopilotPicker() {
  try { await loadTasks(); } catch (_) {}
  const tasks = (tasksState.tasks || [])
    .filter(t => !t.done)
    .sort((a, b) => String(a.due || '9999').localeCompare(String(b.due || '9999')));
  buildAutopilotPicker(tasks);
}

// ── Slash-command menu in the composer ──────────────────────────────────
const SLASH_COMMANDS = [
  { cmd: 'autopilot', icon: '⚡', title: 'Autopilot', desc: 'Beta · pick tasks for J@rv1s to do — review its work', run: openAutopilotPicker },
];
let slashEl = null;
let slashState = { open: false, items: [], active: 0 };

function closeSlash() {
  slashState.open = false;
  if (slashEl) slashEl.classList.add('hidden');
}
function highlightSlash() {
  if (slashEl) slashEl.querySelectorAll('.slash-item').forEach((it, i) => it.classList.toggle('active', i === slashState.active));
}
function renderSlash() {
  if (!slashEl) {
    slashEl = document.createElement('div');
    slashEl.className = 'slash-menu hidden';
    document.body.appendChild(slashEl);
  }
  slashEl.innerHTML = slashState.items.map((c, i) => `
    <div class="slash-item ${i === slashState.active ? 'active' : ''}" data-i="${i}">
      <span class="slash-ico">${c.icon}</span>
      <span class="slash-txt"><span class="slash-name">/${c.cmd}</span><span class="slash-desc">${escape(c.desc)}</span></span>
    </div>`).join('');
  slashEl.querySelectorAll('.slash-item').forEach(it => {
    it.addEventListener('mousedown', (e) => { e.preventDefault(); selectSlash(+it.dataset.i); });
    it.addEventListener('mouseenter', () => { slashState.active = +it.dataset.i; highlightSlash(); });
  });
  slashEl.classList.remove('hidden');
  const r = input.getBoundingClientRect();
  slashEl.style.left = r.left + 'px';
  slashEl.style.width = Math.min(Math.max(r.width, 260), 420) + 'px';
  slashEl.style.top = (r.top - slashEl.offsetHeight - 8) + 'px';
}
function updateSlash() {
  const m = /^\/(\w*)$/.exec(input.value);
  if (!m) { closeSlash(); return; }
  const q = m[1].toLowerCase();
  const items = SLASH_COMMANDS.filter(c => c.cmd.startsWith(q) || c.title.toLowerCase().startsWith(q));
  if (!items.length) { closeSlash(); return; }
  slashState = { open: true, items, active: 0 };
  renderSlash();
}
function selectSlash(i) {
  const c = slashState.items[i];
  closeSlash();
  input.value = '';
  autosize();
  if (c && typeof c.run === 'function') c.run();
}
input.addEventListener('input', updateSlash);
input.addEventListener('blur', () => setTimeout(closeSlash, 120));
input.addEventListener('keydown', (e) => {
  if (!slashState.open) return;
  if (e.key === 'ArrowDown') { e.preventDefault(); e.stopImmediatePropagation(); slashState.active = (slashState.active + 1) % slashState.items.length; highlightSlash(); }
  else if (e.key === 'ArrowUp') { e.preventDefault(); e.stopImmediatePropagation(); slashState.active = (slashState.active - 1 + slashState.items.length) % slashState.items.length; highlightSlash(); }
  else if (e.key === 'Enter' || e.key === 'Tab') { e.preventDefault(); e.stopImmediatePropagation(); selectSlash(slashState.active); }
  else if (e.key === 'Escape') { e.preventDefault(); e.stopImmediatePropagation(); closeSlash(); }
}, true);   // capture phase → beats the Enter-to-send handler

// ── School onboarding modal ────────────────────────────────────────────────
const schoolModal = $('school-modal-backdrop');
let schoolDraft = { platform: null, platform_name: '', url: '', mode: null };

function showSchoolModal(step) {
  schoolModal.classList.remove('hidden');
  schoolStep(step);
}
function hideSchoolModal() {
  schoolModal.classList.add('hidden');
  schoolDraft = { platform: null, platform_name: '', url: '', mode: null };
}
function schoolStep(step) {
  schoolModal.querySelectorAll('.school-step').forEach(s => s.classList.add('hidden'));
  const target = schoolModal.querySelector(`[data-step="${step}"]`);
  if (target) target.classList.remove('hidden');
  const back = schoolModal.querySelector('[data-step-action="back"]');
  if (back) back.style.display = step === 1 ? 'none' : '';
  schoolModal.dataset.curStep = step;
  if (step === 2 && schoolDraft.platform_name) {
    $('step2-platform').textContent = `for ${schoolDraft.platform_name}.`;
  }
  if (step === '3-cloud' && schoolDraft.url) {
    $('school-url').value = schoolDraft.url;
  }
}

schoolModal && schoolModal.querySelectorAll('.platform-btn').forEach(btn =>
  btn.addEventListener('click', () => {
    schoolDraft.platform = btn.dataset.platform;
    schoolDraft.platform_name = btn.dataset.name;
    schoolDraft.url = btn.dataset.defaultUrl || '';
    schoolStep(2);
  }));

schoolModal && schoolModal.querySelectorAll('.mode-btn').forEach(btn =>
  btn.addEventListener('click', () => {
    schoolDraft.mode = btn.dataset.mode;
    schoolStep(btn.dataset.mode === 'desktop' ? '3-desktop' : '3-cloud');
  }));

schoolModal && schoolModal.querySelector('[data-step-action="save-desktop"]').addEventListener('click', async () => {
  await API('/api/school/platform', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ platform: schoolDraft.platform, mode: 'desktop', url: schoolDraft.url }),
  });
  hideSchoolModal();
  loadTasks();
});

schoolModal && schoolModal.querySelector('[data-step-action="save-cloud"]').addEventListener('click', async () => {
  const url = $('school-url').value.trim();
  const username = $('school-user').value.trim();
  const password = $('school-pass').value;
  if (!url || !username || !password) {
    alert('All three fields are required for cloud automation.');
    return;
  }
  await API('/api/school/platform', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ platform: schoolDraft.platform, mode: 'cloud', url, username, password }),
  });
  $('school-pass').value = '';
  hideSchoolModal();
  loadTasks();
  setTimeout(triggerSync, 400);
});

schoolModal && schoolModal.querySelector('[data-step-action="back"]').addEventListener('click', () => {
  const cur = schoolModal.dataset.curStep;
  if (cur === '2') schoolStep(1);
  else if (cur === '3-desktop' || cur === '3-cloud') schoolStep(2);
});
schoolModal && schoolModal.querySelector('[data-step-action="cancel"]').addEventListener('click', hideSchoolModal);
schoolModal && schoolModal.addEventListener('click', (e) => { if (e.target === schoolModal) hideSchoolModal(); });

input.focus();
boot();

/* ════════════════════════════════════════════════════════════
   MOBILE DRAWER — off-canvas sidebar (hamburger + scrim)
   Built here so index.html stays untouched. CSS in styles.css.
   ════════════════════════════════════════════════════════════ */
(function setupMobileDrawer() {
  const sidebar = document.querySelector('.sidebar');
  if (!sidebar || document.getElementById('mobile-menu-btn')) return;
  if (!sidebar.id) sidebar.id = 'app-sidebar';

  const btn = document.createElement('button');
  btn.id = 'mobile-menu-btn';
  btn.className = 'mobile-menu-btn';
  btn.type = 'button';
  btn.setAttribute('aria-label', 'Open navigation menu');
  btn.setAttribute('aria-controls', sidebar.id);
  btn.setAttribute('aria-expanded', 'false');
  btn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/></svg>';

  const scrim = document.createElement('div');
  scrim.id = 'nav-scrim';
  scrim.className = 'nav-scrim';

  document.body.appendChild(scrim);
  document.body.appendChild(btn);

  const isMobile = () => window.matchMedia('(max-width: 760px)').matches;
  const open  = () => { document.body.classList.add('nav-open');    btn.setAttribute('aria-expanded', 'true');  btn.setAttribute('aria-label', 'Close navigation menu'); };
  const close = () => { document.body.classList.remove('nav-open'); btn.setAttribute('aria-expanded', 'false'); btn.setAttribute('aria-label', 'Open navigation menu'); };
  const toggle = () => document.body.classList.contains('nav-open') ? close() : open();

  btn.addEventListener('click', toggle);
  scrim.addEventListener('click', close);
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && document.body.classList.contains('nav-open')) close();
  });
  // tapping a navigation target inside the drawer should reveal the view
  sidebar.addEventListener('click', (e) => {
    if (isMobile() && e.target.closest('.nav-item, .account-card, .recent-chat-item, .project-item, .upcoming-item')) close();
  });
  // leaving mobile width resets the drawer
  window.addEventListener('resize', () => { if (!isMobile()) close(); });
})();

/* ════════════════════════════════════════════════════════════
   A11Y — give every icon-only button an accessible name (from its
   title), including symbol buttons (+ / 📌 / ⋯ / ↻). Covers static
   chrome at load and anything rendered later, via a MutationObserver.
   ════════════════════════════════════════════════════════════ */
(function labelIconButtons() {
  const label = (root) => {
    const nodes = root.querySelectorAll ? root.querySelectorAll('button, [role="button"]') : [];
    nodes.forEach(el => {
      if (el.getAttribute('aria-label')) return;
      const text = (el.textContent || '').trim();
      const hasRealText = text.length > 2 && /[a-z0-9]/i.test(text);
      if (hasRealText) return;                       // already has a meaningful visible label
      const t = el.getAttribute('title');
      if (t) el.setAttribute('aria-label', t);
    });
  };
  label(document);
  const obs = new MutationObserver(muts => {
    muts.forEach(m => m.addedNodes.forEach(n => { if (n.nodeType === 1) label(n); }));
  });
  obs.observe(document.body, { childList: true, subtree: true });

  // Settings toggle switches: name them from their row label, expose as switches,
  // and keep aria-checked in sync with the .on class.
  const switches = document.querySelectorAll('.set-toggle');
  switches.forEach(t => {
    if (!t.getAttribute('aria-label')) {
      const lbl = t.closest('.set-row') && t.closest('.set-row').querySelector('.set-label');
      if (lbl) t.setAttribute('aria-label', lbl.textContent.trim());
    }
    t.setAttribute('role', 'switch');
    t.setAttribute('aria-checked', t.classList.contains('on') ? 'true' : 'false');
  });
  const syncSwitch = new MutationObserver(muts => muts.forEach(m => {
    const el = m.target;
    if (el.classList && el.classList.contains('set-toggle'))
      el.setAttribute('aria-checked', el.classList.contains('on') ? 'true' : 'false');
  }));
  switches.forEach(t => syncSwitch.observe(t, { attributes: true, attributeFilter: ['class'] }));
})();

// =====================================================
// YOUR VOICE — learn & write in the user's own style
// =====================================================
let voiceState = null;
let voiceMode = 'rewrite';
let voiceWired = false;
let voiceBusy = false;

function wireVoice() {
  if (voiceWired) return;
  voiceWired = true;
  $('voice-add-btn')?.addEventListener('click', addVoiceSample);
  $('voice-file')?.addEventListener('change', uploadVoiceFile);
  $('voice-analyze-btn')?.addEventListener('click', analyzeVoice);
  $('voice-run-btn')?.addEventListener('click', () => applyVoice());
  $('voice-copy-btn')?.addEventListener('click', copyVoiceOutput);
  $('voice-samples')?.addEventListener('click', (e) => {
    const b = e.target.closest('.vs-remove');
    if (b) removeVoiceSample(b.dataset.id);
  });
  $('voice-skill-chip')?.addEventListener('click', (e) => {
    if (e.target.closest('#voice-goto-skills')) { e.preventDefault(); switchView('skills'); }
  });
  document.querySelectorAll('.voice-mode-btn').forEach(b =>
    b.addEventListener('click', () => setVoiceMode(b.dataset.mode)));
  $('voice-sample-text')?.addEventListener('keydown', (e) => {
    if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') { e.preventDefault(); addVoiceSample(); }
  });
}

async function loadVoice() {
  try { voiceState = await API('/api/voice'); }
  catch { voiceState = null; }
  renderVoice();
}

function renderVoice() {
  const st = voiceState || {};
  const samples = st.samples || [];
  const words = st.total_words || 0;
  const need = st.min_words || 120;
  const ready = !!st.ready_to_analyze;

  const w = $('voice-words'); if (w) w.textContent = words;
  const rn = $('voice-ready-note');
  if (rn) rn.textContent = ready ? 'ready to analyze' : `need ${need}+`;
  document.querySelector('.voice-meter')?.classList.toggle('ok', ready);

  const sc = $('voice-samples');
  if (sc) {
    sc.innerHTML = samples.length ? samples.map(s => `
      <div class="voice-sample" data-id="${s.id}">
        <div class="vs-main">
          <div class="vs-title">${escape(s.title)}</div>
          <div class="vs-preview">${escape(s.preview)}…</div>
        </div>
        <span class="vs-meta">${s.words}w</span>
        <button class="vs-remove" data-id="${s.id}" title="Remove">✕</button>
      </div>`).join('') : '<p class="voice-empty sm">No samples yet — paste something above.</p>';
  }

  const ab = $('voice-analyze-btn');
  if (ab && !voiceBusy) {
    ab.disabled = !ready;
    ab.textContent = st.has_profile ? '✨ Re-analyze' : '✨ Analyze my writing';
  }

  const wrap = $('voice-report-wrap'), empty = $('voice-report-empty');
  if (st.has_profile && st.report) {
    if (wrap) { wrap.style.display = ''; $('voice-report').innerHTML = marked.parse(st.report); }
    if (empty) empty.style.display = 'none';
    const chip = $('voice-skill-chip');
    if (chip) chip.innerHTML = `<span class="vsc-dot">🖋️</span> Voice skill ready: <strong>${escape(st.voice_name || 'Your Voice')}</strong>. Toggle it in <a href="#" id="voice-goto-skills">Skills</a> to make every reply sound like you.`;
    const note = $('voice-skill-note');
    if (note) note.textContent = st.voice_name ? `${st.voice_name} · learned` : 'learned';
  } else {
    if (wrap) wrap.style.display = 'none';
    if (empty) empty.style.display = '';
    const note = $('voice-skill-note'); if (note) note.textContent = '';
  }

  $('voice-use-card')?.classList.toggle('locked', !st.has_profile);
}

async function addVoiceSample() {
  const ta = $('voice-sample-text'), ti = $('voice-sample-title');
  const text = (ta?.value || '').trim();
  if (!text) { toast('Paste some of your writing first.', 'info'); return; }
  try {
    voiceState = await API('/api/voice/samples', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text, title: ti?.value || '' }),
    });
    if (ta) ta.value = '';
    if (ti) ti.value = '';
    renderVoice();
  } catch (e) { toast(e.error || 'Could not add that sample.', 'error'); }
}

async function uploadVoiceFile(e) {
  const file = e.target.files && e.target.files[0];
  if (!file) return;
  const fd = new FormData();
  fd.append('file', file);
  try {
    voiceState = await API('/api/voice/upload', { method: 'POST', body: fd });
    renderVoice();
    toast(`Added “${file.name}”.`, 'success', 2200);
  } catch (err) {
    toast(err.error || 'Could not read that file. Try pasting the text.', 'error', 5000);
  } finally {
    e.target.value = '';
  }
}

async function removeVoiceSample(id) {
  try {
    const r = await API('/api/voice/samples/' + encodeURIComponent(id), { method: 'DELETE' });
    voiceState = r.state || voiceState;
    renderVoice();
  } catch (e) { toast('Could not remove sample.', 'error'); }
}

async function analyzeVoice() {
  if (voiceBusy) return;
  voiceBusy = true;
  const ab = $('voice-analyze-btn');
  if (ab) { ab.disabled = true; ab.textContent = '✨ Reading your writing…'; ab.classList.add('working'); }
  try {
    voiceState = await API('/api/voice/analyze', { method: 'POST' });
    renderVoice();
    try { state.skills = await API('/api/skills'); renderSkillsPage(); } catch {}
    toast(`Learned your voice — “${voiceState.voice_name || 'Your Voice'}” skill is ready.`, 'success', 4500);
    $('voice-report-wrap')?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  } catch (e) {
    toast(e.error || 'Analysis failed. Try again in a moment.', 'error', 5000);
  } finally {
    voiceBusy = false;
    if (ab) ab.classList.remove('working');
    renderVoice();
  }
}

function setVoiceMode(mode) {
  voiceMode = (mode === 'write') ? 'write' : 'rewrite';
  document.querySelectorAll('.voice-mode-btn').forEach(b =>
    b.classList.toggle('selected', b.dataset.mode === voiceMode));
  const inp = $('voice-input');
  if (inp) inp.placeholder = voiceMode === 'write'
    ? 'Describe what to write — a topic, a prompt, bullet points…'
    : 'Paste text to rewrite in your voice…';
}

async function applyVoice() {
  if (voiceBusy) return;
  const inp = $('voice-input'), instr = $('voice-instructions');
  const text = (inp?.value || '').trim();
  if (!text) { toast(voiceMode === 'write' ? 'Tell me what to write.' : 'Paste some text to rewrite.', 'info'); return; }
  const btn = $('voice-run-btn');
  voiceBusy = true;
  if (btn) { btn.disabled = true; btn.textContent = 'Writing…'; }
  try {
    const r = await API('/api/voice/apply', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text, mode: voiceMode, instructions: instr?.value || '' }),
    });
    const out = $('voice-output'), wrap = $('voice-output-wrap');
    if (out) { out.textContent = r.output || ''; out.dataset.raw = r.output || ''; }
    if (wrap) wrap.style.display = '';
    wrap?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  } catch (e) {
    toast(e.error || 'Could not generate. Try again.', 'error');
  } finally {
    voiceBusy = false;
    if (btn) { btn.disabled = false; btn.textContent = 'Run'; }
  }
}

function copyVoiceOutput() {
  const out = $('voice-output');
  const txt = (out && (out.dataset.raw || out.textContent)) || '';
  if (!txt) return;
  navigator.clipboard.writeText(txt).then(
    () => toast('Copied.', 'success', 1500),
    () => toast('Copy failed.', 'error')
  );
}
