#!/bin/bash
# Double-click this file in Finder to launch J@rv1s (the full hosted product:
# login, onboarding tutorial, plans/paywall, settings, admin).
# It opens a native desktop window. Sign in as the admin account for full access.
cd "$(dirname "$0")" || exit 1
if [ ! -d ".venv" ]; then
  echo "Setting up for the first time…"
  python3 -m venv .venv
  source .venv/bin/activate
  pip install -q -r requirements.txt
else
  source .venv/bin/activate
fi
echo "Launching J@rv1s…  (close this window to quit)"
exec python main.py desktop
