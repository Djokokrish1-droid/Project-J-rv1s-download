# Jarvis

A personal AI assistant powered by Claude — conversation, project/file
management, voice I/O, browser + desktop automation, persistent memory.
Three ways to run: pretty CLI, browser UI, or **native desktop window**.

## Quick start

```bash
cd ~/jarvis
source .venv/bin/activate                # already set up
python main.py desktop                   # ← native desktop window
```

## Launch modes

| Command                    | What you get                              |
|----------------------------|-------------------------------------------|
| `python main.py`           | Pretty CLI (rich + prompt_toolkit)       |
| `python main.py desktop`   | **Native desktop window** (Flask + pywebview) |
| `python main.py web`       | Flask server + auto-opens in browser     |
| `python main.py api`       | Flask REST API only (headless)           |
| `python main.py voice`     | One voice turn then exit                 |

## Layout

```
core/             engine.py · memory.py · project_manager.py
interfaces/       cli.py · voice.py · api_server.py · desktop.py · web/
automation/       browser.py · screen.py
integrations/     anthropic.py
docs/             cluely_reference.md
config.py · requirements.txt · main.py
```

## CLI (`python main.py`)

Markdown-rendered Claude responses inside rounded panels, project & deadline
tables, spinners while thinking, tab-completion on slash commands, persistent
history under `data/cli_history`.

Type `/help` for the full command list. Highlights:

- `/project new <name>` · `/project use <name>` · `/project list` · `/project show`
- `/assign <project> | <title> | <YYYY-MM-DD> [| notes]`
- `/done <project> | <title>` · `/upcoming [days]`
- `/upload <project> <path>` · `/search <query>`
- `/remember <fact>` · `/pref <key> <value>` · `/feedback <text>`
- `/voice` · `/reset` · `/quit`

Anything not starting with `/` is sent to Claude with the active project +
remembered facts injected as system context.

## Desktop / Web UI

`python main.py desktop` launches a native window backed by a local Flask
server on `127.0.0.1:5005` and a polished dark-mode chat UI:

- Left sidebar with **clickable project list** (active one highlighted)
- **Upcoming deadlines** panel with urgency color-coding
- **Markdown rendering** + syntax-highlighted code blocks
- Chat composer with **auto-grow textarea**, Enter to send, Shift+Enter newline
- 🎙 Voice button — record → transcribe → respond → speak
- ↻ Reset conversation
- + button to create a project (modal)

`python main.py web` is the same UI in your default browser.

## REST API

```
GET  /api/health
GET  /api/state                  combined snapshot for the UI
POST /api/chat                   {"message":"..."}
POST /api/reset
GET  /api/projects               POST /api/projects     {"name":"...","description":"..."}
GET  /api/projects/<name>        POST /api/projects/<name>/use
DELETE /api/projects/<name>
POST /api/projects/<name>/assignments {"title":"...","due":"YYYY-MM-DD","notes":"..."}
POST /api/projects/<name>/assignments/complete {"title":"..."}
GET  /api/upcoming?days=14       GET /api/search?q=...
POST /api/memory/remember        POST /api/memory/feedback  POST /api/memory/preference
POST /api/voice/listen           POST /api/voice/speak  {"text":"..."}
```

## Cluely

See [`docs/cluely_reference.md`](docs/cluely_reference.md). Cluely (by Roy Lee)
is a documentation-only integration point; no API key needed.

## Notes

- `ANTHROPIC_API_KEY` lives in `.env`. Default model: `claude-opus-4-7`.
- Memory → `data/memory.json`, session → `data/session.json`, projects under
  `data/projects/<slug>/`, CLI history → `data/cli_history`.
- Voice requires PortAudio (`brew install portaudio` — already installed).
- Desktop control needs Accessibility permission for your terminal app on macOS.
- Browser automation: `playwright install chromium` first.
