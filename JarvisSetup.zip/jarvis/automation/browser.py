"""Browser automation via Playwright (preferred) with Selenium fallback.

Lazy imports so the module loads even if a driver is missing.
"""
from __future__ import annotations
from typing import Any


class BrowserController:
    def __init__(self, engine: str = "playwright", headless: bool = False):
        self.engine = engine
        self.headless = headless
        self._pw = None
        self._browser = None
        self._page = None
        self._driver = None  # selenium

    # --- lifecycle ----------------------------------------------------------
    def start(self) -> None:
        if self.engine == "playwright":
            from playwright.sync_api import sync_playwright
            self._pw = sync_playwright().start()
            self._browser = self._pw.chromium.launch(headless=self.headless)
            self._page = self._browser.new_page()
        else:
            from selenium import webdriver
            from selenium.webdriver.chrome.options import Options
            opts = Options()
            if self.headless:
                opts.add_argument("--headless=new")
            self._driver = webdriver.Chrome(options=opts)

    def stop(self) -> None:
        if self._browser:
            self._browser.close()
        if self._pw:
            self._pw.stop()
        if self._driver:
            self._driver.quit()
        self._pw = self._browser = self._page = self._driver = None

    # --- actions ------------------------------------------------------------
    def open(self, url: str) -> None:
        if self._page:
            self._page.goto(url)
        elif self._driver:
            self._driver.get(url)
        else:
            raise RuntimeError("Browser not started. Call .start() first.")

    def click(self, selector: str) -> None:
        if self._page:
            self._page.click(selector)
        else:
            from selenium.webdriver.common.by import By
            self._driver.find_element(By.CSS_SELECTOR, selector).click()

    def fill(self, selector: str, value: str) -> None:
        if self._page:
            self._page.fill(selector, value)
        else:
            from selenium.webdriver.common.by import By
            el = self._driver.find_element(By.CSS_SELECTOR, selector)
            el.clear()
            el.send_keys(value)

    def extract_text(self, selector: str | None = None) -> str:
        if self._page:
            if selector:
                return self._page.locator(selector).inner_text()
            return self._page.content()
        if selector:
            from selenium.webdriver.common.by import By
            return self._driver.find_element(By.CSS_SELECTOR, selector).text
        return self._driver.page_source

    def screenshot(self, path: str) -> str:
        if self._page:
            self._page.screenshot(path=path)
        else:
            self._driver.save_screenshot(path)
        return path

    def press(self, key: str = "Enter") -> None:
        if self._page:
            self._page.keyboard.press(key)
        else:
            from selenium.webdriver.common.keys import Keys
            from selenium.webdriver.common.action_chains import ActionChains
            ActionChains(self._driver).send_keys(getattr(Keys, key.upper(), key)).perform()

    def title(self) -> str:
        if self._page:
            return self._page.title()
        return self._driver.title if self._driver else ""

    def current_url(self) -> str:
        if self._page:
            return self._page.url
        return self._driver.current_url if self._driver else ""

    # context manager
    def __enter__(self):
        self.start()
        return self

    def __exit__(self, *exc):
        self.stop()
