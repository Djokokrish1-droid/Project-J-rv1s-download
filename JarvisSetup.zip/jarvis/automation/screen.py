"""Desktop control: screenshots, mouse, keyboard via pyautogui."""
from __future__ import annotations
from pathlib import Path
import time


class ScreenController:
    def __init__(self):
        import pyautogui
        self.pg = pyautogui
        self.pg.FAILSAFE = True  # move mouse to corner to abort

    def screenshot(self, path: str | Path) -> str:
        path = str(path)
        self.pg.screenshot(path)
        return path

    def move_mouse(self, x: int, y: int, duration: float = 0.2) -> None:
        self.pg.moveTo(x, y, duration=duration)

    def click(self, x: int | None = None, y: int | None = None, button: str = "left") -> None:
        self.pg.click(x=x, y=y, button=button)

    def double_click(self, x: int | None = None, y: int | None = None) -> None:
        self.pg.doubleClick(x=x, y=y)

    def type_text(self, text: str, interval: float = 0.02) -> None:
        self.pg.typewrite(text, interval=interval)

    def hotkey(self, *keys: str) -> None:
        self.pg.hotkey(*keys)

    def scroll(self, amount: int) -> None:
        self.pg.scroll(amount)

    def screen_size(self) -> tuple[int, int]:
        s = self.pg.size()
        return s.width, s.height

    def locate(self, image_path: str, confidence: float = 0.8):
        """Find an image on screen; returns (x, y) center or None."""
        try:
            return self.pg.locateCenterOnScreen(image_path, confidence=confidence)
        except Exception:
            return None
