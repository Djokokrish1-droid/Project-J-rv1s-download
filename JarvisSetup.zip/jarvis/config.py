"""Central configuration for Jarvis."""
import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

ROOT_DIR = Path(__file__).parent.resolve()
DATA_DIR = ROOT_DIR / "data"
PROJECTS_DIR = DATA_DIR / "projects"
MEMORY_FILE = DATA_DIR / "memory.json"
SESSION_FILE = DATA_DIR / "session.json"
SETTINGS_FILE = DATA_DIR / "settings.json"

for p in (DATA_DIR, PROJECTS_DIR):
    p.mkdir(parents=True, exist_ok=True)

# Anthropic
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")
# Default to a low-cost model (Haiku 4.5 = "Mini J@r"). Switch to Opus/Sonnet in
# the model picker when you need more horsepower. Override via env if desired.
CLAUDE_MODEL = os.getenv("CLAUDE_MODEL", "claude-haiku-4-5-20251001")
MAX_TOKENS = int(os.getenv("CLAUDE_MAX_TOKENS", "1600"))
# Cap how many prior messages we send to the API (cost control on long chats).
HISTORY_LIMIT = int(os.getenv("JARVIS_HISTORY_LIMIT", "24"))

# ── Public-launch guardrails ────────────────────────────────────────────────
# Hosted mode = multi-user accounts + paywall (both the web deploy and desktop app).
HOSTED_MODE = os.getenv("JARVIS_HOSTED", "false").lower() == "true"
# Machine control (browser automation, mic/voice) only makes sense on the user's
# own machine — i.e. the desktop app. The cloud web deploy leaves this OFF, so
# web automation is unavailable on the web. The desktop launcher turns it on.
ALLOW_MACHINE_CONTROL = os.getenv("JARVIS_ALLOW_AUTOMATION", "false").lower() == "true"
USAGE_FILE = DATA_DIR / "usage.json"
# Per-user daily message cap.
DAILY_USER_MESSAGE_CAP = int(os.getenv("JARVIS_USER_DAILY_CAP", "40"))
# Global daily spend ceiling in USD — when exceeded, serving stops (kill-switch).
DAILY_GLOBAL_COST_CEILING = float(os.getenv("JARVIS_DAILY_COST_CEILING", "5.0"))
# Minimum seconds between messages from one user (basic rate limit).
MIN_SECONDS_BETWEEN_MESSAGES = float(os.getenv("JARVIS_MIN_GAP", "1.5"))
# In hosted mode, lock everyone to the cheapest model regardless of picker.
HOSTED_FORCED_MODEL = os.getenv("JARVIS_HOSTED_MODEL", "claude-haiku-4-5-20251001")

# ── Billing (Stripe) ────────────────────────────────────────────────────────
STRIPE_SECRET_KEY = os.getenv("STRIPE_SECRET_KEY", "")           # sk_test_… / sk_live_…
STRIPE_WEBHOOK_SECRET = os.getenv("STRIPE_WEBHOOK_SECRET", "")   # whsec_…
# Three subscription tiers, each its own Stripe Payment Link.
STRIPE_PAYMENT_LINK_STARTER = os.getenv("STRIPE_PAYMENT_LINK_STARTER",
                                        os.getenv("STRIPE_PAYMENT_LINK", ""))
STRIPE_PAYMENT_LINK_PRO = os.getenv("STRIPE_PAYMENT_LINK_PRO", "")
STRIPE_PAYMENT_LINK_MAX = os.getenv("STRIPE_PAYMENT_LINK_MAX", "")
STARTER_DAILY_CAP = int(os.getenv("JARVIS_STARTER_CAP", "20"))
PRO_DAILY_CAP = int(os.getenv("JARVIS_PRO_CAP", "100"))
MAX_DAILY_CAP = int(os.getenv("JARVIS_MAX_CAP", "400"))
STARTER_PRICE = os.getenv("JARVIS_STARTER_PRICE", "$10/mo")
PRO_PRICE = os.getenv("JARVIS_PRO_PRICE", "$22.99/mo")
MAX_PRICE = os.getenv("JARVIS_MAX_PRICE", "$49.99/mo")
# Hard paywall: in hosted mode, require an active subscription to use J@rv1s.
REQUIRE_SUBSCRIPTION = os.getenv("JARVIS_REQUIRE_SUB", "true").lower() == "true"
BILLING_ENABLED = bool(STRIPE_PAYMENT_LINK_STARTER or STRIPE_PAYMENT_LINK_PRO or STRIPE_PAYMENT_LINK_MAX)

# Which Claude model each tier runs on (Max gets full Opus = "J@rv1s 1.0").
PLAN_MODELS = {
    "starter": HOSTED_FORCED_MODEL,             # Haiku
    "professional": HOSTED_FORCED_MODEL,        # Haiku
    "max": os.getenv("JARVIS_MAX_MODEL", "claude-opus-4-7"),  # Opus
}

# Free trial: new accounts get this many days of TRIAL_TIER access, no card.
TRIAL_DAYS = int(os.getenv("JARVIS_TRIAL_DAYS", "7"))
TRIAL_TIER = os.getenv("JARVIS_TRIAL_TIER", "professional")

# Numeric prices (for MRR math on the admin dashboard).
STARTER_PRICE_USD = float(os.getenv("JARVIS_STARTER_USD", "10"))
PRO_PRICE_USD = float(os.getenv("JARVIS_PRO_USD", "22.99"))
MAX_PRICE_USD = float(os.getenv("JARVIS_MAX_USD", "49.99"))

# Admin: usernames in this list see the admin dashboard + bypass the paywall.
ADMIN_USERS = [u.strip().lower() for u in os.getenv("JARVIS_ADMIN_USERS", "admin").split(",") if u.strip()]
# If set, an admin account is auto-created on boot with this password.
ADMIN_PASSWORD = os.getenv("JARVIS_ADMIN_PASSWORD", "")

# Plan catalog (drives the paywall UI + caps + feature gates).
PLANS = [
    {"id": "starter", "name": "Starter", "price": STARTER_PRICE, "price_usd": STARTER_PRICE_USD,
     "cap": STARTER_DAILY_CAP, "web_automation": False,
     "features": [f"{STARTER_DAILY_CAP} messages / day", "All subjects & skills",
                  "Full academic package", "Mini J@r (Haiku)"]},
    {"id": "professional", "name": "Professional", "price": PRO_PRICE, "price_usd": PRO_PRICE_USD,
     "cap": PRO_DAILY_CAP, "web_automation": True,
     "features": [f"{PRO_DAILY_CAP} messages / day (5×)", "Everything in Starter",
                  "Web automation (desktop app)", "7-day free trial"]},
    {"id": "max", "name": "Max", "price": MAX_PRICE, "price_usd": MAX_PRICE_USD,
     "cap": MAX_DAILY_CAP, "web_automation": True,
     "features": [f"{MAX_DAILY_CAP} messages / day (20×)", "Everything in Professional",
                  "Runs on J@rv1s 1.0 (max power)", "Web automation (desktop app)"]},
]
PLAN_CAPS = {p["id"]: p["cap"] for p in PLANS}
PLAN_PRICE_USD = {p["id"]: p["price_usd"] for p in PLANS}

# Cluely (documentation-only integration, no key required)
CLUELY_ENABLED = os.getenv("CLUELY_ENABLED", "false").lower() == "true"
CLUELY_ENDPOINT = os.getenv("CLUELY_ENDPOINT", "https://cluely.example/api")

# Flask API
API_HOST = os.getenv("JARVIS_API_HOST", "127.0.0.1")
API_PORT = int(os.getenv("JARVIS_API_PORT", "5005"))

# Voice
VOICE_RATE = int(os.getenv("VOICE_RATE", "180"))

SYSTEM_PROMPT = """You are Jarvis, a personal AI assistant.
You help the user manage projects, files, assignments, and deadlines, automate
their browser and desktop, and learn their preferences over time. Be concise,
direct, and proactive. When the user references a project by name, use the
project context provided in the conversation."""
