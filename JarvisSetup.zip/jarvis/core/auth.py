"""Lightweight accounts: username + password (PBKDF2), stdlib only.

Users live in data/users.json. Each user gets a stable uid that names their
private data directory (data/users/<uid>/).
"""
from __future__ import annotations
import json
import hashlib
import secrets
import re
import time
from config import DATA_DIR, TRIAL_DAYS, TRIAL_TIER, ADMIN_USERS, ADMIN_PASSWORD

USERS_FILE = DATA_DIR / "users.json"
USERS_DIR = DATA_DIR / "users"
_ITER = 200_000


def _load() -> dict:
    if USERS_FILE.exists():
        try:
            return json.loads(USERS_FILE.read_text())
        except json.JSONDecodeError:
            return {}
    return {}


def _save(d: dict) -> None:
    USERS_FILE.write_text(json.dumps(d, indent=2))


def _hash(password: str, salt: str) -> str:
    return hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt), _ITER).hex()


def _norm(username: str) -> str:
    return username.strip().lower()


def create_user(username: str, password: str) -> tuple[bool, str | None, str | None]:
    """Returns (ok, uid, error)."""
    u = _norm(username)
    if not re.fullmatch(r"[a-z0-9._\-+@]{3,64}", u):
        return False, None, "Enter a valid username or email (3–64 characters)."
    if len(password) < 6:
        return False, None, "Password must be at least 6 characters."
    users = _load()
    if u in users:
        return False, None, "That username is taken."
    salt = secrets.token_hex(16)
    uid = "u_" + secrets.token_hex(8)
    rec = {"uid": uid, "salt": salt, "hash": _hash(password, salt),
           "plan": "none", "paid": False, "trial_ends": None,
           "created": time.time()}
    # grant a free trial on signup (no card)
    if TRIAL_DAYS > 0:
        rec["plan"] = TRIAL_TIER
        rec["trial_ends"] = time.time() + TRIAL_DAYS * 86400
    users[u] = rec
    _save(users)
    (USERS_DIR / uid).mkdir(parents=True, exist_ok=True)
    return True, uid, None


def verify_user(username: str, password: str) -> tuple[bool, str | None]:
    """Returns (ok, uid)."""
    u = _norm(username)
    rec = _load().get(u)
    if not rec:
        return False, None
    if secrets.compare_digest(rec["hash"], _hash(password, rec["salt"])):
        return True, rec["uid"]
    return False, None


def user_dir(uid: str):
    d = USERS_DIR / uid
    d.mkdir(parents=True, exist_ok=True)
    return d


def account_info(uid: str) -> dict:
    username, rec = _record_by_uid(_load(), uid)
    return {
        "username": username or ("you" if uid == "local" else uid),
        "plan": get_plan(uid),
        "created": (rec or {}).get("created"),
        "is_admin": is_admin(uid),
    }


def change_password(uid: str, old: str, new: str) -> tuple[bool, str | None]:
    users = _load()
    username, rec = _record_by_uid(users, uid)
    if not rec:
        return False, "Account not found."
    if not secrets.compare_digest(rec["hash"], _hash(old, rec["salt"])):
        return False, "Current password is incorrect."
    if len(new) < 6:
        return False, "New password must be at least 6 characters."
    rec["salt"] = secrets.token_hex(16)
    rec["hash"] = _hash(new, rec["salt"])
    users[username] = rec
    _save(users)
    return True, None


def delete_user(uid: str) -> bool:
    import shutil
    users = _load()
    username, rec = _record_by_uid(users, uid)
    if not rec:
        return False
    del users[username]
    _save(users)
    d = USERS_DIR / uid
    if d.exists():
        shutil.rmtree(d, ignore_errors=True)
    return True


# ── plans / billing ─────────────────────────────────────────────────────────
def _record_by_uid(users: dict, uid: str):
    for username, rec in users.items():
        if rec.get("uid") == uid:
            return username, rec
    return None, None


def _effective_plan(rec: dict | None) -> str:
    """Resolve a record to its currently-active tier, accounting for trials."""
    if not rec:
        return "none"
    plan = rec.get("plan", "none")
    if plan == "none":
        return "none"
    if rec.get("paid"):
        return plan                       # active paid subscription
    te = rec.get("trial_ends")
    if te and time.time() < te:
        return plan                       # still inside the free trial
    return "none"                         # trial expired, never paid


def get_plan(uid: str) -> str:
    """Effective tier: 'starter' | 'professional' | 'none'."""
    if uid == "local":
        return "professional"
    username, rec = _record_by_uid(_load(), uid)
    if username and username in ADMIN_USERS:
        return "max"                       # admins bypass the paywall
    return _effective_plan(rec)


def is_subscribed(uid: str) -> bool:
    return get_plan(uid) in ("starter", "professional", "max")


def trial_info(uid: str) -> dict:
    """{trialing, days_left} for the paywall/sidebar."""
    if uid == "local":
        return {"trialing": False, "days_left": 0}
    _, rec = _record_by_uid(_load(), uid)
    if not rec or rec.get("paid") or not rec.get("trial_ends"):
        return {"trialing": False, "days_left": 0}
    left = rec["trial_ends"] - time.time()
    if left <= 0:
        return {"trialing": False, "days_left": 0}
    return {"trialing": True, "days_left": max(1, round(left / 86400))}


def is_admin(uid: str) -> bool:
    if uid == "local":
        return True
    username, _ = _record_by_uid(_load(), uid)
    return bool(username and username in ADMIN_USERS)


def ensure_admin() -> None:
    """Auto-create the admin account on boot if ADMIN_PASSWORD is configured."""
    if not ADMIN_PASSWORD:
        return
    users = _load()
    for name in ADMIN_USERS:
        if name not in users:
            salt = secrets.token_hex(16)
            users[name] = {"uid": "u_" + secrets.token_hex(8), "salt": salt,
                           "hash": _hash(ADMIN_PASSWORD, salt), "plan": "professional",
                           "paid": True, "trial_ends": None, "created": time.time()}
    _save(users)


def admin_summary() -> dict:
    """Aggregate user/revenue stats for the admin dashboard."""
    from config import PLAN_PRICE_USD
    users = _load()
    paid = {"starter": 0, "professional": 0, "max": 0}
    trialing = 0
    for name, rec in users.items():
        if name in ADMIN_USERS:
            continue
        if rec.get("paid") and rec.get("plan") in paid:
            paid[rec["plan"]] += 1
        elif rec.get("trial_ends") and time.time() < rec["trial_ends"]:
            trialing += 1
    mrr = sum(paid[t] * PLAN_PRICE_USD.get(t, 0) for t in paid)
    return {
        "total_users": len(users),
        "paid_starter": paid["starter"],
        "paid_professional": paid["professional"],
        "paid_max": paid["max"],
        "paying": sum(paid.values()),
        "trialing": trialing,
        "mrr": round(mrr, 2),
    }


def set_plan(uid: str, plan: str, customer_id: str | None = None) -> None:
    users = _load()
    username, rec = _record_by_uid(users, uid)
    if not rec:
        return
    rec["plan"] = plan
    rec["paid"] = plan in ("starter", "professional", "max")
    rec["trial_ends"] = None              # a real subscription supersedes the trial
    if customer_id:
        rec["stripe_customer_id"] = customer_id
    users[username] = rec
    _save(users)


def set_plan_by_customer(customer_id: str, plan: str) -> bool:
    """Used by webhooks (which know the Stripe customer, not our uid)."""
    users = _load()
    for username, rec in users.items():
        if rec.get("stripe_customer_id") == customer_id:
            rec["plan"] = plan
            rec["paid"] = plan in ("starter", "professional", "max")
            users[username] = rec
            _save(users)
            return True
    return False
