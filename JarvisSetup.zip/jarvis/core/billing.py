"""Stripe billing: subscription checkout + webhook handling.

Degrades gracefully when Stripe isn't configured (BILLING_ENABLED is False) so
the app runs fine locally without keys. To go live you need a Stripe account
(holder must be 18+), a recurring Price, and the three STRIPE_* env vars.
"""
from __future__ import annotations

from urllib.parse import quote
from config import (STRIPE_SECRET_KEY, STRIPE_PAYMENT_LINK_STARTER,
                    STRIPE_PAYMENT_LINK_PRO, STRIPE_PAYMENT_LINK_MAX,
                    STRIPE_WEBHOOK_SECRET, BILLING_ENABLED)
from core import auth

try:
    import stripe
except ImportError:  # pragma: no cover
    stripe = None

if stripe and STRIPE_SECRET_KEY:
    stripe.api_key = STRIPE_SECRET_KEY

_LINKS = {"starter": STRIPE_PAYMENT_LINK_STARTER,
          "professional": STRIPE_PAYMENT_LINK_PRO,
          "max": STRIPE_PAYMENT_LINK_MAX}
_TIERS = ("starter", "professional", "max")


def enabled() -> bool:
    return bool(BILLING_ENABLED)


def checkout_url(uid: str, tier: str = "starter") -> str:
    """Stripe Payment Link for the chosen tier, tagged with the user id so the
    webhook can map the payment back to this account (client_reference_id =
    '<uid>__<tier>')."""
    link = _LINKS.get(tier) or STRIPE_PAYMENT_LINK_STARTER
    if not link:
        raise RuntimeError("Billing is not configured.")
    ref = f"{uid}__{tier}"
    sep = "&" if "?" in link else "?"
    return f"{link}{sep}client_reference_id={quote(ref)}"


def _parse_ref(ref: str) -> tuple[str | None, str]:
    if not ref:
        return None, "starter"
    if "__" in ref:
        uid, tier = ref.rsplit("__", 1)
        if tier not in _TIERS:
            tier = "starter"
        return uid, tier
    return ref, "starter"


def create_portal_session(uid: str, return_url: str) -> str | None:
    """Stripe customer portal so users can manage/cancel their subscription."""
    if not enabled():
        return None
    _, rec = auth._record_by_uid(auth._load(), uid)
    cust = (rec or {}).get("stripe_customer_id")
    if not cust:
        return None
    return stripe.billing_portal.Session.create(customer=cust, return_url=return_url).url


def handle_webhook(payload: bytes, sig_header: str) -> tuple[bool, str]:
    """Verify + process a Stripe webhook. Returns (ok, message)."""
    if not enabled():
        return False, "billing disabled"
    try:
        if STRIPE_WEBHOOK_SECRET:
            event = stripe.Webhook.construct_event(payload, sig_header, STRIPE_WEBHOOK_SECRET)
        else:
            import json
            event = json.loads(payload)
    except Exception as ex:  # signature/parse failure
        return False, f"invalid webhook: {ex}"

    etype = event["type"]
    obj = event["data"]["object"]

    if etype == "checkout.session.completed":
        uid, tier = _parse_ref(obj.get("client_reference_id") or "")
        customer = obj.get("customer")
        if uid:
            auth.set_plan(uid, tier, customer_id=customer)
        return True, f"activated {uid} ({tier})"

    if etype == "customer.subscription.deleted":
        customer = obj.get("customer")
        if customer:
            auth.set_plan_by_customer(customer, "none")
        return True, "canceled"

    if etype == "customer.subscription.updated":
        customer = obj.get("customer")
        status = obj.get("status")
        # only downgrade on a non-active status; tier was set at checkout
        if customer and status not in ("active", "trialing"):
            auth.set_plan_by_customer(customer, "none")
        return True, f"status {status}"

    return True, f"ignored {etype}"
