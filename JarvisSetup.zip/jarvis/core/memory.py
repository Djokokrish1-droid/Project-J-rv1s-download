"""Persistent memory: preferences, facts, and conversation history."""
from __future__ import annotations
import json
import time
from pathlib import Path
from typing import Any

from config import MEMORY_FILE, SESSION_FILE


def _load(path: Path, default: Any) -> Any:
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text())
    except json.JSONDecodeError:
        return default


def _save(path: Path, data: Any) -> None:
    path.write_text(json.dumps(data, indent=2, default=str))


class Memory:
    """Long-term memory: preferences and labeled facts."""

    def __init__(self, path: Path = MEMORY_FILE):
        self.path = path
        data = _load(path, {"preferences": {}, "facts": [], "feedback": []})
        self.preferences: dict = data.get("preferences", {})
        self.facts: list = data.get("facts", [])
        self.feedback: list = data.get("feedback", [])

    def save(self) -> None:
        _save(
            self.path,
            {
                "preferences": self.preferences,
                "facts": self.facts,
                "feedback": self.feedback,
            },
        )

    def set_preference(self, key: str, value: Any) -> None:
        self.preferences[key] = value
        self.save()

    def remember(self, fact: str, tag: str = "general") -> None:
        self.facts.append({"fact": fact, "tag": tag, "ts": time.time()})
        self.save()

    def record_feedback(self, text: str, rating: int | None = None) -> None:
        self.feedback.append({"text": text, "rating": rating, "ts": time.time()})
        self.save()

    def context_block(self) -> str:
        """Render memory as a system-prompt addendum."""
        parts = []
        if self.preferences:
            parts.append("User preferences:")
            for k, v in self.preferences.items():
                parts.append(f"- {k}: {v}")
        if self.facts:
            parts.append("\nRemembered facts:")
            for f in self.facts[-25:]:
                parts.append(f"- [{f['tag']}] {f['fact']}")
        return "\n".join(parts)


class Session:
    """Short-term rolling conversation, persisted across runs."""

    def __init__(self, path: Path = SESSION_FILE, max_turns: int = 40):
        self.path = path
        self.max_turns = max_turns
        self.messages: list[dict] = _load(path, [])

    def add(self, role: str, content: str) -> None:
        self.messages.append({"role": role, "content": content})
        if len(self.messages) > self.max_turns * 2:
            self.messages = self.messages[-self.max_turns * 2 :]
        _save(self.path, self.messages)

    def clear(self) -> None:
        self.messages = []
        _save(self.path, self.messages)

    def history(self) -> list[dict]:
        return list(self.messages)
