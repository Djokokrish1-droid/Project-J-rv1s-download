"""Project, assignment, conversation, and file management.

Each project is a directory:
  data/projects/<slug>/
    meta.json          name, description, instructions, assignments, conversations
    files/             uploaded attachments
"""
from __future__ import annotations
import json
import shutil
import time
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any

from config import PROJECTS_DIR, DATA_DIR


def _slug(name: str) -> str:
    return "".join(c if c.isalnum() or c in "-_" else "-" for c in name.strip().lower())


# ---------------------------------------------------------------------------
# Default homework/academic projects auto-seeded on first launch
# ---------------------------------------------------------------------------
DEFAULT_SUBJECTS = [
    {
        "name": "Math",
        "description": "Math homework, problem sets, proofs.",
        "instructions": (
            "Help me with math homework and concepts. Show work step-by-step "
            "and explain the reasoning, not just the answer. When I'm stuck, "
            "ask one focused question first to find out where I'm stuck. For "
            "competition problems (AMC/AIME) lean into pattern recognition and "
            "key insights. Use LaTeX-style notation when it helps."
        ),
    },
    {
        "name": "English",
        "description": "Essays, reading, writing.",
        "instructions": (
            "Help with English assignments — essays, literary analysis, reading. "
            "When I share writing, give specific feedback on argument, structure, "
            "and word choice. Don't rewrite for me — point out what to improve "
            "and why. Quote my exact text when you flag something. For close "
            "reading, ask what I think before telling me."
        ),
    },
    {
        "name": "History",
        "description": "Notes, essays, AP/SAT prep.",
        "instructions": (
            "Help with history — class notes, essays, research, exam prep. "
            "Connect events to broader themes (cause/effect, continuity/change, "
            "comparative). For essays, focus on thesis clarity and evidence. "
            "When I'm reviewing, quiz me actively rather than lecturing. Cite "
            "specific dates, names, and primary-source ideas where they matter."
        ),
    },
    {
        "name": "Science",
        "description": "Bio, Chem, Physics — homework + concepts.",
        "instructions": (
            "Help with science homework across biology, chemistry, and physics. "
            "When I'm stuck on a problem ask what I've tried first. Use ASCII "
            "diagrams when they help. Distinguish memorization vs. derivation — "
            "for derivable formulas show the derivation once. For lab reports, "
            "focus on the science not the formatting."
        ),
    },
]


class ProjectManager:
    def __init__(self, root: Path = PROJECTS_DIR):
        self.root = root
        self.root.mkdir(parents=True, exist_ok=True)
        self._seed_default_subjects()

    def _seed_default_subjects(self) -> None:
        flag = self.root / ".seeded"   # per-projects-root, so each user gets seeded
        if flag.exists():
            return
        for sub in DEFAULT_SUBJECTS:
            slug = _slug(sub["name"])
            if (self.root / slug).exists():
                continue
            self.create(sub["name"], sub["description"], instructions=sub["instructions"])
        flag.write_text(str(time.time()))

    # --- project CRUD -------------------------------------------------------
    def create(self, name: str, description: str = "", instructions: str = "") -> dict:
        slug = _slug(name)
        pdir = self.root / slug
        if pdir.exists():
            raise ValueError(f"Project '{slug}' already exists.")
        (pdir / "files").mkdir(parents=True)
        meta = {
            "slug": slug,
            "name": name,
            "description": description,
            "instructions": instructions,
            "pinned": True,               # default-pinned so they show in the sidebar
            "created": time.time(),
            "assignments": [],            # {title, due, done, notes}
            "scheduled": [],              # {title, cron, last_run}
            "notes": [],
            "current_conversation_id": None,
            "conversations": [],
        }
        self._save(meta)
        return meta

    def set_pinned(self, name: str, pinned: bool) -> bool:
        meta = self.get(name)
        if not meta:
            return False
        meta["pinned"] = bool(pinned)
        self._save(meta)
        return True

    def list_pinned(self) -> list[dict]:
        return [p for p in self.list() if p.get("pinned", True)]

    def list(self) -> list[dict]:
        out = []
        for p in sorted(self.root.iterdir()):
            mf = p / "meta.json"
            if mf.exists():
                out.append(json.loads(mf.read_text()))
        return out

    def get(self, name: str) -> dict | None:
        mf = self.root / _slug(name) / "meta.json"
        return json.loads(mf.read_text()) if mf.exists() else None

    def _save(self, meta: dict) -> None:
        (self.root / meta["slug"] / "meta.json").write_text(json.dumps(meta, indent=2))

    def delete(self, name: str) -> bool:
        pdir = self.root / _slug(name)
        if not pdir.exists():
            return False
        shutil.rmtree(pdir)
        return True

    def set_instructions(self, name: str, instructions: str) -> bool:
        meta = self.get(name)
        if not meta:
            return False
        meta["instructions"] = instructions
        self._save(meta)
        return True

    # --- files --------------------------------------------------------------
    def upload(self, name: str, src_path: str) -> Path:
        meta = self.get(name)
        if not meta:
            raise ValueError(f"No such project: {name}")
        src = Path(src_path).expanduser()
        if not src.exists():
            raise FileNotFoundError(src)
        dst = self.root / meta["slug"] / "files" / src.name
        shutil.copy2(src, dst)
        return dst

    def save_upload(self, name: str, filename: str, data: bytes) -> Path:
        """Save raw uploaded bytes into the project's files/ directory."""
        meta = self.get(name)
        if not meta:
            raise ValueError(f"No such project: {name}")
        safe = "".join(c for c in Path(filename).name if c.isalnum() or c in "._- ")
        safe = safe.strip() or "upload"
        dst = self.root / meta["slug"] / "files" / safe
        dst.write_bytes(data)
        return dst

    def delete_file(self, name: str, filename: str) -> bool:
        meta = self.get(name)
        if not meta:
            return False
        f = self.root / meta["slug"] / "files" / Path(filename).name
        if f.exists() and f.is_file():
            f.unlink()
            return True
        return False

    def files(self, name: str) -> list[Path]:
        meta = self.get(name)
        if not meta:
            return []
        return sorted((self.root / meta["slug"] / "files").iterdir())

    # --- assignments / deadlines -------------------------------------------
    def add_assignment(self, name: str, title: str, due: str, notes: str = "") -> dict:
        meta = self.get(name)
        if not meta:
            raise ValueError(f"No such project: {name}")
        item = {"title": title, "due": due, "done": False, "notes": notes,
                "created": time.time()}
        meta["assignments"].append(item)
        self._save(meta)
        return item

    def complete_assignment(self, name: str, title: str) -> bool:
        meta = self.get(name)
        if not meta:
            return False
        for a in meta["assignments"]:
            if a["title"].lower() == title.lower():
                a["done"] = True
                self._save(meta)
                return True
        return False

    # --- scheduled (recurring) tasks ---------------------------------------
    def add_scheduled(self, name: str, title: str, cadence: str) -> dict:
        meta = self.get(name)
        if not meta:
            raise ValueError(f"No such project: {name}")
        item = {"title": title, "cadence": cadence, "created": time.time(), "last_run": None}
        meta.setdefault("scheduled", []).append(item)
        self._save(meta)
        return item

    def remove_scheduled(self, name: str, index: int) -> bool:
        meta = self.get(name)
        if not meta:
            return False
        sched = meta.get("scheduled", [])
        if 0 <= index < len(sched):
            sched.pop(index)
            self._save(meta)
            return True
        return False

    def upcoming(self, within_days: int = 14) -> list[dict]:
        out = []
        now = datetime.now()
        for meta in self.list():
            for a in meta["assignments"]:
                if a["done"]:
                    continue
                try:
                    d = datetime.fromisoformat(a["due"])
                except ValueError:
                    continue
                days = (d - now).days
                if days <= within_days:
                    out.append({**a, "project": meta["name"], "days_until": days})
        return sorted(out, key=lambda x: x["due"])

    # --- conversations ------------------------------------------------------
    def conversations(self, name: str) -> list[dict]:
        meta = self.get(name)
        if not meta:
            return []
        # return list sorted by updated desc, without full message bodies
        items = []
        for c in meta.get("conversations", []):
            items.append({
                "id": c["id"],
                "title": c.get("title") or "Untitled",
                "preview": c.get("preview", ""),
                "created": c.get("created"),
                "updated": c.get("updated"),
                "message_count": len(c.get("messages", [])),
            })
        return sorted(items, key=lambda c: c.get("updated") or 0, reverse=True)

    def get_conversation(self, name: str, cid: str) -> dict | None:
        meta = self.get(name)
        if not meta:
            return None
        for c in meta.get("conversations", []):
            if c["id"] == cid:
                return c
        return None

    def new_conversation(self, name: str, title: str = "") -> dict:
        meta = self.get(name)
        if not meta:
            raise ValueError(f"No such project: {name}")
        conv = {
            "id": "c-" + uuid.uuid4().hex[:10],
            "title": title or "New chat",
            "preview": "",
            "created": time.time(),
            "updated": time.time(),
            "messages": [],
        }
        meta.setdefault("conversations", []).append(conv)
        meta["current_conversation_id"] = conv["id"]
        self._save(meta)
        return conv

    def append_to_conversation(
        self,
        name: str,
        cid: str,
        user_msg: dict,
        assistant_msg: dict,
    ) -> None:
        meta = self.get(name)
        if not meta:
            return
        for c in meta.get("conversations", []):
            if c["id"] == cid:
                # set title from the first user message if untitled
                if (not c.get("title") or c["title"] == "New chat") and user_msg.get("content"):
                    c["title"] = user_msg["content"][:60].strip()
                c["preview"] = (user_msg.get("content") or "")[:80].strip()
                c["updated"] = time.time()
                c.setdefault("messages", []).extend([user_msg, assistant_msg])
                self._save(meta)
                return

    def delete_conversation(self, name: str, cid: str) -> bool:
        meta = self.get(name)
        if not meta:
            return False
        before = len(meta.get("conversations", []))
        meta["conversations"] = [c for c in meta.get("conversations", []) if c["id"] != cid]
        if meta.get("current_conversation_id") == cid:
            meta["current_conversation_id"] = None
        if len(meta["conversations"]) < before:
            self._save(meta)
            return True
        return False

    def set_current_conversation(self, name: str, cid: str | None) -> bool:
        meta = self.get(name)
        if not meta:
            return False
        meta["current_conversation_id"] = cid
        self._save(meta)
        return True

    # --- search -------------------------------------------------------------
    def search(self, query: str) -> list[dict]:
        q = query.lower()
        hits = []
        for meta in self.list():
            blob = json.dumps(meta).lower()
            if q in blob:
                hits.append({"project": meta["name"], "match": "metadata"})
            for f in self.files(meta["name"]):
                if q in f.name.lower():
                    hits.append({"project": meta["name"], "match": f"file:{f.name}"})
        return hits

    # --- context block ------------------------------------------------------
    def context_for(self, name: str) -> str:
        meta = self.get(name)
        if not meta:
            return ""
        lines = [f"# Project: {meta['name']}", meta.get("description", "")]
        if meta.get("instructions"):
            lines.append(f"\n## Project Instructions\n{meta['instructions']}")
        if meta["assignments"]:
            lines.append("\n## Assignments:")
            for a in meta["assignments"]:
                status = "✓" if a["done"] else "○"
                lines.append(f"  {status} {a['title']} (due {a['due']}) {a.get('notes','')}")
        files = self.files(meta["name"])
        if files:
            lines.append("\n## Files:")
            for f in files:
                lines.append(f"  - {f.name}")
            # inline the contents of small text-like files so Claude can use them
            TEXT_EXT = {".txt", ".md", ".markdown", ".csv", ".json", ".py",
                        ".tex", ".rtf", ".log"}
            for f in files:
                if f.suffix.lower() in TEXT_EXT and f.stat().st_size < 60_000:
                    try:
                        body = f.read_text(errors="replace")
                    except Exception:
                        continue
                    lines.append(f"\n### Contents of {f.name}\n{body[:8000]}")
        return "\n".join(lines)
