"""User settings that persist across restarts (model, theme, browser policy)."""
from __future__ import annotations
import json
from pathlib import Path
from typing import Any

from config import SETTINGS_FILE, CLAUDE_MODEL

DEFAULTS: dict[str, Any] = {
    "model": CLAUDE_MODEL,
    "theme": "dark",            # "dark" | "light"
    "browser_restricted": True,
    "speak_responses": False,
}


class Settings:
    def __init__(self, path: Path = SETTINGS_FILE):
        self.path = path
        self.data: dict[str, Any] = dict(DEFAULTS)
        if path.exists():
            try:
                self.data.update(json.loads(path.read_text()))
            except json.JSONDecodeError:
                pass

    def get(self, key: str, default: Any = None) -> Any:
        return self.data.get(key, DEFAULTS.get(key, default))

    def set(self, key: str, value: Any) -> None:
        self.data[key] = value
        self.save()

    def save(self) -> None:
        self.path.write_text(json.dumps(self.data, indent=2))
