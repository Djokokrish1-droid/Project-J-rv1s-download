"""Skills: composable system-prompt addendums that change Jarvis's behavior.

Each skill has a prompt that gets injected into the system message when enabled.
Persisted enabled-state + custom skills under data/skills.json.
"""
from __future__ import annotations
import json
from pathlib import Path
from typing import Any

from config import DATA_DIR


UNDETECTABLE_PROMPT = """Write like a real high-school student wrote this in one
pass, not like an AI optimizing for politeness or completeness. Output should
not be flagged as AI by detectors.

Rules:
- Vary sentence length. Mix short punches with longer thoughts.
- Use contractions everywhere natural (it's, don't, can't, won't, gonna).
- Start sentences with And, But, So, Because when it sounds right.
- Allow tiny imperfections — a sentence fragment, an aside, casual word order.
- Don't use em-dashes (—). Use commas, periods, or parentheses.
- Avoid AI-tells: "delve", "leverage", "robust", "comprehensive", "navigate",
  "in conclusion", "it's important to note", "I hope this helps".
- Skip every list that doesn't earn it. Real students don't bullet-point everything.
- Don't over-explain. Real student writing has gaps, jumps, and the occasional
  unsupported claim.
- One-draft energy: assertive, a little uneven, no perfectly-balanced structure.
- For essays, write with a clear point of view. Not "on one hand / on the other"
  unless that's the assignment.
- Casual register by default. Match formality to the assignment if specified."""


HUMANIZER_PROMPT = """Strip the AI-tells from your writing. Sound like a real
person wrote this in one draft, not an assistant optimizing for politeness.

Avoid:
- Em-dashes (—). Use commas, periods, or parentheses instead.
- "Delve into", "leverage", "streamline", "robust", "comprehensive", "navigate",
  "in the realm of", "tapestry", "underscore", "facilitate".
- "It's important to note that", "In conclusion", "Furthermore", "Moreover",
  "That being said", "At the end of the day".
- "I hope this helps!", "Feel free to ask if you have any questions!"
- Overly-symmetric structure — not every list needs exactly three items.
- Hedging like "It really depends" when you can just answer.

Do:
- Vary sentence length. Mix short punches with longer ones.
- Use contractions: it's, don't, won't, you're.
- Start sentences with And, But, So when natural.
- Allow small imperfections — fragments, asides, casual word order.
- Get to the point. State the conclusion, then back it up."""


CONCISE_PROMPT = """Default to terse, high-density answers. Lead with the answer
in the first sentence. Skip preamble. Use lists only when they save the reader
time. Cap your response at ~80 words unless the user explicitly asks for more."""


TUTOR_PROMPT = """You are a Socratic tutor. Don't give answers directly. Instead,
ask one focused question at a time that helps the user discover the answer.
Acknowledge their reasoning. If they're stuck after 2-3 questions, give a small
hint, not the full answer. Only state the answer if they explicitly ask."""


DEFAULT_SKILLS = [
    {
        "id": "undetectable",
        "name": "Undetectable",
        "description": "Realistic high-school student voice. Bypasses AI detectors.",
        "category": "personal",
        "icon": "🥷",
        "gradient": "linear-gradient(135deg, #f59e0b, #ef4444)",
        "prompt": UNDETECTABLE_PROMPT,
    },
    {
        "id": "humanizer",
        "name": "Humanizer",
        "description": "Remove signs of AI-generated writing.",
        "category": "personal",
        "icon": "✍️",
        "gradient": "linear-gradient(135deg, #6366f1, #8b5cf6)",
        "prompt": HUMANIZER_PROMPT,
    },
    {
        "id": "concise",
        "name": "Concise Mode",
        "description": "Terse, high-density answers. Lead with the answer.",
        "category": "system",
        "icon": "⚡",
        "gradient": "linear-gradient(135deg, #06b6d4, #3b82f6)",
        "prompt": CONCISE_PROMPT,
    },
    {
        "id": "tutor",
        "name": "Tutor Mode",
        "description": "Socratic questions instead of direct answers.",
        "category": "system",
        "icon": "🎓",
        "gradient": "linear-gradient(135deg, #10b981, #14b8a6)",
        "prompt": TUTOR_PROMPT,
    },
]


class SkillsManager:
    def __init__(self, path: Path | None = None):
        self.path = path or (DATA_DIR / "skills.json")
        self.skills: list[dict] = [dict(s) for s in DEFAULT_SKILLS]
        self.enabled: set[str] = set()
        self._load()

    def _load(self) -> None:
        if not self.path.exists():
            return
        try:
            data = json.loads(self.path.read_text())
        except json.JSONDecodeError:
            return
        self.enabled = set(data.get("enabled", []))
        # custom skills appended after defaults
        for s in data.get("custom", []):
            if not any(existing["id"] == s["id"] for existing in self.skills):
                self.skills.append({**s, "category": "custom"})

    def _save(self) -> None:
        custom = [s for s in self.skills if s["category"] == "custom"]
        self.path.write_text(json.dumps(
            {"enabled": sorted(self.enabled), "custom": custom}, indent=2
        ))

    # ----- queries -------------------------------------------------------
    def list(self) -> list[dict]:
        return [{**s, "enabled": s["id"] in self.enabled} for s in self.skills]

    def get(self, sid: str) -> dict | None:
        for s in self.skills:
            if s["id"] == sid:
                return {**s, "enabled": s["id"] in self.enabled}
        return None

    def active(self) -> list[dict]:
        return [s for s in self.skills if s["id"] in self.enabled]

    # ----- mutations -----------------------------------------------------
    def enable(self, sid: str) -> None:
        if any(s["id"] == sid for s in self.skills):
            self.enabled.add(sid)
            self._save()

    def disable(self, sid: str) -> None:
        self.enabled.discard(sid)
        self._save()

    def toggle(self, sid: str) -> bool:
        if sid in self.enabled:
            self.disable(sid)
        else:
            self.enable(sid)
        return sid in self.enabled

    def create(self, name: str, description: str, prompt: str,
               icon: str = "✨", category: str = "custom") -> dict:
        sid = "-".join("".join(c if c.isalnum() else " " for c in name.lower()).split())
        if any(s["id"] == sid for s in self.skills):
            raise ValueError(f"Skill '{sid}' already exists.")
        skill = {
            "id": sid,
            "name": name,
            "description": description,
            "category": "custom",
            "icon": icon,
            "gradient": "linear-gradient(135deg, #00d9ff, #b794f6)",
            "prompt": prompt,
        }
        self.skills.append(skill)
        self._save()
        return skill

    def delete(self, sid: str) -> bool:
        before = len(self.skills)
        self.skills = [s for s in self.skills if not (s["id"] == sid and s["category"] == "custom")]
        self.enabled.discard(sid)
        self._save()
        return len(self.skills) < before

    # ----- system prompt addendum ---------------------------------------
    def context_block(self) -> str:
        active = self.active()
        if not active:
            return ""
        parts = ["# Active skills — apply these in addition to the base instructions:"]
        for s in active:
            parts.append(f"\n## {s['name']}\n{s['prompt']}")
        return "\n".join(parts)
