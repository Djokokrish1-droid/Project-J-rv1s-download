"""Usage + cost guardrails for public/multi-user deployment.

Tracks per-user message counts and a global daily estimated spend, and enforces:
  - per-user daily message cap
  - global daily spend ceiling (kill-switch)
  - a minimum gap between a user's messages (rate limit)

Costs are *estimates* from token counts — accurate enough for a safety ceiling,
not for accounting. Always also set a hard budget cap in the Anthropic Console.
"""
from __future__ import annotations
import json
import time
from datetime import date
from pathlib import Path

from config import (USAGE_FILE, DAILY_USER_MESSAGE_CAP, DAILY_GLOBAL_COST_CEILING,
                    MIN_SECONDS_BETWEEN_MESSAGES)

# Approximate USD per 1M tokens (input, output). Cache reads billed ~10% of input.
# These are deliberately conservative estimates; tune as prices change.
PRICING = {
    "claude-haiku-4-5-20251001": (1.0, 5.0),
    "claude-sonnet-4-6":         (3.0, 15.0),
    "claude-opus-4-7":           (15.0, 75.0),
}
_DEFAULT_PRICE = (3.0, 15.0)


def estimate_cost(model: str, usage) -> float:
    """Estimate USD cost of one API response from its usage object."""
    if usage is None:
        return 0.0
    in_p, out_p = PRICING.get(model, _DEFAULT_PRICE)
    inp = getattr(usage, "input_tokens", 0) or 0
    out = getattr(usage, "output_tokens", 0) or 0
    cache_read = getattr(usage, "cache_read_input_tokens", 0) or 0
    cache_write = getattr(usage, "cache_creation_input_tokens", 0) or 0
    # cache reads ~0.1x input price; cache writes ~1.25x input price
    cost = (inp * in_p
            + out * out_p
            + cache_read * in_p * 0.1
            + cache_write * in_p * 1.25) / 1_000_000
    return round(cost, 6)


class UsageGuard:
    def __init__(self, path: Path = USAGE_FILE):
        self.path = path
        self.data = {"date": str(date.today()), "global_cost": 0.0, "users": {}}
        if path.exists():
            try:
                self.data = json.loads(path.read_text())
            except json.JSONDecodeError:
                pass
        self._roll_day()

    def _roll_day(self) -> None:
        today = str(date.today())
        if self.data.get("date") != today:
            self.data = {"date": today, "global_cost": 0.0, "users": {}}
            self._save()

    def _save(self) -> None:
        self.path.write_text(json.dumps(self.data, indent=2))

    def _user(self, uid: str) -> dict:
        return self.data["users"].setdefault(uid, {"count": 0, "cost": 0.0, "last_ts": 0.0})

    def check(self, uid: str, cap: int | None = None) -> tuple[bool, str | None]:
        """Return (allowed, refusal_message). `cap` overrides the default per-user
        daily message cap (used for plan-based limits)."""
        self._roll_day()
        limit = cap if cap is not None else DAILY_USER_MESSAGE_CAP
        # global kill-switch
        if self.data["global_cost"] >= DAILY_GLOBAL_COST_CEILING:
            return False, ("J@rv1s has hit its daily usage budget and is paused until "
                           "tomorrow to keep costs in check. Thanks for understanding.")
        u = self._user(uid)
        now = time.time()
        if now - u["last_ts"] < MIN_SECONDS_BETWEEN_MESSAGES:
            return False, "You're sending messages a little fast — give it a second and try again."
        if u["count"] >= limit:
            return False, (f"You've reached today's limit of {limit} messages. "
                           "Upgrade to Pro for more, or come back tomorrow.")
        return True, None

    def touch(self, uid: str) -> None:
        """Mark a message as started (counts toward the cap, sets rate-limit clock)."""
        self._roll_day()
        u = self._user(uid)
        u["count"] += 1
        u["last_ts"] = time.time()
        self._save()

    def record_cost(self, uid: str, cost: float) -> None:
        self._roll_day()
        self.data["global_cost"] = round(self.data["global_cost"] + cost, 6)
        self._user(uid)["cost"] = round(self._user(uid)["cost"] + cost, 6)
        self._save()

    def stats(self) -> dict:
        self._roll_day()
        return {
            "date": self.data["date"],
            "global_cost_est": round(self.data["global_cost"], 4),
            "ceiling": DAILY_GLOBAL_COST_CEILING,
            "user_cap": DAILY_USER_MESSAGE_CAP,
            "active_users": len(self.data["users"]),
        }
