# Deploying J@rv1s for everyone

This guide takes the local app and puts it online as a multi-user web app where
**you provide the AI** (your API key pays for everyone). Read the cost section
first — this is real money.

---

## 0. Before anything: set a hard spend cap ⚠️

You are billed for every message every user sends. **Set a budget limit now:**

1. Go to the [Anthropic Console](https://console.anthropic.com) → **Settings → Limits**.
2. Set a **monthly spend limit** you're comfortable losing (e.g. $20).
3. Add a payment method with that limit.

J@rv1s also has its own guardrails (a daily $ kill-switch and per-user message
caps), but the Console limit is your real backstop. Use both.

---

## 1. What "hosted mode" changes

Setting `JARVIS_HOSTED=true`:
- Requires every visitor to **sign up / log in**; each user gets isolated projects, chats, and memory.
- **Disables** browser automation, desktop control, and voice (those only make sense on your own Mac).
- **Locks everyone to Mini J@r (Haiku)** — the cheapest model.
- Enforces the **daily spend ceiling** + **per-user message cap**.

## 2. Push the code to GitHub

```bash
cd ~/jarvis
git init && git add -A && git commit -m "J@rv1s"
# create a repo on github.com, then:
git remote add origin https://github.com/<you>/jarvis.git
git push -u origin main
```

`.env` and `data/` are git-ignored, so your API key and user data are never committed. Good.

## 3. Deploy on Render (free tier)

1. Go to [render.com](https://render.com) → **New + → Blueprint**.
2. Connect your GitHub repo. Render reads `render.yaml` automatically.
3. When prompted, set the secret env var **`ANTHROPIC_API_KEY`** to your key.
   (`JARVIS_SECRET` is auto-generated; `JARVIS_HOSTED=true` and the caps are preset.)
4. Click **Apply**. First build takes a few minutes.
5. You get a URL like `https://jarvis-xxxx.onrender.com`. That's your live app.

The build uses `requirements-web.txt` (slim — no Chromium/desktop deps), so it's fast.

### Alternatives
- **Railway / Fly.io**: same idea — Python service, start command from the `Procfile`, set the three env vars.
- **Docker** (any host): `docker build -t jarvis . && docker run -p 8000:8000 -e ANTHROPIC_API_KEY=… -e JARVIS_SECRET=… -e JARVIS_HOSTED=true jarvis`

## 4. Verify

- Visit your URL → you should see the **J@rv1s sign-in screen**.
- Create an account, send a message — it should stream a reply.
- Open the app in a private window, make a second account — its projects should be **separate**.
- Hit your-url`/api/usage` — shows today's estimated spend and the ceiling.

## 5. Tuning the guardrails

Set these env vars on the host to taste:

| Variable | Default | Meaning |
|---|---|---|
| `JARVIS_DAILY_COST_CEILING` | `5.0` | Stop serving everyone once estimated spend hits this many USD/day |
| `JARVIS_USER_DAILY_CAP` | `40` | Max messages per user per day |
| `JARVIS_MIN_GAP` | `1.5` | Min seconds between one user's messages |
| `JARVIS_HOSTED_MODEL` | Haiku | Which model everyone is locked to |

## 5b. Subscriptions (hard paywall, two tiers)

In hosted mode J@rv1s is **subscription-only** — a new account can't send a single
message until it's on a plan. Two tiers, each a Stripe **Payment Link**:

| Plan | Price | Messages/day | Web automation |
|---|---|---|---|
| Starter | $10/mo | 20 | no |
| Professional | $22.99/mo | 100 | yes |

> ⚠️ **Age note:** Stripe requires the account holder to be 18+. You can build/test
> in **test mode** now; real payments need a parent/guardian as the verified holder.

1. In Stripe, create two **Products** (Starter, Professional) each with a recurring price.
2. For each, **Create a Payment Link**. Copy both URLs.
3. **Developers → Webhooks → add endpoint** → `https://your-app/api/billing/webhook`,
   events: `checkout.session.completed`, `customer.subscription.updated`,
   `customer.subscription.deleted`. Copy the signing secret (`whsec_…`).
4. Set env vars on your host:
   ```
   STRIPE_PAYMENT_LINK_STARTER=https://buy.stripe.com/…
   STRIPE_PAYMENT_LINK_PRO=https://buy.stripe.com/…
   STRIPE_WEBHOOK_SECRET=whsec_…
   JARVIS_STARTER_PRICE=$10/mo
   JARVIS_PRO_PRICE=$22.99/mo
   JARVIS_STARTER_CAP=20
   JARVIS_PRO_CAP=100
   JARVIS_REQUIRE_SUB=true
   ```

**How the link maps a payment to a user:** when a logged-in user clicks Subscribe,
J@rv1s appends `?client_reference_id=<their-id>__<tier>` to the Payment Link. Stripe
echoes that back in the `checkout.session.completed` webhook, which flips that exact
account to the right tier. Cancellations come through `customer.subscription.deleted`
and revoke access automatically.

Test with card `4242 4242 4242 4242` (any future expiry/CVC). To test the webhook
locally, use the Stripe CLI: `stripe listen --forward-to localhost:5005/api/billing/webhook`.

Go live: switch Stripe to live mode (adult holder), regenerate the Payment Links +
webhook secret in live mode, and swap the env vars.

## 6. Things to know (honest caveats)

- **Free tiers sleep.** Render's free service spins down after inactivity; the first request after a nap takes ~30–60s to wake.
- **One worker.** The config runs a single gunicorn worker with threads — plenty for a launch, not for thousands of concurrent users. Scale workers up only if you also move usage tracking to a database.
- **Data lives on a disk.** `render.yaml` mounts a 1 GB disk at `data/` so accounts/projects persist across deploys. On other hosts, attach persistent storage or user data resets on redeploy.
- **You're running a service.** You're responsible for the bill and for other people's data/conversations. Keep the spend cap on, and don't collect more than you need.

---

That's it. Local desktop use is unaffected — `python main.py desktop` still runs the
full-power version (Opus, browser, voice) on your own machine.
