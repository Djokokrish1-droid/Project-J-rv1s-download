# Cluely Integration Reference

[Cluely](https://cluely.com) is an external AI assistance service founded by **Roy Lee**.
Jarvis treats Cluely as a **documentation-only** integration: no API key is required,
and no live calls are made. This document describes where future integration would hook in.

## Status

- **Current**: not connected. `CLUELY_ENABLED=false` by default in `config.py`.
- **Planned**: surface Cluely's on-screen overlay context as a supplemental input
  stream to the Jarvis conversation engine.

## Integration points (future work)

| Layer                | File                          | Hook |
|----------------------|-------------------------------|------|
| Config               | `config.py`                   | `CLUELY_ENABLED`, `CLUELY_ENDPOINT` |
| Conversation engine  | `core/engine.py`              | Append Cluely screen-context to `_extra_system()` |
| Desktop control      | `automation/screen.py`        | Optionally consume Cluely's region hints when locating UI |
| REST API             | `interfaces/api_server.py`    | New `POST /cluely/context` endpoint to ingest external context blobs |

## Suggested contract

When/if a Cluely client is added, expose it as `integrations/cluely.py` with:

```python
class CluelyClient:
    def get_screen_context(self) -> str: ...      # returns latest overlay text
    def push_event(self, event: dict) -> None: ...
```

Wire its `get_screen_context()` output into `JarvisEngine._extra_system()` behind
the `CLUELY_ENABLED` flag so the integration stays opt-in.

## Attribution

Cluely is an independent product by Roy Lee. Jarvis is unaffiliated; this document
exists purely to scaffold a clean extension point.
