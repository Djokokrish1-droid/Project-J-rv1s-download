"""Anthropic Claude API wrapper.

Uses prompt caching on the system prompt so repeated turns are cheap, and
retries transient API errors (rate limits, overload, network blips).
"""
from __future__ import annotations
import time
import anthropic

from config import ANTHROPIC_API_KEY, CLAUDE_MODEL, MAX_TOKENS, SYSTEM_PROMPT

_MAX_RETRIES = 4


def _is_retryable(exc: Exception) -> bool:
    if isinstance(exc, (anthropic.APIConnectionError, anthropic.APITimeoutError,
                        anthropic.RateLimitError)):
        return True
    if isinstance(exc, anthropic.APIStatusError):
        return getattr(exc, "status_code", 0) in (408, 409, 429, 500, 502, 503, 529)
    return False


class APIUnavailable(Exception):
    """Raised after retries are exhausted, with a user-friendly message."""


class ClaudeClient:
    def __init__(self, api_key: str | None = None, model: str | None = None):
        key = api_key or ANTHROPIC_API_KEY
        if not key:
            raise RuntimeError(
                "ANTHROPIC_API_KEY is not set. Add it to your environment or .env file."
            )
        self.client = anthropic.Anthropic(api_key=key)
        self.model = model or CLAUDE_MODEL
        self.last_usage = None   # usage object from the most recent call (for cost tracking)

    def _system_blocks(self, extra_system: str | None) -> list[dict]:
        # Base prompt is always cached. The extra block (project context, file
        # contents, skills) is usually the largest part and stays stable within a
        # conversation, so cache it too — repeated turns then read it from cache
        # instead of re-billing the full token count.
        if extra_system:
            return [
                {"type": "text", "text": SYSTEM_PROMPT,
                 "cache_control": {"type": "ephemeral"}},
                {"type": "text", "text": extra_system,
                 "cache_control": {"type": "ephemeral"}},
            ]
        return [{"type": "text", "text": SYSTEM_PROMPT,
                 "cache_control": {"type": "ephemeral"}}]

    def create(self, **kwargs):
        """messages.create with exponential-backoff retries on transient errors."""
        delay = 1.0
        last = None
        for attempt in range(_MAX_RETRIES):
            try:
                resp = self.client.messages.create(**kwargs)
                self.last_usage = getattr(resp, "usage", None)
                return resp
            except Exception as exc:  # noqa: BLE001
                last = exc
                if not _is_retryable(exc) or attempt == _MAX_RETRIES - 1:
                    break
                time.sleep(delay)
                delay *= 2
        raise APIUnavailable(self._friendly(last)) from last

    def chat(self, messages: list[dict], extra_system: str | None = None) -> str:
        resp = self.create(
            model=self.model,
            max_tokens=MAX_TOKENS,
            system=self._system_blocks(extra_system),
            messages=messages,
        )
        return "".join(
            b.text for b in resp.content if getattr(b, "type", "") == "text"
        )

    def chat_stream(self, messages: list[dict], extra_system: str | None = None):
        """Yields text chunks. Retries only if the stream fails before any token
        is produced (so we never duplicate already-shown text)."""
        delay = 1.0
        last = None
        for attempt in range(_MAX_RETRIES):
            produced = False
            try:
                with self.client.messages.stream(
                    model=self.model,
                    max_tokens=MAX_TOKENS,
                    system=self._system_blocks(extra_system),
                    messages=messages,
                ) as stream:
                    for text in stream.text_stream:
                        produced = True
                        yield text
                    try:
                        self.last_usage = stream.get_final_message().usage
                    except Exception:
                        self.last_usage = None
                return
            except Exception as exc:  # noqa: BLE001
                last = exc
                if produced or not _is_retryable(exc) or attempt == _MAX_RETRIES - 1:
                    break
                time.sleep(delay)
                delay *= 2
        raise APIUnavailable(self._friendly(last)) from last

    @staticmethod
    def _friendly(exc: Exception | None) -> str:
        if isinstance(exc, anthropic.RateLimitError):
            return "I'm being rate-limited right now. Give it a few seconds and try again."
        if isinstance(exc, anthropic.AuthenticationError):
            return "API key looks invalid or expired. Check ANTHROPIC_API_KEY in your .env."
        if isinstance(exc, (anthropic.APIConnectionError, anthropic.APITimeoutError)):
            return "I couldn't reach the API — looks like a network hiccup. Try again in a moment."
        if isinstance(exc, anthropic.APIStatusError) and getattr(exc, "status_code", 0) == 529:
            return "The model is overloaded right now. Try again shortly, or switch to a lighter model."
        return f"Something went wrong talking to the API: {exc}"
