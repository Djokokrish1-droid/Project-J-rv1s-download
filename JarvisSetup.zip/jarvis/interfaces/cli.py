"""Claude-Code-style CLI for J@rv1s.

Visual conventions:
  ⏺  marks an assistant turn
  ▸  marks the user prompt (entered via prompt_toolkit)
  Slash commands appear in a tab-completed menu.
  A persistent bottom toolbar shows model + active project + skills.
  Responses stream in real time, then re-render as rich Markdown.
"""
from __future__ import annotations
import sys
import time
import traceback
from datetime import datetime

from rich.console import Console
from rich.markdown import Markdown
from rich.text import Text
from rich.rule import Rule
from rich.live import Live
from rich import box
from rich.table import Table
from rich.padding import Padding
from prompt_toolkit import PromptSession
from prompt_toolkit.history import FileHistory
from prompt_toolkit.completion import WordCompleter
from prompt_toolkit.styles import Style as PTStyle
from prompt_toolkit.formatted_text import HTML

from core.engine import JarvisEngine
from config import DATA_DIR

console = Console()

# ────────────────────────────────────────────────────────────
# Styles
# ────────────────────────────────────────────────────────────
C_ACCENT = "bright_cyan"
C_MUTED = "grey50"
C_DIM = "grey35"
C_USER = "bold white"
C_DOT = "bright_cyan"
C_OK = "bright_green"
C_WARN = "yellow"
C_ERR = "bright_red"

DOT = "⏺"
ARROW = "❯"

# Big block JARVIS, drawn in a blue→cyan gradient
JARVIS_ART = [
    r"     ██╗ █████╗ ██████╗ ██╗   ██╗██╗███████╗",
    r"     ██║██╔══██╗██╔══██╗██║   ██║██║██╔════╝",
    r"     ██║███████║██████╔╝██║   ██║██║███████╗",
    r"██   ██║██╔══██║██╔══██╗╚██╗ ██╔╝██║╚════██║",
    r"╚█████╔╝██║  ██║██║  ██║ ╚████╔╝ ██║███████║",
    r" ╚════╝ ╚═╝  ╚═╝╚═╝  ╚═╝  ╚═══╝  ╚═╝╚══════╝",
]


def _grad_hex(t: float) -> str:
    """Interpolate blue (#2563eb) → cyan (#00d9ff) at t in [0,1]."""
    r = int(0x25 + (0x00 - 0x25) * t)
    g = int(0x63 + (0xd9 - 0x63) * t)
    b = int(0xeb + (0xff - 0xeb) * t)
    return f"#{r:02x}{g:02x}{b:02x}"

SLASH_COMMANDS = [
    "/help", "/quit", "/exit", "/reset",
    "/project", "/project new", "/project use", "/project list", "/project show",
    "/projects",
    "/new", "/conversations",
    "/assign", "/done", "/upcoming",
    "/upload", "/search",
    "/skills", "/skill enable", "/skill disable", "/skill toggle",
    "/model",
    "/remember", "/pref", "/feedback",
    "/voice",
    "/clear",
]


class JarvisCLI:
    def __init__(self):
        self.engine = JarvisEngine()
        self._voice = None
        self.session = PromptSession(
            history=FileHistory(str(DATA_DIR / "cli_history")),
            completer=WordCompleter(SLASH_COMMANDS, ignore_case=True, sentence=True),
            style=PTStyle.from_dict({
                "prompt": "ansicyan bold",
                "bottom-toolbar": "fg:#7a7a8a bg:#11111a",
                "bottom-toolbar.accent": "fg:#00d9ff bold",
                "bottom-toolbar.warn": "fg:#ffb454",
            }),
            bottom_toolbar=self._toolbar,
        )

    # ────────────────────────────────────────────────────────
    # Status toolbar (persistent at bottom of terminal)
    # ────────────────────────────────────────────────────────
    def _toolbar(self):
        e = self.engine
        n_skills = sum(1 for s in e.skills.list() if s["enabled"])
        active = e.active_project or "—"
        conv = ""
        if e.active_project and e.active_conversation_id:
            c = e.projects.get_conversation(e.active_project, e.active_conversation_id)
            if c: conv = f"  ↳  <bottom-toolbar.accent>{c['title'][:32]}</bottom-toolbar.accent>"
        return HTML(
            f"  <bottom-toolbar.accent>J@rv1s</bottom-toolbar.accent>  "
            f"<style fg='#5a5a6a'>·</style>  "
            f"model <bottom-toolbar.accent>{e.claude.model}</bottom-toolbar.accent>  "
            f"<style fg='#5a5a6a'>·</style>  "
            f"project <bottom-toolbar.accent>{active}</bottom-toolbar.accent>{conv}  "
            f"<style fg='#5a5a6a'>·</style>  "
            f"<style fg='#b794f6'>skills {n_skills}</style>"
        )

    # ────────────────────────────────────────────────────────
    # Rendering helpers
    # ────────────────────────────────────────────────────────
    def _banner(self):
        e = self.engine
        console.print()
        # big blue JARVIS block art, gradient per line
        n = len(JARVIS_ART)
        for i, line in enumerate(JARVIS_ART):
            console.print(Text("  " + line, style=f"bold {_grad_hex(i / (n - 1))}"))
        console.print(
            Text("        ", style=C_DIM)
            + Text("your homework AI  ·  ", style=C_DIM)
            + Text("Personal Agent", style=C_ACCENT)
        )
        console.print()
        console.print(
            Text("  ", style=C_DIM)
            + Text(f"{datetime.now().strftime('%A, %B %-d')}", style="white")
            + Text(f"  ·  model ", style=C_DIM)
            + Text(e.claude.model, style=C_ACCENT)
            + Text(f"  ·  ", style=C_DIM)
            + Text(f"{len(e.projects.list())} projects", style="white")
            + Text(f"  ·  ", style=C_DIM)
            + Text(f"{sum(1 for s in e.skills.list() if s['enabled'])} skills enabled",
                   style="white")
        )
        # Tips
        console.print(
            Text("  ", style=C_DIM)
            + Text("Type ", style=C_DIM)
            + Text("/help", style=C_ACCENT)
            + Text(" for commands  ·  ", style=C_DIM)
            + Text("/quit", style=C_ACCENT)
            + Text(" to exit  ·  Tab for completions", style=C_DIM)
        )
        console.print()

    def _user_echo(self, text: str):
        # User text already shown via prompt; just space below.
        pass

    def _stream_reply(self, gen):
        """Show a spinner until the first token, then stream chunks under a ⏺ marker."""
        accumulated = []
        first = True
        status = console.status("[bright_cyan]J@rv1s is thinking…[/]", spinner="dots")
        status.start()
        try:
            for chunk in gen:
                if first:
                    status.stop()
                    console.print(Text(f" {DOT} ", style=C_DOT), end="")
                    first = False
                accumulated.append(chunk)
                sys.stdout.write(chunk)
                sys.stdout.flush()
        except KeyboardInterrupt:
            if first:
                status.stop()
            console.print(Text("\n  [interrupted]", style=C_WARN))
            return "".join(accumulated)
        finally:
            if first:
                status.stop()
        sys.stdout.write("\n")
        sys.stdout.flush()
        console.print()
        return "".join(accumulated)

    # ────────────────────────────────────────────────────────
    # Slash commands
    # ────────────────────────────────────────────────────────
    def _split(self, args: str, n: int) -> list[str]:
        parts = [p.strip() for p in args.split("|")]
        return parts + [""] * (n - len(parts))

    def _help(self):
        t = Table(box=box.SIMPLE_HEAD, show_header=True, header_style=f"bold {C_ACCENT}",
                  border_style=C_DIM, padding=(0, 1))
        t.add_column("Command", style=f"bold {C_ACCENT}", no_wrap=True)
        t.add_column("Description", style="white")
        rows = [
            ("/help", "show this help"),
            ("/quit", "exit J@rv1s"),
            ("/clear", "clear the screen"),
            ("/reset", "delete the current conversation"),
            ("", ""),
            ("/projects", "list every project"),
            ("/project use <name>", "switch active project"),
            ("/project new <name>", "create a project"),
            ("/project show [name]", "show details"),
            ("/new [title]", "start a new conversation in the active project"),
            ("/conversations", "list this project's conversations"),
            ("", ""),
            ("/assign <p> | <title> | <YYYY-MM-DD> [| notes]", "add assignment"),
            ("/done <p> | <title>", "mark complete"),
            ("/upcoming [days]", "list upcoming work"),
            ("/upload <p> <path>", "attach file"),
            ("/search <q>", "search projects + files"),
            ("", ""),
            ("/skills", "list skills"),
            ("/skill toggle <id>", "enable/disable a skill"),
            ("/model [id]", "show or switch model"),
            ("", ""),
            ("/remember <fact>", "long-term memory"),
            ("/pref <key> <value>", "preference"),
            ("/feedback <text>", "feedback"),
            ("/voice", "voice turn (listen → respond → speak)"),
        ]
        for cmd, desc in rows:
            if cmd == "":
                t.add_row("", "")
            else:
                t.add_row(cmd, desc)
        console.print(t)
        console.print(Text("\n  Anything not starting with / goes to Claude.\n", style=C_DIM))

    def _show_projects(self):
        ps = self.engine.projects.list()
        if not ps:
            console.print(Text("  No projects yet. Try /project new <name>.", style=C_DIM))
            return
        t = Table(box=box.SIMPLE_HEAD, header_style=f"bold {C_ACCENT}",
                  border_style=C_DIM, padding=(0, 1))
        t.add_column("Project", style="bold")
        t.add_column("Description", style="white")
        t.add_column("Chats", justify="right", style=C_ACCENT)
        t.add_column("Open ass.", justify="right", style="yellow")
        for p in ps:
            convs = len(p.get("conversations", []))
            open_a = sum(1 for a in p.get("assignments", []) if not a["done"])
            t.add_row(p["name"], p.get("description", "") or "—",
                      str(convs), str(open_a))
        console.print(t)

    def _show_conversations(self):
        e = self.engine
        if not e.active_project:
            console.print(Text("  /project use <name> first.", style=C_WARN))
            return
        convs = e.projects.conversations(e.active_project)
        if not convs:
            console.print(Text("  No conversations in this project yet.", style=C_DIM))
            return
        t = Table(box=box.SIMPLE_HEAD, header_style=f"bold {C_ACCENT}",
                  border_style=C_DIM, padding=(0, 1))
        t.add_column("#", style=C_DIM)
        t.add_column("Title", style="bold")
        t.add_column("Preview", style="white")
        t.add_column("Updated", style=C_DIM, justify="right")
        for i, c in enumerate(convs, 1):
            ts = datetime.fromtimestamp(c["updated"]).strftime("%b %-d %H:%M")
            t.add_row(str(i), c["title"], (c["preview"] or "")[:60], ts)
        console.print(t)
        console.print(Text(f"\n  Type a number to open, or /new <title> to start fresh.\n",
                          style=C_DIM))

    def _show_skills(self):
        sk = self.engine.skills.list()
        t = Table(box=box.SIMPLE_HEAD, header_style=f"bold {C_ACCENT}",
                  border_style=C_DIM, padding=(0, 1))
        t.add_column("", width=2)
        t.add_column("ID", style=C_ACCENT)
        t.add_column("Name", style="bold")
        t.add_column("Category", style=C_DIM)
        t.add_column("Description", style="white")
        for s in sk:
            mark = f"[{C_OK}]●[/]" if s["enabled"] else f"[{C_DIM}]○[/]"
            t.add_row(mark, s["id"], s["name"], s["category"], s["description"])
        console.print(t)
        console.print(Text(f"\n  /skill toggle <id> to flip a skill on/off.\n", style=C_DIM))

    def _show_upcoming(self, days=14):
        items = self.engine.projects.upcoming(days)
        if not items:
            console.print(Text(f"  Nothing due in the next {days} days.", style=C_DIM))
            return
        t = Table(box=box.SIMPLE_HEAD, header_style=f"bold {C_ACCENT}",
                  border_style=C_DIM, padding=(0, 1))
        t.add_column("Project", style="bold")
        t.add_column("Title", style="white")
        t.add_column("Due", style=C_ACCENT)
        t.add_column("In", justify="right")
        for a in items:
            d = a["days_until"]
            color = "red" if d <= 1 else "yellow" if d <= 3 else "green"
            t.add_row(a["project"], a["title"], a["due"], f"[{color}]{d}d[/{color}]")
        console.print(t)

    # ────────────────────────────────────────────────────────
    # Main dispatch
    # ────────────────────────────────────────────────────────
    def handle(self, line: str) -> bool:
        # Numeric → open Nth conversation in active project
        if line.isdigit() and self.engine.active_project:
            idx = int(line) - 1
            convs = self.engine.projects.conversations(self.engine.active_project)
            if 0 <= idx < len(convs):
                self.engine.open_conversation(self.engine.active_project, convs[idx]["id"])
                console.print(Text(f"  → opened ", style=C_DIM)
                              + Text(convs[idx]["title"], style=C_ACCENT))
                return True

        if not line.startswith("/"):
            return self._chat_turn(line)

        cmd, _, rest = line[1:].partition(" ")
        rest = rest.strip()
        e = self.engine
        try:
            if cmd in ("quit", "exit"):
                return False
            elif cmd == "help":
                self._help()
            elif cmd == "clear":
                console.clear()
                self._banner()
            elif cmd == "reset":
                e.reset_conversation()
                console.print(Text("  conversation cleared.", style=C_OK))
            elif cmd == "projects":
                self._show_projects()
            elif cmd == "project":
                sub, _, sub_rest = rest.partition(" ")
                if sub == "new":
                    meta = e.projects.create(sub_rest)
                    console.print(Text(f"  + created ", style=C_OK) + Text(meta["name"], style=C_ACCENT))
                elif sub == "use":
                    if e.set_project(sub_rest):
                        console.print(Text(f"  → active project: ", style=C_DIM)
                                      + Text(sub_rest, style=C_ACCENT))
                    else:
                        console.print(Text(f"  no such project: {sub_rest}", style=C_ERR))
                elif sub == "list" or sub == "":
                    self._show_projects()
                elif sub == "show":
                    name = sub_rest or e.active_project
                    if not name:
                        console.print(Text("  specify a project or /project use one.", style=C_WARN))
                    else:
                        meta = e.projects.get(name)
                        if meta:
                            console.print(Padding(Markdown(e.projects.context_for(name)), (1, 2)))
                        else:
                            console.print(Text(f"  not found: {name}", style=C_ERR))
                else:
                    console.print(Text(f"  unknown subcommand: /project {sub}", style=C_ERR))
            elif cmd == "new":
                if not e.active_project:
                    console.print(Text("  /project use <name> first.", style=C_WARN))
                else:
                    conv = e.start_new_conversation(e.active_project, rest)
                    console.print(Text(f"  + new chat ", style=C_OK)
                                  + Text(conv["title"], style=C_ACCENT))
            elif cmd == "conversations":
                self._show_conversations()
            elif cmd == "assign":
                proj, title, due, notes = self._split(rest, 4)
                a = e.projects.add_assignment(proj, title, due, notes)
                console.print(Text(f"  + ", style=C_OK)
                              + Text(a["title"], style="bold")
                              + Text(f"  due {a['due']}", style=C_DIM))
            elif cmd == "done":
                proj, title = self._split(rest, 2)
                ok = e.projects.complete_assignment(proj, title)
                console.print(Text("  ✓ done" if ok else "  not found", style=C_OK if ok else C_ERR))
            elif cmd == "upcoming":
                self._show_upcoming(int(rest) if rest else 14)
            elif cmd == "upload":
                proj, _, path = rest.partition(" ")
                dst = e.projects.upload(proj, path)
                console.print(Text(f"  uploaded → {dst}", style=C_OK))
            elif cmd == "search":
                hits = e.projects.search(rest)
                if not hits:
                    console.print(Text("  no matches.", style=C_DIM))
                else:
                    for h in hits:
                        console.print(Text(f"  · {h['project']}  ", style=C_DIM)
                                      + Text(h["match"], style="white"))
            elif cmd == "skills":
                self._show_skills()
            elif cmd == "skill":
                sub, _, sid = rest.partition(" ")
                sid = sid.strip()
                if not sid:
                    console.print(Text("  usage: /skill toggle|enable|disable <id>", style=C_WARN))
                elif sub == "toggle":
                    on = e.skills.toggle(sid)
                    console.print(Text(f"  {sid}: ", style=C_DIM)
                                  + Text("enabled" if on else "disabled",
                                         style=C_OK if on else C_DIM))
                elif sub == "enable":
                    e.skills.enable(sid); console.print(Text(f"  {sid} enabled.", style=C_OK))
                elif sub == "disable":
                    e.skills.disable(sid); console.print(Text(f"  {sid} disabled.", style=C_DIM))
                else:
                    console.print(Text(f"  unknown: /skill {sub}", style=C_ERR))
            elif cmd == "model":
                if not rest:
                    console.print(Text(f"  current: ", style=C_DIM)
                                  + Text(e.claude.model, style=C_ACCENT))
                else:
                    e.claude.model = rest.strip()
                    console.print(Text(f"  model → ", style=C_DIM)
                                  + Text(e.claude.model, style=C_ACCENT))
            elif cmd == "remember":
                e.memory.remember(rest); console.print(Text("  noted.", style=C_OK))
            elif cmd == "pref":
                k, _, v = rest.partition(" ")
                e.memory.set_preference(k, v)
                console.print(Text(f"  pref {k}=", style=C_DIM) + Text(v, style="white"))
            elif cmd == "feedback":
                e.feedback(rest); console.print(Text("  feedback saved.", style=C_OK))
            elif cmd == "voice":
                self._voice_turn()
            else:
                console.print(Text(f"  unknown: /{cmd}  ·  try /help", style=C_ERR))
        except Exception as ex:
            console.print(Text(f"  error: {ex}", style=C_ERR))
            console.print(Text(traceback.format_exc(), style=C_DIM))
        return True

    # ────────────────────────────────────────────────────────
    # Chat turn (streaming)
    # ────────────────────────────────────────────────────────
    def _chat_turn(self, text: str) -> bool:
        console.print()
        try:
            self._stream_reply(self.engine.ask_stream(text))
        except KeyboardInterrupt:
            console.print(Text("\n  [interrupted]", style=C_WARN))
        return True

    def _voice_turn(self):
        if self._voice is None:
            from interfaces.voice import VoiceInterface
            self._voice = VoiceInterface()
        console.print(Text(" 🎙  listening…", style=C_ACCENT))
        text = self._voice.listen()
        if not text:
            console.print(Text("  didn't catch that.", style=C_WARN))
            return
        console.print(Text(f" ▸ {text}", style=C_USER))
        console.print()
        full = self._stream_reply(self.engine.ask_stream(text))
        console.print(Text(" 🔊 speaking…", style=C_DIM))
        self._voice.speak(full)

    # ────────────────────────────────────────────────────────
    # Run loop
    # ────────────────────────────────────────────────────────
    def run(self):
        self._banner()
        while True:
            try:
                line = self.session.prompt(HTML(
                    f"<style fg='ansicyan' bold='true'>{ARROW} </style>"
                )).strip()
            except (EOFError, KeyboardInterrupt):
                console.print()
                break
            if not line:
                continue
            if not self.handle(line):
                break
        console.print()
        console.print(Rule(style=C_DIM))
        console.print(Text("  goodbye.", style=C_DIM, justify="center"))
        console.print()


def main():
    JarvisCLI().run()


if __name__ == "__main__":
    main()
