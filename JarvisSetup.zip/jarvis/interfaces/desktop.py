"""Native desktop window for Jarvis — Flask in a thread, pywebview on the main thread.

This is exactly how Claude Desktop and similar apps work: a local web server
serving a UI, wrapped in a native browser window.

The desktop app runs the full hosted product: accounts, the subscription
paywall, and the admin dashboard. Sign in with your admin account for full,
unrestricted access. (Set JARVIS_HOSTED=false in the environment to run the old
unrestricted local mode instead.)
"""
from __future__ import annotations
import os
import secrets
from pathlib import Path

# Enable the hosted product (paywall + accounts + admin) BEFORE config loads.
os.environ.setdefault("JARVIS_HOSTED", "true")
# This is the user's own machine, so browser/voice automation is allowed here
# (it stays off on the cloud web deploy).
os.environ.setdefault("JARVIS_ALLOW_AUTOMATION", "true")
# Stable session secret so the admin login persists across app restarts.
_SECRET_FILE = Path(__file__).parent.parent / "data" / ".secret"
if not os.environ.get("JARVIS_SECRET"):
    _SECRET_FILE.parent.mkdir(parents=True, exist_ok=True)
    if not _SECRET_FILE.exists():
        _SECRET_FILE.write_text(secrets.token_urlsafe(32))
    os.environ["JARVIS_SECRET"] = _SECRET_FILE.read_text().strip()

import threading
import time
import socket
import logging

import webview

from interfaces.api_server import create_app
from config import API_HOST, API_PORT

ICON_PATH = Path(__file__).parent / "web" / "icon.png"


def _wait_for_port(host: str, port: int, timeout: float = 8.0) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with socket.create_connection((host, port), timeout=0.5):
                return True
        except OSError:
            time.sleep(0.1)
    return False


def _run_flask():
    logging.getLogger("werkzeug").setLevel(logging.WARNING)
    app = create_app()
    app.run(host=API_HOST, port=API_PORT, debug=False, use_reloader=False, threaded=True)


def _set_macos_dock_icon():
    """Override the Dock icon to our generated PNG (macOS only)."""
    try:
        from AppKit import NSApplication, NSImage  # type: ignore
        img = NSImage.alloc().initWithContentsOfFile_(str(ICON_PATH))
        if img:
            NSApplication.sharedApplication().setApplicationIconImage_(img)
    except Exception as ex:
        print(f"[desktop] could not set dock icon: {ex}")


def _on_started():
    # webview calls this after its event loop is running. Safe to touch NSApp here.
    _set_macos_dock_icon()


def main():
    t = threading.Thread(target=_run_flask, daemon=True)
    t.start()
    if not _wait_for_port(API_HOST, API_PORT):
        raise RuntimeError("Backend never came up on http://%s:%d" % (API_HOST, API_PORT))

    webview.create_window(
        title="J@rv1s",
        url=f"http://{API_HOST}:{API_PORT}/",
        width=1280,
        height=820,
        min_size=(900, 600),
        background_color="#08080d",
    )
    # `func` runs after webview's mainloop is up — perfect for setting the dock icon.
    webview.start(_on_started)


if __name__ == "__main__":
    main()
