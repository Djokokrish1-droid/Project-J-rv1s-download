"""Voice I/O: SpeechRecognition for STT, pyttsx3 for TTS."""
from __future__ import annotations
from config import VOICE_RATE


class VoiceInterface:
    def __init__(self, rate: int = VOICE_RATE):
        import pyttsx3
        import speech_recognition as sr
        self.engine = pyttsx3.init()
        self.engine.setProperty("rate", rate)
        self.recognizer = sr.Recognizer()
        self._sr = sr

    def speak(self, text: str) -> None:
        self.engine.say(text)
        self.engine.runAndWait()

    def listen(self, timeout: float = 5.0, phrase_time_limit: float = 15.0) -> str:
        with self._sr.Microphone() as source:
            self.recognizer.adjust_for_ambient_noise(source, duration=0.5)
            audio = self.recognizer.listen(source, timeout=timeout,
                                           phrase_time_limit=phrase_time_limit)
        try:
            return self.recognizer.recognize_google(audio)
        except self._sr.UnknownValueError:
            return ""
        except self._sr.RequestError as e:
            return f"[STT error: {e}]"
