// =====================================================
// JARVIS — frontend logic
// =====================================================
const API = (path, opts) => fetch(path, opts).then(async r => {
  const text = await r.text();
  const data = text ? JSON.parse(text) : {};
  return r.ok ? data : Promise.reject(data);
});

// State
let state = {
  active_project: null,
  active_conversation_id: null,
  model: 'claude-opus-4-7',
  projects: [],
  upcoming: [],
  history: [],
  skills: [],
  browser: { running: false },
};
let currentProjectPage = null;  // name of project currently shown in project view
let models = [];
let speakResponses = false;
let skillFilter = 'all';
let skillSearch = '';

// DOM helpers
const $ = (id) => document.getElementById(id);
const $$ = (sel) => document.querySelectorAll(sel);

// Elements
const chat = $('chat');
const input = $('input');
const sendBtn = $('send-btn');
const voiceBtn = $('voice-btn');
const projectList = $('project-list');
const upcomingList = $('upcoming-list');
const activeProjectDisplay = $('active-project-display');
const modelBadge = $('model-badge');
const modelBadgeName = $('model-badge-name');
const modelDropdown = $('model-dropdown');
const statusDot = $('status-dot');
const statusText = $('status-text');
const projectModal = $('modal-backdrop');
const skillModal = $('skill-modal-backdrop');
const browserToggle = $('browser-toggle');
const voiceOutToggle = $('voice-out-toggle');

marked.setOptions({
  breaks: true,
  gfm: true,
  highlight: (code, lang) => {
    if (lang && hljs.getLanguage(lang)) {
      try { return hljs.highlight(code, { language: lang }).value; } catch {}
    }
    return hljs.highlightAuto(code).value;
  },
});

function escape(s) {
  return String(s).replace(/[&<>"']/g, c => ({
    '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
  }[c]));
}

// =====================================================
// Dynamic welcome screen (randomized every load)
// =====================================================
const USER = 'Krish';

const GREETINGS = [
  'How can I help, {n}?',
  'What are we tackling, {n}?',
  'Systems online. Your move, {n}.',
  'Ready when you are, {n}.',
  "Let's get to work, {n}.",
  "What's the mission, {n}?",
  '{day}, {n}.',
  'Back at it, {n}?',
  'All systems nominal, {n}.',
  'Standing by, {n}.',
  "Let's make today count, {n}.",
  'Online and ready, {n}.',
  'At your service, {n}.',
];

const TAGLINES = [
  'Manage projects, draft work, automate tasks.',
  'Homework, deadlines, and everything in between.',
  'Your second brain for school.',
  'Think faster. Submit smarter.',
  'Four subjects, one assistant.',
  'Less busywork. More learning.',
  'Built to make school effortless.',
  'Your unfair advantage, quietly.',
  'Point me at the hard part.',
];

const SUGGESTION_POOL = [
  { icon: '🎯', title: 'Focus Today', desc: "What's most important right now", prompt: 'What should I focus on today?' },
  { icon: '📅', title: "This Week's Deadlines", desc: 'Surface upcoming work', prompt: 'Show me everything due in the next week.' },
  { icon: '📚', title: 'Plan a Study Block', desc: 'Structure focused time', prompt: 'Help me plan my study session.' },
  { icon: '💡', title: 'Quiz Me', desc: 'Active recall on a topic', prompt: "Quiz me on what I'm currently studying." },
  { icon: '✍️', title: 'Write an Essay', desc: 'Outline then draft', prompt: 'Help me outline and draft an essay. Ask me the topic first.' },
  { icon: '🧮', title: 'Solve a Problem', desc: 'Step-by-step walkthrough', prompt: "I have a homework problem I'm stuck on. Walk me through it." },
  { icon: '📖', title: 'Explain a Concept', desc: 'Simply, then test me', prompt: 'Explain a concept I am struggling with, simply, then test me on it.' },
  { icon: '🗂️', title: 'Summarize Notes', desc: 'Key points to review', prompt: 'Summarize my notes into key points I can review.' },
  { icon: '⚡', title: 'Beat Procrastination', desc: 'A 10-minute starter task', prompt: "I'm procrastinating. Give me a 10-minute task to start right now." },
  { icon: '🔬', title: 'Lab Report Help', desc: 'Structure the writeup', prompt: 'Help me structure a lab report for my science class.' },
  { icon: '🌐', title: 'Research a Topic', desc: 'Find solid sources', prompt: 'Help me research a topic and find credible sources.' },
  { icon: '📝', title: 'Check My Work', desc: 'Point out what to fix', prompt: 'Review what I wrote and point out what to improve.' },
];

function pick(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
function sample(arr, n) {
  const copy = [...arr];
  const out = [];
  while (out.length < n && copy.length) out.push(copy.splice(Math.floor(Math.random() * copy.length), 1)[0]);
  return out;
}
function dayPart() {
  const h = new Date().getHours();
  if (h < 12) return 'Good morning';
  if (h < 18) return 'Good afternoon';
  return 'Good evening';
}

function renderWelcome() {
  const titleEl = $('welcome-title');
  const subEl = $('welcome-sub');
  const sugEl = $('welcome-suggestions');
  const bootEl = $('boot-log');
  if (!titleEl) return;

  // greeting
  const g = pick(GREETINGS).replace('{day}', dayPart()).replace('{n}', `<span class="grad">${USER}</span>`);
  titleEl.innerHTML = g;
  subEl.textContent = pick(TAGLINES);

  // suggestions: 4 random
  sugEl.innerHTML = '';
  sample(SUGGESTION_POOL, 4).forEach((s, i) => {
    const b = document.createElement('button');
    b.className = 'suggestion';
    b.style.animationDelay = `${0.25 + i * 0.07}s`;
    b.innerHTML = `<div class="suggestion-icon">${s.icon}</div>
      <div><div class="suggestion-title">${escape(s.title)}</div>
      <div class="suggestion-desc">${escape(s.desc)}</div></div>`;
    b.addEventListener('click', () => { input.value = s.prompt; autosize(); send(); });
    sugEl.appendChild(b);
  });

  // boot log (typed line-by-line)
  const nP = (state.all_projects || state.projects || []).length;
  const nS = (state.skills || []).filter(s => s.enabled).length;
  const modelName = (models.find(m => m.id === state.model) || {}).name || state.model || 'J@rv1s 1.0';
  const lines = [
    '> booting J@rv1s core ............ <span class="bl-ok">OK</span>',
    '> neural link established ........ <span class="bl-ok">OK</span>',
    `> ${nP} projects synced ............. <span class="bl-ok">OK</span>`,
    `> ${nS} skills armed ............... <span class="bl-ok">OK</span>`,
    `> model <span class="bl-ok">${escape(modelName)}</span> ready`,
  ];
  bootEl.innerHTML = '';
  lines.forEach((ln, i) => {
    setTimeout(() => {
      const d = document.createElement('div');
      d.className = 'bl-line';
      d.innerHTML = ln;
      d.style.animation = 'fadeUp 0.25s ease both';
      bootEl.appendChild(d);
    }, 120 + i * 130);
  });

  wireWelcomeFX();
}

// Cursor-reactive magnetism for the welcome screen
function wireWelcomeFX() {
  const welcome = $('welcome');
  const reactor = welcome && welcome.querySelector('.reactor');
  const title = $('welcome-title');
  const sub = $('welcome-sub');
  if (!welcome || !reactor || welcome.dataset.fxWired) return;
  welcome.dataset.fxWired = '1';

  welcome.addEventListener('mousemove', (e) => {
    const r = reactor.getBoundingClientRect();
    const cx = r.left + r.width / 2;
    const cy = r.top + r.height / 2;
    const dx = (e.clientX - cx) / 22;   // tilt strength
    const dy = (e.clientY - cy) / 22;
    reactor.style.transform = `rotateY(${Math.max(-22, Math.min(22, dx))}deg) rotateX(${Math.max(-22, Math.min(22, -dy))}deg)`;
    // subtle parallax on text
    if (title) title.style.transform = `translate(${dx * 0.25}px, ${dy * 0.25}px)`;
    if (sub) sub.style.transform = `translate(${dx * 0.4}px, ${dy * 0.4}px)`;
  });
  welcome.addEventListener('mouseleave', () => {
    reactor.style.transform = '';
    if (title) title.style.transform = '';
    if (sub) sub.style.transform = '';
  });
  // ---- Proximity-driven spin: slow when far, light-speed at the core ----
  const rings = [
    { el: reactor.querySelector('.ring-1'),       base: 48,  dir: 1,  a: 0 },
    { el: reactor.querySelector('.ring-2'),       base: 70,  dir: -1, a: 0 },
    { el: reactor.querySelector('.ring-3'),       base: 104, dir: 1,  a: 0 },
    { el: reactor.querySelector('.reactor-ticks'),base: 14,  dir: 1,  a: 0 },
  ];
  const glow = reactor.querySelector('.reactor-glow');
  const core = reactor.querySelector('.reactor-core');
  if (glow) glow.style.animation = 'none';  // JS drives glow now (avoid CSS conflict)
  let speed = 1;          // eased current multiplier
  let target = 1;         // proximity-derived multiplier
  let lastT = performance.now();

  window.addEventListener('mousemove', (e) => {
    const r = reactor.getBoundingClientRect();
    if (!r.width) return;
    const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
    const d = Math.hypot(e.clientX - cx, e.clientY - cy);
    const maxDist = 480;
    const prox = Math.max(0, 1 - d / maxDist);   // 0 (far) … 1 (centered)
    // steep curve so it really winds up near the core
    target = 1 + Math.pow(prox, 2.4) * 42;       // up to ~43× near the core
  });
  window.addEventListener('mouseout', (e) => { if (!e.relatedTarget) target = 1; });

  function spinFrame(t) {
    if (!reactor.isConnected) return;            // welcome removed → stop loop
    const dt = Math.min(0.05, (t - lastT) / 1000);
    lastT = t;
    speed += (target - speed) * Math.min(1, dt * 3.5);   // smooth ease
    rings.forEach(ring => {
      if (!ring.el) return;
      ring.a += ring.dir * ring.base * speed * dt;
      ring.el.style.transform = `rotate(${ring.a.toFixed(2)}deg)`;
    });
    // glow + core intensify with speed
    const intensity = Math.min(1, (speed - 1) / 42);
    if (glow) {
      glow.style.opacity = (0.5 + intensity * 0.5).toFixed(3);
      glow.style.transform = `scale(${(0.95 + intensity * 0.5).toFixed(3)})`;
    }
    if (core) core.style.filter = `brightness(${(1 + intensity * 0.8).toFixed(2)})`;
    requestAnimationFrame(spinFrame);
  }
  requestAnimationFrame(spinFrame);

  // 3D tilt on each suggestion card
  welcome.querySelectorAll('.suggestion').forEach(card => {
    card.addEventListener('mousemove', (e) => {
      const r = card.getBoundingClientRect();
      const px = (e.clientX - r.left) / r.width - 0.5;
      const py = (e.clientY - r.top) / r.height - 0.5;
      card.style.transform =
        `perspective(600px) rotateX(${(-py * 12).toFixed(2)}deg) rotateY(${(px * 12).toFixed(2)}deg) translateY(-3px) scale(1.03)`;
    });
    card.addEventListener('mouseleave', () => { card.style.transform = ''; });
  });
}

// =====================================================
// Auth (hosted mode)
// =====================================================
let authMode = 'login';
const authOverlay = $('auth-overlay');

function showAuth() { authOverlay.classList.remove('hidden'); $('auth-username').focus(); }
function hideAuth() { authOverlay.classList.add('hidden'); }

function setAuthMode(mode) {
  authMode = mode;
  const signup = mode === 'signup';
  $('auth-sub').textContent = signup ? 'Create your Personal Agent account' : 'Sign in to your Personal Agent';
  $('auth-submit').textContent = signup ? 'Create Account' : 'Sign In';
  $('auth-switch-text').textContent = signup ? 'Already have an account?' : 'New here?';
  $('auth-switch-link').textContent = signup ? 'Sign in' : 'Create an account';
  $('auth-password').setAttribute('autocomplete', signup ? 'new-password' : 'current-password');
  $('auth-confirm-wrap').style.display = signup ? 'block' : 'none';  // confirm only on signup
  $('auth-confirm').value = '';
  $('auth-error').textContent = '';
}

// show / hide password (controls both password + confirm)
let pwVisible = false;
const pwToggle = $('auth-pw-toggle');
if (pwToggle) pwToggle.addEventListener('click', () => {
  pwVisible = !pwVisible;
  const t = pwVisible ? 'text' : 'password';
  $('auth-password').type = t;
  $('auth-confirm').type = t;
  pwToggle.querySelector('.eye').style.display = pwVisible ? 'none' : 'block';
  pwToggle.querySelector('.eye-off').style.display = pwVisible ? 'block' : 'none';
});

async function submitAuth() {
  const username = $('auth-username').value.trim();
  const password = $('auth-password').value;
  if (!username || !password) { $('auth-error').textContent = 'Enter a username and password.'; return; }
  const isSignup = authMode === 'signup';
  if (isSignup && password !== $('auth-confirm').value) {
    $('auth-error').textContent = 'Passwords don’t match.';
    return;
  }
  try {
    await API(`/api/auth/${isSignup ? 'signup' : 'login'}`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password }),
    });
    hideAuth();
    $('auth-password').value = '';
    if (isSignup) { tutIndex = 0; showTutorial(); }   // new users get the tour → plans
    else boot();
  } catch (e) {
    $('auth-error').textContent = e.error || 'Something went wrong.';
  }
}

if (authOverlay) {
  $('auth-submit').addEventListener('click', submitAuth);
  $('auth-password').addEventListener('keydown', (e) => {
    if (e.key !== 'Enter') return;
    if (authMode === 'signup') $('auth-confirm').focus(); else submitAuth();
  });
  $('auth-confirm').addEventListener('keydown', (e) => { if (e.key === 'Enter') submitAuth(); });
  $('auth-username').addEventListener('keydown', (e) => { if (e.key === 'Enter') $('auth-password').focus(); });
  $('auth-switch-link').addEventListener('click', () => setAuthMode(authMode === 'login' ? 'signup' : 'login'));
}

// =====================================================
// Boot
// =====================================================
async function boot() {
  try {
    state = await API('/api/state');
    models = await API('/api/models');
    statusDot.classList.add('ok');
    statusText.textContent = 'connected';
    applyTheme(state.theme || 'dark');
    renderSidebar();
    renderActiveProject();
    renderModel();
    renderBrowserToggle();
    renderSkillsPage();
    renderAllProjects();
    // Hard paywall: if subscription required and not subscribed, gate the app.
    const gated = await loadBilling();
    if (gated) { showPaywall(); return; }
    hidePaywall();
    renderTrialAndAdmin();
    if (state.hosted) applyHostedMode(billingInfo);
    if (state.history && state.history.length > 0) {
      clearChat();
      state.history.forEach(m => appendMessage(m.role, m.content));
    } else {
      renderWelcome();
    }
  } catch (e) {
    if (e && e.auth) { showAuth(); return; }   // hosted mode, not logged in
    statusDot.classList.add('bad');
    statusText.textContent = 'offline';
    console.error('boot failed', e);
  }
}

// Hosted build: hide machine-control by plan. Admins keep everything.
function applyHostedMode(info) {
  const admin = !!(info && info.is_admin);
  const plan = info && info.plan;
  const automation = !!state.automation;   // only the desktop app allows machine control
  const canBrowse = automation && (admin || plan === 'professional' || plan === 'max');
  const showVoice = automation && admin;   // voice uses the local mic (desktop only)
  const hide = (id, cond) => { const el = $(id); if (el) el.style.display = cond ? 'none' : ''; };
  hide('browser-toggle', !canBrowse);
  hide('safesites-toggle', !canBrowse);
  hide('voice-out-toggle', !showVoice);
  hide('voice-btn', !showVoice);
  hide('project-voice-btn', !showVoice);
  // model is tier-driven server-side; lock the picker
  const mp = $('model-picker'); if (mp) mp.style.pointerEvents = 'none';
  const chev = modelBadge && modelBadge.querySelector('svg'); if (chev) chev.style.display = 'none';
}

// =====================================================
// Billing / subscription paywall
// =====================================================
const paywall = $('paywall-overlay');
let billingInfo = null;

// Returns true if the app is gated (user must subscribe before using it).
async function loadBilling() {
  try {
    billingInfo = await API('/api/billing/status');
  } catch { billingInfo = null; return false; }
  renderPlans();
  return billingInfo.require_subscription && !billingInfo.subscribed;
}

function renderPlans() {
  const wrap = $('paywall-plans');
  if (!wrap || !billingInfo) return;
  wrap.innerHTML = '';
  (billingInfo.plans || []).forEach(p => {
    const [amt, per] = (p.price || '').split('/');
    const isCurrent = billingInfo.plan === p.id;
    const isPro = p.id === 'professional';
    const card = document.createElement('div');
    card.className = 'pw-card' + (isPro ? ' pro featured' : '') + (p.id === 'max' ? ' pro' : '') + (isCurrent ? ' current' : '');
    const tag = isPro ? '<span class="pw-tag">★ 7-DAY FREE TRIAL</span>'
              : p.id === 'max' ? '<span class="pw-tag">Max power</span>' : '';
    const cta = isCurrent ? 'Current plan' : isPro ? 'Start 7-Day Free Trial' : 'Subscribe';
    card.innerHTML = `
      ${tag}
      <div class="pw-name">${escape(p.name)}</div>
      <div class="pw-price">${escape(amt)}${per ? `<span>/${escape(per)}</span>` : ''}</div>
      <ul>${p.features.map(f => `<li>${escape(f)}</li>`).join('')}</ul>
      <button class="primary-btn">${cta}</button>`;
    const btn = card.querySelector('button');
    if (isCurrent) { btn.disabled = true; btn.style.opacity = '0.6'; }
    else btn.addEventListener('click', () => startCheckout(p.id));
    wrap.appendChild(card);
  });
}

function showPaywall() { paywall.classList.remove('hidden'); }
function hidePaywall() { paywall.classList.add('hidden'); }

// ---- Onboarding tutorial ----
const tutorial = $('tutorial-overlay');
const TUT_SLIDES = [
  { icon: '🤖', title: 'Welcome to <span class="grad">J@rv1s</span>', text: 'Your personal AI agent for school. Here’s a 30-second tour of what you can do.' },
  { icon: '📚', title: 'Subject Projects', text: 'Math, English, History & Science come built in. Each keeps its own chats, deadlines, uploaded worksheets, and instructions.' },
  { icon: '✨', title: 'Skills', text: 'Toggle behaviors like Undetectable (natural student writing), Humanizer, Concise, and Tutor mode — or build your own.' },
  { icon: '🎙️', title: 'Voice & Web Automation', text: 'Talk to J@rv1s hands-free, and on higher plans let it drive a real browser to do tasks for you.' },
  { icon: '⌘', title: 'Fast Everywhere', text: 'Hit ⌘K for the command palette to jump anywhere. Upload files, set deadlines, switch subjects in a keystroke.' },
  { icon: '🚀', title: 'Pick Your Plan', text: 'One last step — choose a plan to unlock J@rv1s. Professional starts with a 7-day free trial.' },
];
let tutIndex = 0;
function renderTutorial() {
  const s = TUT_SLIDES[tutIndex];
  $('tut-body').innerHTML = `<div class="tut-icon">${s.icon}</div>
    <div class="tut-title">${s.title}</div><div class="tut-text">${s.text}</div>`;
  $('tut-dots').innerHTML = TUT_SLIDES.map((_, i) => `<span class="dot ${i === tutIndex ? 'on' : ''}"></span>`).join('');
  $('tut-back').style.visibility = tutIndex === 0 ? 'hidden' : 'visible';
  $('tut-next').textContent = tutIndex === TUT_SLIDES.length - 1 ? 'See plans →' : 'Next';
}
function showTutorial() { tutorial.classList.remove('hidden'); renderTutorial(); }
function hideTutorial() { tutorial.classList.add('hidden'); }
function finishTutorial() { hideTutorial(); boot(); }   // boot → gated → paywall
if (tutorial) {
  $('tut-next').addEventListener('click', () => {
    if (tutIndex < TUT_SLIDES.length - 1) { tutIndex++; renderTutorial(); }
    else finishTutorial();
  });
  $('tut-back').addEventListener('click', () => { if (tutIndex > 0) { tutIndex--; renderTutorial(); } });
  $('tut-skip').addEventListener('click', finishTutorial);
}

function renderTrialAndAdmin() {
  // trial banner
  const banner = $('trial-banner');
  if (banner && billingInfo && billingInfo.trial && billingInfo.trial.trialing) {
    const d = billingInfo.trial.days_left;
    banner.textContent = `★ ${d} day${d === 1 ? '' : 's'} left in your Pro trial — Subscribe`;
    banner.style.display = 'block';
    banner.onclick = showPaywall;
  } else if (banner) {
    banner.style.display = 'none';
  }
  // admin nav
  const navAdmin = $('nav-admin');
  if (navAdmin) navAdmin.style.display = (billingInfo && billingInfo.is_admin) ? 'flex' : 'none';
}

// admin dashboard
async function loadAdmin() {
  const grid = $('admin-stats');
  if (!grid) return;
  grid.innerHTML = '<div class="stat-card"><div class="stat-label">Loading…</div></div>';
  try {
    const s = await API('/api/admin/stats');
    const u = s.usage || {};
    const cards = [
      ['Total users', s.total_users, ''],
      ['Paying', s.paying, `${s.paid_starter} starter · ${s.paid_professional} pro`],
      ['On trial', s.trialing, 'free Pro trials'],
      ['MRR', `$${s.mrr}`, 'monthly recurring', true],
      ["Today's spend (est)", `$${(u.global_cost_est ?? 0)}`, `ceiling $${u.ceiling ?? '—'}`],
      ['Active today', u.active_users ?? 0, 'users who messaged'],
    ];
    grid.innerHTML = cards.map(([label, val, sub, money]) => `
      <div class="stat-card">
        <div class="stat-label">${escape(label)}</div>
        <div class="stat-value ${money ? 'money' : ''}">${escape(String(val))}</div>
        ${sub ? `<div class="stat-sub">${escape(sub)}</div>` : ''}
      </div>`).join('');
    $('admin-note').textContent = `Estimated daily margin: $${(s.mrr / 30 - (u.global_cost_est || 0)).toFixed(2)} (MRR/30 − today's spend). Spend is an estimate; trust the Anthropic Console for exact billing.`;
  } catch (e) {
    grid.innerHTML = `<div class="stat-card"><div class="stat-label">Error</div><div class="stat-sub">${escape(e.error || 'failed')}</div></div>`;
  }
}
const adminRefresh = $('admin-refresh');
if (adminRefresh) adminRefresh.addEventListener('click', loadAdmin);

// =====================================================
// Settings
// =====================================================
async function loadSettings() {
  try {
    const a = await API('/api/account');
    $('set-username').textContent = a.username || '—';
    const planName = ({ none: 'No active plan', starter: 'Starter', professional: 'Professional', max: 'Max' })[a.plan] || a.plan;
    const trial = a.trial && a.trial.trialing ? ` · ${a.trial.days_left}d trial left` : '';
    $('set-plan').textContent = planName + trial;
    // hide account-only controls in local (non-hosted) mode
    const local = !state.hosted;
    ['set-change-pw', 'set-logout', 'set-delete', 'set-manage'].forEach(id => {
      const el = $(id); if (el) el.style.display = local ? 'none' : '';
    });
  } catch (e) { /* ignore */ }
}

const pwModal = $('password-modal-backdrop');
function bindSettings() {
  $('set-theme') && $('set-theme').addEventListener('click', () => themeToggle && themeToggle.click());
  $('set-logout') && $('set-logout').addEventListener('click', async () => {
    if (!confirm('Sign out?')) return;
    await API('/api/auth/logout', { method: 'POST' }); location.reload();
  });
  $('set-manage') && $('set-manage').addEventListener('click', () => {
    if (billingInfo && billingInfo.subscribed) openPortal(); else showPaywall();
  });
  $('set-export') && $('set-export').addEventListener('click', () => { window.location.href = '/api/account/export'; });
  $('set-clear') && $('set-clear').addEventListener('click', resetConversation);
  $('set-delete') && $('set-delete').addEventListener('click', async () => {
    if (!confirm('Delete your account and ALL data? This cannot be undone.')) return;
    if (!confirm('Really delete everything permanently?')) return;
    await API('/api/account/delete', { method: 'POST' });
    location.reload();
  });
  $('set-change-pw') && $('set-change-pw').addEventListener('click', () => {
    pwModal.classList.remove('hidden'); $('pw-old').focus();
  });
  $('pw-cancel') && $('pw-cancel').addEventListener('click', () => {
    pwModal.classList.add('hidden'); $('pw-old').value = ''; $('pw-new').value = ''; $('pw-error').textContent = '';
  });
  $('pw-save') && $('pw-save').addEventListener('click', async () => {
    try {
      await API('/api/account/password', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ old: $('pw-old').value, new: $('pw-new').value }),
      });
      pwModal.classList.add('hidden'); $('pw-old').value = ''; $('pw-new').value = '';
      $('pw-error').textContent = '';
      alert('Password updated.');
    } catch (e) { $('pw-error').textContent = e.error || 'Could not update password.'; }
  });
  pwModal && pwModal.addEventListener('click', (e) => { if (e.target === pwModal) pwModal.classList.add('hidden'); });
}
bindSettings();

async function startCheckout(tier) {
  const note = $('paywall-note');
  if (!billingInfo || !billingInfo.enabled) {
    note.textContent = 'Payments aren’t switched on yet (Stripe link not set).';
    return;
  }
  note.textContent = 'Opening secure checkout…';
  try {
    const r = await API('/api/billing/checkout', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ tier }),
    });
    if (r.url) window.location.href = r.url;
  } catch (e) { note.textContent = e.error || 'Could not start checkout.'; }
}

async function refreshSubscription() {
  const note = $('paywall-note');
  note.textContent = 'Checking…';
  const gated = await loadBilling();
  if (!gated) { hidePaywall(); boot(); }
  else note.textContent = "No active subscription found yet. If you just paid, give it a few seconds.";
}

if (paywall) {
  $('paywall-refresh').addEventListener('click', refreshSubscription);
  $('paywall-back').addEventListener('click', () => { hidePaywall(); tutIndex = 0; showTutorial(); });
  $('paywall-signout').addEventListener('click', async () => {
    await API('/api/auth/logout', { method: 'POST' }); location.reload();
  });
}

// returning from Stripe: poll a few times for the webhook to land
if (location.search.includes('upgraded=1')) {
  let tries = 0;
  const poll = setInterval(async () => {
    tries++;
    const gated = await loadBilling();
    if (!gated || tries > 6) { clearInterval(poll); if (!gated) { hidePaywall(); } }
  }, 2000);
}

// =====================================================
// View switching
// =====================================================
function switchView(view) {
  document.body.dataset.view = view;
  $$('.nav-item').forEach(el => {
    // highlight the matching view item; highlight New chat when on chat view
    const isActive = el.dataset.view === view ||
                     (view === 'chat' && el.dataset.action === 'new-chat');
    el.classList.toggle('active', isActive);
  });
  if (view === 'admin') loadAdmin();
  if (view === 'settings') loadSettings();
}

async function newChat() {
  // leave any project context and start a clean global conversation
  await API('/api/projects/clear', { method: 'POST' });
  await API('/api/reset', { method: 'POST' });
  state.active_project = null;
  state.active_conversation_id = null;
  currentProjectPage = null;
  switchView('chat');
  clearChat();
  location.reload();
}

$$('.nav-item').forEach(el => {
  el.addEventListener('click', () => {
    if (el.dataset.action === 'new-chat') newChat();
    else if (el.dataset.view) switchView(el.dataset.view);
  });
});

// =====================================================
// Chat rendering
// =====================================================
function clearChat() { chat.innerHTML = ''; }

function appendMessage(role, content) {
  const welcome = chat.querySelector('.welcome');
  if (welcome) welcome.remove();

  const wrap = document.createElement('div');
  wrap.className = `msg ${role}`;

  const avatar = document.createElement('div');
  avatar.className = 'msg-avatar';
  avatar.textContent = role === 'user' ? 'K' : 'J';

  const body = document.createElement('div');
  body.className = 'msg-body';

  const roleEl = document.createElement('div');
  roleEl.className = 'msg-role';
  roleEl.textContent = role === 'user' ? 'You' : 'J@rv1s';

  const contentEl = document.createElement('div');
  contentEl.className = 'msg-content';
  if (role === 'assistant') {
    contentEl.innerHTML = marked.parse(content);
    contentEl.querySelectorAll('pre code').forEach(b => hljs.highlightElement(b));
  } else {
    contentEl.textContent = content;
  }

  body.appendChild(roleEl);
  body.appendChild(contentEl);
  wrap.appendChild(avatar);
  wrap.appendChild(body);
  chat.appendChild(wrap);
  chat.scrollTop = chat.scrollHeight;
  return contentEl;
}

function appendTyping() {
  const welcome = chat.querySelector('.welcome');
  if (welcome) welcome.remove();
  const wrap = document.createElement('div');
  wrap.className = 'msg assistant';
  wrap.id = 'typing-msg';
  wrap.innerHTML = `
    <div class="msg-avatar">J</div>
    <div class="msg-body">
      <div class="msg-role">J@rv1s</div>
      <div class="msg-content"><div class="typing"><span></span><span></span><span></span></div></div>
    </div>`;
  chat.appendChild(wrap);
  chat.scrollTop = chat.scrollHeight;
}
function removeTyping() { const t = $('typing-msg'); if (t) t.remove(); }

// =====================================================
// Sidebar
// =====================================================
function renderSidebar() {
  // Projects
  projectList.innerHTML = '';
  if (state.projects.length === 0) {
    projectList.innerHTML = '<div style="padding:8px 10px;color:var(--text-dim);font-size:12px">No projects yet</div>';
  } else {
    state.projects.forEach(p => {
      const el = document.createElement('div');
      el.className = 'project-item' + (p.name === state.active_project ? ' active' : '');
      const open = p.assignments.filter(a => !a.done).length;
      el.innerHTML = `<span class="name">${escape(p.name)}</span>${open > 0 ? `<span class="count">${open}</span>` : ''}`;
      el.onclick = () => useProject(p.name);
      projectList.appendChild(el);
    });
  }

  // Upcoming
  upcomingList.innerHTML = '';
  if (state.upcoming.length === 0) {
    upcomingList.innerHTML = '<div style="padding:8px 10px;color:var(--text-dim);font-size:12px">Nothing soon</div>';
  } else {
    state.upcoming.slice(0, 6).forEach(a => {
      const cls = a.days_until <= 1 ? 'urgent' : a.days_until <= 3 ? 'soon' : 'fine';
      const el = document.createElement('div');
      el.className = 'upcoming-item';
      el.innerHTML = `
        <div class="title">${escape(a.title)}</div>
        <div class="meta">
          <span>${escape(a.project)}</span>
          <span class="days ${cls}">${a.days_until}d</span>
        </div>`;
      upcomingList.appendChild(el);
    });
  }

  // Skill count badge in nav
  const enabledCount = (state.skills || []).filter(s => s.enabled).length;
  const navCount = $('nav-skill-count');
  navCount.textContent = enabledCount;
  navCount.classList.toggle('show', enabledCount > 0);
}

function renderActiveProject() {
  if (state.active_project) {
    activeProjectDisplay.innerHTML = `<span class="muted">In</span> <strong class="ap-label">${escape(state.active_project)}</strong>`;
  } else {
    activeProjectDisplay.innerHTML = `<strong class="ap-label">General Chat</strong>`;
  }
}

// =====================================================
// Model picker
// =====================================================
function modelClass(id) {
  if (id === 'claude-opus-4-7') return 'm-opus';
  if (id === 'claude-haiku-4-5-20251001') return 'm-haiku';
  if (id === 'claude-sonnet-4-6') return 'm-sonnet';
  return '';
}

function renderModel() {
  const current = models.find(m => m.id === state.model);
  modelBadgeName.textContent = current ? current.name : state.model;
  modelBadgeName.className = 'm-name ' + modelClass(state.model);
  modelDropdown.innerHTML = '';
  models.forEach(m => {
    const opt = document.createElement('div');
    opt.className = 'model-option' + (m.id === state.model ? ' active' : '');
    opt.innerHTML = `
      <div class="top">
        <span class="name m-name ${modelClass(m.id)}">${escape(m.name)}</span>
        <span class="check">✓</span>
      </div>
      <span class="desc">${escape(m.desc)}</span>`;
    opt.onclick = async () => {
      try {
        await API('/api/model', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ model: m.id }),
        });
        state.model = m.id;
        modelDropdown.classList.add('hidden');
        renderModel();
      } catch (e) { alert(e.error || 'Failed to switch model'); }
    };
    modelDropdown.appendChild(opt);
  });
}

modelBadge.addEventListener('click', (e) => {
  e.stopPropagation();
  modelDropdown.classList.toggle('hidden');
});
document.addEventListener('click', (e) => {
  if (!e.target.closest('#model-picker')) modelDropdown.classList.add('hidden');
});

// =====================================================
// Browser automation toggle
// =====================================================
function renderBrowserToggle() {
  const on = !!(state.browser && state.browser.armed);
  browserToggle.classList.toggle('on', on);
  const safe = $('safesites-toggle');
  if (safe) {
    safe.classList.toggle('on', !!(state.browser && state.browser.restricted));
    safe.style.display = on ? 'flex' : 'none';   // only show when armed
  }
}

browserToggle.addEventListener('click', async () => {
  const on = browserToggle.classList.contains('on');
  browserToggle.classList.add('loading');
  try {
    const res = await API(`/api/browser/${on ? 'disable' : 'enable'}`, { method: 'POST' });
    state.browser = res;
    renderBrowserToggle();
  } catch (e) {
    // arming never launches a browser, so this should basically never fail
    console.warn('browser toggle', e);
  } finally {
    browserToggle.classList.remove('loading');
  }
});

// theme toggle
function applyTheme(theme) {
  document.body.dataset.theme = theme;
  const t = $('theme-toggle');
  if (t) t.classList.toggle('on', theme === 'light');
}
const themeToggle = $('theme-toggle');
if (themeToggle) themeToggle.addEventListener('click', async () => {
  const next = (document.body.dataset.theme === 'light') ? 'dark' : 'light';
  applyTheme(next);
  state.theme = next;
  await API('/api/theme', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ theme: next }),
  });
});

const safeToggle = $('safesites-toggle');
if (safeToggle) safeToggle.addEventListener('click', async () => {
  const on = safeToggle.classList.contains('on');
  const res = await API('/api/browser/restrict', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ restricted: !on }),
  });
  state.browser = res;
  renderBrowserToggle();
});

// =====================================================
// Voice-out toggle (speak responses)
// =====================================================
voiceOutToggle.addEventListener('click', () => {
  speakResponses = !speakResponses;
  voiceOutToggle.classList.toggle('on', speakResponses);
});

async function speak(text) {
  try {
    await API('/api/voice/speak', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text }),
    });
  } catch (e) { console.warn('TTS failed', e); }
}

// =====================================================
// Send / chat
// =====================================================
async function send(opts = {}) {
  const text = (opts.text ?? input.value).trim();
  if (!text) return;
  if (!opts.text) {
    input.value = '';
    input.style.height = 'auto';
  }
  sendBtn.disabled = true;
  sendBtn.classList.add('loading');

  appendMessage('user', text);
  appendTyping();

  try {
    await streamReply(text, !!(speakResponses || opts.alwaysSpeak));
  } catch (e) {
    removeTyping();
    appendMessage('assistant', `**Error:** ${e.error || e.message || JSON.stringify(e)}`);
  } finally {
    sendBtn.disabled = false;
    sendBtn.classList.remove('loading');
    input.focus();
  }
}

// Stream the assistant reply token-by-token via SSE; render markdown live.
async function streamReply(message, doSpeak) {
  const resp = await fetch('/api/chat/stream', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ message }),
  });
  if (!resp.ok || !resp.body) {
    // fall back to non-streaming
    removeTyping();
    const res = await API('/api/chat', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message }),
    });
    appendMessage('assistant', res.reply);
    if (doSpeak) speak(res.reply);
    return;
  }

  removeTyping();
  const contentEl = appendMessage('assistant', '');
  contentEl.classList.add('streaming');

  const reader = resp.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';
  let full = '';

  // throttle markdown re-render for smoothness
  let pending = false;
  const renderNow = () => {
    contentEl.innerHTML = marked.parse(full);
    contentEl.querySelectorAll('pre code').forEach(b => hljs.highlightElement(b));
    contentEl.classList.add('streaming');
    chat.scrollTop = chat.scrollHeight;
    pending = false;
  };

  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split('\n\n');
    buffer = lines.pop();
    for (const line of lines) {
      const m = line.match(/^data: (.*)$/s);
      if (!m) continue;
      let payload;
      try { payload = JSON.parse(m[1]); } catch { continue; }
      if (payload.t) {
        full += payload.t;
        if (!pending) { pending = true; requestAnimationFrame(renderNow); }
      } else if (payload.error) {
        full += `\n\n**Error:** ${payload.error}`;
      }
    }
  }
  full = full || '…';
  contentEl.innerHTML = marked.parse(full);
  contentEl.querySelectorAll('pre code').forEach(b => hljs.highlightElement(b));
  contentEl.classList.remove('streaming');
  chat.scrollTop = chat.scrollHeight;
  if (doSpeak) speak(full);
}

// =====================================================
// Projects
// =====================================================
async function useProject(name) {
  // Activate the project on the backend, then open the project view.
  const r = await API(`/api/projects/${encodeURIComponent(name)}/use`, { method: 'POST' });
  state.active_project = name;
  state.active_conversation_id = r.conversation_id || null;
  renderSidebar();
  renderActiveProject();
  await openProjectPage(name);
}

async function openProjectPage(name) {
  currentProjectPage = name;
  switchView('project');
  // skeleton while loading
  $('project-title-display').textContent = name;
  $('project-suggestions').innerHTML =
    Array(6).fill('<div class="skeleton skel-card"></div>').join('');
  $('project-recents').innerHTML =
    Array(3).fill('<div class="skeleton skel-card"></div>').join('');
  // load detail + conversations + suggestions + files in parallel
  const [meta, convs, sugg, files] = await Promise.all([
    API(`/api/projects/${encodeURIComponent(name)}`),
    API(`/api/projects/${encodeURIComponent(name)}/conversations`),
    API(`/api/projects/${encodeURIComponent(name)}/suggestions`),
    API(`/api/projects/${encodeURIComponent(name)}/files`),
  ]);
  renderProjectPage(meta, convs, sugg, files);
}

function fmtBytes(n) {
  if (n < 1024) return n + ' B';
  if (n < 1048576) return (n / 1024).toFixed(0) + ' KB';
  return (n / 1048576).toFixed(1) + ' MB';
}

async function uploadFiles(fileList) {
  if (!currentProjectPage || !fileList.length) return;
  const fd = new FormData();
  for (const f of fileList) fd.append('file', f);
  await fetch(`/api/projects/${encodeURIComponent(currentProjectPage)}/files`, {
    method: 'POST', body: fd,
  });
  openProjectPage(currentProjectPage);  // refresh
}

async function deleteFile(fname) {
  if (!currentProjectPage) return;
  await API(`/api/projects/${encodeURIComponent(currentProjectPage)}/files/${encodeURIComponent(fname)}`, { method: 'DELETE' });
  openProjectPage(currentProjectPage);
}

function renderProjectPage(meta, convs, suggestions, files = []) {
  $('project-title-display').textContent = meta.name;
  $('project-conv-count').textContent = `${convs.length} chat${convs.length === 1 ? '' : 's'}`;

  // instructions card
  const ib = $('instructions-body');
  ib.textContent = meta.instructions || meta.description || 'No instructions yet. Click the pencil to add some.';
  ib.dataset.value = meta.instructions || '';

  // assignments card
  const ab = $('assignments-body');
  ab.innerHTML = '';
  const assigns = meta.assignments || [];
  if (!assigns.length) {
    ab.innerHTML = '<div class="muted-body" style="padding:0">No deadlines yet.</div>';
  } else {
    assigns.forEach(a => {
      const row = document.createElement('div');
      row.className = 'assign-row' + (a.done ? ' done' : '');
      row.innerHTML = `
        <button class="assign-check" title="Toggle complete">${a.done ? '✓' : ''}</button>
        <div class="assign-info">
          <div class="assign-title">${escape(a.title)}</div>
          <div class="assign-due">due ${escape(a.due)}${a.notes ? ' · ' + escape(a.notes) : ''}</div>
        </div>`;
      row.querySelector('.assign-check').addEventListener('click', async () => {
        await API(`/api/projects/${encodeURIComponent(meta.name)}/assignments/complete`, {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ title: a.title }),
        });
        openProjectPage(meta.name); refreshState();
      });
      ab.appendChild(row);
    });
  }

  // scheduled card
  const scb = $('scheduled-body');
  scb.innerHTML = '';
  const sched = meta.scheduled || [];
  if (!sched.length) {
    scb.innerHTML = '<div class="muted-body" style="padding:0">No recurring tasks.</div>';
  } else {
    sched.forEach((s, i) => {
      const row = document.createElement('div');
      row.className = 'assign-row';
      row.innerHTML = `<div class="assign-info">
          <div class="assign-title">${escape(s.title)}</div>
          <div class="assign-due">${escape(s.cadence)}</div>
        </div>
        <button class="fi-del" title="Remove">×</button>`;
      row.querySelector('.fi-del').addEventListener('click', async () => {
        await API(`/api/projects/${encodeURIComponent(meta.name)}/scheduled/${i}`, { method: 'DELETE' });
        openProjectPage(meta.name);
      });
      scb.appendChild(row);
    });
  }

  // context card: files + drop zone
  const cb = $('context-body');
  cb.innerHTML = '';
  cb.insertAdjacentHTML('beforeend', `<div class="label">Files (${files.length})</div>`);
  if (files.length) {
    files.forEach(f => {
      const row = document.createElement('div');
      row.className = 'context-item file-item';
      row.innerHTML = `<span class="fi-name">📄 ${escape(f.name)}</span>
        <span class="fi-meta">${fmtBytes(f.size)}</span>
        <button class="fi-del" title="Remove">×</button>`;
      row.querySelector('.fi-del').addEventListener('click', () => deleteFile(f.name));
      cb.appendChild(row);
    });
  }
  const drop = document.createElement('label');
  drop.className = 'dropzone';
  drop.innerHTML = `<input type="file" multiple hidden>
    <span>＋ Drop files or click to upload</span>`;
  const fileInput = drop.querySelector('input');
  fileInput.addEventListener('change', () => uploadFiles(fileInput.files));
  ['dragenter', 'dragover'].forEach(ev => drop.addEventListener(ev, (e) => {
    e.preventDefault(); drop.classList.add('drag');
  }));
  ['dragleave', 'drop'].forEach(ev => drop.addEventListener(ev, (e) => {
    e.preventDefault(); drop.classList.remove('drag');
  }));
  drop.addEventListener('drop', (e) => uploadFiles(e.dataTransfer.files));
  cb.appendChild(drop);
  cb.insertAdjacentHTML('beforeend', '<div class="label" style="margin-top:10px">Memory</div>');
  cb.insertAdjacentHTML('beforeend', `<div class="context-item">🧠 Personal memory + preferences</div>`);

  // suggestions
  const sg = $('project-suggestions');
  sg.innerHTML = '';
  suggestions.forEach((s, i) => {
    const b = document.createElement('button');
    b.className = 'suggestion-chip';
    b.style.animationDelay = `${i * 0.05}s`;
    b.innerHTML = `<span class="chip-icon">${s.icon}</span><span>${escape(s.title)}</span>`;
    b.addEventListener('click', () => startConversationWith(s.prompt));
    sg.appendChild(b);
  });

  // recents
  const rl = $('project-recents');
  rl.innerHTML = '';
  if (convs.length === 0) {
    rl.innerHTML = '<div class="recents-empty">No conversations yet. Start one above ↑</div>';
  } else {
    convs.forEach((c, i) => {
      const card = document.createElement('div');
      card.className = 'recent-card';
      card.style.animationDelay = `${i * 0.04}s`;
      card.innerHTML = `
        <div class="recent-icon">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
          </svg>
        </div>
        <div class="recent-info">
          <div class="recent-title">${escape(c.title)}</div>
          ${c.preview ? `<div class="recent-preview">${escape(c.preview)}</div>` : ''}
        </div>
        <div class="recent-time">${timeAgo(c.updated)}</div>`;
      card.addEventListener('click', () => openConversation(meta.name, c.id));
      rl.appendChild(card);
    });
  }
}

function timeAgo(ts) {
  if (!ts) return '';
  const s = Date.now() / 1000 - ts;
  if (s < 60) return 'just now';
  if (s < 3600) return Math.floor(s / 60) + ' min ago';
  if (s < 86400) return Math.floor(s / 3600) + ' hr ago';
  if (s < 604800) return Math.floor(s / 86400) + ' days ago';
  return new Date(ts * 1000).toLocaleDateString();
}

async function startConversationWith(text) {
  if (!currentProjectPage) return;
  // create a new conversation and send the seed message
  await API(`/api/projects/${encodeURIComponent(currentProjectPage)}/conversations`, { method: 'POST' });
  // refresh state so active_conversation_id is set
  state = await API('/api/state');
  switchView('chat');
  clearChat();
  await send({ text });
  renderChatBreadcrumb();
}

async function startNewConversation() {
  if (!currentProjectPage) return;
  await API(`/api/projects/${encodeURIComponent(currentProjectPage)}/conversations`, { method: 'POST' });
  state = await API('/api/state');
  switchView('chat');
  clearChat();
  renderChatBreadcrumb();
  input.focus();
}

async function openConversation(project, cid) {
  await API(`/api/projects/${encodeURIComponent(project)}/conversations/${cid}/open`, { method: 'POST' });
  state = await API('/api/state');
  switchView('chat');
  clearChat();
  if (state.history && state.history.length) {
    state.history.forEach(m => appendMessage(m.role, m.content));
  }
  renderChatBreadcrumb();
}

function renderChatBreadcrumb() {
  const back = $('chat-back-btn');
  const disp = $('active-project-display');
  if (state.active_project) {
    back.classList.remove('hidden');
    back.textContent = `← ${state.active_project}`;
    disp.innerHTML = `<span class="muted">In</span> <strong class="ap-label">${escape(state.active_project)}</strong>`;
  } else {
    back.classList.add('hidden');
    disp.innerHTML = `<strong class="ap-label">General Chat</strong>`;
  }
}

async function newProject(name, description) {
  await API('/api/projects', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, description }),
  });
  await refreshState();
}

async function refreshState() {
  state = await API('/api/state');
  renderSidebar();
  renderActiveProject();
  renderBrowserToggle();
  renderSkillsPage();
  renderAllProjects();
}

function renderAllProjects() {
  const grid = $('all-projects-grid');
  if (!grid) return;
  grid.innerHTML = '';
  (state.all_projects || []).forEach((p, i) => {
    const open = p.assignments.filter(a => !a.done).length;
    const convs = (p.conversations || []).length;
    const pinned = p.pinned !== false;
    const card = document.createElement('div');
    card.className = 'project-card';
    card.style.animationDelay = `${i * 0.05}s`;
    card.innerHTML = `
      <div class="pc-actions">
        <button class="pc-action pin ${pinned ? 'pinned' : ''}" data-action="pin" title="${pinned ? 'Unpin' : 'Pin'}">📌</button>
        <button class="pc-action delete" data-action="delete" title="Delete">🗑</button>
      </div>
      <div class="pc-name">${escape(p.name)}</div>
      <div class="pc-desc">${escape(p.description || '')}</div>
      <div class="pc-stats">
        <span><strong>${convs}</strong> chats</span>
        <span><strong>${open}</strong> open</span>
        <span><strong>${p.assignments.length}</strong> total</span>
      </div>`;
    card.addEventListener('click', (e) => {
      if (e.target.closest('.pc-action')) return;
      useProject(p.name);
    });
    card.querySelector('[data-action="pin"]').addEventListener('click', async (e) => {
      e.stopPropagation();
      await API(`/api/projects/${encodeURIComponent(p.name)}/pin`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pinned: !pinned }),
      });
      await refreshState();
    });
    card.querySelector('[data-action="delete"]').addEventListener('click', async (e) => {
      e.stopPropagation();
      if (!confirm(`Delete "${p.name}" and all its conversations?`)) return;
      await API(`/api/projects/${encodeURIComponent(p.name)}`, { method: 'DELETE' });
      await refreshState();
    });
    grid.appendChild(card);
  });
  if ((state.all_projects || []).length === 0) {
    grid.innerHTML = '<div class="recents-empty">No projects yet. Create one.</div>';
  }
}

async function resetConversation() {
  await API('/api/reset', { method: 'POST' });
  clearChat();
  location.reload();
}

// =====================================================
// Voice (round-trip: listen → chat → speak)
// =====================================================
async function voiceTurn() {
  voiceBtn.classList.add('active');
  try {
    const res = await API('/api/voice/listen', { method: 'POST' });
    if (res.text) {
      await send({ text: res.text, alwaysSpeak: true });
    }
  } catch (e) {
    appendMessage('assistant', `**Voice error:** ${e.error || JSON.stringify(e)}`);
  } finally {
    voiceBtn.classList.remove('active');
  }
}

// =====================================================
// Skills page
// =====================================================
function renderSkillsPage() {
  const skills = (state.skills || []).filter(s => {
    if (skillFilter !== 'all' && s.category !== skillFilter) return false;
    if (skillSearch && !(`${s.name} ${s.description}`.toLowerCase().includes(skillSearch.toLowerCase()))) return false;
    return true;
  });
  const sections = { personal: $('grid-personal'), system: $('grid-system'), custom: $('grid-custom') };
  Object.values(sections).forEach(g => g.innerHTML = '');

  skills.forEach(s => {
    const card = document.createElement('div');
    card.className = 'skill-card' + (s.enabled ? ' enabled' : '') + (s.category === 'custom' ? ' custom' : '');
    card.innerHTML = `
      <div class="skill-icon" style="background: ${s.gradient || 'linear-gradient(135deg,#00d9ff,#b794f6)'}">${s.icon || '✨'}</div>
      <div class="skill-info">
        <div class="skill-name">${escape(s.name)}</div>
        <div class="skill-desc">${escape(s.description)}</div>
      </div>
      ${s.category === 'custom' ? '<button class="skill-delete" title="Delete skill">×</button>' : ''}
      <div class="skill-check">✓</div>`;
    card.addEventListener('click', async (e) => {
      if (e.target.classList.contains('skill-delete')) return;
      const r = await API(`/api/skills/${encodeURIComponent(s.id)}/toggle`, { method: 'POST' });
      const idx = state.skills.findIndex(x => x.id === s.id);
      if (idx >= 0) state.skills[idx].enabled = r.enabled;
      renderSkillsPage();
      renderSidebar();
    });
    const del = card.querySelector('.skill-delete');
    if (del) {
      del.addEventListener('click', async (e) => {
        e.stopPropagation();
        if (!confirm(`Delete "${s.name}"?`)) return;
        await API(`/api/skills/${encodeURIComponent(s.id)}`, { method: 'DELETE' });
        await refreshState();
      });
    }
    sections[s.category]?.appendChild(card);
  });

  // hide empty sections
  $$('.skills-section').forEach(sec => {
    const grid = sec.querySelector('.skills-grid');
    sec.classList.toggle('hidden', grid.children.length === 0);
  });

  // active note in top bar
  const active = (state.skills || []).filter(s => s.enabled);
  const note = $('skills-active-note');
  if (active.length > 0) {
    note.textContent = `${active.length} active`;
  } else {
    note.textContent = '';
  }
}

$('skill-search').addEventListener('input', (e) => {
  skillSearch = e.target.value;
  renderSkillsPage();
});
$$('.pill').forEach(p => {
  p.addEventListener('click', () => {
    $$('.pill').forEach(x => x.classList.remove('active'));
    p.classList.add('active');
    skillFilter = p.dataset.filter;
    renderSkillsPage();
  });
});

// =====================================================
// Modals
// =====================================================
function openNewProjectModal() {
  projectModal.classList.remove('hidden');
  $('np-name').focus();
}
$('new-project-btn').addEventListener('click', openNewProjectModal);
const allNewBtn = $('all-new-project-btn');
if (allNewBtn) allNewBtn.addEventListener('click', openNewProjectModal);
$('np-cancel').addEventListener('click', () => {
  projectModal.classList.add('hidden');
  $('np-name').value = ''; $('np-desc').value = '';
});
$('np-create').addEventListener('click', async () => {
  const name = $('np-name').value.trim();
  if (!name) return;
  try {
    await newProject(name, $('np-desc').value.trim());
    projectModal.classList.add('hidden');
    $('np-name').value = ''; $('np-desc').value = '';
  } catch (e) { alert(e.error || 'Failed to create project'); }
});
projectModal.addEventListener('click', (e) => {
  if (e.target === projectModal) projectModal.classList.add('hidden');
});

$('new-skill-btn').addEventListener('click', () => {
  skillModal.classList.remove('hidden');
  $('ns-name').focus();
});
$('ns-cancel').addEventListener('click', () => {
  skillModal.classList.add('hidden');
  ['ns-name','ns-icon','ns-desc','ns-prompt'].forEach(id => $(id).value = '');
});
$('ns-create').addEventListener('click', async () => {
  const name = $('ns-name').value.trim();
  const prompt = $('ns-prompt').value.trim();
  if (!name || !prompt) { alert('Name and instructions are required.'); return; }
  try {
    await API('/api/skills', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name,
        description: $('ns-desc').value.trim(),
        icon: $('ns-icon').value.trim() || '✨',
        prompt,
      }),
    });
    skillModal.classList.add('hidden');
    ['ns-name','ns-icon','ns-desc','ns-prompt'].forEach(id => $(id).value = '');
    await refreshState();
  } catch (e) { alert(e.error || 'Failed to create skill'); }
});
skillModal.addEventListener('click', (e) => {
  if (e.target === skillModal) skillModal.classList.add('hidden');
});

// =====================================================
// Composer
// =====================================================
function autosize() {
  input.style.height = 'auto';
  input.style.height = Math.min(input.scrollHeight, 220) + 'px';
}
input.addEventListener('input', autosize);
input.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    send();
  }
});
sendBtn.addEventListener('click', () => send());
voiceBtn.addEventListener('click', voiceTurn);
$('reset-btn').addEventListener('click', resetConversation);

// (welcome suggestions are wired dynamically in renderWelcome)

// project-view interactions
$('project-back').addEventListener('click', () => {
  switchView('chat');
});
$('chat-back-btn').addEventListener('click', () => {
  if (currentProjectPage) openProjectPage(currentProjectPage);
  else switchView('chat');
});
$('project-new-conv').addEventListener('click', startNewConversation);

$('project-send-btn').addEventListener('click', () => {
  const t = $('project-input').value.trim();
  if (!t) return;
  $('project-input').value = '';
  startConversationWith(t);
});
$('project-input').addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    $('project-send-btn').click();
  }
});
$('project-voice-btn').addEventListener('click', async () => {
  const btn = $('project-voice-btn');
  btn.classList.add('active');
  try {
    const r = await API('/api/voice/listen', { method: 'POST' });
    if (r.text) {
      $('project-input').value = r.text;
      $('project-send-btn').click();
    }
  } catch (e) { alert('Voice error: ' + (e.error || JSON.stringify(e))); }
  finally { btn.classList.remove('active'); }
});

// assignment modal
const asModal = $('assignment-modal-backdrop');
$('add-assignment-btn').addEventListener('click', () => {
  asModal.classList.remove('hidden'); $('as-title').focus();
});
$('as-cancel').addEventListener('click', () => {
  asModal.classList.add('hidden');
  ['as-title','as-due','as-notes'].forEach(id => $(id).value = '');
});
$('as-create').addEventListener('click', async () => {
  const title = $('as-title').value.trim();
  const due = $('as-due').value;
  if (!title || !due || !currentProjectPage) { alert('Title and due date required.'); return; }
  await API(`/api/projects/${encodeURIComponent(currentProjectPage)}/assignments`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ title, due, notes: $('as-notes').value.trim() }),
  });
  asModal.classList.add('hidden');
  ['as-title','as-due','as-notes'].forEach(id => $(id).value = '');
  openProjectPage(currentProjectPage); refreshState();
});
asModal.addEventListener('click', (e) => { if (e.target === asModal) asModal.classList.add('hidden'); });

// scheduled modal
const scModal = $('scheduled-modal-backdrop');
$('add-scheduled-btn').addEventListener('click', () => {
  scModal.classList.remove('hidden'); $('sc-title').focus();
});
$('sc-cancel').addEventListener('click', () => { scModal.classList.add('hidden'); $('sc-title').value = ''; });
$('sc-create').addEventListener('click', async () => {
  const title = $('sc-title').value.trim();
  if (!title || !currentProjectPage) { alert('Describe the task.'); return; }
  await API(`/api/projects/${encodeURIComponent(currentProjectPage)}/scheduled`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ title, cadence: $('sc-cadence').value }),
  });
  scModal.classList.add('hidden'); $('sc-title').value = '';
  openProjectPage(currentProjectPage);
});
scModal.addEventListener('click', (e) => { if (e.target === scModal) scModal.classList.add('hidden'); });

// instructions modal
const instrModal = $('instructions-modal-backdrop');
$('edit-instructions-btn').addEventListener('click', () => {
  $('instr-text').value = $('instructions-body').dataset.value || '';
  instrModal.classList.remove('hidden');
  $('instr-text').focus();
});
$('instr-cancel').addEventListener('click', () => instrModal.classList.add('hidden'));
$('instr-save').addEventListener('click', async () => {
  const text = $('instr-text').value;
  if (!currentProjectPage) return;
  await fetch(`/api/projects/${encodeURIComponent(currentProjectPage)}/instructions`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ instructions: text }),
  });
  instrModal.classList.add('hidden');
  await openProjectPage(currentProjectPage);  // refresh
});
instrModal.addEventListener('click', (e) => { if (e.target === instrModal) instrModal.classList.add('hidden'); });

// =====================================================
// ⌘K Command palette
// =====================================================
const palette = $('palette-backdrop');
const paletteInput = $('palette-input');
const paletteList = $('palette-list');
let paletteCmds = [];
let paletteSel = 0;

function buildPaletteCommands() {
  const c = [];
  c.push({ label: 'New Chat', hint: 'chat', run: newChat });
  c.push({ label: 'Go to Projects', hint: 'view', run: () => switchView('projects') });
  c.push({ label: 'Go to Skills', hint: 'view', run: () => switchView('skills') });
  c.push({ label: 'Back to Chat', hint: 'view', run: () => switchView('chat') });
  (state.all_projects || state.projects || []).forEach(p =>
    c.push({ label: `Open ${p.name}`, hint: 'project', run: () => useProject(p.name) }));
  models.forEach(m =>
    c.push({ label: `Model → ${m.name}`, hint: 'model', run: async () => {
      await API('/api/model', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ model: m.id }) });
      state.model = m.id; renderModel();
    }}));
  (state.skills || []).forEach(s =>
    c.push({ label: `${s.enabled ? 'Disable' : 'Enable'} skill: ${s.name}`, hint: 'skill', run: async () => {
      const r = await API(`/api/skills/${encodeURIComponent(s.id)}/toggle`, { method: 'POST' });
      const i = state.skills.findIndex(x => x.id === s.id); if (i >= 0) state.skills[i].enabled = r.enabled;
      renderSkillsPage(); renderSidebar();
    }}));
  c.push({ label: 'Open Settings', hint: 'view', run: () => switchView('settings') });
  c.push({ label: 'Toggle Appearance (Light / Dark)', hint: 'theme', run: () => themeToggle && themeToggle.click() });
  c.push({ label: 'Toggle Browser Automation', hint: 'browser', run: () => browserToggle.click() });
  c.push({ label: 'New Project', hint: 'create', run: openNewProjectModal });
  c.push({ label: 'Reset Conversation', hint: 'danger', run: resetConversation });
  if (state.hosted) c.push({ label: 'Sign Out', hint: 'account', run: async () => {
    await API('/api/auth/logout', { method: 'POST' }); location.reload();
  }});
  return c;
}

function renderPalette(filter = '') {
  const f = filter.toLowerCase();
  const items = paletteCmds.filter(c => c.label.toLowerCase().includes(f));
  paletteSel = Math.min(paletteSel, Math.max(0, items.length - 1));
  paletteList.innerHTML = '';
  if (!items.length) {
    paletteList.innerHTML = '<div class="palette-empty">No matching commands</div>';
    paletteList._items = [];
    return;
  }
  items.forEach((c, i) => {
    const el = document.createElement('div');
    el.className = 'palette-item' + (i === paletteSel ? ' sel' : '');
    el.innerHTML = `<span>${escape(c.label)}</span><span class="pi-hint">${escape(c.hint)}</span>`;
    el.addEventListener('click', () => { closePalette(); c.run(); });
    el.addEventListener('mousemove', () => { paletteSel = i; [...paletteList.children].forEach((x, j) => x.classList.toggle('sel', j === i)); });
    paletteList.appendChild(el);
  });
  paletteList._items = items;
}

function openPalette() {
  paletteCmds = buildPaletteCommands();
  paletteSel = 0;
  palette.classList.remove('hidden');
  paletteInput.value = '';
  renderPalette('');
  paletteInput.focus();
}
function closePalette() { palette.classList.add('hidden'); }

paletteInput.addEventListener('input', () => { paletteSel = 0; renderPalette(paletteInput.value); });
paletteInput.addEventListener('keydown', (e) => {
  const items = paletteList._items || [];
  if (e.key === 'ArrowDown') { e.preventDefault(); paletteSel = Math.min(paletteSel + 1, items.length - 1); renderPalette(paletteInput.value); }
  else if (e.key === 'ArrowUp') { e.preventDefault(); paletteSel = Math.max(paletteSel - 1, 0); renderPalette(paletteInput.value); }
  else if (e.key === 'Enter') { e.preventDefault(); if (items[paletteSel]) { closePalette(); items[paletteSel].run(); } }
  else if (e.key === 'Escape') { closePalette(); }
});
palette.addEventListener('click', (e) => { if (e.target === palette) closePalette(); });
document.addEventListener('keydown', (e) => {
  if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
    e.preventDefault();
    palette.classList.contains('hidden') ? openPalette() : closePalette();
  }
});

input.focus();
boot();
