"""Jarvis entry point.

Modes:
  python main.py             # interactive CLI (pretty TUI)
  python main.py desktop     # native desktop window (Flask + pywebview)
  python main.py web         # Flask API + UI in your browser
  python main.py api         # Flask REST API only (headless)
  python main.py voice       # one voice turn then exit
"""
from __future__ import annotations
import sys


def main():
    mode = sys.argv[1] if len(sys.argv) > 1 else "cli"
    if mode == "cli":
        from interfaces.cli import main as run
        run()
    elif mode == "desktop":
        from interfaces.desktop import main as run
        run()
    elif mode == "web":
        import webbrowser, threading, time
        from interfaces.api_server import main as run_api
        from config import API_HOST, API_PORT
        threading.Timer(1.2, lambda: webbrowser.open(f"http://{API_HOST}:{API_PORT}/")).start()
        run_api()
    elif mode == "api":
        from interfaces.api_server import main as run
        run()
    elif mode == "voice":
        from interfaces.cli import JarvisCLI
        JarvisCLI()._voice_turn()
    else:
        print(f"Unknown mode: {mode}. Use cli | desktop | web | api | voice.")
        sys.exit(2)


if __name__ == "__main__":
    main()
