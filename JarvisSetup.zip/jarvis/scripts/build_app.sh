#!/bin/bash
# Build a double-clickable J@rv1s.app that launches the desktop UI.
# Reuses the existing venv at ~/jarvis/.venv (no heavy repackaging).
set -e

JARVIS_DIR="$HOME/jarvis"
APP_DIR="$HOME/Applications/Jarvis.app"
ICON_PNG="$JARVIS_DIR/interfaces/web/icon.png"

echo "→ Building $APP_DIR"
rm -rf "$APP_DIR"
mkdir -p "$APP_DIR/Contents/MacOS" "$APP_DIR/Contents/Resources"

# --- icon: png → iconset → icns ---
ICONSET="$(mktemp -d)/jarvis.iconset"
mkdir -p "$ICONSET"
for SZ in 16 32 64 128 256 512; do
  sips -z $SZ $SZ "$ICON_PNG" --out "$ICONSET/icon_${SZ}x${SZ}.png" >/dev/null
  D=$((SZ*2))
  sips -z $D $D "$ICON_PNG" --out "$ICONSET/icon_${SZ}x${SZ}@2x.png" >/dev/null
done
iconutil -c icns "$ICONSET" -o "$APP_DIR/Contents/Resources/jarvis.icns"

# --- launcher executable ---
cat > "$APP_DIR/Contents/MacOS/Jarvis" << 'LAUNCH'
#!/bin/bash
cd "$HOME/jarvis" || exit 1
source .venv/bin/activate
exec python main.py desktop
LAUNCH
chmod +x "$APP_DIR/Contents/MacOS/Jarvis"

# --- Info.plist ---
cat > "$APP_DIR/Contents/Info.plist" << 'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleName</key><string>J@rv1s</string>
  <key>CFBundleDisplayName</key><string>J@rv1s</string>
  <key>CFBundleIdentifier</key><string>com.krishvenkatraman.jarvis</string>
  <key>CFBundleVersion</key><string>1.0</string>
  <key>CFBundleShortVersionString</key><string>1.0</string>
  <key>CFBundleExecutable</key><string>Jarvis</string>
  <key>CFBundleIconFile</key><string>jarvis.icns</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>NSHighResolutionCapable</key><true/>
  <key>LSMinimumSystemVersion</key><string>11.0</string>
  <key>NSMicrophoneUsageDescription</key><string>J@rv1s uses the microphone for voice commands.</string>
</dict>
</plist>
PLIST

# refresh icon cache for this bundle
touch "$APP_DIR"
echo "✓ Built J@rv1s.app at $APP_DIR"
echo "  Launch it from ~/Applications or Spotlight (\"Jarvis\")."
