"""Generate the Jarvis app icon (1024x1024 PNG) using PIL.

Run once: python scripts/make_icon.py
Output:   interfaces/web/icon.png
"""
from pathlib import Path
import math
from PIL import Image, ImageDraw, ImageFilter

OUT = Path(__file__).resolve().parent.parent / "interfaces" / "web" / "icon.png"
SIZE = 1024

# --- canvas: rounded square dark background ----------------------------------
img = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
bg = Image.new("RGBA", (SIZE, SIZE), (10, 10, 18, 255))

# subtle radial glow on bg
glow_bg = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
gd = ImageDraw.Draw(glow_bg)
for r, a in [(int(SIZE * 0.45), 70), (int(SIZE * 0.30), 90), (int(SIZE * 0.18), 110)]:
    gd.ellipse((SIZE/2 - r, SIZE/2 - r, SIZE/2 + r, SIZE/2 + r),
               fill=(0, 217, 255, a))
glow_bg = glow_bg.filter(ImageFilter.GaussianBlur(50))
bg = Image.alpha_composite(bg, glow_bg)

# rounded-square mask
mask = Image.new("L", (SIZE, SIZE), 0)
md = ImageDraw.Draw(mask)
md.rounded_rectangle((0, 0, SIZE, SIZE), radius=int(SIZE * 0.22), fill=255)
bg.putalpha(mask)
img.paste(bg, (0, 0))

draw = ImageDraw.Draw(img)
cx, cy = SIZE // 2, SIZE // 2

# --- outer gradient ring -----------------------------------------------------
outer_r = int(SIZE * 0.36)
ring_w = int(SIZE * 0.030)
SEG = 360
for i in range(SEG):
    angle = (i / SEG) * 360
    # sin-based blend so the seam matches
    t = (math.sin(math.radians(angle - 90)) + 1) / 2
    # cyan (0,217,255) → purple (183,148,246)
    r = int(0   + (183 - 0)   * t)
    g = int(217 + (148 - 217) * t)
    b = int(255 + (246 - 255) * t)
    bbox = (cx - outer_r, cy - outer_r, cx + outer_r, cy + outer_r)
    draw.arc(bbox, start=angle - 1.5, end=angle + 1.5,
             fill=(r, g, b, 255), width=ring_w)

# soft glow around outer ring
ring_glow = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
rgd = ImageDraw.Draw(ring_glow)
rgd.ellipse((cx - outer_r - 8, cy - outer_r - 8,
             cx + outer_r + 8, cy + outer_r + 8),
            outline=(0, 217, 255, 90), width=ring_w + 14)
ring_glow = ring_glow.filter(ImageFilter.GaussianBlur(20))
img = Image.alpha_composite(img, ring_glow)
draw = ImageDraw.Draw(img)

# --- middle thin ring (subtle) ----------------------------------------------
mid_r = int(SIZE * 0.22)
draw.ellipse((cx - mid_r, cy - mid_r, cx + mid_r, cy + mid_r),
             outline=(255, 255, 255, 30), width=2)

# --- center orb --------------------------------------------------------------
orb_r = int(SIZE * 0.12)
# layered fill for depth
for r, col in [
    (orb_r, (183, 148, 246, 255)),
    (int(orb_r * 0.82), (110, 180, 255, 255)),
    (int(orb_r * 0.55), (0, 217, 255, 255)),
    (int(orb_r * 0.30), (220, 250, 255, 255)),
]:
    draw.ellipse((cx - r, cy - r, cx + r, cy + r), fill=col)

# orb glow
orb_glow = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
ogd = ImageDraw.Draw(orb_glow)
ogd.ellipse((cx - orb_r * 2, cy - orb_r * 2,
             cx + orb_r * 2, cy + orb_r * 2),
            fill=(0, 217, 255, 80))
orb_glow = orb_glow.filter(ImageFilter.GaussianBlur(40))
img = Image.alpha_composite(img, orb_glow)

# re-mask to keep rounded square
final = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
final.paste(img, (0, 0), mask)

final.save(OUT)
print(f"Wrote {OUT}  ({OUT.stat().st_size:,} bytes)")
