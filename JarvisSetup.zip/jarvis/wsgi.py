"""Production WSGI entry point for J@rv1s (hosted/web mode).

Run with gunicorn:
    gunicorn --workers 1 --threads 8 --timeout 120 --bind 0.0.0.0:$PORT wsgi:app

Required environment variables in production:
    ANTHROPIC_API_KEY   your API key (billing runs through this — set a cap!)
    JARVIS_HOSTED=true  enables multi-user auth + disables machine control
    JARVIS_SECRET       a long random string (keeps logins valid across restarts)
Optional:
    JARVIS_DAILY_COST_CEILING   global $/day kill-switch (default 5.0)
    JARVIS_USER_DAILY_CAP       messages per user per day (default 40)
"""
from interfaces.api_server import create_app

app = create_app()
