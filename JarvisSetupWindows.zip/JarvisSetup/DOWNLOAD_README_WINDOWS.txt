╔══════════════════════════════════════════════════════════╗
║   J@rv1s — your Personal Agent  (Windows)                 ║
╚══════════════════════════════════════════════════════════╝

TO RUN (Windows 10/11):
  1. Unzip this folder (right-click the .zip → Extract All).
  2. Double-click  "Launch J@rv1s.bat"
  3. First launch sets everything up automatically (~1 min), then
     the J@rv1s window opens.
  4. Create an account or sign in to get started.

If Windows SmartScreen warns "Windows protected your PC":
  → click "More info" → "Run anyway".

REQUIREMENTS:
  • Windows 10 or 11 (with the WebView2 runtime — preinstalled on
    Windows 11 and most Windows 10; if the window doesn't open, install
    "Microsoft Edge WebView2 Runtime" from microsoft.com).
  • Python 3 — get it from https://www.python.org/downloads/
    IMPORTANT: tick "Add Python to PATH" during install.

Prefer no install? Visit our website and use J@rv1s in your browser.
(Voice and web automation are available in the Mac desktop app.)

Questions: support@projectjarvis.app
Developed & Created by Krish Venkatraman and the Project J@rv1s Team.
