"""Quick local test for the Google Classroom scraper.

Run:
    python -m automation.scrapers.test_classroom

What happens:
    1. Chromium opens (headed) using a profile at ~/.jarvis-test-profile/google_classroom/
    2. If you're not logged in, sign in to your school Google account.
    3. The scraper extracts your assignments and prints them.
    4. Subsequent runs reuse the cached login.
"""
from __future__ import annotations
import json
import sys
from pathlib import Path

from automation.scrapers import google_classroom


def main() -> int:
    profile = Path.home() / ".jarvis-test-profile" / "google_classroom"
    print(f"[test] Using profile dir: {profile}")
    print("[test] Opening Chromium…")
    items = google_classroom.scrape(profile, headless=False)
    print(f"\n[test] Found {len(items)} assignment(s):\n")
    print(json.dumps(items, indent=2, default=str))
    return 0


if __name__ == "__main__":
    sys.exit(main())
