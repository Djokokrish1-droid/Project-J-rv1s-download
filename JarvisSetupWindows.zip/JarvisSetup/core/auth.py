"""Lightweight accounts: username + password (PBKDF2), stdlib only.

Users live in data/users.json. Each user gets a stable uid that names their
private data directory (data/users/<uid>/).
"""
from __future__ import annotations
import json
import hashlib
import secrets
import re
import time
from config import DATA_DIR, TRIAL_DAYS, TRIAL_TIER, ADMIN_USERS, ADMIN_PASSWORD

USERS_FILE = DATA_DIR / "users.json"
USERS_DIR = DATA_DIR / "users"
_ITER = 200_000


def _load() -> dict:
    if USERS_FILE.exists():
        try:
            return json.loads(USERS_FILE.read_text())
        except json.JSONDecodeError:
            return {}
    return {}


def _save(d: dict) -> None:
    USERS_FILE.write_text(json.dumps(d, indent=2))


def _hash(password: str, salt: str) -> str:
    return hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt), _ITER).hex()


def _norm(username: str) -> str:
    return username.strip().lower()


def create_user(username: str, password: str) -> tuple[bool, str | None, str | None]:
    """Returns (ok, uid, error)."""
    u = _norm(username)
    if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", u):
        return False, None, "Please enter a valid email address."
    if len(password) < 6:
        return False, None, "Password must be at least 6 characters."
    users = _load()
    if u in users:
        return False, None, "An account with that email already exists."
    salt = secrets.token_hex(16)
    uid = "u_" + secrets.token_hex(8)
    rec = {"uid": uid, "email": u, "salt": salt, "hash": _hash(password, salt),
           "plan": "none", "paid": False, "trial_ends": None,
           "created": time.time()}
    # grant a free trial on signup (no card)
    if TRIAL_DAYS > 0:
        rec["plan"] = TRIAL_TIER
        rec["trial_ends"] = time.time() + TRIAL_DAYS * 86400
    users[u] = rec
    _save(users)
    (USERS_DIR / uid).mkdir(parents=True, exist_ok=True)
    return True, uid, None


def verify_user(username: str, password: str) -> tuple[bool, str | None, str | None]:
    """Returns (ok, uid, reason). On success, stamps last_login.
    Reason is 'ok' | 'no_user' | 'bad_password' | 'invalid_input'."""
    u = _norm(username)
    if not u or not password:
        return False, None, "invalid_input"
    users = _load()
    rec = users.get(u)
    if not rec:
        return False, None, "no_user"
    if secrets.compare_digest(rec["hash"], _hash(password, rec["salt"])):
        rec["last_login"] = time.time()
        users[u] = rec
        _save(users)
        return True, rec["uid"], "ok"
    return False, None, "bad_password"


def email_exists(email: str) -> bool:
    """True iff an account with this email is registered."""
    u = _norm(email)
    return bool(u) and u in _load()


def user_dir(uid: str):
    d = USERS_DIR / uid
    d.mkdir(parents=True, exist_ok=True)
    return d


def account_info(uid: str) -> dict:
    username, rec = _record_by_uid(_load(), uid)
    return {
        "username": username or ("you" if uid == "local" else uid),
        "email": (rec or {}).get("email", username),
        "plan": get_plan(uid),
        "created": (rec or {}).get("created"),
        "last_login": (rec or {}).get("last_login"),
        "is_admin": is_admin(uid),
        "uid": uid,
        "prefs": (rec or {}).get("prefs") or default_prefs(),
        "trial": trial_info(uid),
    }


# ── per-user preferences (Settings → General etc.) ──────────────────────────
PREF_FIELDS = {
    # General
    "full_name": str,
    "nickname": str,
    "work_type": str,
    "custom_instructions": str,
    "timezone": str,
    "language": str,
    # Preferences
    "chat_font": str,
    "voice": str,
    "voice_speed": str,
    "appearance": str,           # "system" | "light" | "dark"
    # Privacy
    "location_metadata": bool,
    "help_improve": bool,
    # Capabilities
    "search_chats": bool,
    "generate_memory": bool,
    "connector_discovery": bool,
    "artifacts": bool,
    "ai_powered_artifacts": bool,
    "inline_visualizations": bool,
    "tool_access_mode": str,     # "load_when_needed" | "all"
    "code_execution": bool,
    "network_egress": bool,
    # Notifications
    "notify_email_updates": bool,
    "notify_product_news": bool,
    "notify_weekly_digest": bool,
    "notify_trial_ending": bool,
}


def default_prefs() -> dict:
    return {
        "full_name": "", "nickname": "", "work_type": "Other",
        "custom_instructions": "",
        "timezone": "America/New_York", "language": "en",
        "chat_font": "default", "voice": "alloy", "voice_speed": "Normal",
        "appearance": "dark",
        "location_metadata": False, "help_improve": True,
        "search_chats": True, "generate_memory": True,
        "connector_discovery": True, "artifacts": True,
        "ai_powered_artifacts": True, "inline_visualizations": True,
        "tool_access_mode": "load_when_needed",
        "code_execution": True, "network_egress": False,
        "notify_email_updates": True,
        "notify_product_news": False,
        "notify_weekly_digest": False,
        "notify_trial_ending": True,
    }


def get_prefs(uid: str) -> dict:
    username, rec = _record_by_uid(_load(), uid)
    prefs = default_prefs()
    if rec and rec.get("prefs"):
        prefs.update(rec["prefs"])
    return prefs


def update_prefs(uid: str, partial: dict) -> dict:
    users = _load()
    username, rec = _record_by_uid(users, uid)
    if not rec:
        return default_prefs()
    cur = rec.get("prefs") or {}
    # Only accept known keys, coerce types.
    for k, v in (partial or {}).items():
        if k not in PREF_FIELDS:
            continue
        typ = PREF_FIELDS[k]
        if typ is bool:
            cur[k] = bool(v)
        else:
            cur[k] = (str(v) if v is not None else "")
    rec["prefs"] = cur
    users[username] = rec
    _save(users)
    out = default_prefs(); out.update(cur)
    return out


def change_password(uid: str, old: str, new: str) -> tuple[bool, str | None]:
    users = _load()
    username, rec = _record_by_uid(users, uid)
    if not rec:
        return False, "Account not found."
    if not secrets.compare_digest(rec["hash"], _hash(old, rec["salt"])):
        return False, "Current password is incorrect."
    if len(new) < 6:
        return False, "New password must be at least 6 characters."
    rec["salt"] = secrets.token_hex(16)
    rec["hash"] = _hash(new, rec["salt"])
    users[username] = rec
    _save(users)
    return True, None


def _sha(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def create_reset_token(email: str) -> tuple[str | None, str | None]:
    """Returns (token, email) if an account exists, else (None, None).
    Stores only a hash of the token + a 1-hour expiry on the user record."""
    users = _load()
    u = _norm(email)
    rec = users.get(u)
    if not rec:
        return None, None
    token = secrets.token_urlsafe(32)
    rec["reset_hash"] = _sha(token)
    rec["reset_expires"] = time.time() + 3600
    users[u] = rec
    _save(users)
    return token, u


def reset_password(token: str, new_password: str) -> tuple[bool, str | None]:
    if len(new_password) < 6:
        return False, "Password must be at least 6 characters."
    users = _load()
    h = _sha(token)
    for username, rec in users.items():
        if rec.get("reset_hash") == h:
            if (rec.get("reset_expires") or 0) < time.time():
                return False, "This reset link has expired. Request a new one."
            rec["salt"] = secrets.token_hex(16)
            rec["hash"] = _hash(new_password, rec["salt"])
            rec.pop("reset_hash", None)
            rec.pop("reset_expires", None)
            users[username] = rec
            _save(users)
            return True, None
    return False, "Invalid or already-used reset link."


def delete_user(uid: str) -> bool:
    import shutil
    users = _load()
    username, rec = _record_by_uid(users, uid)
    if not rec:
        return False
    del users[username]
    _save(users)
    d = USERS_DIR / uid
    if d.exists():
        shutil.rmtree(d, ignore_errors=True)
    return True


# ── plans / billing ─────────────────────────────────────────────────────────
def _record_by_uid(users: dict, uid: str):
    for username, rec in users.items():
        if rec.get("uid") == uid:
            return username, rec
    return None, None


def email_for_uid(uid: str) -> str | None:
    """Get the email address registered to a uid (used for transactional mail)."""
    username, rec = _record_by_uid(_load(), uid)
    return (rec or {}).get("email") or username


def email_for_customer(customer_id: str) -> str | None:
    """Get the email registered to a Stripe customer id (used by webhooks)."""
    if not customer_id:
        return None
    for username, rec in _load().items():
        if rec.get("stripe_customer_id") == customer_id:
            return rec.get("email") or username
    return None


def _effective_plan(rec: dict | None) -> str:
    """Resolve a record to its currently-active tier, accounting for trials."""
    if not rec:
        return "none"
    plan = rec.get("plan", "none")
    if plan == "none":
        return "none"
    if rec.get("paid"):
        return plan                       # active paid subscription
    te = rec.get("trial_ends")
    if te and time.time() < te:
        return plan                       # still inside the free trial
    return "none"                         # trial expired, never paid


def get_plan(uid: str) -> str:
    """Effective tier: 'starter' | 'professional' | 'none'."""
    if uid == "local":
        return "professional"
    username, rec = _record_by_uid(_load(), uid)
    if username and username in ADMIN_USERS:
        return "max"                       # admins bypass the paywall
    return _effective_plan(rec)


def is_subscribed(uid: str) -> bool:
    return get_plan(uid) in ("starter", "professional", "max", "ultra", "apex")


def trial_info(uid: str) -> dict:
    """{trialing, days_left} for the paywall/sidebar."""
    if uid == "local":
        return {"trialing": False, "days_left": 0}
    _, rec = _record_by_uid(_load(), uid)
    if not rec or rec.get("paid") or not rec.get("trial_ends"):
        return {"trialing": False, "days_left": 0}
    left = rec["trial_ends"] - time.time()
    if left <= 0:
        return {"trialing": False, "days_left": 0}
    return {"trialing": True, "days_left": max(1, round(left / 86400))}


def is_admin(uid: str) -> bool:
    if uid == "local":
        return True
    username, _ = _record_by_uid(_load(), uid)
    return bool(username and username in ADMIN_USERS)


def ensure_admin() -> None:
    """Auto-create the admin account on boot if ADMIN_PASSWORD is configured."""
    if not ADMIN_PASSWORD:
        return
    users = _load()
    for name in ADMIN_USERS:
        if name not in users:
            salt = secrets.token_hex(16)
            users[name] = {"uid": "u_" + secrets.token_hex(8), "salt": salt,
                           "hash": _hash(ADMIN_PASSWORD, salt), "plan": "professional",
                           "paid": True, "trial_ends": None, "created": time.time()}
    _save(users)


def admin_summary() -> dict:
    """Aggregate user/revenue stats for the admin dashboard."""
    from config import PLAN_PRICE_USD
    users = _load()
    paid = {"starter": 0, "professional": 0, "max": 0, "ultra": 0, "apex": 0}
    trialing = 0
    for name, rec in users.items():
        if name in ADMIN_USERS:
            continue
        if rec.get("paid") and rec.get("plan") in paid:
            paid[rec["plan"]] += 1
        elif rec.get("trial_ends") and time.time() < rec["trial_ends"]:
            trialing += 1
    mrr = sum(paid[t] * PLAN_PRICE_USD.get(t, 0) for t in paid)
    return {
        "total_users": len(users),
        "paid_starter": paid["starter"],
        "paid_professional": paid["professional"],
        "paid_max": paid["max"],
        "paid_ultra": paid["ultra"],
        "paid_apex": paid["apex"],
        "paying": sum(paid.values()),
        "trialing": trialing,
        "mrr": round(mrr, 2),
    }


def set_plan(uid: str, plan: str, customer_id: str | None = None) -> None:
    users = _load()
    username, rec = _record_by_uid(users, uid)
    if not rec:
        return
    rec["plan"] = plan
    rec["paid"] = plan in ("starter", "professional", "max", "ultra", "apex")
    rec["trial_ends"] = None              # a real subscription supersedes the trial
    if customer_id:
        rec["stripe_customer_id"] = customer_id
    users[username] = rec
    _save(users)


def set_plan_by_customer(customer_id: str, plan: str) -> bool:
    """Used by webhooks (which know the Stripe customer, not our uid)."""
    users = _load()
    for username, rec in users.items():
        if rec.get("stripe_customer_id") == customer_id:
            rec["plan"] = plan
            rec["paid"] = plan in ("starter", "professional", "max", "ultra", "apex")
            users[username] = rec
            _save(users)
            return True
    return False
