"""Stripe billing: subscription checkout + webhook handling.

Degrades gracefully when Stripe isn't configured (BILLING_ENABLED is False) so
the app runs fine locally without keys. To go live you need a Stripe account
(holder must be 18+), a recurring Price, and the three STRIPE_* env vars.
"""
from __future__ import annotations

from urllib.parse import quote
from config import (STRIPE_SECRET_KEY,
                    STRIPE_PAYMENT_LINK_STARTER, STRIPE_PAYMENT_LINK_PRO,
                    STRIPE_PAYMENT_LINK_MAX, STRIPE_PAYMENT_LINK_ULTRA,
                    STRIPE_PAYMENT_LINK_APEX,
                    STRIPE_PAYMENT_LINK_STARTER_ANNUAL, STRIPE_PAYMENT_LINK_PRO_ANNUAL,
                    STRIPE_PAYMENT_LINK_MAX_ANNUAL, STRIPE_PAYMENT_LINK_ULTRA_ANNUAL,
                    STRIPE_PAYMENT_LINK_APEX_ANNUAL,
                    STRIPE_WEBHOOK_SECRET, BILLING_ENABLED)
from core import auth

try:
    import stripe
except ImportError:  # pragma: no cover
    stripe = None

if stripe and STRIPE_SECRET_KEY:
    stripe.api_key = STRIPE_SECRET_KEY

# (tier, interval) → Payment Link URL. Annual links have no trial baked in.
_LINKS = {
    ("starter",      "monthly"): STRIPE_PAYMENT_LINK_STARTER,
    ("professional", "monthly"): STRIPE_PAYMENT_LINK_PRO,
    ("max",          "monthly"): STRIPE_PAYMENT_LINK_MAX,
    ("ultra",        "monthly"): STRIPE_PAYMENT_LINK_ULTRA,
    ("apex",         "monthly"): STRIPE_PAYMENT_LINK_APEX,
    ("starter",      "annual"):  STRIPE_PAYMENT_LINK_STARTER_ANNUAL,
    ("professional", "annual"):  STRIPE_PAYMENT_LINK_PRO_ANNUAL,
    ("max",          "annual"):  STRIPE_PAYMENT_LINK_MAX_ANNUAL,
    ("ultra",        "annual"):  STRIPE_PAYMENT_LINK_ULTRA_ANNUAL,
    ("apex",         "annual"):  STRIPE_PAYMENT_LINK_APEX_ANNUAL,
}
_TIERS = ("starter", "professional", "max", "ultra", "apex")
_INTERVALS = ("monthly", "annual")


def enabled() -> bool:
    return bool(BILLING_ENABLED)


def checkout_url(uid: str, tier: str = "starter", interval: str = "monthly") -> str:
    """Stripe Payment Link for (tier, interval), tagged with the user id so the
    webhook can map the payment back to this account.
    client_reference_id = '<uid>__<tier>__<interval>'."""
    if tier not in _TIERS: tier = "starter"
    if interval not in _INTERVALS: interval = "monthly"
    link = _LINKS.get((tier, interval)) or _LINKS.get((tier, "monthly")) or STRIPE_PAYMENT_LINK_STARTER
    if not link:
        raise RuntimeError("Billing is not configured.")
    ref = f"{uid}__{tier}__{interval}"
    sep = "&" if "?" in link else "?"
    return f"{link}{sep}client_reference_id={quote(ref)}"


def _parse_ref(ref: str) -> tuple[str | None, str, str]:
    """Parse '<uid>__<tier>[__<interval>]' → (uid, tier, interval)."""
    if not ref:
        return None, "starter", "monthly"
    parts = ref.split("__")
    uid = parts[0]
    tier = parts[1] if len(parts) > 1 and parts[1] in _TIERS else "starter"
    interval = parts[2] if len(parts) > 2 and parts[2] in _INTERVALS else "monthly"
    return uid, tier, interval


def create_portal_session(uid: str, return_url: str) -> str | None:
    """Stripe customer portal so users can manage/cancel their subscription."""
    if not enabled():
        return None
    _, rec = auth._record_by_uid(auth._load(), uid)
    cust = (rec or {}).get("stripe_customer_id")
    if not cust:
        return None
    return stripe.billing_portal.Session.create(customer=cust, return_url=return_url).url


def handle_webhook(payload: bytes, sig_header: str) -> tuple[bool, str]:
    """Verify + process a Stripe webhook. Returns (ok, message)."""
    if not enabled():
        return False, "billing disabled"
    try:
        if STRIPE_WEBHOOK_SECRET:
            event = stripe.Webhook.construct_event(payload, sig_header, STRIPE_WEBHOOK_SECRET)
        else:
            import json
            event = json.loads(payload)
    except Exception as ex:  # signature/parse failure
        return False, f"invalid webhook: {ex}"

    etype = event["type"]
    obj = event["data"]["object"]

    if etype == "checkout.session.completed":
        uid, tier, interval = _parse_ref(obj.get("client_reference_id") or "")
        customer = obj.get("customer")
        if uid:
            auth.set_plan(uid, tier, customer_id=customer)
            # Send the welcome packet — best effort, never block the webhook.
            try:
                from core import mailer
                email = (obj.get("customer_details") or {}).get("email") \
                        or obj.get("customer_email") \
                        or auth.email_for_uid(uid)
                if email:
                    mailer.subscription_welcome(email, tier, interval)
            except Exception as ex:  # noqa: BLE001
                print(f"[billing] welcome email error: {ex}")
        return True, f"activated {uid} ({tier}, {interval})"

    if etype == "customer.subscription.deleted":
        customer = obj.get("customer")
        prior_plan = None
        if customer:
            # Capture the tier *before* we downgrade, so the email can name it.
            from core import auth as _a
            for _u, _r in _a._load().items():
                if _r.get("stripe_customer_id") == customer:
                    prior_plan = _r.get("plan")
                    break
            auth.set_plan_by_customer(customer, "none")
            try:
                from core import mailer
                email = auth.email_for_customer(customer)
                if email and prior_plan:
                    mailer.subscription_canceled(email, prior_plan)
            except Exception as ex:  # noqa: BLE001
                print(f"[billing] cancel email error: {ex}")
        return True, "canceled"

    if etype == "customer.subscription.updated":
        customer = obj.get("customer")
        status = obj.get("status")
        # only downgrade on a non-active status; tier was set at checkout
        if customer and status not in ("active", "trialing"):
            auth.set_plan_by_customer(customer, "none")
        return True, f"status {status}"

    return True, f"ignored {etype}"
