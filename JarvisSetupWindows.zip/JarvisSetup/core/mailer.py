"""Transactional email via Resend (https://resend.com). stdlib HTTP only.

Degrades gracefully: if no API key is configured, it logs what *would* have
been sent instead of failing — so signup/reset still work in development.

Public functions used by the app:
  welcome(email)                    — sent on account creation
  password_reset(email, link)       — sent on "Forgot password" click
  subscription_welcome(email, tier) — sent when Stripe checkout completes
  subscription_canceled(email, tier)— sent when subscription cancels
"""
from __future__ import annotations
import json
import urllib.request

from config import (RESEND_API_KEY, MAIL_FROM, MAIL_REPLY_TO, APP_NAME,
                    APP_BASE_URL, SUPPORT_EMAIL, EMAIL_ENABLED, PLANS)


PLAN_BY_ID = {p["id"]: p for p in PLANS}

# Last send error, exposed via /api/admin/mailer for debugging.
_LAST_RESULT: dict = {"ok": None, "status": None, "body": "", "error": ""}


def configured() -> bool:
    return EMAIL_ENABLED


def last_result() -> dict:
    return dict(_LAST_RESULT)


def send(to: str, subject: str, html: str, *, reply_to: str | None = None) -> bool:
    """Low-level send via Resend. Returns True on success.
    Captures the response into module-level _LAST_RESULT so failures can be
    surfaced via /api/admin/mailer without grepping Render logs.
    """
    global _LAST_RESULT
    _LAST_RESULT = {"ok": False, "status": None, "body": "", "error": "", "to": to}
    if not RESEND_API_KEY:
        msg = "RESEND_API_KEY is empty — env var not set on this deploy."
        print(f"[mailer] ❌ {msg}", flush=True)
        _LAST_RESULT["error"] = msg
        return False
    if not MAIL_FROM:
        msg = "MAIL_FROM is empty — set JARVIS_MAIL_FROM env var."
        print(f"[mailer] ❌ {msg}", flush=True)
        _LAST_RESULT["error"] = msg
        return False
    payload = {"from": MAIL_FROM, "to": [to], "subject": subject, "html": html}
    rt = reply_to or MAIL_REPLY_TO
    if rt:
        payload["reply_to"] = rt
    print(f"[mailer] → POST resend  to={to}  from={MAIL_FROM!r}  subject={subject!r}", flush=True)
    try:
        # Cloudflare (in front of api.resend.com) blocks the default Python-urllib
        # User-Agent as "bot traffic" → error code 1010. Send a real UA + Accept
        # so we look like a normal client.
        req = urllib.request.Request(
            "https://api.resend.com/emails",
            data=json.dumps(payload).encode(),
            headers={
                "Authorization": f"Bearer {RESEND_API_KEY}",
                "Content-Type": "application/json",
                "Accept": "application/json",
                "User-Agent": "Jarvis/1.0 (+https://projectjarvis.app)",
            },
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            body = resp.read().decode("utf-8", errors="replace")
            print(f"[mailer] ✅ resend OK ({resp.status}): {body[:200]}", flush=True)
            _LAST_RESULT.update({"ok": True, "status": resp.status, "body": body[:500]})
            return True
    except urllib.error.HTTPError as ex:
        try:
            err_body = ex.read().decode("utf-8", errors="replace")
        except Exception:
            err_body = "(no body)"
        print(f"[mailer] ❌ resend HTTP {ex.code}: {err_body}", flush=True)
        _LAST_RESULT.update({"status": ex.code, "body": err_body[:600],
                             "error": f"HTTP {ex.code}: {err_body[:400]}"})
        return False
    except Exception as ex:  # noqa: BLE001 — never crash the app on email failure
        print(f"[mailer] ❌ resend send failed ({type(ex).__name__}): {ex}", flush=True)
        _LAST_RESULT["error"] = f"{type(ex).__name__}: {ex}"
        return False


def diagnostics() -> dict:
    """Live snapshot of mailer config — used by /api/mailer/health (admin)."""
    return {
        "configured": configured(),
        "from": MAIL_FROM or "(empty)",
        "reply_to": MAIL_REPLY_TO or "(empty)",
        "api_key_present": bool(RESEND_API_KEY),
        "api_key_prefix": (RESEND_API_KEY[:6] + "…") if RESEND_API_KEY else "(empty)",
    }


# ── Shared layout ───────────────────────────────────────────────────────────
def _shell(body: str, *, preheader: str = "") -> str:
    """Wrap inner HTML in the standard J@rv1s email chrome."""
    app_link = APP_BASE_URL or "https://web.projectjarvis.app"
    support = SUPPORT_EMAIL or "support@projectjarvis.app"
    hidden = (f"<div style='display:none;font-size:1px;color:#08080d;line-height:1px;"
              f"max-height:0;max-width:0;opacity:0;overflow:hidden'>{preheader}</div>"
              if preheader else "")
    return f"""<!doctype html><html><body style="margin:0;background:#08080d">{hidden}
<div style="font-family:Inter,-apple-system,Segoe UI,Arial,sans-serif;background:#08080d;color:#e8e8ef;padding:36px 16px">
  <div style="max-width:540px;margin:0 auto;background:#11111a;border:1px solid rgba(255,255,255,.08);border-radius:18px;padding:34px 30px">
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:22px">
      <div style="width:34px;height:34px;border-radius:50%;background:radial-gradient(circle,#00d9ff 0%,#0a2940 70%);box-shadow:0 0 18px rgba(0,217,255,.55)"></div>
      <div style="font-weight:800;letter-spacing:.14em;font-size:14px;background:linear-gradient(135deg,#00d9ff,#b794f6);-webkit-background-clip:text;background-clip:text;color:transparent">{APP_NAME}</div>
    </div>
    {body}
    <div style="margin-top:28px;padding-top:18px;border-top:1px solid rgba(255,255,255,.08);color:#6a6a7a;font-size:12px;line-height:1.6">
      <div>Need help? Email <a href="mailto:{support}" style="color:#00d9ff;text-decoration:none">{support}</a></div>
      <div style="margin-top:6px">{APP_NAME} · <a href="{app_link}" style="color:#6a6a7a;text-decoration:none">{app_link}</a></div>
      <div style="margin-top:6px;color:#454555">Developed &amp; Created by Krish Venkatraman and the Project J@rv1s Team.</div>
    </div>
  </div>
</div></body></html>"""


def _btn(href: str, label: str) -> str:
    return (f"<a href='{href}' style='display:inline-block;background:linear-gradient(135deg,#00d9ff,#b794f6);"
            f"color:#fff;text-decoration:none;padding:13px 24px;border-radius:12px;font-weight:700;"
            f"box-shadow:0 8px 22px rgba(0,217,255,.25)'>{label}</a>")


# ── Templates ───────────────────────────────────────────────────────────────
def welcome(to: str) -> bool:
    app_link = APP_BASE_URL or "https://web.projectjarvis.app"
    body = f"""
    <h2 style="margin:0 0 8px;font-size:24px">Welcome to <span style="background:linear-gradient(135deg,#00d9ff,#b794f6);-webkit-background-clip:text;background-clip:text;color:transparent">J@rv1s</span>, {to.split('@')[0]} 👋</h2>
    <p style="color:#a8a8b8;line-height:1.65;margin:0 0 18px">
      Your account is live. J@rv1s is your personal AI agent — built to take homework, projects, and busywork off your plate.
    </p>
    <p style="color:#a8a8b8;line-height:1.65;margin:0 0 22px">
      To unlock messaging, pick a plan. <strong style="color:#e8e8ef">Professional, Max, Ultra, and Apex</strong> all start with a <strong style="color:#4ade80">7-day free trial</strong> — card required, cancel anytime.
    </p>
    <div style="margin:8px 0 22px">{_btn(app_link, "Choose your plan →")}</div>
    <div style="background:rgba(0,217,255,.05);border:1px solid rgba(0,217,255,.18);border-radius:12px;padding:16px 18px;margin-top:10px">
      <div style="font-weight:700;color:#00d9ff;font-size:13px;letter-spacing:.06em;text-transform:uppercase;margin-bottom:10px">3 things to try first</div>
      <ul style="margin:0;padding-left:20px;color:#c8c8d8;line-height:1.7;font-size:14px">
        <li>Open a subject project (Math, English, History, Science) and drop in a worksheet</li>
        <li>Toggle a Skill — Undetectable, Humanizer, Tutor mode — to change how J@rv1s writes</li>
        <li>Hit <code style="background:#1a1a24;padding:2px 6px;border-radius:4px;font-size:12px">⌘K</code> for the command palette</li>
      </ul>
    </div>
    """
    return send(to, f"Welcome to {APP_NAME} — your account is live",
                _shell(body, preheader="Your J@rv1s account is ready. Pick a plan to get started."))


def password_reset(to: str, link: str) -> bool:
    body = f"""
    <h2 style="margin:0 0 8px;font-size:22px">Reset your password 🔐</h2>
    <p style="color:#a8a8b8;line-height:1.65;margin:0 0 20px">
      Someone (hopefully you) asked to reset the password on <strong>{to}</strong>.
      Click the button below to set a new one. This link expires in <strong style="color:#e8e8ef">1 hour</strong>.
    </p>
    <div style="margin:8px 0 22px">{_btn(link, "Reset password")}</div>
    <p style="color:#7a7a8a;line-height:1.6;font-size:13px;margin:0">
      If you didn't request this, you can safely ignore this email — your password won't change.
    </p>
    <p style="color:#5a5a6a;font-size:12px;margin-top:18px;word-break:break-all">
      Or paste this link into your browser:<br><span style="color:#7a7a8a">{link}</span>
    </p>
    <p style="color:#454555;font-size:11px;margin-top:18px;font-style:italic">
      This is an automated message — please don't reply.
    </p>
    """
    return send(to, f"Reset your {APP_NAME} password",
                _shell(body, preheader="Reset your J@rv1s password. Link expires in 1 hour."),
                reply_to="")  # explicit empty → no reply-to override; resets are no-reply


def subscription_welcome(to: str, tier: str, interval: str = "monthly") -> bool:
    """Sent right after Stripe checkout completes — the 'welcome packet'."""
    plan = PLAN_BY_ID.get(tier, {"name": tier.title(), "features": []})
    app_link = APP_BASE_URL or "https://web.projectjarvis.app"
    period = "annual" if interval == "annual" else "monthly"
    trial_blurb = ""
    if plan.get("trial_days") and interval == "monthly":
        trial_blurb = (f"<p style='color:#4ade80;font-weight:600;margin:0 0 14px;font-size:14px'>"
                       f"★ Your 7-day free trial is now active. We won't charge you until it ends — "
                       f"cancel anytime from Settings before then.</p>")
    feats_html = "".join(f"<li>{f}</li>" for f in plan.get("features", []))
    body = f"""
    <div style="background:linear-gradient(135deg,rgba(0,217,255,.12),rgba(183,148,246,.08));border:1px solid rgba(0,217,255,.3);border-radius:14px;padding:22px 22px 18px;margin-bottom:22px">
      <div style="font-size:12px;font-weight:700;letter-spacing:.12em;color:#00d9ff;text-transform:uppercase;margin-bottom:8px">Plan unlocked</div>
      <div style="font-size:30px;font-weight:800;line-height:1.1">{plan['name']} <span style="color:#7a7a8a;font-size:16px;font-weight:500">· {period}</span></div>
    </div>
    <h2 style="margin:0 0 8px;font-size:22px">You're in. 🎯</h2>
    <p style="color:#a8a8b8;line-height:1.65;margin:0 0 18px">
      Thanks for going with <strong style="color:#e8e8ef">{plan['name']}</strong>. Your account is fully unlocked and ready to work for you.
    </p>
    {trial_blurb}
    <div style="margin:14px 0 22px">{_btn(app_link, "Open J@rv1s →")}</div>

    <div style="background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.08);border-radius:12px;padding:18px;margin-bottom:18px">
      <div style="font-weight:700;color:#e8e8ef;font-size:14px;margin-bottom:10px">What's included</div>
      <ul style="margin:0;padding-left:20px;color:#c8c8d8;line-height:1.75;font-size:14px">{feats_html}</ul>
    </div>

    <div style="background:rgba(0,217,255,.05);border:1px solid rgba(0,217,255,.18);border-radius:12px;padding:16px 18px">
      <div style="font-weight:700;color:#00d9ff;font-size:13px;letter-spacing:.06em;text-transform:uppercase;margin-bottom:10px">Getting started — pick one</div>
      <ul style="margin:0;padding-left:20px;color:#c8c8d8;line-height:1.7;font-size:14px">
        <li><strong style="color:#e8e8ef">Drop a worksheet</strong> into a subject project — J@rv1s will work the problems with you</li>
        <li><strong style="color:#e8e8ef">Try a Skill</strong> — Undetectable, Humanizer, or Tutor mode</li>
        <li><strong style="color:#e8e8ef">Set deadlines</strong> on the project page and J@rv1s tracks them for you</li>
      </ul>
    </div>

    <p style="color:#7a7a8a;line-height:1.6;font-size:13px;margin:22px 0 0">
      Manage or cancel anytime from <strong style="color:#a8a8b8">Settings → Manage subscription</strong>.
      Questions? Just reply to this email — we read every one.
    </p>
    """
    return send(to, f"Welcome to {APP_NAME} {plan['name']} 🚀",
                _shell(body, preheader=f"Your {plan['name']} plan is active. Here's everything you unlocked."))


def subscription_canceled(to: str, tier: str) -> bool:
    plan = PLAN_BY_ID.get(tier, {"name": tier.title()})
    app_link = APP_BASE_URL or "https://web.projectjarvis.app"
    body = f"""
    <h2 style="margin:0 0 8px;font-size:22px">Your subscription has been cancelled</h2>
    <p style="color:#a8a8b8;line-height:1.65;margin:0 0 18px">
      Your <strong style="color:#e8e8ef">{plan['name']}</strong> plan has been cancelled and you won't be billed again.
      Your account stays — sign in any time, and resubscribe whenever you want.
    </p>
    <div style="margin:14px 0 22px">{_btn(app_link, "Open J@rv1s")}</div>
    <p style="color:#7a7a8a;line-height:1.6;font-size:13px;margin:0">
      We'd love to hear what didn't work for you. Reply to this email and tell us — feedback genuinely shapes what we build next.
    </p>
    """
    return send(to, f"Your {APP_NAME} subscription was cancelled",
                _shell(body, preheader="Your plan was cancelled. Your account stays."))
