"""Persistent memory: preferences, facts, and conversation history."""
from __future__ import annotations
import json
import time
from pathlib import Path
from typing import Any

from config import MEMORY_FILE, SESSION_FILE


def _load(path: Path, default: Any) -> Any:
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text())
    except json.JSONDecodeError:
        return default


def _save(path: Path, data: Any) -> None:
    path.write_text(json.dumps(data, indent=2, default=str))


class Memory:
    """Long-term memory: preferences, facts, and imported context from other AIs."""

    def __init__(self, path: Path = MEMORY_FILE):
        self.path = path
        data = _load(path, {"preferences": {}, "facts": [], "feedback": [], "imported": []})
        self.preferences: dict = data.get("preferences", {})
        self.facts: list = data.get("facts", [])
        self.feedback: list = data.get("feedback", [])
        # Each import = {"source": "chatgpt"|"gemini"|..., "text": "...", "ts": 12345}
        self.imported: list = data.get("imported", [])

    def save(self) -> None:
        _save(
            self.path,
            {
                "preferences": self.preferences,
                "facts": self.facts,
                "feedback": self.feedback,
                "imported": self.imported,
            },
        )

    def set_preference(self, key: str, value: Any) -> None:
        self.preferences[key] = value
        self.save()

    def remember(self, fact: str, tag: str = "general") -> str:
        """Append a fact. Returns the assigned id."""
        import secrets as _s
        fid = "m_" + _s.token_hex(5)
        self.facts.append({"id": fid, "fact": fact, "tag": tag, "ts": time.time()})
        self.save()
        return fid

    def update_fact(self, fact_id: str, *, fact: str | None = None, tag: str | None = None) -> dict | None:
        for f in self.facts:
            if f.get("id") == fact_id:
                if fact is not None: f["fact"] = fact.strip()
                if tag is not None: f["tag"] = tag.strip()
                self.save()
                return f
        return None

    def delete_fact(self, fact_id: str) -> bool:
        n = len(self.facts)
        self.facts = [f for f in self.facts if f.get("id") != fact_id]
        if len(self.facts) != n:
            self.save(); return True
        return False

    def clear_facts(self, tag: str | None = None) -> int:
        """Delete facts (optionally only those tagged X). Returns count deleted."""
        before = len(self.facts)
        if tag:
            self.facts = [f for f in self.facts if f.get("tag") != tag]
        else:
            self.facts = []
        self.save()
        return before - len(self.facts)

    def all_atoms(self) -> list[dict]:
        """Unified view: facts + preferences + imports, each as an atom."""
        atoms = []
        for f in self.facts:
            atoms.append({
                "id": f.get("id"), "kind": "fact", "text": f.get("fact"),
                "tag": f.get("tag", "general"), "ts": f.get("ts"),
            })
        for k, v in self.preferences.items():
            atoms.append({
                "id": f"pref:{k}", "kind": "preference", "text": f"{k}: {v}",
                "tag": "preference", "ts": None,
            })
        for i, b in enumerate(self.imported):
            atoms.append({
                "id": f"imp:{i}", "kind": "imported", "text": b.get("text", ""),
                "tag": f"from {b.get('source', 'other AI')}", "ts": b.get("ts"),
            })
        # newest first
        atoms.sort(key=lambda a: a.get("ts") or 0, reverse=True)
        return atoms

    def record_feedback(self, text: str, rating: int | None = None) -> None:
        self.feedback.append({"text": text, "rating": rating, "ts": time.time()})
        self.save()

    # ── imported memory (from other AI providers via Settings → Memory) ─────
    def add_import(self, text: str, source: str = "other_ai") -> None:
        """Append a memory dump from another AI to this user's memory."""
        text = (text or "").strip()
        if not text:
            return
        self.imported.append({"source": source, "text": text, "ts": time.time()})
        self.save()

    def clear_imports(self) -> None:
        self.imported = []
        self.save()

    def imported_text(self) -> str:
        """All imported memory blobs joined together (newest at the bottom)."""
        return "\n\n---\n\n".join(b["text"] for b in self.imported if b.get("text"))

    def context_block(self) -> str:
        """Render memory as a system-prompt addendum."""
        parts = []
        if self.preferences:
            parts.append("User preferences:")
            for k, v in self.preferences.items():
                parts.append(f"- {k}: {v}")
        if self.facts:
            parts.append("\nRemembered facts:")
            for f in self.facts[-25:]:
                parts.append(f"- [{f['tag']}] {f['fact']}")
        if self.imported:
            parts.append("\nImported memory (from the user's other AI providers — treat as authoritative background on them):")
            parts.append(self.imported_text())
        return "\n".join(parts)


class Session:
    """Short-term rolling conversation, persisted across runs."""

    def __init__(self, path: Path = SESSION_FILE, max_turns: int = 40):
        self.path = path
        self.max_turns = max_turns
        self.messages: list[dict] = _load(path, [])

    def add(self, role: str, content: str) -> None:
        self.messages.append({"role": role, "content": content})
        if len(self.messages) > self.max_turns * 2:
            self.messages = self.messages[-self.max_turns * 2 :]
        _save(self.path, self.messages)

    def clear(self) -> None:
        self.messages = []
        _save(self.path, self.messages)

    def history(self) -> list[dict]:
        return list(self.messages)
