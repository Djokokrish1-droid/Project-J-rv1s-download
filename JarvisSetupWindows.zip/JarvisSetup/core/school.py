"""School-platform Tasks: storage + (stubbed) automation hooks.

Each user gets a per-user data directory holding:
  data/users/<uid>/school.json   — connected platform + automation mode
  data/users/<uid>/tasks.json    — list of assignment tasks

Automation modes:
  "desktop"  → Playwright runs on the user's Mac via the desktop app
  "cloud"    → Playwright runs on the server (uses extra credits)
  "manual"   → user enters tasks by hand; no automation

The actual Playwright drivers live in `core/automation/` (TODO) — this module
just persists state and exposes the surface the Flask routes call.
"""
from __future__ import annotations
import base64
import json
import os
import secrets
import time
from pathlib import Path

from config import DATA_DIR


# ── storage helpers ─────────────────────────────────────────────────────────
def _user_dir(uid: str) -> Path:
    d = DATA_DIR / "users" / uid
    d.mkdir(parents=True, exist_ok=True)
    return d


def _load_json(p: Path, default):
    if not p.exists():
        return default
    try:
        return json.loads(p.read_text())
    except Exception:
        return default


def _save_json(p: Path, data) -> None:
    p.write_text(json.dumps(data, indent=2))


# ── credentials (encrypted at rest) ─────────────────────────────────────────
# Lightweight XOR-with-rolling-key obfuscation backed by a server secret.
# Good enough to keep creds out of plaintext on disk; not a substitute for
# Fernet/KMS if you ever take this to production scale.
def _server_key() -> bytes:
    """Per-deployment key. Stable across restarts because it's derived from
    the env's SECRET_KEY, plus a per-install salt persisted to disk."""
    base = os.getenv("JARVIS_SCHOOL_KEY") or os.getenv("FLASK_SECRET_KEY") or "jarvis"
    salt_path = DATA_DIR / ".school_salt"
    if salt_path.exists():
        salt = salt_path.read_text().strip()
    else:
        salt = secrets.token_hex(16)
        salt_path.write_text(salt)
    return (base + salt).encode()


def _crypt(b: bytes) -> bytes:
    k = _server_key()
    return bytes(c ^ k[i % len(k)] for i, c in enumerate(b))


def encrypt(s: str) -> str:
    return base64.b64encode(_crypt(s.encode())).decode()


def decrypt(s: str) -> str:
    try:
        return _crypt(base64.b64decode(s.encode())).decode()
    except Exception:
        return ""


# ── platform connection ────────────────────────────────────────────────────
SUPPORTED_PLATFORMS = {
    "google_classroom": "Google Classroom",
    "canvas": "Canvas",
    "schoology": "Schoology",
    "powerschool": "PowerSchool",
    "blackboard": "Blackboard",
    "custom": "Other",
}
# Per-platform metadata for the Connectors UI: icon, login URL, scraper-capable
PLATFORM_META = {
    "google_classroom": {
        "name": "Google Classroom",
        "icon": "🎓",
        "login_url": "https://classroom.google.com/u/0/h",
        "ready": True,
        "warnings": "Uses your real Chrome. Sign in once — J@rv1s caches the session locally.",
    },
    "canvas": {
        "name": "Canvas",
        "icon": "🎨",
        "login_url": "https://canvas.instructure.com",
        "ready": False,    # scraper not built yet
        "warnings": "Scraper not yet built — coming soon.",
    },
    "schoology": {
        "name": "Schoology", "icon": "📘",
        "login_url": "https://app.schoology.com",
        "ready": False, "warnings": "Scraper not yet built — coming soon.",
    },
    "powerschool": {
        "name": "PowerSchool", "icon": "🏫",
        "login_url": "https://powerschool.com",
        "ready": False, "warnings": "Scraper not yet built — coming soon.",
    },
    "blackboard": {
        "name": "Blackboard", "icon": "⬛",
        "login_url": "https://blackboard.com",
        "ready": False, "warnings": "Scraper not yet built — coming soon.",
    },
}
VALID_MODES = ("desktop", "cloud", "manual")


def get_platform(uid: str) -> dict | None:
    """Returns the user's connected platform config (without password)."""
    rec = _load_json(_user_dir(uid) / "school.json", None)
    if not rec:
        return None
    return {
        "platform": rec.get("platform"),
        "platform_name": SUPPORTED_PLATFORMS.get(rec.get("platform", ""), "School"),
        "mode": rec.get("mode"),
        "url": rec.get("url"),
        "username": rec.get("username"),
        "has_password": bool(rec.get("password_enc")),
        "connected_at": rec.get("connected_at"),
        "last_synced_at": rec.get("last_synced_at"),
        "last_sync_count": rec.get("last_sync_count"),
    }


def set_platform(uid: str, platform: str, mode: str, *,
                 url: str = "", username: str = "", password: str = "") -> dict:
    """Save the user's school connection. Password is encrypted at rest."""
    if platform not in SUPPORTED_PLATFORMS:
        platform = "custom"
    if mode not in VALID_MODES:
        mode = "manual"
    rec = {
        "platform": platform,
        "mode": mode,
        "url": (url or "").strip(),
        "username": (username or "").strip(),
        "connected_at": time.time(),
    }
    if password:
        rec["password_enc"] = encrypt(password)
    _save_json(_user_dir(uid) / "school.json", rec)
    return get_platform(uid)


def disconnect(uid: str) -> None:
    p = _user_dir(uid) / "school.json"
    if p.exists():
        p.unlink()


# ── multi-connector model (new) ────────────────────────────────────────────
# Stored at data/users/<uid>/connectors.json as a list of dicts:
#   {platform, mode, connected_at, last_synced_at, last_sync_count, last_error,
#    status: "idle" | "syncing" | "error" | "needs_login"}
def _connectors_path(uid: str) -> Path:
    return _user_dir(uid) / "connectors.json"


def list_connectors(uid: str) -> list[dict]:
    """Return all connectors for this user, enriched with platform metadata."""
    conns = _load_json(_connectors_path(uid), [])
    out = []
    for c in conns:
        meta = PLATFORM_META.get(c.get("platform"), {})
        out.append({
            **c,
            "name": meta.get("name", c.get("platform", "Unknown")),
            "icon": meta.get("icon", "🔗"),
            "ready": meta.get("ready", False),
        })
    return out


def get_connector(uid: str, platform: str) -> dict | None:
    for c in list_connectors(uid):
        if c.get("platform") == platform:
            return c
    return None


def upsert_connector(uid: str, platform: str, **fields) -> dict:
    """Create or update a connector entry."""
    conns = _load_json(_connectors_path(uid), [])
    rec = next((c for c in conns if c.get("platform") == platform), None)
    if not rec:
        rec = {"platform": platform, "mode": fields.get("mode", "desktop"),
               "status": "idle", "connected_at": time.time()}
        conns.append(rec)
    for k, v in fields.items():
        if v is not None:
            rec[k] = v
    _save_json(_connectors_path(uid), conns)
    return rec


def remove_connector(uid: str, platform: str) -> bool:
    conns = _load_json(_connectors_path(uid), [])
    new = [c for c in conns if c.get("platform") != platform]
    if len(new) == len(conns):
        return False
    _save_json(_connectors_path(uid), new)
    # Also clear the Playwright profile (logged-out state).
    import shutil as _sh
    pd = _user_dir(uid) / "playwright" / platform
    if pd.exists():
        _sh.rmtree(pd, ignore_errors=True)
    return True


def is_logged_in(uid: str, platform: str) -> bool:
    """Best-effort check: does a cached Playwright profile exist for this
    platform? Doesn't actually validate the session — sync will surface that."""
    pd = _user_dir(uid) / "playwright" / platform
    return pd.exists() and any(pd.iterdir())


def connect_via_browser(uid: str, platform: str, *, headless: bool = False,
                        wait_seconds: int = 180) -> dict:
    """Launch a real Chrome window for the user to sign into `platform`.
    Blocks until the user lands on a non-login URL OR `wait_seconds` elapses.
    Caches the session in the per-platform Playwright profile dir.
    Returns {ok, logged_in, message}.
    """
    meta = PLATFORM_META.get(platform)
    if not meta:
        return {"ok": False, "error": f"Unknown platform: {platform}"}
    if not meta.get("ready"):
        return {"ok": False, "error": meta.get("warnings", "Not yet supported.")}

    pd = _user_dir(uid) / "playwright" / platform
    pd.mkdir(parents=True, exist_ok=True)
    login_url = meta["login_url"]
    upsert_connector(uid, platform, status="connecting", last_error=None)

    try:
        from playwright.sync_api import sync_playwright
        import time as _t
        with sync_playwright() as pw:
            launch_kwargs = dict(
                user_data_dir=str(pd),
                headless=headless,
                viewport={"width": 1280, "height": 900},
                args=["--disable-blink-features=AutomationControlled",
                      "--no-first-run", "--no-default-browser-check"],
            )
            try:
                ctx = pw.chromium.launch_persistent_context(channel="chrome", **launch_kwargs)
            except Exception:
                ctx = pw.chromium.launch_persistent_context(**launch_kwargs)
            ctx.add_init_script(
                "Object.defineProperty(navigator,'webdriver',{get:()=>undefined});"
                "window.chrome = window.chrome || {runtime:{}};"
            )
            page = ctx.pages[0] if ctx.pages else ctx.new_page()
            page.goto(login_url, wait_until="domcontentloaded")
            # Wait for the user to finish login (URL leaves accounts/login subpaths)
            deadline = _t.time() + wait_seconds
            logged_in = False
            while _t.time() < deadline:
                url = page.url or ""
                if "accounts.google.com" in url or "ServiceLogin" in url or "/login" in url:
                    _t.sleep(1); continue
                # Heuristic: we're on the platform's actual app domain
                if any(host in url for host in [meta["login_url"].split("/")[2]]):
                    logged_in = True
                    break
                _t.sleep(1)
            ctx.close()
    except Exception as ex:
        upsert_connector(uid, platform, status="error", last_error=str(ex))
        return {"ok": False, "error": str(ex)}

    status = "idle" if logged_in else "needs_login"
    upsert_connector(uid, platform, status=status,
                     connected_at=time.time() if logged_in else None,
                     last_error=None)
    return {"ok": True, "logged_in": logged_in,
            "message": "Signed in ✓" if logged_in else "Login window timed out — try again."}


def sync_connector(uid: str, platform: str, *, headless: bool = False) -> dict:
    """Run the platform scraper and add/dedup tasks. Marks status throughout."""
    meta = PLATFORM_META.get(platform)
    if not meta:
        return {"ok": False, "error": f"Unknown platform: {platform}"}
    if not meta.get("ready"):
        return {"ok": False, "error": meta.get("warnings", "Not yet supported.")}

    upsert_connector(uid, platform, status="syncing", last_error=None)
    pd = _user_dir(uid) / "playwright" / platform
    try:
        items = _run_scraper(platform, pd, headless=headless)
    except Exception as ex:
        upsert_connector(uid, platform, status="error", last_error=str(ex))
        return {"ok": False, "error": str(ex)}

    added = 0
    for it in items:
        before = len(_load_json(_user_dir(uid) / "tasks.json", []))
        add_task(uid, title=it.get("title", ""), subject=it.get("subject", ""),
                 due=it.get("due", ""), link=it.get("link", ""),
                 description=it.get("description", ""),
                 source=it.get("source", platform),
                 external_id=it.get("external_id", ""))
        after = len(_load_json(_user_dir(uid) / "tasks.json", []))
        if after > before:
            added += 1

    upsert_connector(uid, platform, status="idle",
                     last_synced_at=time.time(),
                     last_sync_count=len(items),
                     last_added_count=added)
    return {"ok": True, "added": added, "found": len(items),
            "tasks": list_tasks(uid),
            "message": f"Synced {len(items)} ({added} new)."}


# ── tasks ──────────────────────────────────────────────────────────────────
def list_tasks(uid: str) -> list[dict]:
    tasks = _load_json(_user_dir(uid) / "tasks.json", [])
    # newest-first by due (urgent first) then by created
    tasks.sort(key=lambda t: (t.get("due") or "9999", -(t.get("created") or 0)))
    return tasks


def get_task(uid: str, task_id: str) -> dict | None:
    for t in list_tasks(uid):
        if t.get("id") == task_id:
            return t
    return None


def add_task(uid: str, *, title: str, subject: str = "", due: str = "",
             link: str = "", description: str = "", source: str = "manual",
             external_id: str = "") -> dict:
    """Add a task. If `external_id` is supplied and already present, the
    existing task is updated (title/due/link refreshed) rather than duplicated.
    Returns the (new or updated) task."""
    tasks = _load_json(_user_dir(uid) / "tasks.json", [])
    # Dedup by external_id when present (e.g. classroom:c123:a456)
    if external_id:
        for t in tasks:
            if t.get("external_id") == external_id:
                t["title"] = (title or t.get("title", "")).strip() or t["title"]
                if subject: t["subject"] = subject.strip()
                if due:     t["due"] = due.strip()
                if link:    t["link"] = link.strip()
                if description: t["description"] = description.strip()
                t["last_synced"] = time.time()
                _save_json(_user_dir(uid) / "tasks.json", tasks)
                return t
    task = {
        "id": "t_" + secrets.token_hex(6),
        "external_id": external_id,
        "title": (title or "").strip() or "Untitled task",
        "subject": (subject or "").strip(),
        "due": (due or "").strip(),
        "link": (link or "").strip(),
        "description": (description or "").strip(),
        "source": source,       # "manual" | "google_classroom" | "canvas" | …
        "done": False,
        "created": time.time(),
    }
    tasks.append(task)
    _save_json(_user_dir(uid) / "tasks.json", tasks)
    return task


def update_task(uid: str, task_id: str, **fields) -> dict | None:
    tasks = _load_json(_user_dir(uid) / "tasks.json", [])
    for t in tasks:
        if t.get("id") == task_id:
            for k, v in fields.items():
                if v is not None:
                    t[k] = v
            _save_json(_user_dir(uid) / "tasks.json", tasks)
            return t
    return None


def delete_task(uid: str, task_id: str) -> bool:
    tasks = _load_json(_user_dir(uid) / "tasks.json", [])
    new = [t for t in tasks if t.get("id") != task_id]
    if len(new) == len(tasks):
        return False
    _save_json(_user_dir(uid) / "tasks.json", new)
    return True


## (kept-in-file shim — actual Playwright sync lives in sync_tasks below)
def _profile_dir(uid: str, platform: str) -> Path:
    p = _user_dir(uid) / "playwright" / platform
    p.mkdir(parents=True, exist_ok=True)
    return p


# ── sync + automation ─────────────────────────────────────────────────────
def sync_tasks(uid: str, *, force_local: bool = False) -> dict:
    """Pull current assignments from the connected platform.

    `force_local=True` means we're inside the desktop app — run Playwright
    in-process, with a headed browser. Otherwise on the cloud server:
      - mode=desktop → tell the web client to open the desktop app
      - mode=cloud   → run Playwright headlessly on the server
      - mode=manual  → no-op
    """
    cfg = get_platform(uid)
    if not cfg:
        return {"ok": False, "error": "no_platform"}
    platform = cfg.get("platform")
    mode = cfg.get("mode")

    # Manual mode never syncs.
    if mode == "manual":
        return {"ok": True, "queued": False, "added": 0,
                "message": "Manual mode — add tasks by hand."}

    # Desktop mode on the cloud server → tell the client to open the app.
    if mode == "desktop" and not force_local:
        return {"ok": True, "queued": False, "added": 0,
                "message": "Open the J@rv1s desktop app to run sync locally.",
                "action": "open_desktop_app"}

    # Cloud mode (or desktop running locally) → actually scrape.
    headless = (mode == "cloud") and not force_local
    try:
        items = _run_scraper(platform, _profile_dir(uid, platform), headless=headless)
    except Exception as ex:
        return {"ok": False, "error": str(ex),
                "message": f"Sync failed: {ex}"}

    added = 0
    for it in items:
        before = len(_load_json(_user_dir(uid) / "tasks.json", []))
        add_task(uid,
                 title=it.get("title", ""),
                 subject=it.get("subject", ""),
                 due=it.get("due", ""),
                 link=it.get("link", ""),
                 description=it.get("description", ""),
                 source=it.get("source", platform),
                 external_id=it.get("external_id", ""))
        after = len(_load_json(_user_dir(uid) / "tasks.json", []))
        if after > before:
            added += 1

    # Update last-synced timestamp on the platform config.
    rec = _load_json(_user_dir(uid) / "school.json", {}) or {}
    rec["last_synced_at"] = time.time()
    rec["last_sync_count"] = len(items)
    _save_json(_user_dir(uid) / "school.json", rec)

    return {"ok": True, "added": added, "found": len(items),
            "message": (f"Synced {len(items)} assignment{'s' if len(items)!=1 else ''} "
                        f"({added} new)."),
            "tasks": list_tasks(uid)}


def _run_scraper(platform: str, profile_dir: Path, *, headless: bool) -> list[dict]:
    """Dispatch to the correct scraper module. Easy to extend with more."""
    if platform == "google_classroom":
        from automation.scrapers import google_classroom
        return google_classroom.scrape(profile_dir, headless=headless)
    # TODO: add canvas / schoology / powerschool / blackboard
    raise NotImplementedError(
        f"Scraper for '{platform}' isn't built yet. Currently supported: google_classroom."
    )


def run_task(uid: str, task_id: str, mode_choice: str = "answers") -> dict:
    """Have J@rv1s actually work the assignment.

    mode_choice:
      "answers" → produce the file/answers; nothing is submitted.
      "submit"  → also submit it for the user via Playwright.

    Current implementation is a stub returning the action plan; the Flask
    route hands off to the LLM for the "answers" path and to Playwright
    (desktop or cloud) for the "submit" path. See core/engine.py for chat.
    """
    task = get_task(uid, task_id)
    if not task:
        return {"ok": False, "error": "no_such_task"}
    cfg = get_platform(uid) or {}
    return {
        "ok": True,
        "task": task,
        "mode": cfg.get("mode", "manual"),
        "choice": mode_choice,
        "next": "chat_with_seed",   # frontend opens chat with the assignment prompt
    }
