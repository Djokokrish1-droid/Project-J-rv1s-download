"""Flask REST API + web UI host for Jarvis."""
from __future__ import annotations
from pathlib import Path

import os
import json
from flask import (Flask, request, jsonify, send_from_directory, Response,
                   stream_with_context, g, session)
from flask_cors import CORS

from core.engine import JarvisEngine
from core.usage import UsageGuard
from core import auth
from config import (API_HOST, API_PORT, HOSTED_MODE, DATA_DIR, REQUIRE_SUBSCRIPTION,
                    ALLOW_MACHINE_CONTROL)

WEB_DIR = Path(__file__).parent / "web"


def create_app(engine: JarvisEngine | None = None) -> Flask:
    app = Flask(__name__, static_folder=None)
    app.secret_key = os.getenv("JARVIS_SECRET", "dev-secret-change-me")
    app.config["PERMANENT_SESSION_LIFETIME"] = 60 * 60 * 24 * 30  # 30 days
    CORS(app, supports_credentials=True)

    auth.ensure_admin()  # create the admin account if ADMIN_PASSWORD is set

    # One spend guard shared across all users; one engine per user, lazily made.
    shared_usage = UsageGuard()
    engines: dict[str, JarvisEngine] = {}
    if engine is not None:
        engines["local"] = engine

    def get_engine(uid: str) -> JarvisEngine:
        if uid not in engines:
            data_dir = DATA_DIR if uid == "local" else auth.user_dir(uid)
            eng = JarvisEngine(data_dir=data_dir, usage=shared_usage)
            # Admins default to the top-tier model (Opus) the first time their
            # engine spins up; they can still switch via the picker.
            if HOSTED_MODE and auth.is_admin(uid) and not eng.settings.data.get("model"):
                from config import PLAN_MODELS
                eng.set_model(PLAN_MODELS.get("max", eng.claude.model))
            engines[uid] = eng
        # Always sync per-user prefs (custom instructions + nickname) onto the
        # engine so Settings → General changes apply on the next message.
        eng = engines[uid]
        prefs = auth.get_prefs(uid) if uid != "local" else auth.default_prefs()
        eng.custom_instructions = prefs.get("custom_instructions", "")
        eng.nickname = prefs.get("nickname", "") or prefs.get("full_name", "").split(" ")[0]
        eng.auto_memory = bool(prefs.get("generate_memory", True))
        return eng

    @app.before_request
    def _resolve_user():
        if request.method == "OPTIONS":
            return
        uid = session.get("uid")
        path = request.path
        if not uid and HOSTED_MODE:
            # public paths are fine; data endpoints require login
            _public = (path.startswith("/api/auth") or path == "/api/health"
                       or path == "/api/billing/webhook")
            if path.startswith("/api/") and not _public:
                return jsonify({"error": "auth required", "auth": True}), 401
            g.uid, g.eng = None, None
            return
        g.uid = uid or "local"
        g.eng = get_engine(g.uid)

        # Hard paywall on the thing that costs money + delivers the product:
        # SENDING MESSAGES. Browsing (projects, skills, settings) is allowed so an
        # unsubscribed user can look around, but they cannot chat without a plan.
        if (HOSTED_MODE and REQUIRE_SUBSCRIPTION and g.uid != "local"
                and path.startswith("/api/chat")):
            if not auth.is_admin(g.uid) and not auth.is_subscribed(g.uid):
                return jsonify({"error": "subscription required", "paywall": True}), 402

    # -- auth --------------------------------------------------------------
    @app.post("/api/auth/signup")
    def signup():
        d = request.get_json(force=True) or {}
        email = (d.get("username", "") or d.get("email", "")).strip().lower()
        # Pre-check so the error code is "email_exists" instead of generic
        if email and auth.email_exists(email):
            return {"error": f"An account already exists for {email}. Sign in instead?",
                    "code": "email_exists", "email": email}, 409
        ok, uid, err = auth.create_user(email, d.get("password", ""))
        if not ok:
            return {"error": err, "code": "create_failed"}, 400
        session["uid"] = uid
        session.permanent = True
        try:
            from core import mailer
            sent = mailer.welcome(email)
            print(f"[signup] welcome email send returned: {sent}")
        except Exception as ex:  # never block signup on email
            print(f"[signup] welcome email exception: {type(ex).__name__}: {ex}")
        return {"ok": True, "username": email}

    @app.post("/api/auth/forgot")
    def forgot_password():
        d = request.get_json(force=True) or {}
        email = (d.get("email", "") or "").strip().lower()
        token, addr = auth.create_reset_token(email)
        if token and addr:
            from core import mailer
            base = (__import__("config").APP_BASE_URL or request.host_url.rstrip("/")).rstrip("/")
            mailer.password_reset(addr, f"{base}/reset?token={token}")
        # Always say the same thing — never reveal which emails are registered.
        return {"ok": True}

    @app.post("/api/auth/reset")
    def reset_password():
        d = request.get_json(force=True) or {}
        ok, err = auth.reset_password(d.get("token", ""), d.get("password", ""))
        return ({"ok": True} if ok else ({"error": err}, 400))

    @app.get("/reset")
    def reset_page():
        return send_from_directory(WEB_DIR, "reset.html")

    @app.post("/api/auth/login")
    def login():
        d = request.get_json(force=True) or {}
        ok, uid, reason = auth.verify_user(d.get("username", ""), d.get("password", ""))
        if not ok:
            msg = {
                "no_user": "No account found with that email. Create one instead?",
                "bad_password": "Incorrect password. Try again or use 'Forgot password?'",
                "invalid_input": "Enter your email and password.",
            }.get(reason, "Invalid email or password.")
            return {"error": msg, "code": reason}, 401
        session["uid"] = uid
        session.permanent = True
        return {"ok": True, "username": d["username"].strip().lower()}

    @app.post("/api/auth/logout")
    def logout():
        session.clear()
        return {"ok": True}

    @app.get("/api/auth/me")
    def me():
        uid = session.get("uid")
        return {"authed": bool(uid), "hosted": HOSTED_MODE,
                "is_admin": bool(uid and auth.is_admin(uid))}

    # -- account / settings ------------------------------------------------
    @app.get("/api/account")
    def account():
        uid = getattr(g, "uid", None) or "local"
        from core import auth as _auth
        return {**_auth.account_info(uid), "trial": _auth.trial_info(uid)}

    @app.post("/api/account/password")
    def change_password():
        d = request.get_json(force=True) or {}
        uid = getattr(g, "uid", None)
        if not uid or uid == "local":
            return {"error": "Not available."}, 400
        ok, err = auth.change_password(uid, d.get("old", ""), d.get("new", ""))
        return ({"ok": True} if ok else ({"error": err}, 400))

    @app.post("/api/account/delete")
    def delete_account():
        uid = getattr(g, "uid", None)
        if not uid or uid == "local":
            return {"error": "Not available."}, 400
        ok = auth.delete_user(uid)
        # Evict the in-memory engine for this uid so any cached state is gone.
        engines.pop(uid, None)
        session.clear()
        if not ok:
            return {"error": "Account not found."}, 404
        print(f"[account] deleted uid={uid}")
        return {"ok": True}

    # -- mailer diagnostics (admin only) -----------------------------------
    @app.get("/api/admin/mailer")
    def admin_mailer():
        uid = getattr(g, "uid", None)
        if not uid or not auth.is_admin(uid):
            return {"error": "admins only"}, 403
        from core import mailer
        return mailer.diagnostics()

    @app.post("/api/admin/mailer/test")
    def admin_mailer_test():
        uid = getattr(g, "uid", None)
        if not uid or not auth.is_admin(uid):
            return {"error": "admins only"}, 403
        from core import mailer
        to = (request.get_json(silent=True) or {}).get("to") or auth.email_for_uid(uid)
        if not to:
            return {"error": "No recipient"}, 400
        ok = mailer.welcome(to)
        # Include the exact Resend response so the user can see the error
        # without grepping Render logs.
        return {"ok": ok, "to": to, "configured": mailer.configured(),
                "last_result": mailer.last_result()}

    @app.get("/api/account/export")
    def export_account():
        eng = g.eng
        data = {
            "account": auth.account_info(getattr(g, "uid", "local")),
            "preferences": eng.memory.preferences,
            "facts": eng.memory.facts,
            "imported": eng.memory.imported,
            "projects": eng.projects.list(),
        }
        return Response(json.dumps(data, indent=2, default=str),
                        mimetype="application/json",
                        headers={"Content-Disposition": "attachment; filename=jarvis-export.json"})

    # -- preferences (Settings → General/Privacy/Capabilities) ------------
    @app.get("/api/account/prefs")
    def prefs_get():
        uid = getattr(g, "uid", None) or "local"
        return {"prefs": auth.get_prefs(uid) if uid != "local" else auth.default_prefs()}

    @app.put("/api/account/prefs")
    def prefs_update():
        uid = getattr(g, "uid", None)
        if not uid or uid == "local":
            return {"error": "Sign in first."}, 401
        partial = request.get_json(force=True) or {}
        return {"prefs": auth.update_prefs(uid, partial)}

    # -- usage (Settings → Usage tab) --------------------------------------
    @app.get("/api/usage/me")
    def usage_me():
        from config import PLAN_CAPS, DAILY_GLOBAL_COST_CEILING
        uid = getattr(g, "uid", None) or "local"
        plan = auth.get_plan(uid)
        cap = PLAN_CAPS.get(plan, 0) if uid != "local" else 9999
        eng = g.eng
        stats = eng.usage.stats() if eng else {}
        used = stats.get("user_today", 0) if hasattr(eng, "usage") else 0
        return {
            "plan": plan,
            "daily_cap": cap,
            "used_today": used,
            "percent_used": min(100, round(100 * used / cap)) if cap else 0,
            "global_cost_est": stats.get("global_cost_est", 0),
            "ceiling": DAILY_GLOBAL_COST_CEILING,
            "active_users": stats.get("active_users", 0),
            "session": stats,
        }

    # -- memory (import from other AI providers, view, clear) --------------
    @app.get("/api/memory")
    def memory_get():
        from config import MEMORY_IMPORT_PROMPT
        eng = g.eng
        return {
            "import_prompt": MEMORY_IMPORT_PROMPT,
            "imported": eng.memory.imported,
            "imported_text": eng.memory.imported_text(),
            "preferences": eng.memory.preferences,
            "facts_count": len(eng.memory.facts),
        }

    @app.post("/api/memory/import")
    def memory_import():
        d = request.get_json(force=True) or {}
        text = (d.get("text") or "").strip()
        source = (d.get("source") or "other_ai").strip().lower()[:40]
        if not text:
            return {"error": "Paste the export from your other AI first."}, 400
        eng = g.eng
        eng.memory.add_import(text, source=source)
        return {"ok": True, "count": len(eng.memory.imported)}

    @app.delete("/api/memory/import")
    def memory_clear_imports():
        eng = g.eng
        eng.memory.clear_imports()
        return {"ok": True}

    @app.delete("/api/memory/import/<int:index>")
    def memory_delete_one(index):
        eng = g.eng
        if 0 <= index < len(eng.memory.imported):
            eng.memory.imported.pop(index)
            eng.memory.save()
            return {"ok": True, "count": len(eng.memory.imported)}
        return {"error": "out of range"}, 404

    # ---- Memories page: per-atom CRUD --------------------------------
    @app.get("/api/memory/atoms")
    def memory_atoms():
        """Unified list: facts + preferences + imports as a single feed."""
        eng = g.eng
        return {"atoms": eng.memory.all_atoms()}

    @app.post("/api/memory/facts")
    def memory_fact_add():
        d = request.get_json(force=True) or {}
        text = (d.get("text") or "").strip()
        if not text:
            return {"error": "Fact text required."}, 400
        tag = (d.get("tag") or "manual").strip()[:32]
        eng = g.eng
        fid = eng.memory.remember(text, tag=tag)
        return {"ok": True, "id": fid}

    @app.put("/api/memory/facts/<fact_id>")
    def memory_fact_update(fact_id):
        d = request.get_json(force=True) or {}
        eng = g.eng
        rec = eng.memory.update_fact(fact_id, fact=d.get("text"), tag=d.get("tag"))
        return ({"fact": rec} if rec else ({"error": "no such fact"}, 404))

    @app.delete("/api/memory/facts/<fact_id>")
    def memory_fact_delete(fact_id):
        eng = g.eng
        ok = eng.memory.delete_fact(fact_id)
        return ({"ok": True} if ok else ({"error": "no such fact"}, 404))

    @app.delete("/api/memory/facts")
    def memory_facts_clear():
        eng = g.eng
        tag = request.args.get("tag")
        n = eng.memory.clear_facts(tag=tag)
        return {"ok": True, "deleted": n}

    # -- public pages (no login) -------------------------------------------
    @app.get("/terms")
    def terms_page():
        return send_from_directory(WEB_DIR, "terms.html")

    @app.get("/privacy")
    def privacy_page():
        return send_from_directory(WEB_DIR, "privacy.html")

    @app.get("/help")
    def help_page():
        return send_from_directory(WEB_DIR, "help.html")

    @app.get("/pricing")
    def pricing_page():
        return send_from_directory(WEB_DIR, "pricing.html")

    # -- admin -------------------------------------------------------------
    @app.get("/api/admin/stats")
    def admin_stats():
        uid = getattr(g, "uid", None)
        if not uid or not auth.is_admin(uid):
            return {"error": "admins only"}, 403
        return {
            **auth.admin_summary(),
            "usage": eng.usage.stats() if (eng := g.eng) else {},
        }

    # -- billing (Stripe) --------------------------------------------------
    @app.get("/api/billing/status")
    def billing_status():
        from core import billing, auth as _auth
        from config import PLANS, REQUIRE_SUBSCRIPTION
        uid = getattr(g, "uid", None) or "local"
        return {
            "enabled": billing.enabled(),
            "subscribed": _auth.is_subscribed(uid),
            "plan": _auth.get_plan(uid),
            "trial": _auth.trial_info(uid),
            "is_admin": _auth.is_admin(uid),
            "require_subscription": REQUIRE_SUBSCRIPTION and HOSTED_MODE,
            "plans": PLANS,
        }

    @app.post("/api/billing/checkout")
    def billing_checkout():
        from core import billing
        uid = getattr(g, "uid", None)
        if not uid or uid == "local":
            return {"error": "Sign in first."}, 401
        if not billing.enabled():
            return {"error": "Billing isn't configured yet."}, 503
        body = request.get_json(silent=True) or {}
        tier = body.get("tier", "starter")
        interval = body.get("interval", "monthly")
        try:
            return {"url": billing.checkout_url(uid, tier, interval)}
        except Exception as ex:
            return {"error": str(ex)}, 500

    @app.post("/api/billing/portal")
    def billing_portal():
        from core import billing
        uid = getattr(g, "uid", None)
        if not uid or uid == "local":
            return {"error": "Sign in first."}, 401
        url = billing.create_portal_session(uid, return_url=request.host_url.rstrip("/"))
        return {"url": url} if url else ({"error": "No subscription to manage."}, 404)

    @app.post("/api/billing/webhook")
    def billing_webhook():
        from core import billing
        ok, msg = billing.handle_webhook(request.get_data(), request.headers.get("Stripe-Signature", ""))
        return ({"ok": True, "msg": msg} if ok else ({"error": msg}, 400))

    # -- school / tasks ----------------------------------------------------
    def _require_uid():
        uid = getattr(g, "uid", None)
        if not uid or uid == "local":
            return None, ({"error": "Sign in first."}, 401)
        return uid, None

    @app.get("/api/school/platform")
    def school_get():
        uid, err = _require_uid()
        if err: return err
        from core import school
        return {"platform": school.get_platform(uid)}

    @app.post("/api/school/platform")
    def school_set():
        uid, err = _require_uid()
        if err: return err
        from core import school
        d = request.get_json(force=True) or {}
        cfg = school.set_platform(uid,
            platform=d.get("platform", "custom"),
            mode=d.get("mode", "manual"),
            url=d.get("url", ""),
            username=d.get("username", ""),
            password=d.get("password", ""))
        return {"platform": cfg}

    @app.delete("/api/school/platform")
    def school_disconnect():
        uid, err = _require_uid()
        if err: return err
        from core import school
        school.disconnect(uid)
        return {"ok": True}

    @app.get("/api/tasks")
    def tasks_list():
        uid, err = _require_uid()
        if err: return err
        from core import school
        return {"tasks": school.list_tasks(uid),
                "platform": school.get_platform(uid)}

    @app.post("/api/tasks")
    def tasks_add():
        uid, err = _require_uid()
        if err: return err
        from core import school
        d = request.get_json(force=True) or {}
        t = school.add_task(uid,
            title=d.get("title", ""),
            subject=d.get("subject", ""),
            due=d.get("due", ""),
            link=d.get("link", ""),
            description=d.get("description", ""))
        return {"task": t}

    @app.put("/api/tasks/<task_id>")
    def tasks_update(task_id):
        uid, err = _require_uid()
        if err: return err
        from core import school
        d = request.get_json(force=True) or {}
        t = school.update_task(uid, task_id,
            title=d.get("title"), subject=d.get("subject"),
            due=d.get("due"), link=d.get("link"),
            description=d.get("description"), done=d.get("done"))
        return ({"task": t} if t else ({"error": "no such task"}, 404))

    @app.delete("/api/tasks/<task_id>")
    def tasks_delete(task_id):
        uid, err = _require_uid()
        if err: return err
        from core import school
        ok = school.delete_task(uid, task_id)
        return ({"ok": True} if ok else ({"error": "no such task"}, 404))

    @app.post("/api/tasks/sync")
    def tasks_sync():
        uid, err = _require_uid()
        if err: return err
        from core import school
        return school.sync_tasks(uid)

    @app.post("/api/tasks/<task_id>/run")
    def tasks_run(task_id):
        uid, err = _require_uid()
        if err: return err
        from core import school
        d = request.get_json(silent=True) or {}
        return school.run_task(uid, task_id, mode_choice=d.get("choice", "answers"))

    # -- multi-connector model ---------------------------------------------
    @app.get("/api/connectors")
    def connectors_list():
        uid, err = _require_uid()
        if err: return err
        from core import school
        # Build a unified list: every supported platform + its current state
        connected = {c["platform"]: c for c in school.list_connectors(uid)}
        out = []
        for pid, meta in school.PLATFORM_META.items():
            c = connected.get(pid, {})
            out.append({
                "platform": pid,
                "name": meta["name"],
                "icon": meta["icon"],
                "ready": meta["ready"],
                "warnings": meta.get("warnings", ""),
                "status": c.get("status", "disconnected"),
                "connected_at": c.get("connected_at"),
                "last_synced_at": c.get("last_synced_at"),
                "last_sync_count": c.get("last_sync_count"),
                "last_added_count": c.get("last_added_count"),
                "last_error": c.get("last_error"),
                "logged_in": school.is_logged_in(uid, pid),
            })
        return {"connectors": out, "supports_local_browser": HOSTED_MODE is False or not HOSTED_MODE}

    @app.post("/api/connectors/<platform>/connect")
    def connectors_connect(platform):
        """Launch a real-Chrome login flow for this platform.
        Desktop-only by design — most school Google accounts block OAuth
        and Google flags cloud Chromium as bot traffic."""
        uid, err = _require_uid()
        if err: return err
        from core import school
        if HOSTED_MODE:
            return {"ok": False,
                    "action": "open_desktop_app",
                    "error": "School connectors run on your computer, not in the cloud. Download the J@rv1s desktop app at projectjarvis.app/download to connect."}
        d = request.get_json(silent=True) or {}
        result = school.connect_via_browser(uid, platform,
                                            headless=bool(d.get("headless", False)))
        return result

    @app.post("/api/connectors/<platform>/sync")
    def connectors_sync(platform):
        uid, err = _require_uid()
        if err: return err
        from core import school
        if HOSTED_MODE:
            return {"ok": False, "action": "open_desktop_app",
                    "error": "School sync runs on your computer, not in the cloud. Open the J@rv1s desktop app to sync."}
        return school.sync_connector(uid, platform, headless=False)

    @app.delete("/api/connectors/<platform>")
    def connectors_remove(platform):
        uid, err = _require_uid()
        if err: return err
        from core import school
        ok = school.remove_connector(uid, platform)
        return ({"ok": True} if ok else ({"error": "not connected"}, 404))

    # -- static web UI -----------------------------------------------------
    @app.get("/")
    def index():
        return send_from_directory(WEB_DIR, "index.html")

    @app.get("/static/<path:filename>")
    def static_files(filename):
        return send_from_directory(WEB_DIR, filename)

    # -- meta --------------------------------------------------------------
    @app.get("/api/health")
    def health():
        return {"status": "ok", "active_project": g.eng.active_project,
                "model": g.eng.claude.model}

    @app.get("/api/state")
    def state():
        return {
            "active_project": g.eng.active_project,
            "active_conversation_id": g.eng.active_conversation_id,
            "model": g.eng.claude.model,
            "theme": g.eng.settings.get("theme", "dark"),
            "projects": g.eng.projects.list_pinned(),
            "all_projects": g.eng.projects.list(),
            "upcoming": g.eng.projects.upcoming(14),
            "history": g.eng.current_history(),
            "preferences": g.eng.memory.preferences,
            "skills": g.eng.skills.list(),
            "browser": g.eng.browser_status(),
            "hosted": HOSTED_MODE,
            "automation": ALLOW_MACHINE_CONTROL,
        }

    # -- model selection ---------------------------------------------------
    @app.get("/api/models")
    def models():
        return jsonify([
            {"id": "claude-opus-4-7", "name": "J@rv1s 1.0",
             "desc": "Premium tier. Maximum capability."},
            {"id": "claude-sonnet-4-6", "name": "Jarvix 1.1",
             "desc": "Balanced. Fast and capable."},
            {"id": "claude-haiku-4-5-20251001", "name": "Mini J@r 1.0",
             "desc": "Lightning fast. For quick replies."},
        ])

    @app.post("/api/model")
    def set_model():
        d = request.get_json(force=True)
        new = (d or {}).get("model", "").strip()
        if not new:
            return {"error": "model required"}, 400
        # In hosted mode, only admins can switch model; regular users are
        # locked to whatever their plan tier specifies.
        if HOSTED_MODE and not auth.is_admin(getattr(g, "uid", "") or ""):
            return {"error": "Model is set by your plan."}, 403
        g.eng.set_model(new)
        return {"model": new}

    @app.post("/api/theme")
    def set_theme():
        d = request.get_json(force=True)
        theme = (d or {}).get("theme", "dark")
        g.eng.settings.set("theme", theme)
        return {"theme": theme}

    # -- skills ------------------------------------------------------------
    @app.get("/api/skills")
    def list_skills():
        return jsonify(g.eng.skills.list())

    @app.post("/api/skills")
    def create_skill():
        d = request.get_json(force=True)
        try:
            s = g.eng.skills.create(
                name=d["name"],
                description=d.get("description", ""),
                prompt=d["prompt"],
                icon=d.get("icon", "✨"),
            )
            return jsonify(s), 201
        except ValueError as ex:
            return {"error": str(ex)}, 400

    @app.post("/api/skills/<sid>/toggle")
    def toggle_skill(sid):
        on = g.eng.skills.toggle(sid)
        return {"id": sid, "enabled": on}

    @app.post("/api/skills/<sid>/enable")
    def enable_skill(sid):
        g.eng.skills.enable(sid)
        return {"id": sid, "enabled": True}

    @app.post("/api/skills/<sid>/disable")
    def disable_skill(sid):
        g.eng.skills.disable(sid)
        return {"id": sid, "enabled": False}

    @app.delete("/api/skills/<sid>")
    def delete_skill(sid):
        ok = g.eng.skills.delete(sid)
        return {"ok": ok}

    # -- browser automation (arm/disarm; launches lazily on demand) --------
    # In hosted mode these features are disabled — they'd control the server, not
    # the user's own machine.
    def _machine_disabled():
        return {"error": "This feature is disabled on the hosted version."}, 403

    @app.get("/api/browser/status")
    def browser_status():
        return g.eng.browser_status()

    @app.post("/api/browser/enable")
    def browser_enable():
        if not ALLOW_MACHINE_CONTROL:
            return {"error": "Web automation runs only in the J@rv1s desktop app, "
                    "not on the web."}, 403
        if HOSTED_MODE:
            uid = getattr(g, "uid", "") or ""
            if not auth.is_admin(uid) and auth.get_plan(uid) not in ("professional", "max"):
                return {"error": "Web automation is a Professional feature.",
                        "upgrade": True}, 403
        g.eng.arm_browser()
        return g.eng.browser_status()

    @app.post("/api/browser/disable")
    def browser_disable():
        g.eng.disarm_browser()
        return g.eng.browser_status()

    @app.post("/api/browser/restrict")
    def browser_restrict():
        d = request.get_json(silent=True) or {}
        g.eng.set_browser_restricted(bool(d.get("restricted", True)))
        return g.eng.browser_status()

    @app.post("/api/browser/allowlist")
    def browser_allowlist_add():
        d = request.get_json(force=True)
        if d.get("add"):
            g.eng.add_allowed_site(d["add"])
        if d.get("remove"):
            g.eng.remove_allowed_site(d["remove"])
        return g.eng.browser_status()

    # -- chat --------------------------------------------------------------
    def _uid():
        return getattr(g, "uid", None) or "local"

    @app.get("/api/usage")
    def usage():
        return g.eng.usage.stats()

    @app.post("/api/chat")
    def chat():
        data = request.get_json(force=True)
        msg = (data or {}).get("message", "").strip()
        if not msg:
            return {"error": "message required"}, 400
        reply = g.eng.ask(msg, user_id=_uid())
        return {"reply": reply, "history": g.eng.session.history()}

    @app.post("/api/chat/stream")
    def chat_stream():
        data = request.get_json(force=True)
        msg = (data or {}).get("message", "").strip()
        if not msg:
            return {"error": "message required"}, 400

        uid = _uid()

        def generate():
            try:
                for chunk in g.eng.ask_stream(msg, user_id=uid):
                    yield f"data: {json.dumps({'t': chunk})}\n\n"
                yield f"data: {json.dumps({'done': True})}\n\n"
            except Exception as ex:
                yield f"data: {json.dumps({'error': str(ex)})}\n\n"

        return Response(stream_with_context(generate()),
                        mimetype="text/event-stream",
                        headers={"Cache-Control": "no-cache",
                                 "X-Accel-Buffering": "no"})

    @app.post("/api/reset")
    def reset():
        g.eng.reset_conversation()
        return {"ok": True}

    # -- projects ----------------------------------------------------------
    @app.get("/api/projects")
    def list_projects():
        return jsonify(g.eng.projects.list())

    @app.post("/api/projects")
    def new_project():
        data = request.get_json(force=True)
        meta = g.eng.projects.create(data["name"], data.get("description", ""))
        return jsonify(meta), 201

    @app.get("/api/projects/<name>")
    def project_detail(name):
        meta = g.eng.projects.get(name)
        if not meta:
            return {"error": "not found"}, 404
        return jsonify(meta)

    @app.delete("/api/projects/<name>")
    def delete_project(name):
        ok = g.eng.projects.delete(name)
        if g.eng.active_project == name:
            g.eng.active_project = None
        return ({"ok": True} if ok else ({"error": "not found"}, 404))

    @app.post("/api/projects/<name>/use")
    def use_project(name):
        ok = g.eng.set_project(name)
        return ({"active": name, "conversation_id": g.eng.active_conversation_id}
                if ok else ({"error": "not found"}, 404))

    @app.post("/api/projects/clear")
    def clear_project():
        g.eng.clear_project()
        return {"ok": True}

    # -- files -------------------------------------------------------------
    @app.get("/api/projects/<name>/files")
    def list_files(name):
        return jsonify([{"name": f.name, "size": f.stat().st_size}
                        for f in g.eng.projects.files(name)])

    @app.post("/api/projects/<name>/files")
    def upload_file(name):
        if not g.eng.projects.get(name):
            return {"error": "not found"}, 404
        saved = []
        for f in request.files.getlist("file"):
            data = f.read()
            dst = g.eng.projects.save_upload(name, f.filename, data)
            saved.append(dst.name)
        if not saved:
            return {"error": "no file provided"}, 400
        return {"saved": saved}, 201

    @app.delete("/api/projects/<name>/files/<path:filename>")
    def delete_file(name, filename):
        ok = g.eng.projects.delete_file(name, filename)
        return {"ok": ok}

    @app.post("/api/projects/<name>/pin")
    def pin_project(name):
        d = request.get_json(silent=True) or {}
        pinned = bool(d.get("pinned", True))
        ok = g.eng.projects.set_pinned(name, pinned)
        return ({"name": name, "pinned": pinned} if ok else ({"error": "not found"}, 404))

    @app.put("/api/projects/<name>/instructions")
    def set_instructions(name):
        d = request.get_json(force=True)
        ok = g.eng.projects.set_instructions(name, d.get("instructions", ""))
        return ({"ok": True} if ok else ({"error": "not found"}, 404))

    # -- conversations -----------------------------------------------------
    @app.get("/api/projects/<name>/conversations")
    def list_conversations(name):
        return jsonify(g.eng.projects.conversations(name))

    @app.post("/api/projects/<name>/conversations")
    def new_conversation(name):
        d = request.get_json(silent=True) or {}
        conv = g.eng.start_new_conversation(name, d.get("title", ""))
        return jsonify({
            "id": conv["id"], "title": conv["title"],
            "preview": conv["preview"], "created": conv["created"],
            "updated": conv["updated"], "message_count": 0,
        }), 201

    @app.get("/api/projects/<name>/conversations/<cid>")
    def get_conversation(name, cid):
        conv = g.eng.projects.get_conversation(name, cid)
        if not conv:
            return {"error": "not found"}, 404
        return jsonify(conv)

    @app.post("/api/projects/<name>/conversations/<cid>/open")
    def open_conversation(name, cid):
        ok = g.eng.open_conversation(name, cid)
        return ({"ok": True} if ok else ({"error": "not found"}, 404))

    @app.delete("/api/projects/<name>/conversations/<cid>")
    def delete_conversation(name, cid):
        ok = g.eng.projects.delete_conversation(name, cid)
        if g.eng.active_conversation_id == cid:
            g.eng.active_conversation_id = None
        return {"ok": ok}

    # -- project-page suggestions -----------------------------------------
    @app.get("/api/projects/<name>/suggestions")
    def suggestions(name):
        meta = g.eng.projects.get(name)
        if not meta:
            return {"error": "not found"}, 404
        n = meta["name"]
        items = [
            {"icon": "📝", "title": "Create a Study Guide",
             "prompt": f"Make me a focused study guide for what we've been working on in {n}. Pull from our recent chats and any uploaded files."},
            {"icon": "🧠", "title": "Quiz Me",
             "prompt": f"Quiz me on the most important {n} concepts. Active recall, one question at a time, escalate difficulty."},
            {"icon": "✅", "title": "Complete an Assignment",
             "prompt": f"Walk me through completing my next {n} assignment. Start by asking which one and what's already done."},
            {"icon": "📊", "title": "Summarize This Week",
             "prompt": f"Summarize what I've covered in {n} this week. Highlight anything I struggled with or skipped."},
            {"icon": "🎯", "title": "Find My Weak Spots",
             "prompt": f"Look at my recent {n} work and identify 2-3 concepts I should drill before the next test."},
            {"icon": "📅", "title": "Plan My Next Study Block",
             "prompt": f"Plan a 60-minute {n} study block for tonight. Be specific about what to do and in what order."},
        ]
        return jsonify(items)

    @app.post("/api/projects/<name>/assignments")
    def add_assignment(name):
        d = request.get_json(force=True)
        item = g.eng.projects.add_assignment(name, d["title"], d["due"], d.get("notes", ""))
        return jsonify(item), 201

    @app.post("/api/projects/<name>/assignments/complete")
    def complete_assignment(name):
        d = request.get_json(force=True)
        ok = g.eng.projects.complete_assignment(name, d["title"])
        return {"ok": ok}

    @app.post("/api/projects/<name>/scheduled")
    def add_scheduled(name):
        d = request.get_json(force=True)
        try:
            item = g.eng.projects.add_scheduled(name, d["title"], d.get("cadence", "weekly"))
            return jsonify(item), 201
        except ValueError as ex:
            return {"error": str(ex)}, 404

    @app.delete("/api/projects/<name>/scheduled/<int:index>")
    def remove_scheduled(name, index):
        return {"ok": g.eng.projects.remove_scheduled(name, index)}

    @app.get("/api/upcoming")
    def upcoming():
        days = int(request.args.get("days", 14))
        return jsonify(g.eng.projects.upcoming(days))

    @app.get("/api/search")
    def search():
        q = request.args.get("q", "")
        return jsonify(g.eng.projects.search(q))

    # -- memory ------------------------------------------------------------
    @app.post("/api/memory/remember")
    def remember():
        d = request.get_json(force=True)
        g.eng.memory.remember(d["fact"], d.get("tag", "general"))
        return {"ok": True}

    @app.post("/api/memory/feedback")
    def feedback():
        d = request.get_json(force=True)
        g.eng.feedback(d["text"], d.get("rating"))
        return {"ok": True}

    @app.post("/api/memory/preference")
    def preference():
        d = request.get_json(force=True)
        g.eng.memory.set_preference(d["key"], d["value"])
        return {"ok": True}

    # -- voice (best-effort; requires mic) ---------------------------------
    @app.post("/api/voice/listen")
    def voice_listen():
        if not ALLOW_MACHINE_CONTROL or (HOSTED_MODE and not auth.is_admin(getattr(g, "uid", "") or "")):
            return _machine_disabled()
        try:
            from interfaces.voice import VoiceInterface
            v = VoiceInterface()
            text = v.listen()
            return {"text": text}
        except Exception as ex:
            return {"error": str(ex)}, 500

    @app.post("/api/voice/speak")
    def voice_speak():
        if not ALLOW_MACHINE_CONTROL or (HOSTED_MODE and not auth.is_admin(getattr(g, "uid", "") or "")):
            return _machine_disabled()
        try:
            from interfaces.voice import VoiceInterface
            d = request.get_json(force=True)
            v = VoiceInterface()
            v.speak(d.get("text", ""))
            return {"ok": True}
        except Exception as ex:
            return {"error": str(ex)}, 500

    return app


def main():
    app = create_app()
    app.run(host=API_HOST, port=API_PORT, debug=False)


if __name__ == "__main__":
    main()
