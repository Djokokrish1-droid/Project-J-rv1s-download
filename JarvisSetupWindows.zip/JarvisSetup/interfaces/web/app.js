// =====================================================
// JARVIS — frontend logic
// =====================================================
const API = (path, opts) => fetch(path, opts).then(async r => {
  const text = await r.text();
  const data = text ? JSON.parse(text) : {};
  return r.ok ? data : Promise.reject(data);
});

// State
let state = {
  active_project: null,
  active_conversation_id: null,
  model: 'claude-opus-4-7',
  projects: [],
  upcoming: [],
  history: [],
  skills: [],
  browser: { running: false },
};
let currentProjectPage = null;  // name of project currently shown in project view
let models = [];
let speakResponses = false;
let skillFilter = 'all';
let skillSearch = '';

// DOM helpers
const $ = (id) => document.getElementById(id);
const $$ = (sel) => document.querySelectorAll(sel);

// Elements
const chat = $('chat');
const input = $('input');
const sendBtn = $('send-btn');
const voiceBtn = $('voice-btn');
const projectList = $('project-list');
const upcomingList = $('upcoming-list');
const activeProjectDisplay = $('active-project-display');
const modelBadge = $('model-badge');
const modelBadgeName = $('model-badge-name');
const modelDropdown = $('model-dropdown');
const statusDot = $('status-dot');
const statusText = $('status-text');
const projectModal = $('modal-backdrop');
const skillModal = $('skill-modal-backdrop');
const browserToggle = $('browser-toggle');
const voiceOutToggle = $('voice-out-toggle');

marked.setOptions({
  breaks: true,
  gfm: true,
  highlight: (code, lang) => {
    if (lang && hljs.getLanguage(lang)) {
      try { return hljs.highlight(code, { language: lang }).value; } catch {}
    }
    return hljs.highlightAuto(code).value;
  },
});

function escape(s) {
  return String(s).replace(/[&<>"']/g, c => ({
    '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
  }[c]));
}

// =====================================================
// Dynamic welcome screen (randomized every load)
// =====================================================
const USER = 'Krish';

const GREETINGS = [
  'How can I help, {n}?',
  'What are we tackling, {n}?',
  'Systems online. Your move, {n}.',
  'Ready when you are, {n}.',
  "Let's get to work, {n}.",
  "What's the mission, {n}?",
  '{day}, {n}.',
  'Back at it, {n}?',
  'All systems nominal, {n}.',
  'Standing by, {n}.',
  "Let's make today count, {n}.",
  'Online and ready, {n}.',
  'At your service, {n}.',
];

const TAGLINES = [
  'Manage projects, draft work, automate tasks.',
  'Homework, deadlines, and everything in between.',
  'Your second brain for school.',
  'Think faster. Submit smarter.',
  'Four subjects, one assistant.',
  'Less busywork. More learning.',
  'Built to make school effortless.',
  'Your unfair advantage, quietly.',
  'Point me at the hard part.',
];

const SUGGESTION_POOL = [
  { icon: '🎯', title: 'Focus Today', desc: "What's most important right now", prompt: 'What should I focus on today?' },
  { icon: '📅', title: "This Week's Deadlines", desc: 'Surface upcoming work', prompt: 'Show me everything due in the next week.' },
  { icon: '📚', title: 'Plan a Study Block', desc: 'Structure focused time', prompt: 'Help me plan my study session.' },
  { icon: '💡', title: 'Quiz Me', desc: 'Active recall on a topic', prompt: "Quiz me on what I'm currently studying." },
  { icon: '✍️', title: 'Write an Essay', desc: 'Outline then draft', prompt: 'Help me outline and draft an essay. Ask me the topic first.' },
  { icon: '🧮', title: 'Solve a Problem', desc: 'Step-by-step walkthrough', prompt: "I have a homework problem I'm stuck on. Walk me through it." },
  { icon: '📖', title: 'Explain a Concept', desc: 'Simply, then test me', prompt: 'Explain a concept I am struggling with, simply, then test me on it.' },
  { icon: '🗂️', title: 'Summarize Notes', desc: 'Key points to review', prompt: 'Summarize my notes into key points I can review.' },
  { icon: '⚡', title: 'Beat Procrastination', desc: 'A 10-minute starter task', prompt: "I'm procrastinating. Give me a 10-minute task to start right now." },
  { icon: '🔬', title: 'Lab Report Help', desc: 'Structure the writeup', prompt: 'Help me structure a lab report for my science class.' },
  { icon: '🌐', title: 'Research a Topic', desc: 'Find solid sources', prompt: 'Help me research a topic and find credible sources.' },
  { icon: '📝', title: 'Check My Work', desc: 'Point out what to fix', prompt: 'Review what I wrote and point out what to improve.' },
];

function pick(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
function sample(arr, n) {
  const copy = [...arr];
  const out = [];
  while (out.length < n && copy.length) out.push(copy.splice(Math.floor(Math.random() * copy.length), 1)[0]);
  return out;
}
function dayPart() {
  const h = new Date().getHours();
  if (h < 12) return 'Good morning';
  if (h < 18) return 'Good afternoon';
  return 'Good evening';
}

function renderWelcome() {
  const titleEl = $('welcome-title');
  const subEl = $('welcome-sub');
  const sugEl = $('welcome-suggestions');
  const bootEl = $('boot-log');
  if (!titleEl) return;

  // greeting
  const g = pick(GREETINGS).replace('{day}', dayPart()).replace('{n}', `<span class="grad">${USER}</span>`);
  titleEl.innerHTML = g;
  subEl.textContent = pick(TAGLINES);

  // suggestions: 4 random
  sugEl.innerHTML = '';
  sample(SUGGESTION_POOL, 4).forEach((s, i) => {
    const b = document.createElement('button');
    b.className = 'suggestion';
    b.style.animationDelay = `${0.25 + i * 0.07}s`;
    b.innerHTML = `<div class="suggestion-icon">${s.icon}</div>
      <div><div class="suggestion-title">${escape(s.title)}</div>
      <div class="suggestion-desc">${escape(s.desc)}</div></div>`;
    b.addEventListener('click', () => { input.value = s.prompt; autosize(); send(); });
    sugEl.appendChild(b);
  });

  // boot log (typed line-by-line)
  const nP = (state.all_projects || state.projects || []).length;
  const nS = (state.skills || []).filter(s => s.enabled).length;
  const modelName = (models.find(m => m.id === state.model) || {}).name || state.model || 'J@rv1s 1.0';
  const lines = [
    '> booting J@rv1s core ............ <span class="bl-ok">OK</span>',
    '> neural link established ........ <span class="bl-ok">OK</span>',
    `> ${nP} projects synced ............. <span class="bl-ok">OK</span>`,
    `> ${nS} skills armed ............... <span class="bl-ok">OK</span>`,
    `> model <span class="bl-ok">${escape(modelName)}</span> ready`,
  ];
  bootEl.innerHTML = '';
  lines.forEach((ln, i) => {
    setTimeout(() => {
      const d = document.createElement('div');
      d.className = 'bl-line';
      d.innerHTML = ln;
      d.style.animation = 'fadeUp 0.25s ease both';
      bootEl.appendChild(d);
    }, 120 + i * 130);
  });

  wireWelcomeFX();
}

// Cursor-reactive magnetism for the welcome screen
function wireWelcomeFX() {
  const welcome = $('welcome');
  const reactor = welcome && welcome.querySelector('.reactor');
  const title = $('welcome-title');
  const sub = $('welcome-sub');
  if (!welcome || !reactor || welcome.dataset.fxWired) return;
  welcome.dataset.fxWired = '1';

  welcome.addEventListener('mousemove', (e) => {
    const r = reactor.getBoundingClientRect();
    const cx = r.left + r.width / 2;
    const cy = r.top + r.height / 2;
    const dx = (e.clientX - cx) / 22;   // tilt strength
    const dy = (e.clientY - cy) / 22;
    reactor.style.transform = `rotateY(${Math.max(-22, Math.min(22, dx))}deg) rotateX(${Math.max(-22, Math.min(22, -dy))}deg)`;
    // subtle parallax on text
    if (title) title.style.transform = `translate(${dx * 0.25}px, ${dy * 0.25}px)`;
    if (sub) sub.style.transform = `translate(${dx * 0.4}px, ${dy * 0.4}px)`;
  });
  welcome.addEventListener('mouseleave', () => {
    reactor.style.transform = '';
    if (title) title.style.transform = '';
    if (sub) sub.style.transform = '';
  });
  // ---- Proximity-driven spin: slow when far, light-speed at the core ----
  const rings = [
    { el: reactor.querySelector('.ring-1'),       base: 48,  dir: 1,  a: 0 },
    { el: reactor.querySelector('.ring-2'),       base: 70,  dir: -1, a: 0 },
    { el: reactor.querySelector('.ring-3'),       base: 104, dir: 1,  a: 0 },
    { el: reactor.querySelector('.reactor-ticks'),base: 14,  dir: 1,  a: 0 },
  ];
  const glow = reactor.querySelector('.reactor-glow');
  const core = reactor.querySelector('.reactor-core');
  if (glow) glow.style.animation = 'none';  // JS drives glow now (avoid CSS conflict)
  let speed = 1;          // eased current multiplier
  let target = 1;         // proximity-derived multiplier
  let lastT = performance.now();

  window.addEventListener('mousemove', (e) => {
    const r = reactor.getBoundingClientRect();
    if (!r.width) return;
    const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
    const d = Math.hypot(e.clientX - cx, e.clientY - cy);
    const maxDist = 480;
    const prox = Math.max(0, 1 - d / maxDist);   // 0 (far) … 1 (centered)
    // steep curve so it really winds up near the core
    target = 1 + Math.pow(prox, 2.4) * 42;       // up to ~43× near the core
  });
  window.addEventListener('mouseout', (e) => { if (!e.relatedTarget) target = 1; });

  function spinFrame(t) {
    if (!reactor.isConnected) return;            // welcome removed → stop loop
    const dt = Math.min(0.05, (t - lastT) / 1000);
    lastT = t;
    speed += (target - speed) * Math.min(1, dt * 3.5);   // smooth ease
    rings.forEach(ring => {
      if (!ring.el) return;
      ring.a += ring.dir * ring.base * speed * dt;
      ring.el.style.transform = `rotate(${ring.a.toFixed(2)}deg)`;
    });
    // glow + core intensify with speed
    const intensity = Math.min(1, (speed - 1) / 42);
    if (glow) {
      glow.style.opacity = (0.5 + intensity * 0.5).toFixed(3);
      glow.style.transform = `scale(${(0.95 + intensity * 0.5).toFixed(3)})`;
    }
    if (core) core.style.filter = `brightness(${(1 + intensity * 0.8).toFixed(2)})`;
    requestAnimationFrame(spinFrame);
  }
  requestAnimationFrame(spinFrame);

  // 3D tilt on each suggestion card
  welcome.querySelectorAll('.suggestion').forEach(card => {
    card.addEventListener('mousemove', (e) => {
      const r = card.getBoundingClientRect();
      const px = (e.clientX - r.left) / r.width - 0.5;
      const py = (e.clientY - r.top) / r.height - 0.5;
      card.style.transform =
        `perspective(600px) rotateX(${(-py * 12).toFixed(2)}deg) rotateY(${(px * 12).toFixed(2)}deg) translateY(-3px) scale(1.03)`;
    });
    card.addEventListener('mouseleave', () => { card.style.transform = ''; });
  });
}

// =====================================================
// Auth (hosted mode)
// =====================================================
let authMode = 'login';
const authOverlay = $('auth-overlay');

function showAuth() { authOverlay.classList.remove('hidden'); $('auth-username').focus(); }
function hideAuth() { authOverlay.classList.add('hidden'); }

function setAuthMode(mode) {
  authMode = mode;
  const signup = mode === 'signup';
  $('auth-username').placeholder = 'Email';
  $('auth-username').setAttribute('autocomplete', signup ? 'email' : 'username');
  $('auth-sub').textContent = signup ? 'Create your Personal Agent account' : 'Sign in to your Personal Agent';
  $('auth-submit').textContent = signup ? 'Create Account' : 'Sign In';
  $('auth-switch-text').textContent = signup ? 'Already have an account?' : 'New here?';
  $('auth-switch-link').textContent = signup ? 'Sign in' : 'Create an account';
  $('auth-password').setAttribute('autocomplete', signup ? 'new-password' : 'current-password');
  $('auth-confirm-wrap').style.display = signup ? 'block' : 'none';  // confirm only on signup
  $('auth-confirm').value = '';
  const fr = $('auth-forgot-row'); if (fr) fr.style.display = signup ? 'none' : 'block';
  $('auth-error').textContent = '';
}

// show / hide password (controls both password + confirm)
let pwVisible = false;
const pwToggle = $('auth-pw-toggle');
if (pwToggle) pwToggle.addEventListener('click', () => {
  pwVisible = !pwVisible;
  const t = pwVisible ? 'text' : 'password';
  $('auth-password').type = t;
  $('auth-confirm').type = t;
  pwToggle.querySelector('.eye').style.display = pwVisible ? 'none' : 'block';
  pwToggle.querySelector('.eye-off').style.display = pwVisible ? 'block' : 'none';
});

async function submitAuth() {
  const username = $('auth-username').value.trim();
  const password = $('auth-password').value;
  if (!username || !password) { $('auth-error').textContent = 'Enter a username and password.'; return; }
  const isSignup = authMode === 'signup';
  if (isSignup && password !== $('auth-confirm').value) {
    $('auth-error').textContent = 'Passwords don’t match.';
    return;
  }
  try {
    await API(`/api/auth/${isSignup ? 'signup' : 'login'}`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password }),
    });
    hideAuth();
    $('auth-password').value = '';
    if (isSignup) {
      // New users: show the tutorial first, then boot into app, then paywall.
      tutIndex = 0;
      showTutorial();
    } else {
      // Returning users: standard boot (paywall pops immediately if gated).
      boot();
    }
  } catch (e) {
    const errEl = $('auth-error');
    errEl.innerHTML = '';
    const msg = e && (e.error || e.message) || 'Something went wrong.';
    errEl.appendChild(document.createTextNode(msg));
    // If this email already has an account, offer to switch to sign-in mode.
    if (e && e.code === 'email_exists' && e.email) {
      errEl.appendChild(document.createElement('br'));
      const link = document.createElement('button');
      link.type = 'button';
      link.className = 'auth-inline-link';
      link.textContent = `Sign in as ${e.email} →`;
      link.addEventListener('click', () => {
        setAuthMode('login');
        $('auth-username').value = e.email;
        $('auth-password').focus();
      });
      errEl.appendChild(link);
    } else if (e && e.code === 'no_user') {
      // Wrong email at login → offer to create account
      errEl.appendChild(document.createElement('br'));
      const link = document.createElement('button');
      link.type = 'button';
      link.className = 'auth-inline-link';
      link.textContent = 'Create an account instead →';
      link.addEventListener('click', () => setAuthMode('signup'));
      errEl.appendChild(link);
    }
  }
}

if (authOverlay) {
  $('auth-submit').addEventListener('click', submitAuth);
  $('auth-password').addEventListener('keydown', (e) => {
    if (e.key !== 'Enter') return;
    if (authMode === 'signup') $('auth-confirm').focus(); else submitAuth();
  });
  $('auth-confirm').addEventListener('keydown', (e) => { if (e.key === 'Enter') submitAuth(); });
  $('auth-username').addEventListener('keydown', (e) => { if (e.key === 'Enter') $('auth-password').focus(); });
  $('auth-switch-link').addEventListener('click', () => setAuthMode(authMode === 'login' ? 'signup' : 'login'));
  const forgot = $('auth-forgot-link');
  if (forgot) forgot.addEventListener('click', async () => {
    const email = ($('auth-username').value || '').trim();
    if (!email) { $('auth-error').textContent = 'Enter your email above, then tap “Forgot password?”'; return; }
    $('auth-error').textContent = '';
    try {
      await API('/api/auth/forgot', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });
    } catch { /* never reveal errors */ }
    $('auth-sub').textContent = 'If an account exists for that email, a reset link is on its way. Check your inbox.';
  });
}

// =====================================================
// Boot
// =====================================================
// opts.delayPaywall — show the app first, pop pricing after a few seconds
// (used right after signup so new users see the product before the gate).
async function boot(opts = {}) {
  try {
    state = await API('/api/state');
    models = await API('/api/models');
    statusDot.classList.add('ok');
    statusText.textContent = 'connected';
    applyTheme(state.theme || 'dark');
    renderSidebar();
    renderActiveProject();
    renderModel();
    renderBrowserToggle();
    renderSkillsPage();
    renderAllProjects();
    const isGated = await loadBilling();   // sets module-level `gated`
    renderTrialAndAdmin();
    refreshAccountCard();
    if (state.hosted) applyHostedMode(billingInfo);
    if (state.history && state.history.length > 0) {
      clearChat();
      state.history.forEach(m => appendMessage(m.role, m.content));
    } else {
      renderWelcome();
    }
    // App is browsable; paywall sits on top (dismissible) until they subscribe.
    if (isGated) {
      if (opts.delayPaywall) {
        // Let new users watch the welcome screen + boot log animation play out.
        setTimeout(() => { if (gated) showPaywall(); }, 4200);
      } else showPaywall();
    } else hidePaywall();
  } catch (e) {
    if (e && e.auth) { showAuth(); return; }   // hosted mode, not logged in
    statusDot.classList.add('bad');
    statusText.textContent = 'offline';
    console.error('boot failed', e);
  }
}

// Hosted build: hide machine-control by plan. Admins keep everything.
function applyHostedMode(info) {
  const admin = !!(info && info.is_admin);
  const plan = info && info.plan;
  const automation = !!state.automation;   // only the desktop app allows machine control
  const canBrowse = automation && (admin || plan === 'professional' || plan === 'max' || plan === 'ultra' || plan === 'apex');
  const showVoice = automation && admin;   // voice uses the local mic (desktop only)
  const hide = (id, cond) => { const el = $(id); if (el) el.style.display = cond ? 'none' : ''; };
  hide('browser-toggle', !canBrowse);
  hide('safesites-toggle', !canBrowse);
  hide('voice-out-toggle', !showVoice);
  hide('voice-btn', !showVoice);
  hide('project-voice-btn', !showVoice);
  // model picker: admins can switch freely; regular users are locked to their plan.
  const mp = $('model-picker');
  if (mp) mp.style.pointerEvents = admin ? '' : 'none';
  const chev = modelBadge && modelBadge.querySelector('svg');
  if (chev) chev.style.display = admin ? '' : 'none';
}

// =====================================================
// Billing / subscription paywall
// =====================================================
const paywall = $('paywall-overlay');
let billingInfo = null;
let gated = false;   // true = logged in but no plan → can browse, can't message

// Returns true if messaging is gated (must subscribe). Also sets `gated`.
async function loadBilling() {
  try {
    billingInfo = await API('/api/billing/status');
  } catch { billingInfo = null; gated = false; return false; }
  renderPlans();
  gated = !!(billingInfo.require_subscription && !billingInfo.subscribed);
  updateComposerLock();
  return gated;
}

// Reflect the locked state in the composer (hint + placeholder).
function updateComposerLock() {
  const hint = document.querySelector('.composer-hint span');
  if (hint) hint.innerHTML = gated
    ? '🔒 Subscribe to start chatting'
    : '<kbd>Enter</kbd> send · <kbd>Shift</kbd>+<kbd>Enter</kbd> newline · <kbd>🎙</kbd> voice → speak';
}

let billingInterval = 'monthly';   // 'monthly' | 'annual'

function renderPlans() {
  const wrap = $('paywall-plans');
  if (!wrap || !billingInfo) return;
  const plans = billingInfo.plans || [];
  wrap.innerHTML = '';

  // ── Interval toggle pill ─────────────────────────────────────────
  const toggle = document.createElement('div');
  toggle.className = 'billing-toggle';
  toggle.innerHTML = `
    <button data-i="monthly" class="${billingInterval === 'monthly' ? 'on' : ''}">Monthly</button>
    <button data-i="annual" class="${billingInterval === 'annual' ? 'on' : ''}">Annual <span class="bt-save">up to 65% off</span></button>`;
  toggle.querySelectorAll('button').forEach(b =>
    b.addEventListener('click', () => { billingInterval = b.dataset.i; renderPlans(); }));
  wrap.appendChild(toggle);

  // ── Plan cards grid ──────────────────────────────────────────────
  const grid = document.createElement('div');
  grid.className = 'pw-grid';
  const isAnnual = billingInterval === 'annual';

  plans.forEach(p => {
    const isCurrent = billingInfo.plan === p.id;
    const hasTrial = (p.trial_days || 0) > 0 && !isAnnual;   // trial only on monthly
    const featured = p.id === 'professional';
    const accent = featured || p.id === 'max' || p.id === 'ultra' || p.id === 'apex';
    const priceStr = isAnnual ? p.price_annual : p.price;
    const [amt, per] = (priceStr || '').split('/');
    const discount = p.annual_discount_pct || 0;

    let tag = '';
    if (hasTrial) tag = '<span class="pw-tag">★ 7-DAY FREE TRIAL</span>';
    else if (isAnnual && discount) tag = `<span class="pw-tag">SAVE ${discount}%</span>`;
    else if (p.id === 'max') tag = '<span class="pw-tag">Max power</span>';
    else if (p.id === 'ultra') tag = '<span class="pw-tag">Ultra</span>';
    else if (p.id === 'apex') tag = '<span class="pw-tag">★ APEX</span>';

    let cta = 'Subscribe';
    if (isCurrent) cta = 'Current plan';
    else if (hasTrial) cta = 'Start 7-Day Free Trial';
    else if (isAnnual) cta = 'Subscribe (annual)';

    const sub = isAnnual ? `<div class="pw-sub">${escape(p.price)} when billed monthly</div>` : '';

    const card = document.createElement('div');
    card.className = 'pw-card' + (featured ? ' pro featured' : '') + (accent && !featured ? ' pro' : '') + (isCurrent ? ' current' : '');
    card.innerHTML = `
      ${tag}
      <div class="pw-name">${escape(p.name)}</div>
      <div class="pw-price">${escape(amt)}${per ? `<span>/${escape(per)}</span>` : ''}</div>
      ${sub}
      <ul>${(p.features || []).map(f => `<li>${escape(f)}</li>`).join('')}</ul>
      <button class="primary-btn">${cta}</button>`;
    const btn = card.querySelector('button');
    if (isCurrent) { btn.disabled = true; btn.style.opacity = '0.6'; }
    else btn.addEventListener('click', () => startCheckout(p.id, billingInterval));
    grid.appendChild(card);
  });
  wrap.appendChild(grid);
}

function showPaywall() { paywall.classList.remove('hidden'); }
function hidePaywall() { paywall.classList.add('hidden'); }

// ---- Onboarding tutorial ----
const tutorial = $('tutorial-overlay');
const TUT_SLIDES = [
  { icon: '🤖', title: 'Welcome to <span class="grad">J@rv1s</span>', text: 'Your personal AI agent for school. Here’s a 30-second tour of what you can do.' },
  { icon: '📚', title: 'Subject Projects', text: 'Math, English, History & Science come built in. Each keeps its own chats, deadlines, uploaded worksheets, and instructions.' },
  { icon: '✨', title: 'Skills', text: 'Toggle behaviors like Undetectable (natural student writing), Humanizer, Concise, and Tutor mode — or build your own.' },
  { icon: '🎙️', title: 'Voice & Web Automation', text: 'Talk to J@rv1s hands-free, and on higher plans let it drive a real browser to do tasks for you.' },
  { icon: '⌘', title: 'Fast Everywhere', text: 'Hit ⌘K for the command palette to jump anywhere. Upload files, set deadlines, switch subjects in a keystroke.' },
  { icon: '🚀', title: 'Pick Your Plan', text: 'One last step — choose a plan to unlock J@rv1s. Professional starts with a 7-day free trial.' },
];
let tutIndex = 0;
function renderTutorial() {
  const s = TUT_SLIDES[tutIndex];
  $('tut-body').innerHTML = `<div class="tut-icon">${s.icon}</div>
    <div class="tut-title">${s.title}</div><div class="tut-text">${s.text}</div>`;
  $('tut-dots').innerHTML = TUT_SLIDES.map((_, i) => `<span class="dot ${i === tutIndex ? 'on' : ''}"></span>`).join('');
  $('tut-back').style.visibility = tutIndex === 0 ? 'hidden' : 'visible';
  $('tut-next').textContent = tutIndex === TUT_SLIDES.length - 1 ? 'See plans →' : 'Next';
}
function showTutorial() { tutorial.classList.remove('hidden'); renderTutorial(); }
function hideTutorial() { tutorial.classList.add('hidden'); }
// After the tutorial: load the app, then pop the paywall after a short delay
// so the user sees the welcome screen / animation before being asked to pay.
function finishTutorial() { hideTutorial(); boot({ delayPaywall: true }); }
if (tutorial) {
  $('tut-next').addEventListener('click', () => {
    if (tutIndex < TUT_SLIDES.length - 1) { tutIndex++; renderTutorial(); }
    else finishTutorial();
  });
  $('tut-back').addEventListener('click', () => { if (tutIndex > 0) { tutIndex--; renderTutorial(); } });
}

async function refreshAccountCard() {
  try {
    const a = await API('/api/account');
    renderAccountCard(a);
  } catch { /* ignore */ }
}

function renderTrialAndAdmin() {
  // trial banner
  const banner = $('trial-banner');
  if (banner && billingInfo && billingInfo.trial && billingInfo.trial.trialing) {
    const d = billingInfo.trial.days_left;
    banner.textContent = `★ ${d} day${d === 1 ? '' : 's'} left in your Pro trial — Subscribe`;
    banner.style.display = 'block';
    banner.onclick = showPaywall;
  } else if (banner) {
    banner.style.display = 'none';
  }
  // admin nav
  const navAdmin = $('nav-admin');
  if (navAdmin) navAdmin.style.display = (billingInfo && billingInfo.is_admin) ? 'flex' : 'none';
}

// admin dashboard
async function loadAdmin() {
  const grid = $('admin-stats');
  if (!grid) return;
  grid.innerHTML = '<div class="stat-card"><div class="stat-label">Loading…</div></div>';
  try {
    const s = await API('/api/admin/stats');
    const u = s.usage || {};
    const cards = [
      ['Total users', s.total_users, ''],
      ['Paying', s.paying, `${s.paid_starter} starter · ${s.paid_professional} pro · ${s.paid_max} max · ${s.paid_ultra ?? 0} ultra · ${s.paid_apex ?? 0} apex`],
      ['On trial', s.trialing, 'free Pro trials'],
      ['MRR', `$${s.mrr}`, 'monthly recurring', true],
      ["Today's spend (est)", `$${(u.global_cost_est ?? 0)}`, `ceiling $${u.ceiling ?? '—'}`],
      ['Active today', u.active_users ?? 0, 'users who messaged'],
    ];
    grid.innerHTML = cards.map(([label, val, sub, money]) => `
      <div class="stat-card">
        <div class="stat-label">${escape(label)}</div>
        <div class="stat-value ${money ? 'money' : ''}">${escape(String(val))}</div>
        ${sub ? `<div class="stat-sub">${escape(sub)}</div>` : ''}
      </div>`).join('');
    $('admin-note').textContent = `Estimated daily margin: $${(s.mrr / 30 - (u.global_cost_est || 0)).toFixed(2)} (MRR/30 − today's spend). Spend is an estimate; trust the Anthropic Console for exact billing.`;
  } catch (e) {
    grid.innerHTML = `<div class="stat-card"><div class="stat-label">Error</div><div class="stat-sub">${escape(e.error || 'failed')}</div></div>`;
  }
}
const adminRefresh = $('admin-refresh');
if (adminRefresh) adminRefresh.addEventListener('click', loadAdmin);

// =====================================================
// Settings
// =====================================================
async function loadSettings() {
  try {
    const a = await API('/api/account');
    settingsAccount = a;
    $('set-username').textContent = a.email || a.username || '—';
    if ($('set-uid')) $('set-uid').textContent = a.uid || '—';
    // Fmt account dates
    const fmtDate = (t) => t ? new Date(t * 1000).toLocaleString() : '—';
    if ($('set-created')) $('set-created').textContent = fmtDate(a.created);
    if ($('set-last-login')) $('set-last-login').textContent = fmtDate(a.last_login);
    const planName = ({ none: 'No active plan', starter: 'Starter', professional: 'Professional', max: 'Max', ultra: 'Ultra', apex: 'Apex' })[a.plan] || a.plan;
    const trial = a.trial && a.trial.trialing ? ` · ${a.trial.days_left}d trial left` : '';
    // Billing hero
    if ($('plan-hero-title')) {
      $('plan-hero-title').textContent = `${planName} plan`;
      $('plan-hero-sub').textContent = trial || (a.plan === 'none' ? 'No active plan — pick one to unlock messaging' :
        ({starter:'20 messages / day · Mini J@r', professional:'100 messages / day (5×) · Web automation',
          max:'400 messages / day (20×) · J@rv1s 1.0', ultra:'1,000 messages / day (50×) · Priority support',
          apex:'2,000 messages / day (100×) · Dedicated priority support'})[a.plan] || '');
    }
    // hide account-only controls in local (non-hosted) mode
    const local = !state.hosted;
    ['set-change-pw', 'set-logout', 'set-delete', 'set-manage'].forEach(id => {
      const el = $(id); if (el) el.style.display = local ? 'none' : '';
    });
    // Load + apply prefs
    if (a.prefs) {
      settingsPrefs = a.prefs;
      applyPrefsToUI(a.prefs);
    }
  } catch (e) { /* ignore */ }
  loadMemoryStatus();
}

let settingsPrefs = {};
let settingsAccount = null;

function applyPrefsToUI(p) {
  const set = (id, v) => { const el = $(id); if (el && v != null) el.value = v; };
  set('pref-full-name', p.full_name);
  set('pref-nickname', p.nickname);
  set('pref-work-type', p.work_type);
  set('pref-instructions', p.custom_instructions);
  set('pref-voice', p.voice);
  set('pref-tool-access', p.tool_access_mode);
  set('pref-timezone', p.timezone);
  set('pref-language', p.language);
  // segmented buttons
  const segActivate = (groupId, val) => {
    const g = $(groupId); if (!g) return;
    g.querySelectorAll('.seg-btn').forEach(b => b.classList.toggle('active', b.dataset.val === val));
  };
  segActivate('pref-appearance', p.appearance);
  segActivate('pref-voice-speed', p.voice_speed);
  // toggles
  document.querySelectorAll('[data-pref]').forEach(el => {
    if (el.classList.contains('set-toggle')) {
      el.classList.toggle('on', !!p[el.dataset.pref]);
    }
  });
}

// Debounced save for text fields
let _prefSaveTimer = null;
function queuePrefSave(partial) {
  Object.assign(settingsPrefs, partial);
  clearTimeout(_prefSaveTimer);
  _prefSaveTimer = setTimeout(async () => {
    try {
      const r = await API('/api/account/prefs', {
        method: 'PUT', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(partial),
      });
      settingsPrefs = r.prefs;
    } catch (e) { console.warn('pref save', e); }
  }, 450);
}

// Wire prefs once on load (idempotent)
let _prefsWired = false;
function wireSettings() {
  if (_prefsWired) return; _prefsWired = true;

  // Tab switching
  document.querySelectorAll('.settings-tab').forEach(btn => {
    btn.addEventListener('click', () => {
      const tab = btn.dataset.tab;
      document.querySelectorAll('.settings-tab').forEach(b => b.classList.toggle('active', b === btn));
      document.querySelectorAll('.settings-tab-content').forEach(c =>
        c.classList.toggle('active', c.dataset.tabContent === tab));
      if (tab === 'usage') loadUsage();
    });
  });

  // Text inputs / textareas / selects → debounced save
  const wireField = (id, key) => {
    const el = $(id);
    if (!el) return;
    el.addEventListener('input', () => queuePrefSave({ [key]: el.value }));
    el.addEventListener('change', () => queuePrefSave({ [key]: el.value }));
  };
  wireField('pref-full-name', 'full_name');
  wireField('pref-nickname', 'nickname');
  wireField('pref-work-type', 'work_type');
  wireField('pref-instructions', 'custom_instructions');
  wireField('pref-voice', 'voice');
  wireField('pref-tool-access', 'tool_access_mode');
  wireField('pref-timezone', 'timezone');
  wireField('pref-language', 'language');

  // Segmented controls
  const wireSeg = (groupId, key) => {
    const g = $(groupId); if (!g) return;
    g.querySelectorAll('.seg-btn').forEach(b => b.addEventListener('click', () => {
      g.querySelectorAll('.seg-btn').forEach(x => x.classList.remove('active'));
      b.classList.add('active');
      queuePrefSave({ [key]: b.dataset.val });
      if (key === 'appearance') {
        if (b.dataset.val === 'light' || b.dataset.val === 'dark') applyTheme(b.dataset.val);
      }
    }));
  };
  wireSeg('pref-appearance', 'appearance');
  wireSeg('pref-voice-speed', 'voice_speed');

  // Toggles
  document.querySelectorAll('.set-toggle[data-pref]').forEach(el => {
    el.addEventListener('click', () => {
      if (el.disabled) return;
      const key = el.dataset.pref;
      const next = !el.classList.contains('on');
      el.classList.toggle('on', next);
      queuePrefSave({ [key]: next });
    });
  });

  // Billing buttons
  $('set-adjust-plan') && $('set-adjust-plan').addEventListener('click', showPaywall);

  // Usage refresh
  $('usage-refresh') && $('usage-refresh').addEventListener('click', loadUsage);
}

async function loadUsage() {
  try {
    const u = await API('/api/usage/me');
    const planLabel = ({starter:'Starter (1×)', professional:'Professional (5×)', max:'Max (20×)',
                       ultra:'Ultra (50×)', apex:'Apex (100×)', none:'No plan'})[u.plan] || u.plan;
    $('usage-plan-name') && ($('usage-plan-name').textContent = planLabel);
    $('usage-used') && ($('usage-used').textContent = u.used_today || 0);
    $('usage-cap') && ($('usage-cap').textContent = u.daily_cap || '—');
    const pct = u.percent_used || 0;
    if ($('usage-fill-today')) $('usage-fill-today').style.width = pct + '%';
    if ($('usage-pct-today')) $('usage-pct-today').textContent = pct + '% used';
    // Admin sees server cost
    if (settingsAccount && settingsAccount.is_admin && $('usage-cost-row')) {
      $('usage-cost-row').style.display = '';
      const cost = u.global_cost_est || 0;
      const ceil = u.ceiling || 5;
      const cpct = Math.min(100, Math.round(100 * cost / ceil));
      $('usage-fill-cost').style.width = cpct + '%';
      $('usage-pct-cost').textContent = '$' + cost.toFixed(2);
      $('usage-ceiling').textContent = `Resets at midnight · ceiling $${ceil}`;
    }
    $('usage-pct-auto') && ($('usage-pct-auto').textContent = '0 / 15');
    $('usage-fill-auto') && ($('usage-fill-auto').style.width = '0%');
  } catch (e) { /* ignore */ }
}

wireSettings();

// =====================================================
// MEMORIES VIEW — top-level atomic-memory CRUD
// =====================================================
let memFeed = { atoms: [] };
let memFilter = 'all';
let memSearch = '';

async function loadMemories() {
  try {
    memFeed = await API('/api/memory/atoms');
  } catch { memFeed = { atoms: [] }; }
  renderMemFeed();
  // sidebar count badge
  const nav = $('nav-mem-count');
  const n = (memFeed.atoms || []).length;
  if (nav) {
    nav.textContent = n;
    nav.style.display = n ? '' : 'none';
  }
}

function renderMemFeed() {
  const feed = $('mem-feed');
  const stat = $('mem-feed-stat');
  if (!feed) return;
  const all = memFeed.atoms || [];
  const filtered = all.filter(a => {
    if (memFilter === 'auto') return a.tag === 'auto';
    if (memFilter !== 'all' && a.kind !== memFilter) return false;
    if (memSearch && !((a.text || '') + ' ' + (a.tag || ''))
        .toLowerCase().includes(memSearch.toLowerCase())) return false;
    return true;
  });
  if (stat) stat.textContent = `${filtered.length} of ${all.length}`;
  feed.innerHTML = '';
  if (!filtered.length) {
    feed.innerHTML = `
      <div class="mem-empty">
        <div class="empty-icon">🧠</div>
        <h3>${all.length ? 'Nothing matches that filter' : 'No memories yet'}</h3>
        <p>${all.length
            ? 'Try a different filter, or clear the search box.'
            : 'Add a memory manually, import from another AI, or just chat — J@rv1s extracts atomic facts automatically when "Generate memory from chat" is on.'}</p>
      </div>`;
    return;
  }
  filtered.forEach(a => feed.appendChild(renderMemAtom(a)));
}

function renderMemAtom(a) {
  const card = document.createElement('div');
  card.className = 'mem-atom';
  const ico = ({fact:'•', preference:'⚙', imported:'↳', auto:'✨'})[a.tag === 'auto' ? 'auto' : a.kind] || '•';
  const kindCls = a.tag === 'auto' ? 'auto' : a.kind;
  const time = a.ts ? new Date(a.ts * 1000).toLocaleDateString() : '';
  card.innerHTML = `
    <div class="mem-atom-kind ${kindCls}">${ico}</div>
    <div class="mem-atom-body">
      <div class="mem-atom-text">${escape(a.text || '')}</div>
      <div class="mem-atom-meta">
        ${a.tag ? `<span class="mem-atom-tag">${escape(a.tag)}</span>` : ''}
        ${time ? `<span>${escape(time)}</span>` : ''}
      </div>
    </div>
    <div class="mem-atom-actions">
      ${a.kind === 'fact' ? '<button data-act="edit" title="Edit">✎</button>' : ''}
      <button data-act="del" title="Delete">🗑</button>
    </div>`;
  const editBtn = card.querySelector('[data-act="edit"]');
  if (editBtn) editBtn.addEventListener('click', () => openMemAtomModal(a));
  card.querySelector('[data-act="del"]').addEventListener('click', () => deleteAtom(a));
  return card;
}

async function deleteAtom(a) {
  if (!confirm(`Delete this memory?\n\n"${(a.text || '').slice(0, 80)}…"`)) return;
  try {
    if (a.kind === 'fact') {
      await API(`/api/memory/facts/${a.id}`, { method: 'DELETE' });
    } else if (a.kind === 'imported') {
      const idx = parseInt((a.id || '').split(':')[1] || '-1', 10);
      if (idx >= 0) await API(`/api/memory/import/${idx}`, { method: 'DELETE' });
    } else {
      alert('Preferences are managed in Settings → General.');
      return;
    }
    loadMemories();
  } catch (e) { alert(e.error || 'Delete failed.'); }
}

// Memory-atom add/edit modal
const memAtomBackdrop = $('mem-atom-backdrop');
let memEditTarget = null;
function openMemAtomModal(atom) {
  memEditTarget = atom;
  $('mem-atom-title').textContent = atom ? 'Edit memory' : 'Add memory';
  $('mem-atom-text').value = atom ? (atom.text || '') : '';
  $('mem-atom-tag').value = atom && atom.tag !== 'auto' && atom.tag !== 'general' ? atom.tag : '';
  $('mem-atom-delete').style.display = atom ? '' : 'none';
  memAtomBackdrop.classList.remove('hidden');
  $('mem-atom-text').focus();
}
$('mem-add-open') && $('mem-add-open').addEventListener('click', () => openMemAtomModal(null));
$('mem-atom-cancel') && $('mem-atom-cancel').addEventListener('click', () => memAtomBackdrop.classList.add('hidden'));
memAtomBackdrop && memAtomBackdrop.addEventListener('click', (e) => {
  if (e.target === memAtomBackdrop) memAtomBackdrop.classList.add('hidden');
});
$('mem-atom-save') && $('mem-atom-save').addEventListener('click', async () => {
  const text = $('mem-atom-text').value.trim();
  const tag = $('mem-atom-tag').value.trim() || 'manual';
  if (!text) { alert('Memory text required.'); return; }
  try {
    if (memEditTarget && memEditTarget.kind === 'fact') {
      await API(`/api/memory/facts/${memEditTarget.id}`, {
        method: 'PUT', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text, tag }),
      });
    } else {
      await API('/api/memory/facts', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text, tag }),
      });
    }
    memAtomBackdrop.classList.add('hidden');
    loadMemories();
  } catch (e) { alert(e.error || 'Save failed.'); }
});
$('mem-atom-delete') && $('mem-atom-delete').addEventListener('click', async () => {
  if (!memEditTarget || memEditTarget.kind !== 'fact') return;
  if (!confirm('Delete this memory?')) return;
  await API(`/api/memory/facts/${memEditTarget.id}`, { method: 'DELETE' });
  memAtomBackdrop.classList.add('hidden');
  loadMemories();
});

// Feed filter + search + bulk actions
document.querySelectorAll('[data-mem-filter]').forEach(b =>
  b.addEventListener('click', () => {
    document.querySelectorAll('[data-mem-filter]').forEach(x => x.classList.remove('active'));
    b.classList.add('active');
    memFilter = b.dataset.memFilter;
    renderMemFeed();
  }));
$('mem-feed-search') && $('mem-feed-search').addEventListener('input', (e) => {
  memSearch = e.target.value;
  renderMemFeed();
});
$('mem-import-open') && $('mem-import-open').addEventListener('click', async () => {
  if (!memoryInfo) await loadMemoryStatus();
  $('mem-prompt-pre').textContent = (memoryInfo && memoryInfo.import_prompt) || '';
  $('mem-paste').value = '';
  $('mem-import-backdrop').classList.remove('hidden');
});
$('mem-clear-auto') && $('mem-clear-auto').addEventListener('click', async () => {
  if (!confirm('Delete every auto-saved memory? (Manual & imported memories stay.)')) return;
  await API('/api/memory/facts?tag=auto', { method: 'DELETE' });
  loadMemories();
});

// =====================================================
// CONNECTORS VIEW — top-level page with platform cards
// =====================================================
let connectorsState = { connectors: [] };

async function loadConnectors() {
  // Cloud web users see a "desktop-only" pitch instead of the full UI.
  if (state.hosted && !state.automation) {
    renderDesktopExclusive('connectors');
    const nav = $('nav-conn-count');
    if (nav) { nav.textContent = '↓'; nav.style.display = ''; nav.classList.add('nav-pulse'); }
    return;
  }
  try {
    connectorsState = await API('/api/connectors');
  } catch (e) {
    if (e && e.auth) { showAuth(); return; }
    connectorsState = { connectors: [] };
  }
  renderConnectors();
  // sidebar badge: count of connected platforms
  const nav = $('nav-conn-count');
  const connected = (connectorsState.connectors || []).filter(c => c.logged_in).length;
  if (nav) {
    if (connected > 0) {
      nav.textContent = connected;
      nav.style.display = '';
      nav.classList.remove('nav-pulse');
    } else {
      nav.textContent = '!';
      nav.style.display = '';
      nav.classList.add('nav-pulse');
    }
  }
}

function renderDesktopExclusive(which) {
  // `which` is "connectors" or "tasks" — slight copy difference.
  const isConnectors = which === 'connectors';
  const target = isConnectors ? $('conn-school-grid')?.parentElement : $('tasks-body');
  if (!target) return;
  // Wipe everything inside the view, replace with the pitch.
  if (isConnectors) {
    // Clear the connectors-view body but keep the topbar
    const view = document.querySelector('.view-connectors');
    if (view) {
      // Keep topbar only
      Array.from(view.children).forEach(child => {
        if (!child.classList.contains('topbar')) child.remove();
      });
      const cta = document.createElement('div');
      cta.innerHTML = desktopExclusiveHTML(isConnectors);
      view.appendChild(cta.firstElementChild);
      wireDesktopExclusiveButtons();
    }
  } else {
    target.innerHTML = desktopExclusiveHTML(false);
    wireDesktopExclusiveButtons();
  }
}

function desktopExclusiveHTML(isConnectors) {
  const title = isConnectors
    ? `<span class="grad">School connectors</span><br>only run on your computer.`
    : `<span class="grad">Tasks</span> only work in the desktop app.`;
  const sub = isConnectors
    ? `Most school Google accounts block third-party logins (OAuth), and Google flags cloud-based browsers as bots. So J@rv1s connects to Classroom, Canvas, Schoology and more <strong>on your actual computer</strong> — using your real Chrome, your real session. Nothing is sent to our servers. Ever.`
    : `Your assignments come from your school portal — and your school's Google account doesn't let outside apps log in from the cloud. So J@rv1s does the pulling locally on your Mac. Install the desktop app once, sign in, and your tasks appear here.`;

  return `
    <div class="desktop-exclusive">
      <div class="desktop-exclusive-badge"><span class="dot"></span>Desktop-only feature · by design</div>
      <div class="desktop-exclusive-orb"></div>
      <h1>${title}</h1>
      <p>${sub}</p>
      <div class="desktop-exclusive-actions">
        <a class="primary" href="https://projectjarvis.app/download" target="_blank" rel="noopener">
          ↓ Download for Mac · Free
        </a>
        <a class="secondary" href="https://projectjarvis.app/download" target="_blank" rel="noopener">
          Windows version
        </a>
      </div>
      <div class="desktop-exclusive-features">
        <div class="desktop-exclusive-feature">
          <div class="ico">🔒</div>
          <div class="lbl">Your session stays local</div>
          <div class="desc">School login never touches our servers</div>
        </div>
        <div class="desktop-exclusive-feature">
          <div class="ico">⚡</div>
          <div class="lbl">Works with strict schools</div>
          <div class="desc">No OAuth needed — uses your real Chrome</div>
        </div>
        <div class="desktop-exclusive-feature">
          <div class="ico">🤖</div>
          <div class="lbl">Pulls every assignment</div>
          <div class="desc">Across every class, every tab, automatically</div>
        </div>
      </div>
    </div>
  `;
}

function wireDesktopExclusiveButtons() {
  // Hook is here in case we want to track download clicks later.
}

// School platforms ⇆ "other" productivity stubs
const _SCHOOL_PLATFORMS = ['google_classroom','canvas','schoology','powerschool','blackboard'];

function renderConnectors() {
  const schoolGrid = $('conn-school-grid');
  const otherGrid = $('conn-other-grid');
  if (!schoolGrid || !otherGrid) return;
  schoolGrid.innerHTML = '';
  otherGrid.innerHTML = '';

  // School cards from API
  (connectorsState.connectors || []).forEach(c => {
    schoolGrid.appendChild(renderConnectorCard(c));
  });
  // Hard-coded productivity stubs (until we wire OAuth)
  const stubs = [
    { platform: 'gmail',    name: 'Gmail',           icon: '📧', desc: 'Read recent threads, draft replies, summarize inbox.' },
    { platform: 'calendar', name: 'Google Calendar', icon: '📅', desc: "See today's schedule, find free time, propose meetings." },
    { platform: 'drive',    name: 'Google Drive',    icon: '📂', desc: 'Pull context from docs you share with J@rv1s.' },
    { platform: 'slack',    name: 'Slack',           icon: '💬', desc: 'Read recent channels, draft messages, summarize threads.' },
    { platform: 'notion',   name: 'Notion',          icon: '📓', desc: 'Pull pages, search workspace, append updates.' },
    { platform: 'github',   name: 'GitHub',          icon: '🐙', desc: 'Browse repos, read issues / PRs, draft code reviews.' },
  ];
  stubs.forEach(s => {
    otherGrid.appendChild(renderConnectorCard({
      platform: s.platform, name: s.name, icon: s.icon, ready: false,
      status: 'disconnected', logged_in: false,
      _desc: s.desc,
    }));
  });
}

function renderConnectorCard(c) {
  const card = document.createElement('div');
  card.className = 'conn-tile' + (c.ready === false ? ' coming-soon' : '');
  card.dataset.platform = c.platform;

  // mouse-tracking glow
  card.addEventListener('mousemove', (e) => {
    const r = card.getBoundingClientRect();
    card.style.setProperty('--mx', ((e.clientX - r.left) / r.width * 100) + '%');
    card.style.setProperty('--my', ((e.clientY - r.top) / r.height * 100) + '%');
  });

  const statusKey = c.logged_in ? 'connected'
                  : (c.status === 'syncing' ? 'syncing'
                  : (c.status === 'error' ? 'error'
                  : (c.ready === false ? 'coming-soon' : 'disconnected')));
  const statusLabel = ({
    connected: 'Connected',
    syncing: 'Syncing…',
    error: 'Error',
    'coming-soon': 'Coming soon',
    disconnected: 'Not connected',
  })[statusKey];

  const desc = c._desc || (DESCRIPTIONS[c.platform] || 'Pull tasks + context from this platform.');

  const lastSync = c.last_synced_at
    ? `Last synced ${timeAgo(c.last_synced_at)} · ${c.last_sync_count || 0} found`
    : (c.connected_at ? `Connected ${timeAgo(c.connected_at)}` : '');

  card.innerHTML = `
    <div class="conn-tile-head">
      <div class="conn-tile-icon">${c.icon || '🔗'}</div>
      <div class="conn-tile-info">
        <div class="conn-tile-name">${escape(c.name || c.platform)}</div>
        <div class="conn-tile-status ${statusKey}"><span class="dot"></span>${statusLabel}</div>
      </div>
    </div>
    <div class="conn-tile-desc">${escape(desc)}</div>
    ${lastSync ? `<div class="conn-tile-meta"><span>${escape(lastSync)}</span>${c.last_error ? `<span title="${escape(c.last_error)}" style="color:var(--danger)">!</span>` : ''}</div>` : ''}
    <div class="conn-tile-actions">
      ${c.ready === false
        ? `<button disabled>Coming soon</button>`
        : (c.logged_in
            ? `<button data-act="sync" class="primary">↻ Sync now</button>
               <button data-act="disconnect" class="danger">Disconnect</button>`
            : `<button data-act="connect" class="primary">Connect →</button>`)}
    </div>
  `;

  const conBtn  = card.querySelector('[data-act="connect"]');
  const syncBtn = card.querySelector('[data-act="sync"]');
  const disBtn  = card.querySelector('[data-act="disconnect"]');
  if (conBtn)  conBtn.addEventListener('click', () => connectPlatform(c.platform));
  if (syncBtn) syncBtn.addEventListener('click', () => syncPlatform(c.platform));
  if (disBtn)  disBtn.addEventListener('click', () => disconnectPlatform(c.platform));

  return card;
}

const DESCRIPTIONS = {
  google_classroom: 'Pull every assignment from Google Classroom — Assigned, Missing, and No Due Date sections, across all your classes.',
  canvas: 'Sync your Canvas course assignments and due dates straight into Tasks.',
  schoology: 'Pull assignments + announcements from your Schoology portal.',
  powerschool: 'See your PowerSchool tasks alongside everything else.',
  blackboard: 'Sync from your Blackboard Learn courses.',
};

async function connectPlatform(platform) {
  try {
    const r = await API('/api/connectors/' + platform + '/connect', { method: 'POST' });
    if (r.action === 'open_desktop_app') {
      alert('Sign-in needs to run in the J@rv1s desktop app. Download it from projectjarvis.app/download — then come back.');
      return;
    }
    if (r.ok && r.logged_in) {
      alert('✓ Signed in! Click "Sync now" to pull your assignments.');
    } else if (r.error) {
      alert('Connection failed: ' + r.error);
    } else {
      alert(r.message || 'Login window timed out — try again.');
    }
  } catch (e) {
    alert((e && e.error) || 'Failed to start connect flow.');
  } finally {
    loadConnectors();
  }
}

async function syncPlatform(platform) {
  // Optimistic: show syncing in UI immediately
  const tile = document.querySelector(`.conn-tile[data-platform="${platform}"] .conn-tile-status`);
  if (tile) { tile.className = 'conn-tile-status syncing'; tile.innerHTML = '<span class="dot"></span>Syncing…'; }
  try {
    const r = await API('/api/connectors/' + platform + '/sync', { method: 'POST' });
    if (r.action === 'open_desktop_app') {
      alert('Sync runs in the J@rv1s desktop app. Open it on your Mac — then come back.');
      return;
    }
    if (r.ok) {
      alert(r.message || `Synced ${r.found || 0} assignments (${r.added || 0} new).`);
    } else if (r.error) {
      alert('Sync failed: ' + r.error);
    }
  } catch (e) {
    alert((e && e.error) || 'Sync failed.');
  } finally {
    loadConnectors();
  }
}

async function disconnectPlatform(platform) {
  if (!confirm(`Disconnect from this platform? Your existing tasks stay.`)) return;
  await API('/api/connectors/' + platform, { method: 'DELETE' });
  loadConnectors();
}

$('conn-refresh') && $('conn-refresh').addEventListener('click', loadConnectors);

// On every boot, prime the Connectors count badge.
const _origBoot = boot;
boot = async function(opts) {
  await _origBoot.call(this, opts);
  loadConnectors();
};

// =====================================================
// HISTORY VIEW — every chat across every project
// =====================================================
let historyAll = [];        // flat list of {project, id, title, updated, files, preview}
let historyFilter = { q: '', project: '', sort: 'newest' };

async function loadHistory() {
  // Build from state.all_projects which we already have. Refresh first.
  try {
    state = await API('/api/state');
  } catch (e) {
    if (e && e.auth) { showAuth(); return; }
  }
  historyAll = [];
  (state.all_projects || []).forEach(p => {
    (p.conversations || []).forEach(c => {
      historyAll.push({
        project: p.name,
        id: c.id,
        title: c.title || '(Untitled)',
        preview: c.preview || '',
        updated: c.updated || 0,
        files: c.files || [],     // attached files if any
      });
    });
  });
  // Populate project filter dropdown
  const sel = $('hist-project');
  if (sel) {
    const projects = Array.from(new Set(historyAll.map(h => h.project))).sort();
    sel.innerHTML = '<option value="">All projects</option>' +
      projects.map(p => `<option value="${escape(p)}">${escape(p)}</option>`).join('');
  }
  renderHistory();
}

function renderHistory() {
  const list = $('hist-list');
  const count = $('hist-count');
  if (!list) return;
  const q = historyFilter.q.toLowerCase();
  let rows = historyAll.filter(h => {
    if (historyFilter.project && h.project !== historyFilter.project) return false;
    if (q && !((h.title || '') + ' ' + (h.project || '') + ' ' + (h.preview || ''))
        .toLowerCase().includes(q)) return false;
    return true;
  });
  // Sort
  if (historyFilter.sort === 'oldest') rows.sort((a, b) => (a.updated || 0) - (b.updated || 0));
  else if (historyFilter.sort === 'project') rows.sort((a, b) => (a.project || '').localeCompare(b.project || '') || ((b.updated || 0) - (a.updated || 0)));
  else rows.sort((a, b) => (b.updated || 0) - (a.updated || 0));

  if (count) count.textContent = `${rows.length} chat${rows.length === 1 ? '' : 's'}`;
  list.innerHTML = '';
  if (!rows.length) {
    list.innerHTML = `
      <div class="hist-empty">
        <div class="ico">💬</div>
        <h3>${historyAll.length ? 'Nothing matches that filter' : 'No chats yet'}</h3>
        <p>${historyAll.length ? 'Try a different search or filter.' : 'Start chatting and your history will appear here.'}</p>
      </div>`;
    return;
  }
  rows.forEach(h => list.appendChild(renderHistRow(h)));
}

function renderHistRow(h) {
  const row = document.createElement('div');
  row.className = 'hist-row';
  // Build file tag string
  const fileChips = (h.files || []).slice(0, 2).map(f =>
    `<span class="file-tag">📎 ${escape(f.name || f)}</span>`).join('');
  const moreFiles = (h.files || []).length > 2
    ? `<span class="file-tag">+${(h.files || []).length - 2}</span>` : '';
  row.innerHTML = `
    <span class="ico">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
      </svg>
    </span>
    <div class="title">${escape(h.title)}</div>
    <div class="meta">
      ${fileChips}${moreFiles}
      <span class="project-tag">${escape(h.project)}</span>
    </div>
    <div class="when">${escape(timeAgo(h.updated) || '—')}</div>
  `;
  row.addEventListener('click', () => openConversation(h.project, h.id));
  return row;
}

// Bar wiring
$('hist-search') && $('hist-search').addEventListener('input', (e) => {
  historyFilter.q = e.target.value; renderHistory();
});
$('hist-project') && $('hist-project').addEventListener('change', (e) => {
  historyFilter.project = e.target.value; renderHistory();
});
$('hist-sort') && $('hist-sort').addEventListener('change', (e) => {
  historyFilter.sort = e.target.value; renderHistory();
});
$('hist-new') && $('hist-new').addEventListener('click', newChat);

// ─── Memory import flow ────────────────────────────────────────────────────
let memoryInfo = null;
async function loadMemoryStatus() {
  try {
    memoryInfo = await API('/api/memory');
  } catch { memoryInfo = null; return; }
  const n = (memoryInfo.imported || []).length;
  const row = $('mem-status-row'), clear = $('mem-clear-row');
  if (n > 0) {
    row.style.display = ''; clear.style.display = '';
    const chars = (memoryInfo.imported_text || '').length;
    $('mem-status').textContent = `${n} import${n === 1 ? '' : 's'} · ${chars.toLocaleString()} characters stored`;
  } else {
    row.style.display = 'none'; clear.style.display = 'none';
  }
}

// open import modal: paint the prompt + clear paste box
$('set-mem-import') && $('set-mem-import').addEventListener('click', async () => {
  if (!memoryInfo) await loadMemoryStatus();
  $('mem-prompt-pre').textContent = (memoryInfo && memoryInfo.import_prompt) || '';
  $('mem-paste').value = '';
  $('mem-copy').textContent = '📋 Copy';
  $('mem-copy').classList.remove('copied');
  $('mem-import-backdrop').classList.remove('hidden');
});

// copy prompt
$('mem-copy') && $('mem-copy').addEventListener('click', async () => {
  try {
    await navigator.clipboard.writeText($('mem-prompt-pre').textContent);
    $('mem-copy').textContent = '✓ Copied';
    $('mem-copy').classList.add('copied');
    setTimeout(() => {
      $('mem-copy').textContent = '📋 Copy';
      $('mem-copy').classList.remove('copied');
    }, 1800);
  } catch { alert('Copy failed — select and copy manually.'); }
});

// save imported memory
$('mem-import-save') && $('mem-import-save').addEventListener('click', async () => {
  const text = $('mem-paste').value.trim();
  if (!text) { alert('Paste your memory export first.'); return; }
  try {
    await API('/api/memory/import', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text, source: $('mem-source').value }),
    });
    $('mem-import-backdrop').classList.add('hidden');
    $('mem-paste').value = '';
    await loadMemoryStatus();
    alert(`Memory imported. J@rv1s will use this context from now on.`);
  } catch (e) { alert(e.error || 'Import failed.'); }
});

$('mem-import-cancel') && $('mem-import-cancel').addEventListener('click', () =>
  $('mem-import-backdrop').classList.add('hidden'));
$('mem-import-backdrop') && $('mem-import-backdrop').addEventListener('click', (e) => {
  if (e.target.id === 'mem-import-backdrop') e.currentTarget.classList.add('hidden');
});

// view / edit existing imported memory
$('set-mem-view') && $('set-mem-view').addEventListener('click', async () => {
  if (!memoryInfo) await loadMemoryStatus();
  $('mem-view-text').value = (memoryInfo && memoryInfo.imported_text) || '';
  $('mem-view-backdrop').classList.remove('hidden');
});

$('mem-view-save') && $('mem-view-save').addEventListener('click', async () => {
  const text = $('mem-view-text').value.trim();
  // Save = wipe imports + replace with the edited text as one entry
  await API('/api/memory/import', { method: 'DELETE' });
  if (text) {
    await API('/api/memory/import', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text, source: 'edited' }),
    });
  }
  $('mem-view-backdrop').classList.add('hidden');
  await loadMemoryStatus();
});

$('mem-view-cancel') && $('mem-view-cancel').addEventListener('click', () =>
  $('mem-view-backdrop').classList.add('hidden'));
$('mem-view-backdrop') && $('mem-view-backdrop').addEventListener('click', (e) => {
  if (e.target.id === 'mem-view-backdrop') e.currentTarget.classList.add('hidden');
});

// clear all imported memory
$('set-mem-clear') && $('set-mem-clear').addEventListener('click', async () => {
  if (!confirm('Clear ALL imported memory? This wipes everything you brought in from other AIs.')) return;
  await API('/api/memory/import', { method: 'DELETE' });
  await loadMemoryStatus();
});

const pwModal = $('password-modal-backdrop');
function bindSettings() {
  $('set-theme') && $('set-theme').addEventListener('click', () => themeToggle && themeToggle.click());
  $('set-logout') && $('set-logout').addEventListener('click', async () => {
    if (!confirm('Sign out?')) return;
    await API('/api/auth/logout', { method: 'POST' }); location.reload();
  });
  $('set-manage') && $('set-manage').addEventListener('click', () => {
    if (billingInfo && billingInfo.subscribed) openPortal(); else showPaywall();
  });
  $('set-export') && $('set-export').addEventListener('click', () => { window.location.href = '/api/account/export'; });
  $('set-clear') && $('set-clear').addEventListener('click', resetConversation);
  $('set-delete') && $('set-delete').addEventListener('click', async () => {
    if (!confirm('Delete your account and ALL data? This cannot be undone.')) return;
    if (!confirm('Really delete everything permanently? Conversations, projects, memory — all gone.')) return;
    try {
      const r = await API('/api/account/delete', { method: 'POST' });
      if (r.ok) {
        alert('Account deleted. Goodbye 👋');
        // Send to auth screen, not a refresh — refresh might 401-loop on a deleted session.
        window.location.href = '/?deleted=1';
      } else {
        alert(r.error || 'Delete failed.');
      }
    } catch (e) {
      alert((e && e.error) || 'Delete failed. If you have an active subscription, cancel it first via Stripe portal.');
    }
  });
  $('set-change-pw') && $('set-change-pw').addEventListener('click', () => {
    pwModal.classList.remove('hidden'); $('pw-old').focus();
  });
  $('pw-cancel') && $('pw-cancel').addEventListener('click', () => {
    pwModal.classList.add('hidden'); $('pw-old').value = ''; $('pw-new').value = ''; $('pw-error').textContent = '';
  });
  $('pw-save') && $('pw-save').addEventListener('click', async () => {
    try {
      await API('/api/account/password', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ old: $('pw-old').value, new: $('pw-new').value }),
      });
      pwModal.classList.add('hidden'); $('pw-old').value = ''; $('pw-new').value = '';
      $('pw-error').textContent = '';
      alert('Password updated.');
    } catch (e) { $('pw-error').textContent = e.error || 'Could not update password.'; }
  });
  pwModal && pwModal.addEventListener('click', (e) => { if (e.target === pwModal) pwModal.classList.add('hidden'); });
}
bindSettings();

async function startCheckout(tier, interval = 'monthly') {
  const note = $('paywall-note');
  if (!billingInfo || !billingInfo.enabled) {
    note.textContent = 'Payments aren’t switched on yet (Stripe link not set).';
    return;
  }
  note.textContent = 'Opening secure checkout…';
  try {
    const r = await API('/api/billing/checkout', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ tier, interval }),
    });
    if (r.url) window.location.href = r.url;
  } catch (e) { note.textContent = e.error || 'Could not start checkout.'; }
}

async function refreshSubscription() {
  const note = $('paywall-note');
  note.textContent = 'Checking…';
  await loadBilling();
  if (!gated) { hidePaywall(); boot(); }
  else note.textContent = "No active subscription found yet. If you just paid, give it a few seconds.";
}

if (paywall) {
  $('paywall-refresh').addEventListener('click', refreshSubscription);
  // "Explore first" — dismiss the paywall and browse the app (messaging still locked).
  $('paywall-back').addEventListener('click', hidePaywall);
  $('paywall-signout').addEventListener('click', async () => {
    await API('/api/auth/logout', { method: 'POST' }); location.reload();
  });
}

// returning from Stripe: poll a few times for the webhook to land
if (location.search.includes('upgraded=1')) {
  let tries = 0;
  const poll = setInterval(async () => {
    tries++;
    await loadBilling();
    if (!gated || tries > 6) { clearInterval(poll); if (!gated) hidePaywall(); }
  }, 2000);
}

// =====================================================
// View switching
// =====================================================
function switchView(view) {
  document.body.dataset.view = view;
  $$('.nav-item').forEach(el => {
    // highlight the matching view item; highlight New chat when on chat view
    const isActive = el.dataset.view === view ||
                     (view === 'chat' && el.dataset.action === 'new-chat');
    el.classList.toggle('active', isActive);
  });
  if (view === 'admin') loadAdmin();
  if (view === 'settings') loadSettings();
  if (view === 'tasks') loadTasks();
  if (view === 'memories') loadMemories();
  if (view === 'connectors') loadConnectors();
  if (view === 'history') loadHistory();
}

async function newChat() {
  // leave any project context and start a clean global conversation
  await API('/api/projects/clear', { method: 'POST' });
  await API('/api/reset', { method: 'POST' });
  state.active_project = null;
  state.active_conversation_id = null;
  currentProjectPage = null;
  switchView('chat');
  clearChat();
  location.reload();
}

$$('.nav-item').forEach(el => {
  el.addEventListener('click', () => {
    if (el.dataset.action === 'new-chat') newChat();
    else if (el.dataset.action === 'search') openPalette();
    else if (el.dataset.view) switchView(el.dataset.view);
  });
});

// Account card (sidebar bottom-left) → opens settings.
const accountCard = $('account-card');
if (accountCard) accountCard.addEventListener('click', () => switchView('settings'));

function renderAccountCard(info) {
  if (!accountCard || !info) return;
  const name = info.email || info.username || 'Account';
  const plan = info.plan === 'none' ? 'No plan' :
               ({starter:'Starter', professional:'Professional', max:'Max', ultra:'Ultra', apex:'Apex'})[info.plan] || info.plan;
  $('ac-name').textContent = name;
  $('ac-plan').textContent = info.is_admin ? 'Admin' : `${plan} plan`;
  $('ac-avatar').textContent = (name[0] || 'J').toUpperCase();
}

// Aggregate conversations across pinned projects → "Recent chats" sidebar list
function renderRecentChats() {
  const wrap = $('recent-chats');
  if (!wrap) return;
  const all = [];
  (state.all_projects || []).forEach(p => {
    (p.conversations || []).forEach(c => {
      all.push({ project: p.name, id: c.id, title: c.title || 'Untitled', updated: c.updated || 0 });
    });
  });
  all.sort((a, b) => (b.updated || 0) - (a.updated || 0));
  const top = all.slice(0, 10);
  wrap.innerHTML = '';
  if (!top.length) {
    wrap.innerHTML = '<div class="empty">No chats yet</div>';
    return;
  }
  top.forEach(c => {
    const el = document.createElement('div');
    el.className = 'recent-chat-item';
    el.textContent = c.title;
    el.title = `${c.title} · ${c.project}`;
    el.addEventListener('click', () => openConversation(c.project, c.id));
    wrap.appendChild(el);
  });
}

// =====================================================
// Chat rendering
// =====================================================
function clearChat() { chat.innerHTML = ''; }

function appendMessage(role, content) {
  const welcome = chat.querySelector('.welcome');
  if (welcome) welcome.remove();

  const wrap = document.createElement('div');
  wrap.className = `msg ${role}`;

  const avatar = document.createElement('div');
  avatar.className = 'msg-avatar';
  avatar.textContent = role === 'user' ? 'K' : 'J';

  const body = document.createElement('div');
  body.className = 'msg-body';

  const roleEl = document.createElement('div');
  roleEl.className = 'msg-role';
  roleEl.textContent = role === 'user' ? 'You' : 'J@rv1s';

  const contentEl = document.createElement('div');
  contentEl.className = 'msg-content';
  if (role === 'assistant') {
    contentEl.innerHTML = marked.parse(content);
    contentEl.querySelectorAll('pre code').forEach(b => hljs.highlightElement(b));
  } else {
    contentEl.textContent = content;
  }

  body.appendChild(roleEl);
  body.appendChild(contentEl);
  wrap.appendChild(avatar);
  wrap.appendChild(body);
  chat.appendChild(wrap);
  chat.scrollTop = chat.scrollHeight;
  return contentEl;
}

function appendTyping() {
  const welcome = chat.querySelector('.welcome');
  if (welcome) welcome.remove();
  const wrap = document.createElement('div');
  wrap.className = 'msg assistant';
  wrap.id = 'typing-msg';
  wrap.innerHTML = `
    <div class="msg-avatar">J</div>
    <div class="msg-body">
      <div class="msg-role">J@rv1s</div>
      <div class="msg-content"><div class="typing"><span></span><span></span><span></span></div></div>
    </div>`;
  chat.appendChild(wrap);
  chat.scrollTop = chat.scrollHeight;
}
function removeTyping() { const t = $('typing-msg'); if (t) t.remove(); }

// =====================================================
// Sidebar
// =====================================================
function renderSidebar() {
  // Projects
  projectList.innerHTML = '';
  if (state.projects.length === 0) {
    projectList.innerHTML = '<div style="padding:8px 10px;color:var(--text-dim);font-size:12px">No projects yet</div>';
  } else {
    state.projects.forEach(p => {
      const el = document.createElement('div');
      el.className = 'project-item' + (p.name === state.active_project ? ' active' : '');
      const open = p.assignments.filter(a => !a.done).length;
      el.innerHTML = `
        <span class="name">${escape(p.name)}</span>
        ${open > 0 ? `<span class="count">${open}</span>` : ''}
        <button class="pi-unpin" title="Unpin" aria-label="Unpin ${escape(p.name)}">×</button>
      `;
      el.addEventListener('click', (e) => {
        if (e.target.closest('.pi-unpin')) return;   // don't open on unpin
        useProject(p.name);
      });
      el.querySelector('.pi-unpin').addEventListener('click', async (e) => {
        e.stopPropagation();
        await API(`/api/projects/${encodeURIComponent(p.name)}/pin`, {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ pinned: false }),
        });
        await refreshState();
      });
      projectList.appendChild(el);
    });
  }

  // Upcoming
  upcomingList.innerHTML = '';
  if (state.upcoming.length === 0) {
    upcomingList.innerHTML = '<div style="padding:8px 10px;color:var(--text-dim);font-size:12px">Nothing soon</div>';
  } else {
    state.upcoming.slice(0, 6).forEach(a => {
      const cls = a.days_until <= 1 ? 'urgent' : a.days_until <= 3 ? 'soon' : 'fine';
      const el = document.createElement('div');
      el.className = 'upcoming-item';
      el.innerHTML = `
        <div class="title">${escape(a.title)}</div>
        <div class="meta">
          <span>${escape(a.project)}</span>
          <span class="days ${cls}">${a.days_until}d</span>
        </div>`;
      upcomingList.appendChild(el);
    });
  }

  // Skill count badge in nav
  const enabledCount = (state.skills || []).filter(s => s.enabled).length;
  const navCount = $('nav-skill-count');
  navCount.textContent = enabledCount;
  navCount.classList.toggle('show', enabledCount > 0);

  renderRecentChats();
}

function renderActiveProject() {
  if (state.active_project) {
    activeProjectDisplay.innerHTML = `<span class="muted">In</span> <strong class="ap-label">${escape(state.active_project)}</strong>`;
  } else {
    activeProjectDisplay.innerHTML = `<strong class="ap-label">General Chat</strong>`;
  }
}

// =====================================================
// Model picker
// =====================================================
function modelClass(id) {
  if (id === 'claude-opus-4-7') return 'm-opus';
  if (id === 'claude-haiku-4-5-20251001') return 'm-haiku';
  if (id === 'claude-sonnet-4-6') return 'm-sonnet';
  return '';
}

function renderModel() {
  const current = models.find(m => m.id === state.model);
  modelBadgeName.textContent = current ? current.name : state.model;
  modelBadgeName.className = 'm-name ' + modelClass(state.model);
  modelDropdown.innerHTML = '';
  models.forEach(m => {
    const opt = document.createElement('div');
    opt.className = 'model-option' + (m.id === state.model ? ' active' : '');
    opt.innerHTML = `
      <div class="top">
        <span class="name m-name ${modelClass(m.id)}">${escape(m.name)}</span>
        <span class="check">✓</span>
      </div>
      <span class="desc">${escape(m.desc)}</span>`;
    opt.onclick = async () => {
      try {
        await API('/api/model', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ model: m.id }),
        });
        state.model = m.id;
        modelDropdown.classList.add('hidden');
        renderModel();
      } catch (e) { alert(e.error || 'Failed to switch model'); }
    };
    modelDropdown.appendChild(opt);
  });
}

modelBadge.addEventListener('click', (e) => {
  e.stopPropagation();
  modelDropdown.classList.toggle('hidden');
});
document.addEventListener('click', (e) => {
  if (!e.target.closest('#model-picker')) modelDropdown.classList.add('hidden');
});

// =====================================================
// Browser automation toggle
// =====================================================
function renderBrowserToggle() {
  const on = !!(state.browser && state.browser.armed);
  browserToggle.classList.toggle('on', on);
  const safe = $('safesites-toggle');
  if (safe) {
    safe.classList.toggle('on', !!(state.browser && state.browser.restricted));
    safe.style.display = on ? 'flex' : 'none';   // only show when armed
  }
}

browserToggle.addEventListener('click', async () => {
  const on = browserToggle.classList.contains('on');
  browserToggle.classList.add('loading');
  try {
    const res = await API(`/api/browser/${on ? 'disable' : 'enable'}`, { method: 'POST' });
    state.browser = res;
    renderBrowserToggle();
  } catch (e) {
    // arming never launches a browser, so this should basically never fail
    console.warn('browser toggle', e);
  } finally {
    browserToggle.classList.remove('loading');
  }
});

// theme toggle
function applyTheme(theme) {
  document.body.dataset.theme = theme;
  const t = $('theme-toggle');
  if (t) t.classList.toggle('on', theme === 'light');
}
const themeToggle = $('theme-toggle');
if (themeToggle) themeToggle.addEventListener('click', async () => {
  const next = (document.body.dataset.theme === 'light') ? 'dark' : 'light';
  applyTheme(next);
  state.theme = next;
  await API('/api/theme', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ theme: next }),
  });
});

const safeToggle = $('safesites-toggle');
if (safeToggle) safeToggle.addEventListener('click', async () => {
  const on = safeToggle.classList.contains('on');
  const res = await API('/api/browser/restrict', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ restricted: !on }),
  });
  state.browser = res;
  renderBrowserToggle();
});

// =====================================================
// Voice-out toggle (speak responses)
// =====================================================
voiceOutToggle.addEventListener('click', () => {
  speakResponses = !speakResponses;
  voiceOutToggle.classList.toggle('on', speakResponses);
});

async function speak(text) {
  try {
    await API('/api/voice/speak', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text }),
    });
  } catch (e) { console.warn('TTS failed', e); }
}

// =====================================================
// Send / chat
// =====================================================
async function send(opts = {}) {
  const text = (opts.text ?? input.value).trim();
  if (!text) return;
  if (gated) { showPaywall(); return; }   // no messaging without a plan
  if (!opts.text) {
    input.value = '';
    input.style.height = 'auto';
  }
  sendBtn.disabled = true;
  sendBtn.classList.add('loading');

  appendMessage('user', text);
  appendTyping();

  try {
    await streamReply(text, !!(speakResponses || opts.alwaysSpeak));
  } catch (e) {
    removeTyping();
    appendMessage('assistant', `**Error:** ${e.error || e.message || JSON.stringify(e)}`);
  } finally {
    sendBtn.disabled = false;
    sendBtn.classList.remove('loading');
    input.focus();
  }
}

// Stream the assistant reply token-by-token via SSE; render markdown live.
async function streamReply(message, doSpeak) {
  const resp = await fetch('/api/chat/stream', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ message }),
  });
  if (!resp.ok || !resp.body) {
    // fall back to non-streaming
    removeTyping();
    const res = await API('/api/chat', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message }),
    });
    appendMessage('assistant', res.reply);
    if (doSpeak) speak(res.reply);
    return;
  }

  removeTyping();
  const contentEl = appendMessage('assistant', '');
  contentEl.classList.add('streaming');

  const reader = resp.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';
  let full = '';

  // throttle markdown re-render for smoothness
  let pending = false;
  const renderNow = () => {
    contentEl.innerHTML = marked.parse(full);
    contentEl.querySelectorAll('pre code').forEach(b => hljs.highlightElement(b));
    contentEl.classList.add('streaming');
    chat.scrollTop = chat.scrollHeight;
    pending = false;
  };

  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split('\n\n');
    buffer = lines.pop();
    for (const line of lines) {
      const m = line.match(/^data: (.*)$/s);
      if (!m) continue;
      let payload;
      try { payload = JSON.parse(m[1]); } catch { continue; }
      if (payload.t) {
        full += payload.t;
        if (!pending) { pending = true; requestAnimationFrame(renderNow); }
      } else if (payload.error) {
        full += `\n\n**Error:** ${payload.error}`;
      }
    }
  }
  full = full || '…';
  contentEl.innerHTML = marked.parse(full);
  contentEl.querySelectorAll('pre code').forEach(b => hljs.highlightElement(b));
  contentEl.classList.remove('streaming');
  chat.scrollTop = chat.scrollHeight;
  if (doSpeak) speak(full);
}

// =====================================================
// Projects
// =====================================================
async function useProject(name) {
  // Activate the project on the backend, then open the project view.
  const r = await API(`/api/projects/${encodeURIComponent(name)}/use`, { method: 'POST' });
  state.active_project = name;
  state.active_conversation_id = r.conversation_id || null;
  renderSidebar();
  renderActiveProject();
  await openProjectPage(name);
}

async function openProjectPage(name) {
  currentProjectPage = name;
  switchView('project');
  // skeleton while loading
  $('project-title-display').textContent = name;
  $('project-suggestions').innerHTML =
    Array(6).fill('<div class="skeleton skel-card"></div>').join('');
  $('project-recents').innerHTML =
    Array(3).fill('<div class="skeleton skel-card"></div>').join('');
  // load detail + conversations + suggestions + files in parallel
  const [meta, convs, sugg, files] = await Promise.all([
    API(`/api/projects/${encodeURIComponent(name)}`),
    API(`/api/projects/${encodeURIComponent(name)}/conversations`),
    API(`/api/projects/${encodeURIComponent(name)}/suggestions`),
    API(`/api/projects/${encodeURIComponent(name)}/files`),
  ]);
  renderProjectPage(meta, convs, sugg, files);
}

function fmtBytes(n) {
  if (n < 1024) return n + ' B';
  if (n < 1048576) return (n / 1024).toFixed(0) + ' KB';
  return (n / 1048576).toFixed(1) + ' MB';
}

async function uploadFiles(fileList) {
  if (!currentProjectPage || !fileList.length) return;
  const fd = new FormData();
  for (const f of fileList) fd.append('file', f);
  await fetch(`/api/projects/${encodeURIComponent(currentProjectPage)}/files`, {
    method: 'POST', body: fd,
  });
  openProjectPage(currentProjectPage);  // refresh
}

async function deleteFile(fname) {
  if (!currentProjectPage) return;
  await API(`/api/projects/${encodeURIComponent(currentProjectPage)}/files/${encodeURIComponent(fname)}`, { method: 'DELETE' });
  openProjectPage(currentProjectPage);
}

function renderProjectPage(meta, convs, suggestions, files = []) {
  $('project-title-display').textContent = meta.name;
  $('project-conv-count').textContent = `${convs.length} chat${convs.length === 1 ? '' : 's'}`;

  // instructions card
  const ib = $('instructions-body');
  ib.textContent = meta.instructions || meta.description || 'No instructions yet. Click the pencil to add some.';
  ib.dataset.value = meta.instructions || '';

  // assignments card
  const ab = $('assignments-body');
  ab.innerHTML = '';
  const assigns = meta.assignments || [];
  if (!assigns.length) {
    ab.innerHTML = '<div class="muted-body" style="padding:0">No deadlines yet.</div>';
  } else {
    assigns.forEach(a => {
      const row = document.createElement('div');
      row.className = 'assign-row' + (a.done ? ' done' : '');
      row.innerHTML = `
        <button class="assign-check" title="Toggle complete">${a.done ? '✓' : ''}</button>
        <div class="assign-info">
          <div class="assign-title">${escape(a.title)}</div>
          <div class="assign-due">due ${escape(a.due)}${a.notes ? ' · ' + escape(a.notes) : ''}</div>
        </div>`;
      row.querySelector('.assign-check').addEventListener('click', async () => {
        await API(`/api/projects/${encodeURIComponent(meta.name)}/assignments/complete`, {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ title: a.title }),
        });
        openProjectPage(meta.name); refreshState();
      });
      ab.appendChild(row);
    });
  }

  // scheduled card
  const scb = $('scheduled-body');
  scb.innerHTML = '';
  const sched = meta.scheduled || [];
  if (!sched.length) {
    scb.innerHTML = '<div class="muted-body" style="padding:0">No recurring tasks.</div>';
  } else {
    sched.forEach((s, i) => {
      const row = document.createElement('div');
      row.className = 'assign-row';
      row.innerHTML = `<div class="assign-info">
          <div class="assign-title">${escape(s.title)}</div>
          <div class="assign-due">${escape(s.cadence)}</div>
        </div>
        <button class="fi-del" title="Remove">×</button>`;
      row.querySelector('.fi-del').addEventListener('click', async () => {
        await API(`/api/projects/${encodeURIComponent(meta.name)}/scheduled/${i}`, { method: 'DELETE' });
        openProjectPage(meta.name);
      });
      scb.appendChild(row);
    });
  }

  // context card: files + drop zone
  const cb = $('context-body');
  cb.innerHTML = '';
  cb.insertAdjacentHTML('beforeend', `<div class="label">Files (${files.length})</div>`);
  if (files.length) {
    files.forEach(f => {
      const row = document.createElement('div');
      row.className = 'context-item file-item';
      row.innerHTML = `<span class="fi-name">📄 ${escape(f.name)}</span>
        <span class="fi-meta">${fmtBytes(f.size)}</span>
        <button class="fi-del" title="Remove">×</button>`;
      row.querySelector('.fi-del').addEventListener('click', () => deleteFile(f.name));
      cb.appendChild(row);
    });
  }
  const drop = document.createElement('label');
  drop.className = 'dropzone';
  drop.innerHTML = `<input type="file" multiple hidden>
    <span>＋ Drop files or click to upload</span>`;
  const fileInput = drop.querySelector('input');
  fileInput.addEventListener('change', () => uploadFiles(fileInput.files));
  ['dragenter', 'dragover'].forEach(ev => drop.addEventListener(ev, (e) => {
    e.preventDefault(); drop.classList.add('drag');
  }));
  ['dragleave', 'drop'].forEach(ev => drop.addEventListener(ev, (e) => {
    e.preventDefault(); drop.classList.remove('drag');
  }));
  drop.addEventListener('drop', (e) => uploadFiles(e.dataTransfer.files));
  cb.appendChild(drop);
  cb.insertAdjacentHTML('beforeend', '<div class="label" style="margin-top:10px">Memory</div>');
  cb.insertAdjacentHTML('beforeend', `<div class="context-item">🧠 Personal memory + preferences</div>`);

  // suggestions
  const sg = $('project-suggestions');
  sg.innerHTML = '';
  suggestions.forEach((s, i) => {
    const b = document.createElement('button');
    b.className = 'suggestion-chip';
    b.style.animationDelay = `${i * 0.05}s`;
    b.innerHTML = `<span class="chip-icon">${s.icon}</span><span>${escape(s.title)}</span>`;
    b.addEventListener('click', () => startConversationWith(s.prompt));
    sg.appendChild(b);
  });

  // recents
  const rl = $('project-recents');
  rl.innerHTML = '';
  if (convs.length === 0) {
    rl.innerHTML = '<div class="recents-empty">No conversations yet. Start one above ↑</div>';
  } else {
    convs.forEach((c, i) => {
      const card = document.createElement('div');
      card.className = 'recent-card';
      card.style.animationDelay = `${i * 0.04}s`;
      card.innerHTML = `
        <div class="recent-icon">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
          </svg>
        </div>
        <div class="recent-info">
          <div class="recent-title">${escape(c.title)}</div>
          ${c.preview ? `<div class="recent-preview">${escape(c.preview)}</div>` : ''}
        </div>
        <div class="recent-time">${timeAgo(c.updated)}</div>`;
      card.addEventListener('click', () => openConversation(meta.name, c.id));
      rl.appendChild(card);
    });
  }
}

function timeAgo(ts) {
  if (!ts) return '';
  const s = Date.now() / 1000 - ts;
  if (s < 60) return 'just now';
  if (s < 3600) return Math.floor(s / 60) + ' min ago';
  if (s < 86400) return Math.floor(s / 3600) + ' hr ago';
  if (s < 604800) return Math.floor(s / 86400) + ' days ago';
  return new Date(ts * 1000).toLocaleDateString();
}

async function startConversationWith(text) {
  if (!currentProjectPage) return;
  // create a new conversation and send the seed message
  await API(`/api/projects/${encodeURIComponent(currentProjectPage)}/conversations`, { method: 'POST' });
  // refresh state so active_conversation_id is set
  state = await API('/api/state');
  switchView('chat');
  clearChat();
  await send({ text });
  renderChatBreadcrumb();
}

async function startNewConversation() {
  if (!currentProjectPage) return;
  await API(`/api/projects/${encodeURIComponent(currentProjectPage)}/conversations`, { method: 'POST' });
  state = await API('/api/state');
  switchView('chat');
  clearChat();
  renderChatBreadcrumb();
  input.focus();
}

async function openConversation(project, cid) {
  await API(`/api/projects/${encodeURIComponent(project)}/conversations/${cid}/open`, { method: 'POST' });
  state = await API('/api/state');
  switchView('chat');
  clearChat();
  if (state.history && state.history.length) {
    state.history.forEach(m => appendMessage(m.role, m.content));
  }
  renderChatBreadcrumb();
}

function renderChatBreadcrumb() {
  const back = $('chat-back-btn');
  const disp = $('active-project-display');
  if (state.active_project) {
    back.classList.remove('hidden');
    back.textContent = `← ${state.active_project}`;
    disp.innerHTML = `<span class="muted">In</span> <strong class="ap-label">${escape(state.active_project)}</strong>`;
  } else {
    back.classList.add('hidden');
    disp.innerHTML = `<strong class="ap-label">General Chat</strong>`;
  }
}

async function newProject(name, description) {
  await API('/api/projects', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, description }),
  });
  await refreshState();
}

async function refreshState() {
  state = await API('/api/state');
  renderSidebar();
  renderActiveProject();
  renderBrowserToggle();
  renderSkillsPage();
  renderAllProjects();
}

function renderAllProjects() {
  const grid = $('all-projects-grid');
  if (!grid) return;
  grid.innerHTML = '';
  (state.all_projects || []).forEach((p, i) => {
    const open = p.assignments.filter(a => !a.done).length;
    const convs = (p.conversations || []).length;
    const pinned = p.pinned !== false;
    const card = document.createElement('div');
    card.className = 'project-card';
    card.style.animationDelay = `${i * 0.05}s`;
    card.innerHTML = `
      <div class="pc-actions">
        <button class="pc-action pin ${pinned ? 'pinned' : ''}" data-action="pin" title="${pinned ? 'Unpin' : 'Pin'}">📌</button>
        <button class="pc-action delete" data-action="delete" title="Delete">🗑</button>
      </div>
      <div class="pc-name">${escape(p.name)}</div>
      <div class="pc-desc">${escape(p.description || '')}</div>
      <div class="pc-stats">
        <span><strong>${convs}</strong> chats</span>
        <span><strong>${open}</strong> open</span>
        <span><strong>${p.assignments.length}</strong> total</span>
      </div>`;
    card.addEventListener('click', (e) => {
      if (e.target.closest('.pc-action')) return;
      useProject(p.name);
    });
    card.querySelector('[data-action="pin"]').addEventListener('click', async (e) => {
      e.stopPropagation();
      await API(`/api/projects/${encodeURIComponent(p.name)}/pin`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pinned: !pinned }),
      });
      await refreshState();
    });
    card.querySelector('[data-action="delete"]').addEventListener('click', async (e) => {
      e.stopPropagation();
      if (!confirm(`Delete "${p.name}" and all its conversations?`)) return;
      await API(`/api/projects/${encodeURIComponent(p.name)}`, { method: 'DELETE' });
      await refreshState();
    });
    grid.appendChild(card);
  });
  if ((state.all_projects || []).length === 0) {
    grid.innerHTML = '<div class="recents-empty">No projects yet. Create one.</div>';
  }
}

async function resetConversation() {
  await API('/api/reset', { method: 'POST' });
  clearChat();
  location.reload();
}

// =====================================================
// Voice (round-trip: listen → chat → speak)
// =====================================================
async function voiceTurn() {
  voiceBtn.classList.add('active');
  try {
    const res = await API('/api/voice/listen', { method: 'POST' });
    if (res.text) {
      await send({ text: res.text, alwaysSpeak: true });
    }
  } catch (e) {
    appendMessage('assistant', `**Voice error:** ${e.error || JSON.stringify(e)}`);
  } finally {
    voiceBtn.classList.remove('active');
  }
}

// =====================================================
// Skills page
// =====================================================
function renderSkillsPage() {
  const skills = (state.skills || []).filter(s => {
    if (skillFilter !== 'all' && s.category !== skillFilter) return false;
    if (skillSearch && !(`${s.name} ${s.description}`.toLowerCase().includes(skillSearch.toLowerCase()))) return false;
    return true;
  });
  const sections = { personal: $('grid-personal'), system: $('grid-system'), custom: $('grid-custom') };
  Object.values(sections).forEach(g => g.innerHTML = '');

  skills.forEach(s => {
    const card = document.createElement('div');
    card.className = 'skill-card' + (s.enabled ? ' enabled' : '') + (s.category === 'custom' ? ' custom' : '');
    card.innerHTML = `
      <div class="skill-icon" style="background: ${s.gradient || 'linear-gradient(135deg,#00d9ff,#b794f6)'}">${s.icon || '✨'}</div>
      <div class="skill-info">
        <div class="skill-name">${escape(s.name)}</div>
        <div class="skill-desc">${escape(s.description)}</div>
      </div>
      ${s.category === 'custom' ? '<button class="skill-delete" title="Delete skill">×</button>' : ''}
      <div class="skill-check">✓</div>`;
    card.addEventListener('click', async (e) => {
      if (e.target.classList.contains('skill-delete')) return;
      const r = await API(`/api/skills/${encodeURIComponent(s.id)}/toggle`, { method: 'POST' });
      const idx = state.skills.findIndex(x => x.id === s.id);
      if (idx >= 0) state.skills[idx].enabled = r.enabled;
      renderSkillsPage();
      renderSidebar();
    });
    const del = card.querySelector('.skill-delete');
    if (del) {
      del.addEventListener('click', async (e) => {
        e.stopPropagation();
        if (!confirm(`Delete "${s.name}"?`)) return;
        await API(`/api/skills/${encodeURIComponent(s.id)}`, { method: 'DELETE' });
        await refreshState();
      });
    }
    sections[s.category]?.appendChild(card);
  });

  // hide empty sections
  $$('.skills-section').forEach(sec => {
    const grid = sec.querySelector('.skills-grid');
    sec.classList.toggle('hidden', grid.children.length === 0);
  });

  // active note in top bar
  const active = (state.skills || []).filter(s => s.enabled);
  const note = $('skills-active-note');
  if (active.length > 0) {
    note.textContent = `${active.length} active`;
  } else {
    note.textContent = '';
  }
}

$('skill-search').addEventListener('input', (e) => {
  skillSearch = e.target.value;
  renderSkillsPage();
});
$$('.pill').forEach(p => {
  p.addEventListener('click', () => {
    $$('.pill').forEach(x => x.classList.remove('active'));
    p.classList.add('active');
    skillFilter = p.dataset.filter;
    renderSkillsPage();
  });
});

// =====================================================
// Modals
// =====================================================
function openNewProjectModal() {
  projectModal.classList.remove('hidden');
  $('np-name').focus();
}
$('new-project-btn').addEventListener('click', openNewProjectModal);
const allNewBtn = $('all-new-project-btn');
if (allNewBtn) allNewBtn.addEventListener('click', openNewProjectModal);
$('np-cancel').addEventListener('click', () => {
  projectModal.classList.add('hidden');
  $('np-name').value = ''; $('np-desc').value = '';
});
$('np-create').addEventListener('click', async () => {
  const name = $('np-name').value.trim();
  if (!name) return;
  try {
    await newProject(name, $('np-desc').value.trim());
    projectModal.classList.add('hidden');
    $('np-name').value = ''; $('np-desc').value = '';
  } catch (e) { alert(e.error || 'Failed to create project'); }
});
projectModal.addEventListener('click', (e) => {
  if (e.target === projectModal) projectModal.classList.add('hidden');
});

$('new-skill-btn').addEventListener('click', () => {
  skillModal.classList.remove('hidden');
  $('ns-name').focus();
});
$('ns-cancel').addEventListener('click', () => {
  skillModal.classList.add('hidden');
  ['ns-name','ns-icon','ns-desc','ns-prompt'].forEach(id => $(id).value = '');
});
$('ns-create').addEventListener('click', async () => {
  const name = $('ns-name').value.trim();
  const prompt = $('ns-prompt').value.trim();
  if (!name || !prompt) { alert('Name and instructions are required.'); return; }
  try {
    await API('/api/skills', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name,
        description: $('ns-desc').value.trim(),
        icon: $('ns-icon').value.trim() || '✨',
        prompt,
      }),
    });
    skillModal.classList.add('hidden');
    ['ns-name','ns-icon','ns-desc','ns-prompt'].forEach(id => $(id).value = '');
    await refreshState();
  } catch (e) { alert(e.error || 'Failed to create skill'); }
});
skillModal.addEventListener('click', (e) => {
  if (e.target === skillModal) skillModal.classList.add('hidden');
});

// =====================================================
// Composer
// =====================================================
function autosize() {
  input.style.height = 'auto';
  input.style.height = Math.min(input.scrollHeight, 220) + 'px';
}
input.addEventListener('input', autosize);
input.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    send();
  }
});
sendBtn.addEventListener('click', () => send());
voiceBtn.addEventListener('click', voiceTurn);
$('reset-btn').addEventListener('click', resetConversation);

// (welcome suggestions are wired dynamically in renderWelcome)

// project-view interactions
$('project-back').addEventListener('click', () => {
  switchView('chat');
});
$('chat-back-btn').addEventListener('click', () => {
  if (currentProjectPage) openProjectPage(currentProjectPage);
  else switchView('chat');
});
$('project-new-conv').addEventListener('click', startNewConversation);

$('project-send-btn').addEventListener('click', () => {
  const t = $('project-input').value.trim();
  if (!t) return;
  $('project-input').value = '';
  startConversationWith(t);
});
$('project-input').addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    $('project-send-btn').click();
  }
});
$('project-voice-btn').addEventListener('click', async () => {
  const btn = $('project-voice-btn');
  btn.classList.add('active');
  try {
    const r = await API('/api/voice/listen', { method: 'POST' });
    if (r.text) {
      $('project-input').value = r.text;
      $('project-send-btn').click();
    }
  } catch (e) { alert('Voice error: ' + (e.error || JSON.stringify(e))); }
  finally { btn.classList.remove('active'); }
});

// assignment modal
const asModal = $('assignment-modal-backdrop');
$('add-assignment-btn').addEventListener('click', () => {
  asModal.classList.remove('hidden'); $('as-title').focus();
});
$('as-cancel').addEventListener('click', () => {
  asModal.classList.add('hidden');
  ['as-title','as-due','as-notes'].forEach(id => $(id).value = '');
});
$('as-create').addEventListener('click', async () => {
  const title = $('as-title').value.trim();
  const due = $('as-due').value;
  if (!title || !due || !currentProjectPage) { alert('Title and due date required.'); return; }
  await API(`/api/projects/${encodeURIComponent(currentProjectPage)}/assignments`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ title, due, notes: $('as-notes').value.trim() }),
  });
  asModal.classList.add('hidden');
  ['as-title','as-due','as-notes'].forEach(id => $(id).value = '');
  openProjectPage(currentProjectPage); refreshState();
});
asModal.addEventListener('click', (e) => { if (e.target === asModal) asModal.classList.add('hidden'); });

// scheduled modal
const scModal = $('scheduled-modal-backdrop');
$('add-scheduled-btn').addEventListener('click', () => {
  scModal.classList.remove('hidden'); $('sc-title').focus();
});
$('sc-cancel').addEventListener('click', () => { scModal.classList.add('hidden'); $('sc-title').value = ''; });
$('sc-create').addEventListener('click', async () => {
  const title = $('sc-title').value.trim();
  if (!title || !currentProjectPage) { alert('Describe the task.'); return; }
  await API(`/api/projects/${encodeURIComponent(currentProjectPage)}/scheduled`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ title, cadence: $('sc-cadence').value }),
  });
  scModal.classList.add('hidden'); $('sc-title').value = '';
  openProjectPage(currentProjectPage);
});
scModal.addEventListener('click', (e) => { if (e.target === scModal) scModal.classList.add('hidden'); });

// instructions modal
const instrModal = $('instructions-modal-backdrop');
$('edit-instructions-btn').addEventListener('click', () => {
  $('instr-text').value = $('instructions-body').dataset.value || '';
  instrModal.classList.remove('hidden');
  $('instr-text').focus();
});
$('instr-cancel').addEventListener('click', () => instrModal.classList.add('hidden'));
$('instr-save').addEventListener('click', async () => {
  const text = $('instr-text').value;
  if (!currentProjectPage) return;
  await fetch(`/api/projects/${encodeURIComponent(currentProjectPage)}/instructions`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ instructions: text }),
  });
  instrModal.classList.add('hidden');
  await openProjectPage(currentProjectPage);  // refresh
});
instrModal.addEventListener('click', (e) => { if (e.target === instrModal) instrModal.classList.add('hidden'); });

// =====================================================
// ⌘K Command palette
// =====================================================
const palette = $('palette-backdrop');
const paletteInput = $('palette-input');
const paletteList = $('palette-list');
let paletteCmds = [];
let paletteSel = 0;

function buildPaletteCommands() {
  const c = [];
  c.push({ label: 'New Chat', hint: 'chat', run: newChat });
  c.push({ label: 'Go to Projects', hint: 'view', run: () => switchView('projects') });
  c.push({ label: 'Go to Skills', hint: 'view', run: () => switchView('skills') });
  c.push({ label: 'Back to Chat', hint: 'view', run: () => switchView('chat') });
  (state.all_projects || state.projects || []).forEach(p =>
    c.push({ label: `Open ${p.name}`, hint: 'project', run: () => useProject(p.name) }));
  models.forEach(m =>
    c.push({ label: `Model → ${m.name}`, hint: 'model', run: async () => {
      await API('/api/model', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ model: m.id }) });
      state.model = m.id; renderModel();
    }}));
  (state.skills || []).forEach(s =>
    c.push({ label: `${s.enabled ? 'Disable' : 'Enable'} skill: ${s.name}`, hint: 'skill', run: async () => {
      const r = await API(`/api/skills/${encodeURIComponent(s.id)}/toggle`, { method: 'POST' });
      const i = state.skills.findIndex(x => x.id === s.id); if (i >= 0) state.skills[i].enabled = r.enabled;
      renderSkillsPage(); renderSidebar();
    }}));
  c.push({ label: 'Open Settings', hint: 'view', run: () => switchView('settings') });
  c.push({ label: 'Toggle Appearance (Light / Dark)', hint: 'theme', run: () => themeToggle && themeToggle.click() });
  c.push({ label: 'Toggle Browser Automation', hint: 'browser', run: () => browserToggle.click() });
  c.push({ label: 'New Project', hint: 'create', run: openNewProjectModal });
  c.push({ label: 'Reset Conversation', hint: 'danger', run: resetConversation });
  if (state.hosted) c.push({ label: 'Sign Out', hint: 'account', run: async () => {
    await API('/api/auth/logout', { method: 'POST' }); location.reload();
  }});
  return c;
}

function renderPalette(filter = '') {
  const f = filter.toLowerCase();
  const items = paletteCmds.filter(c => c.label.toLowerCase().includes(f));
  paletteSel = Math.min(paletteSel, Math.max(0, items.length - 1));
  paletteList.innerHTML = '';
  if (!items.length) {
    paletteList.innerHTML = '<div class="palette-empty">No matching commands</div>';
    paletteList._items = [];
    return;
  }
  items.forEach((c, i) => {
    const el = document.createElement('div');
    el.className = 'palette-item' + (i === paletteSel ? ' sel' : '');
    el.innerHTML = `<span>${escape(c.label)}</span><span class="pi-hint">${escape(c.hint)}</span>`;
    el.addEventListener('click', () => { closePalette(); c.run(); });
    el.addEventListener('mousemove', () => { paletteSel = i; [...paletteList.children].forEach((x, j) => x.classList.toggle('sel', j === i)); });
    paletteList.appendChild(el);
  });
  paletteList._items = items;
}

function openPalette() {
  paletteCmds = buildPaletteCommands();
  paletteSel = 0;
  palette.classList.remove('hidden');
  paletteInput.value = '';
  renderPalette('');
  paletteInput.focus();
}
function closePalette() { palette.classList.add('hidden'); }

paletteInput.addEventListener('input', () => { paletteSel = 0; renderPalette(paletteInput.value); });
paletteInput.addEventListener('keydown', (e) => {
  const items = paletteList._items || [];
  if (e.key === 'ArrowDown') { e.preventDefault(); paletteSel = Math.min(paletteSel + 1, items.length - 1); renderPalette(paletteInput.value); }
  else if (e.key === 'ArrowUp') { e.preventDefault(); paletteSel = Math.max(paletteSel - 1, 0); renderPalette(paletteInput.value); }
  else if (e.key === 'Enter') { e.preventDefault(); if (items[paletteSel]) { closePalette(); items[paletteSel].run(); } }
  else if (e.key === 'Escape') { closePalette(); }
});
palette.addEventListener('click', (e) => { if (e.target === palette) closePalette(); });
document.addEventListener('keydown', (e) => {
  if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
    e.preventDefault();
    palette.classList.contains('hidden') ? openPalette() : closePalette();
  }
});

// =====================================================
// TASKS — school-platform assignments + automation
// =====================================================
let tasksState = { tasks: [], platform: null };

async function loadTasks() {
  // Cloud web users see desktop-exclusive pitch on Tasks too
  if (state.hosted && !state.automation) {
    renderDesktopExclusive('tasks');
    return;
  }
  try {
    tasksState = await API('/api/tasks');
  } catch (e) {
    if (e && e.auth) { showAuth(); return; }
    tasksState = { tasks: [], platform: null };
  }
  renderTasksView();
}

function renderTasksView() {
  const body = $('tasks-body');
  const label = $('tasks-platform-label');
  const sync = $('tasks-sync');
  const disc = $('tasks-disconnect');
  const navCount = $('nav-task-count');
  if (!body) return;

  const open = tasksState.tasks.filter(t => !t.done);
  if (navCount) {
    navCount.textContent = open.length;
    navCount.style.display = open.length ? '' : 'none';
  }

  if (tasksState.platform) {
    const p = tasksState.platform;
    label.textContent = `${p.platform_name} · ${p.mode === 'desktop' ? 'desktop' : p.mode === 'cloud' ? 'cloud' : 'manual'}`;
    sync.style.display = p.mode !== 'manual' ? '' : 'none';
    disc.style.display = '';
  } else {
    label.textContent = 'Not connected';
    sync.style.display = 'none';
    disc.style.display = 'none';
  }

  if (!tasksState.tasks.length) {
    if (!tasksState.platform) {
      // Beautiful CTA card redirecting to Connectors
      body.innerHTML = `
        <div class="tasks-cta-card">
          <div class="tasks-cta-orb"></div>
          <h3 class="tasks-cta-title">Connect a school platform to get started</h3>
          <p class="tasks-cta-sub">
            J@rv1s pulls every assignment from <strong>Google Classroom, Canvas, Schoology, PowerSchool</strong> &amp; more —
            so you stop checking six places a day.
          </p>
          <button class="tasks-cta-btn" id="empty-connect-cta">Go to Connectors  →</button>
        </div>`;
      const btn = $('empty-connect-cta');
      if (btn) btn.addEventListener('click', () => switchView('connectors'));
    } else {
      body.innerHTML = `
        <div class="tasks-empty">
          <div class="empty-icon">📋</div>
          <h3>No tasks yet — sync or add one</h3>
          <p>Pull assignments from ${escape(tasksState.platform.platform_name)} or add tasks manually.</p>
          <button class="primary-btn" id="empty-sync">↻ Sync now</button>
        </div>`;
      const es = $('empty-sync'); if (es) es.addEventListener('click', triggerSync);
    }
    return;
  }

  body.innerHTML = '<div class="task-grid" id="task-grid"></div>';
  const grid = $('task-grid');
  tasksState.tasks.forEach(t => grid.appendChild(renderTaskCard(t)));
}

function renderTaskCard(t) {
  const card = document.createElement('div');
  card.className = 'task-card' + (t.done ? ' done' : '');
  const dueCls = !t.due ? '' : (daysUntil(t.due) <= 1 ? 'urgent' : daysUntil(t.due) <= 3 ? 'soon' : '');
  const dueLabel = t.due ? `Due ${t.due}` : '';
  card.innerHTML = `
    <div class="task-head">
      ${t.subject ? `<span class="task-subject">${escape(t.subject)}</span>` : ''}
      ${dueLabel ? `<span class="task-due ${dueCls}">${escape(dueLabel)}</span>` : ''}
    </div>
    <div class="task-title">${escape(t.title)}</div>
    ${t.description ? `<div class="task-desc">${escape(t.description.slice(0, 180))}${t.description.length > 180 ? '…' : ''}</div>` : ''}
    <div class="task-actions">
      ${t.link ? `<a href="${escape(t.link)}" target="_blank" rel="noopener">Open ↗</a>` : ''}
      <button data-act="help">💬 Help me</button>
      <button class="do-it" data-act="run">⚡ Do it for me</button>
      <button data-act="toggle" class="task-done-check">${t.done ? '↺' : '✓'}</button>
      <button data-act="del" title="Delete">🗑</button>
    </div>`;
  card.querySelector('[data-act="help"]').addEventListener('click', () => helpWithTask(t));
  card.querySelector('[data-act="run"]').addEventListener('click', () => showRunTaskModal(t));
  card.querySelector('[data-act="toggle"]').addEventListener('click', async () => {
    await API(`/api/tasks/${t.id}`, {
      method: 'PUT', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ done: !t.done }),
    });
    loadTasks();
  });
  card.querySelector('[data-act="del"]').addEventListener('click', async () => {
    if (!confirm(`Delete "${t.title}"?`)) return;
    await API(`/api/tasks/${t.id}`, { method: 'DELETE' });
    loadTasks();
  });
  return card;
}

function daysUntil(yyyymmdd) {
  try {
    const d = new Date(yyyymmdd);
    return Math.ceil((d - new Date()) / 86400000);
  } catch { return 999; }
}

function helpWithTask(t) {
  const seed = `Help me with this assignment:\n\n**${t.title}**${t.subject ? ` (${t.subject})` : ''}${t.due ? `\nDue: ${t.due}` : ''}${t.description ? `\n\n${t.description}` : ''}${t.link ? `\n\nLink: ${t.link}` : ''}`;
  switchView('chat');
  setTimeout(() => { input.value = seed; autosize(); send(); }, 100);
}

async function triggerSync() {
  const r = await API('/api/tasks/sync', { method: 'POST' });
  if (r.action === 'open_desktop_app') {
    alert("Open the J@rv1s desktop app to run the sync locally. Your school session lives on your Mac.");
  } else if (r.queued) {
    alert("Cloud sync started — check back in a minute for new tasks.");
  } else if (r.message) {
    alert(r.message);
  }
  loadTasks();
}

$('tasks-sync') && $('tasks-sync').addEventListener('click', triggerSync);
$('tasks-disconnect') && $('tasks-disconnect').addEventListener('click', async () => {
  if (!confirm('Disconnect from your school platform? Your tasks stay.')) return;
  await API('/api/school/platform', { method: 'DELETE' });
  loadTasks();
});

// ── Add task modal ─────────────────────────────────────────────────────────
const taskModal = $('task-modal-backdrop');
$('tasks-add') && $('tasks-add').addEventListener('click', () => {
  taskModal.classList.remove('hidden');
  $('task-title').focus();
});
$('task-cancel') && $('task-cancel').addEventListener('click', closeAddTask);
function closeAddTask() {
  taskModal.classList.add('hidden');
  ['task-title','task-subject','task-due','task-link','task-desc'].forEach(id => $(id).value = '');
}
$('task-create') && $('task-create').addEventListener('click', async () => {
  const body = {
    title: $('task-title').value.trim(),
    subject: $('task-subject').value.trim(),
    due: $('task-due').value,
    link: $('task-link').value.trim(),
    description: $('task-desc').value.trim(),
  };
  if (!body.title) { alert('Title is required.'); return; }
  await API('/api/tasks', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  closeAddTask();
  loadTasks();
});
taskModal && taskModal.addEventListener('click', (e) => { if (e.target === taskModal) closeAddTask(); });

// ── "Do it for me" run modal ───────────────────────────────────────────────
const taskRunModal = $('task-run-backdrop');
let runningTask = null;
function showRunTaskModal(t) {
  runningTask = t;
  $('task-run-desc').textContent = `J@rv1s will handle: ${t.title}`;
  taskRunModal.classList.remove('hidden');
}
$('task-run-cancel') && $('task-run-cancel').addEventListener('click', () => taskRunModal.classList.add('hidden'));
taskRunModal && taskRunModal.querySelectorAll('[data-run]').forEach(btn => btn.addEventListener('click', async () => {
  const choice = btn.dataset.run;
  taskRunModal.classList.add('hidden');
  const r = await API(`/api/tasks/${runningTask.id}/run`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ choice }),
  });
  if (r.next === 'chat_with_seed') {
    helpWithTask(runningTask);
  }
}));
taskRunModal && taskRunModal.addEventListener('click', (e) => { if (e.target === taskRunModal) taskRunModal.classList.add('hidden'); });

// ── School onboarding modal ────────────────────────────────────────────────
const schoolModal = $('school-modal-backdrop');
let schoolDraft = { platform: null, platform_name: '', url: '', mode: null };

function showSchoolModal(step) {
  schoolModal.classList.remove('hidden');
  schoolStep(step);
}
function hideSchoolModal() {
  schoolModal.classList.add('hidden');
  schoolDraft = { platform: null, platform_name: '', url: '', mode: null };
}
function schoolStep(step) {
  schoolModal.querySelectorAll('.school-step').forEach(s => s.classList.add('hidden'));
  const target = schoolModal.querySelector(`[data-step="${step}"]`);
  if (target) target.classList.remove('hidden');
  const back = schoolModal.querySelector('[data-step-action="back"]');
  if (back) back.style.display = step === 1 ? 'none' : '';
  schoolModal.dataset.curStep = step;
  if (step === 2 && schoolDraft.platform_name) {
    $('step2-platform').textContent = `for ${schoolDraft.platform_name}.`;
  }
  if (step === '3-cloud' && schoolDraft.url) {
    $('school-url').value = schoolDraft.url;
  }
}

schoolModal && schoolModal.querySelectorAll('.platform-btn').forEach(btn =>
  btn.addEventListener('click', () => {
    schoolDraft.platform = btn.dataset.platform;
    schoolDraft.platform_name = btn.dataset.name;
    schoolDraft.url = btn.dataset.defaultUrl || '';
    schoolStep(2);
  }));

schoolModal && schoolModal.querySelectorAll('.mode-btn').forEach(btn =>
  btn.addEventListener('click', () => {
    schoolDraft.mode = btn.dataset.mode;
    schoolStep(btn.dataset.mode === 'desktop' ? '3-desktop' : '3-cloud');
  }));

schoolModal && schoolModal.querySelector('[data-step-action="save-desktop"]').addEventListener('click', async () => {
  await API('/api/school/platform', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ platform: schoolDraft.platform, mode: 'desktop', url: schoolDraft.url }),
  });
  hideSchoolModal();
  loadTasks();
});

schoolModal && schoolModal.querySelector('[data-step-action="save-cloud"]').addEventListener('click', async () => {
  const url = $('school-url').value.trim();
  const username = $('school-user').value.trim();
  const password = $('school-pass').value;
  if (!url || !username || !password) {
    alert('All three fields are required for cloud automation.');
    return;
  }
  await API('/api/school/platform', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ platform: schoolDraft.platform, mode: 'cloud', url, username, password }),
  });
  $('school-pass').value = '';
  hideSchoolModal();
  loadTasks();
  setTimeout(triggerSync, 400);
});

schoolModal && schoolModal.querySelector('[data-step-action="back"]').addEventListener('click', () => {
  const cur = schoolModal.dataset.curStep;
  if (cur === '2') schoolStep(1);
  else if (cur === '3-desktop' || cur === '3-cloud') schoolStep(2);
});
schoolModal && schoolModal.querySelector('[data-step-action="cancel"]').addEventListener('click', hideSchoolModal);
schoolModal && schoolModal.addEventListener('click', (e) => { if (e.target === schoolModal) hideSchoolModal(); });

input.focus();
boot();
