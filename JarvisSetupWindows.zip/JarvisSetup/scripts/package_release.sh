#!/bin/bash
# Package J@rv1s for distribution: produces two ZIPs (Mac + Windows) with the
# current source + launcher scripts, ready to upload to the
# Project-J-rv1s-download GitHub repo.
#
# Output:
#   ~/Desktop/jarvis-release/JarvisSetup-Mac.zip
#   ~/Desktop/jarvis-release/JarvisSetupWindows.zip
set -e

SRC="$HOME/jarvis"
OUT="$HOME/Desktop/jarvis-release"
STAGE="$(mktemp -d)/JarvisSetup"

echo "→ Staging fresh source from $SRC"
mkdir -p "$STAGE" "$OUT"

# Copy source, EXCLUDING things we never want to ship:
#   .venv        (user creates their own on first run)
#   data/        (user's local accounts/conversations)
#   .env         (secrets!)
#   .git, .DS_Store, __pycache__, *.pyc  (junk)
rsync -a \
  --exclude='.venv' \
  --exclude='data' \
  --exclude='.env' \
  --exclude='.env.*' \
  --exclude='.git' \
  --exclude='.DS_Store' \
  --exclude='__pycache__' \
  --exclude='*.pyc' \
  --exclude='.jarvis-test-profile' \
  --exclude='node_modules' \
  --exclude='*.zip' \
  "$SRC/" "$STAGE/"

# Quick README for new users.
cat > "$STAGE/README.txt" << 'README'
J@rv1s — your Personal Agent

MAC:
  Double-click "Launch J@rv1s.command".
  First run sets things up (Python venv + dependencies, ~1 min).
  Sign in or create an account when the window opens.

WINDOWS:
  Double-click "Launch J@rv1s.bat".
  First run sets things up (Python venv + dependencies, ~1 min).
  Requires Python 3 from python.org (with "Add to PATH" checked).

After installing, click the Connectors page to plug J@rv1s into your
school portal (Google Classroom, Canvas, etc.) and let it pull every
assignment for you. Tasks appear in the Tasks page.

— Krish Venkatraman & the Project J@rv1s Team
   support@projectjarvis.app
README

# Make sure the launcher is executable in the Mac archive
chmod +x "$STAGE/Launch J@rv1s.command" 2>/dev/null || true

echo "→ Zipping JarvisSetup-Mac.zip"
( cd "$(dirname "$STAGE")" && zip -qr "$OUT/JarvisSetup-Mac.zip" "$(basename "$STAGE")" \
    -x "*Launch J@rv1s.bat*" )

echo "→ Zipping JarvisSetupWindows.zip"
( cd "$(dirname "$STAGE")" && zip -qr "$OUT/JarvisSetupWindows.zip" "$(basename "$STAGE")" \
    -x "*Launch J@rv1s.command*" )

rm -rf "$(dirname "$STAGE")"

echo ""
echo "✓ Built fresh release zips:"
ls -lh "$OUT"
echo ""
echo "Next: upload these two files to the Project-J-rv1s-download GitHub repo"
echo "(replace the old JarvisSetup-Mac.zip + JarvisSetupWindows.zip files)."
