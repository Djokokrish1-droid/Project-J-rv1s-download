@echo off
REM ===  J@rv1s launcher for Windows  ===
REM Double-click this file to launch J@rv1s. First run sets things up (~1 min).
cd /d "%~dp0"

where python >nul 2>&1
if errorlevel 1 (
  echo Python 3 is required and was not found.
  echo Install it from https://www.python.org/downloads/  ^(check "Add to PATH"^),
  echo then double-click this file again.
  echo.
  pause
  exit /b
)

if not exist ".venv\Scripts\python.exe" (
  echo First-time setup, please wait...
  python -m venv .venv
  call ".venv\Scripts\activate.bat"
  python -m pip install --upgrade pip >nul
  python -m pip install -r requirements-desktop.txt
) else (
  call ".venv\Scripts\activate.bat"
)

echo Launching J@rv1s...
python main.py desktop
pause
